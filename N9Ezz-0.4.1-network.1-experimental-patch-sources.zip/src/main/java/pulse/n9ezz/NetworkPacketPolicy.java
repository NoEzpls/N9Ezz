package pulse.n9ezz;

import java.util.Set;

/** Network transport policy for the pinned Minecraft 1.21.11 client. */
public final class NetworkPacketPolicy {
    private NetworkPacketPolicy() { }

    // These messages carry authoritative state or mandatory protocol replies.
    // Keep their native order and delivery: a module's cancellable notification
    // must not swallow a teleport, impulse, inventory revision, ping or reply.
    // 1.21.11 has inventory revisions and ping/pong, not the old ConfirmTransaction.
    // Intermediary/named identities were checked against the Yarn commit recorded
    // in packet-mappings.json. No packet IDs from a different game version are used.
    private static final Set<String> REQUIRED = Set.of(
        // OpenScreenS2CPacket,
        "net.minecraft.class_3944", "net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket",
        // CloseScreenS2CPacket,
        "net.minecraft.class_2645", "net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket",
        // ScreenHandlerPropertyUpdateS2CPacket,
        "net.minecraft.class_2651", "net.minecraft.network.packet.s2c.play.ScreenHandlerPropertyUpdateS2CPacket",
        // ScreenHandlerSlotUpdateS2CPacket,
        "net.minecraft.class_2653", "net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket",
        // SetPlayerInventoryS2CPacket,
        "net.minecraft.class_9835", "net.minecraft.network.packet.s2c.play.SetPlayerInventoryS2CPacket",
        // SetCursorItemS2CPacket,
        "net.minecraft.class_9834", "net.minecraft.network.packet.s2c.play.SetCursorItemS2CPacket",
        // PlayerPositionLookS2CPacket,
        "net.minecraft.class_2708", "net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket",
        // EntityVelocityUpdateS2CPacket,
        "net.minecraft.class_2743", "net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket",
        // InventoryS2CPacket,
        "net.minecraft.class_2649", "net.minecraft.network.packet.s2c.play.InventoryS2CPacket",
        // CommonPingS2CPacket,
        "net.minecraft.class_6373", "net.minecraft.network.packet.s2c.common.CommonPingS2CPacket",
        // KeepAliveS2CPacket,
        "net.minecraft.class_2670", "net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket",
        // KeepAliveC2SPacket,
        "net.minecraft.class_2827", "net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket",
        // CommonPongC2SPacket,
        "net.minecraft.class_6374", "net.minecraft.network.packet.c2s.common.CommonPongC2SPacket",
        // TeleportConfirmC2SPacket,
        "net.minecraft.class_2793", "net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket",
        // PlayerActionResponseS2CPacket,
        "net.minecraft.class_4463", "net.minecraft.network.packet.s2c.play.PlayerActionResponseS2CPacket",
        // ExplosionS2CPacket,
        "net.minecraft.class_2664", "net.minecraft.network.packet.s2c.play.ExplosionS2CPacket"
    );

    public static boolean mayCancel(Object packet) {
        // Only the pinned protocol control messages override event cancellation.
        // Chat/visual notification filtering remains with its existing modules.
        return packet == null || !REQUIRED.contains(packet.getClass().getName());
    }
}
