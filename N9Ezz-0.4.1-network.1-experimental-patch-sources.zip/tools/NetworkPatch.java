import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LocalVariableNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.VarInsnNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.BasicVerifier;
import org.objectweb.asm.util.CheckClassAdapter;

/**
 * Offline, baseline-specific patcher. This intentionally does not load Minecraft,
 * module classes, or the supplied helper into this process. Run using Java 21 and
 * ASM 9.9.1 core/tree/analysis/util on the classpath:
 *   NetworkPatch input.jar helperClassesDirectory NEW-output.jar
 *
 * Only the three named integration classes and one new policy helper may change.
 * Payload bytes of every other archive entry, including modules, are preserved.
 */
public final class NetworkPatch implements Opcodes {
    private static final String BASELINE_SHA256 =
            "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424";
    private static final String ENTITY = "pulse/n9ezz/mixin/CombatEntityMixin";
    private static final String CONNECTION = "ru/pulse/mixin/ClientConnectionMixin";
    private static final String DISPATCH = "pulse/n9ezz/CombatDispatch";
    private static final String POLICY = "pulse/n9ezz/NetworkPacketPolicy";
    private static final String CALLBACK =
            "org/spongepowered/asm/mixin/injection/callback/CallbackInfo";
    private static final String DISPATCHED = "n9ezz$dispatched";
    private static final String DISPATCH_BODY = "n9ezz$dispatchAfterMovement";
    // Avoid January 1 midnight: the JDK treats that exact DOS value as its
    // pre-1980 sentinel and adds a timezone-dependent extended timestamp.
    private static final LocalDateTime ZIP_TIME = LocalDateTime.of(1980, 1, 2, 0, 0);

    private NetworkPatch() { }

    public static void main(String[] args) throws Exception {
        require(args.length == 3,
                "Usage: NetworkPatch input.jar helperClassesDirectory NEW-output.jar");
        Path input = Path.of(args[0]).toRealPath();
        Path helperDirectory = Path.of(args[1]).toRealPath();
        Path output = Path.of(args[2]).toAbsolutePath().normalize();
        require(Files.isDirectory(helperDirectory), "Helper path must be a directory");
        require(!Files.exists(output, LinkOption.NOFOLLOW_LINKS),
                "Output must be a new file: " + output);
        require(Files.isDirectory(output.getParent()), "Output parent must already exist");
        require(BASELINE_SHA256.equals(sha256(Files.readAllBytes(input))),
                "Unsupported input SHA-256; refusing to patch an unknown baseline");

        Map<String, byte[]> original = readArchive(input);
        require(!original.containsKey(POLICY + ".class"), "Policy helper already exists");
        Map<String, byte[]> result = new TreeMap<>(original);
        Map<String, byte[]> changes = new LinkedHashMap<>();
        changes.put(ENTITY + ".class", patchVelocity(requiredEntry(original, ENTITY)));
        changes.put(CONNECTION + ".class", patchConnection(requiredEntry(original, CONNECTION)));
        changes.put(DISPATCH + ".class", patchDispatch(requiredEntry(original, DISPATCH)));

        Path helperFile = helperDirectory.resolve(POLICY + ".class").toRealPath();
        require(helperFile.startsWith(helperDirectory), "Helper resolves outside its directory");
        byte[] helper = Files.readAllBytes(helperFile);
        ClassNode helperNode = readClass(helper, POLICY);
        require((helperNode.access & (ACC_PUBLIC | ACC_FINAL)) == (ACC_PUBLIC | ACC_FINAL),
                "Expected a public final policy helper");
        MethodNode mayCancel = method(helperNode, "mayCancel", "(Ljava/lang/Object;)Z");
        require((mayCancel.access & (ACC_PUBLIC | ACC_STATIC)) == (ACC_PUBLIC | ACC_STATIC),
                "Policy mayCancel(Object) must be public static");
        verify(helper);
        changes.put(POLICY + ".class", helper);
        result.putAll(changes);

        // Defensive scope assertion: all modules/resources retain their exact bytes.
        require(result.size() == original.size() + 1, "Unexpected archive entry count");
        for (Map.Entry<String, byte[]> entry : original.entrySet()) {
            if (!changes.containsKey(entry.getKey())) {
                require(Arrays.equals(entry.getValue(), result.get(entry.getKey())),
                        "Unintended change: " + entry.getKey());
            }
        }

        writeNewArchive(output, result);
        // Read back actual disk bytes rather than trusting only the writer's inputs.
        Map<String, byte[]> written = readArchive(output);
        require(written.keySet().equals(result.keySet()), "Written archive entry mismatch");
        for (String name : result.keySet()) {
            require(Arrays.equals(result.get(name), written.get(name)),
                    "Written archive payload mismatch: " + name);
        }
        printManifest(original, changes, sha256(Files.readAllBytes(output)));
    }

    private static byte[] patchVelocity(byte[] bytes) throws Exception {
        ClassNode node = readClass(bytes, ENTITY);
        MethodNode target = method(node, "n9ezzVelocity",
                "(Lnet/minecraft/class_243;)Lnet/minecraft/class_243;");
        require(target.access == ACC_PRIVATE, "Unexpected velocity hook access");
        require(target.visibleAnnotations != null && target.visibleAnnotations.stream().anyMatch(
                annotation -> annotation.desc.equals(
                        "Lorg/spongepowered/asm/mixin/injection/ModifyVariable;")),
                "Velocity injection annotation is missing");
        require(countCall(target, "pulse/n9ezz/u21", "scale",
                "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Lnet/minecraft/class_243;") == 1,
                "Unexpected velocity hook body");

        // Server velocity must reach vanilla unscaled. Keep the injection annotation,
        // method descriptor, and parameter metadata; only replace its executable body.
        // This user-authorized override intentionally removes the Velocity effect here.
        target.instructions.clear();
        target.tryCatchBlocks.clear();
        target.localVariables = new ArrayList<>();
        target.visibleLocalVariableAnnotations = null;
        target.invisibleLocalVariableAnnotations = null;
        LabelNode start = new LabelNode();
        LabelNode end = new LabelNode();
        target.instructions.add(start);
        target.instructions.add(new VarInsnNode(ALOAD, 1));
        target.instructions.add(new InsnNode(ARETURN));
        target.instructions.add(end);
        target.localVariables.add(new LocalVariableNode("this", "L" + ENTITY + ";",
                null, start, end, 0));
        target.localVariables.add(new LocalVariableNode("velocity", "Lnet/minecraft/class_243;",
                null, start, end, 1));
        target.maxStack = 1;
        target.maxLocals = 2;
        return writeAndVerify(bytes, node);
    }

    private static byte[] patchConnection(byte[] bytes) throws Exception {
        ClassNode node = readClass(bytes, CONNECTION);
        guardCancel(method(node, "onChannelRead",
                "(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/class_2596;L"
                        + CALLBACK + ";)V"), 2, 3);
        guardCancel(method(node, "onSendPacket", "(Lnet/minecraft/class_2596;L"
                + CALLBACK + ";)V"), 1, 2);
        return writeAndVerify(bytes, node);
    }

    private static void guardCancel(MethodNode target, int packetLocal, int callbackLocal) {
        require(target.access == ACC_PRIVATE, "Unexpected packet hook access");
        require(countCall(target, "meteordevelopment/orbit/EventBus", "post",
                "(Lmeteordevelopment/orbit/ICancellable;)Lmeteordevelopment/orbit/ICancellable;") == 1,
                "Expected one original event publication in " + target.name);
        require(countCall(target, CALLBACK, "cancel", "()V") == 1,
                "Expected one cancellation site in " + target.name);
        MethodInsnNode cancel = null;
        for (AbstractInsnNode instruction : target.instructions) {
            if (instruction instanceof MethodInsnNode call && call.owner.equals(CALLBACK)
                    && call.name.equals("cancel") && call.desc.equals("()V")) {
                cancel = call;
            }
        }
        require(cancel != null && cancel.getOpcode() == INVOKEVIRTUAL,
                "Unexpected callback invocation");
        AbstractInsnNode load = previousCode(cancel);
        require(load instanceof VarInsnNode variable && variable.getOpcode() == ALOAD
                && variable.var == callbackLocal, "Unexpected callback local");
        AbstractInsnNode branch = previousCode(load);
        require(branch instanceof JumpInsnNode jump && jump.getOpcode() == IFEQ,
                "Unexpected original cancellation branch");
        LabelNode skip = ((JumpInsnNode) branch).label;
        AbstractInsnNode eventCheck = previousCode(branch);
        require(eventCheck instanceof MethodInsnNode call
                && call.owner.equals("pulse/events/PacketEvent") && call.name.equals("c")
                && call.desc.equals("()Z"), "Unexpected event cancellation check");

        // All event observers still run at the original point. Cancellation alone is
        // gated, so mandatory inbound corrections and outbound acknowledgements keep
        // their original vanilla packet objects, order, and scheduling.
        // Reuse the existing empty-stack branch target and its original stack map.
        InsnList guard = new InsnList();
        guard.add(new VarInsnNode(ALOAD, packetLocal));
        guard.add(new MethodInsnNode(INVOKESTATIC, POLICY, "mayCancel",
                "(Ljava/lang/Object;)Z", false));
        guard.add(new JumpInsnNode(IFEQ, skip));
        target.instructions.insertBefore(load, guard);
    }

    private static byte[] patchDispatch(byte[] bytes) throws Exception {
        ClassNode node = readClass(bytes, DISPATCH);
        field(node, "f0", "J", ACC_PRIVATE | ACC_STATIC);
        field(node, "f4", "Z", ACC_PRIVATE | ACC_STATIC);
        require(node.fields.stream().noneMatch(f -> f.name.equals(DISPATCHED)),
                "Dispatch guard already exists");
        require(node.methods.stream().noneMatch(m -> m.name.equals(DISPATCH_BODY)),
                "Dispatch wrapper already exists");
        MethodNode begin = method(node, "begin", "(Lnet/minecraft/class_310;)V");
        MethodNode body = method(node, "afterMovement", "()V");
        require(begin.access == (ACC_PUBLIC | ACC_STATIC)
                && body.access == (ACC_PUBLIC | ACC_STATIC), "Unexpected dispatch method access");
        require(countField(begin, PUTSTATIC, DISPATCH, "f0", "J") == 1
                && countField(begin, PUTSTATIC, DISPATCH, "f4", "Z") == 1,
                "Unexpected tick initialization");
        require(countField(body, PUTSTATIC, DISPATCH, "f4", "Z") == 2
                && countCall(body, "pulse/n9ezz/e", "m8", "()V") == 1
                && countCall(body, "pulse/n9ezz/u28", "flush", "()V") == 1,
                "Unexpected post-movement dispatch body");
        require(body.visibleAnnotations == null && body.invisibleAnnotations == null
                && body.visibleTypeAnnotations == null && body.invisibleTypeAnnotations == null,
                "Unexpected dispatch annotations");

        node.fields.add(new FieldNode(ACC_PRIVATE | ACC_STATIC, DISPATCHED, "Z", null, null));
        InsnList reset = new InsnList();
        reset.add(new InsnNode(ICONST_0));
        reset.add(new FieldInsnNode(PUTSTATIC, DISPATCH, DISPATCHED, "Z"));
        // begin() is the existing START_CLIENT_TICK hook, not a wall-clock timer.
        // Reset only there: repeated movement callbacks cannot accelerate dispatch.
        begin.instructions.insert(reset);

        body.name = DISPATCH_BODY;
        body.access = ACC_PRIVATE | ACC_STATIC;
        MethodNode wrapper = new MethodNode(ASM9, ACC_PUBLIC | ACC_STATIC,
                "afterMovement", "()V", null, null);
        LabelNode done = new LabelNode();
        LabelNode tryStart = new LabelNode();
        LabelNode tryEnd = new LabelNode();
        LabelNode failure = new LabelNode();
        wrapper.instructions.add(new FieldInsnNode(GETSTATIC, DISPATCH, DISPATCHED, "Z"));
        wrapper.instructions.add(new JumpInsnNode(IFNE, done));
        // Mark before calling listeners: a reentrant callback must not send a second
        // batch. The original body and its module ordering remain untouched.
        wrapper.instructions.add(new InsnNode(ICONST_1));
        wrapper.instructions.add(new FieldInsnNode(PUTSTATIC, DISPATCH, DISPATCHED, "Z"));
        wrapper.instructions.add(tryStart);
        wrapper.instructions.add(new MethodInsnNode(INVOKESTATIC, DISPATCH, DISPATCH_BODY,
                "()V", false));
        wrapper.instructions.add(tryEnd);
        resetMovementSent(wrapper.instructions);
        wrapper.instructions.add(new JumpInsnNode(GOTO, done));
        wrapper.instructions.add(failure);
        wrapper.instructions.add(new FrameNode(F_SAME1, 0, null, 1,
                new Object[] {"java/lang/Throwable"}));
        wrapper.instructions.add(new VarInsnNode(ASTORE, 0));
        // Equivalent to finally { movementSent = false; }: exceptions must not let
        // later manual actions claim the post-movement window. Rethrow unchanged.
        resetMovementSent(wrapper.instructions);
        wrapper.instructions.add(new VarInsnNode(ALOAD, 0));
        wrapper.instructions.add(new InsnNode(ATHROW));
        wrapper.instructions.add(done);
        wrapper.instructions.add(new FrameNode(F_SAME, 0, null, 0, null));
        wrapper.instructions.add(new InsnNode(RETURN));
        wrapper.tryCatchBlocks.add(new TryCatchBlockNode(tryStart, tryEnd, failure, null));
        wrapper.maxStack = 1;
        wrapper.maxLocals = 1;
        node.methods.add(wrapper);
        return writeAndVerify(bytes, node);
    }

    private static void resetMovementSent(InsnList instructions) {
        instructions.add(new InsnNode(ICONST_0));
        instructions.add(new FieldInsnNode(PUTSTATIC, DISPATCH, "f4", "Z"));
    }

    private static ClassNode readClass(byte[] bytes, String expectedName) {
        ClassNode node = new ClassNode(ASM9);
        new ClassReader(bytes).accept(node, 0);
        require(node.name.equals(expectedName), "Unexpected class name: " + node.name);
        require(node.version == V21, "Expected Java 21 class: " + expectedName);
        return node;
    }

    private static byte[] writeAndVerify(byte[] original, ClassNode node) throws Exception {
        // Reuse the constant pool and existing frames. New control flow uses only
        // known empty-stack merge points; no guessed Minecraft type hierarchy is used.
        ClassWriter writer = new ClassWriter(new ClassReader(original), ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        byte[] bytes = writer.toByteArray();
        verify(bytes);
        return bytes;
    }

    private static void verify(byte[] bytes) throws Exception {
        new ClassReader(bytes).accept(new CheckClassAdapter(new ClassWriter(0), false), 0);
        ClassNode node = new ClassNode(ASM9);
        new ClassReader(bytes).accept(node, 0);
        for (MethodNode method : node.methods) {
            if ((method.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0) {
                // BasicVerifier checks stack/local types without loading game classes.
                // Runtime mixin integration still requires the Minecraft launch test.
                new Analyzer<>(new BasicVerifier()).analyze(node.name, method);
            }
        }
    }

    private static MethodNode method(ClassNode node, String name, String descriptor) {
        List<MethodNode> matches = node.methods.stream()
                .filter(m -> m.name.equals(name) && m.desc.equals(descriptor)).toList();
        require(matches.size() == 1, "Missing or duplicate method: " + node.name + "." + name);
        return matches.getFirst();
    }

    private static void field(ClassNode node, String name, String descriptor, int access) {
        List<FieldNode> matches = node.fields.stream()
                .filter(f -> f.name.equals(name) && f.desc.equals(descriptor)).toList();
        require(matches.size() == 1 && matches.getFirst().access == access,
                "Unexpected field: " + node.name + "." + name);
    }

    private static int countCall(MethodNode method, String owner, String name, String descriptor) {
        int count = 0;
        for (AbstractInsnNode instruction : method.instructions) {
            if (instruction instanceof MethodInsnNode call && call.owner.equals(owner)
                    && call.name.equals(name) && call.desc.equals(descriptor)) count++;
        }
        return count;
    }

    private static int countField(MethodNode method, int opcode, String owner, String name,
            String descriptor) {
        int count = 0;
        for (AbstractInsnNode instruction : method.instructions) {
            if (instruction instanceof FieldInsnNode field && field.getOpcode() == opcode
                    && field.owner.equals(owner) && field.name.equals(name)
                    && field.desc.equals(descriptor)) count++;
        }
        return count;
    }

    private static AbstractInsnNode previousCode(AbstractInsnNode instruction) {
        AbstractInsnNode previous = instruction.getPrevious();
        while (previous != null && previous.getOpcode() < 0) previous = previous.getPrevious();
        return previous;
    }

    private static byte[] requiredEntry(Map<String, byte[]> entries, String name) {
        byte[] bytes = entries.get(name + ".class");
        require(bytes != null, "Missing class entry: " + name);
        return bytes;
    }

    private static Map<String, byte[]> readArchive(Path input) throws IOException {
        Map<String, byte[]> result = new TreeMap<>();
        try (ZipFile archive = new ZipFile(input.toFile())) {
            var entries = archive.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = entry.getName();
                require(!name.startsWith("/") && !name.contains("\\")
                        && !Arrays.asList(name.split("/")).contains(".."),
                        "Unsafe archive entry: " + name);
                require(!result.containsKey(name), "Duplicate archive entry: " + name);
                String upper = name.toUpperCase(Locale.ROOT);
                require(!(upper.startsWith("META-INF/") && (upper.endsWith(".SF")
                        || upper.endsWith(".RSA") || upper.endsWith(".DSA")
                        || upper.endsWith(".EC") || upper.startsWith("META-INF/SIG-"))),
                        "Signed archives cannot be patched: " + name);
                try (var stream = archive.getInputStream(entry)) {
                    result.put(name, stream.readAllBytes());
                }
            }
        }
        byte[] manifestBytes = result.get("META-INF/MANIFEST.MF");
        if (manifestBytes != null) {
            Manifest manifest = new Manifest(new ByteArrayInputStream(manifestBytes));
            checkUnsignedAttributes(manifest.getMainAttributes());
            for (Attributes attributes : manifest.getEntries().values()) {
                checkUnsignedAttributes(attributes);
            }
        }
        return result;
    }

    private static void checkUnsignedAttributes(Attributes attributes) {
        for (Object key : attributes.keySet()) {
            String name = key.toString().toUpperCase(Locale.ROOT);
            require(!name.contains("-DIGEST") && !name.equals("SIGNATURE-VERSION"),
                    "Signed manifest attributes cannot be patched: " + key);
        }
    }

    private static void writeNewArchive(Path output, Map<String, byte[]> entries) throws IOException {
        // CREATE_NEW is atomic with respect to an existing target. Never overwrite a
        // user's JAR. STORED entries and fixed local timestamps make output reproducible
        // across machines/time zones without relying on a particular deflater version.
        boolean created = false;
        try {
            OutputStream file = Files.newOutputStream(output, StandardOpenOption.CREATE_NEW,
                    StandardOpenOption.WRITE);
            created = true;
            try (ZipOutputStream archive = new ZipOutputStream(file)) {
                for (Map.Entry<String, byte[]> payload : entries.entrySet()) {
                    byte[] bytes = payload.getValue();
                    CRC32 crc = new CRC32();
                    crc.update(bytes);
                    ZipEntry entry = new ZipEntry(payload.getKey());
                    entry.setMethod(ZipEntry.STORED);
                    entry.setTimeLocal(ZIP_TIME);
                    entry.setSize(bytes.length);
                    entry.setCompressedSize(bytes.length);
                    entry.setCrc(crc.getValue());
                    archive.putNextEntry(entry);
                    archive.write(bytes);
                    archive.closeEntry();
                }
            }
        } catch (IOException | RuntimeException failure) {
            if (created) {
                try { Files.deleteIfExists(output); }
                catch (IOException cleanupFailure) { failure.addSuppressed(cleanupFailure); }
            }
            throw failure;
        }
    }

    private static String sha256(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }

    private static void printManifest(Map<String, byte[]> original, Map<String, byte[]> changes,
            String outputHash) throws Exception {
        System.out.println("{");
        System.out.println("  \"baselineSha256\": \"" + BASELINE_SHA256 + "\",");
        System.out.println("  \"outputSha256\": \"" + outputHash + "\",");
        System.out.println("  \"unchangedEntries\": " + (original.size() - 3) + ",");
        System.out.println("  \"changedEntries\": [");
        int index = 0;
        for (Map.Entry<String, byte[]> entry : changes.entrySet()) {
            byte[] before = original.get(entry.getKey());
            System.out.print("    {\"entry\": \"" + entry.getKey() + "\", \"beforeSha256\": "
                    + (before == null ? "null" : "\"" + sha256(before) + "\"")
                    + ", \"afterSha256\": \"" + sha256(entry.getValue()) + "\"}");
            System.out.println(++index == changes.size() ? "" : ",");
        }
        System.out.println("  ]");
        System.out.println("}");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }
}
