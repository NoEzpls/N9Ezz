#!/usr/bin/env python3
"""Build and test an offline, narrowly scoped update of the verified 0.4.1 release.

The artifact branch has no complete Pulse sources. Keep its signed-off inputs
immutable and apply the reviewed Java bytecode transformation only after checking
their hashes. This is not a source-only rebuild of Pulse or a gameplay test.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
RELEASE = ROOT.parent
VERSION = "0.4.1-network.1-experimental"
BASE_JAR = "N9Ezz-Universal-Loader-0.4.1-experimental.jar"
BASE_SOURCES = "N9Ezz-Universal-Loader-0.4.1-experimental-sources.zip"
BASE_CLIENT_HASH = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424"
INPUTS = {
    BASE_JAR: "b81855307752b3d20df9bff66175914d2a118e7cce688c15e24b153952c60b3b",
    BASE_SOURCES: "b5451d33b11c389cadf1b8d85879a9f625faed60022f6cc9dae87ff9864dc960",
}
RECIPE_FILES = (
    ".gitignore", "README.md", "build.py", "setup-cloud.sh", "packet-mappings.json",
    "client-source.patch", "tools/NetworkPatch.java", "tests/NetworkPatchTest.java",
    "src/main/java/pulse/n9ezz/NetworkPacketPolicy.java",
    "source-reference/client/src/main/java/pulse/n9ezz/CombatDispatch.java",
    "source-reference/client/src/main/java/pulse/n9ezz/mixin/CombatEntityMixin.java",
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def replace_exact(path, old, new, count=1):
    content = path.read_text()
    if content.count(old) != count:
        raise RuntimeError(f"Unexpected source contract in {path.name}: {old}")
    path.write_text(content.replace(old, new))


def run(command, cwd, report=None):
    result = subprocess.run(list(map(str, command)), cwd=cwd,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if report:
        report.write_text(result.stdout)
    if result.returncode:
        print(result.stdout, end="")
        raise subprocess.CalledProcessError(result.returncode, command)
    print(result.stdout, end="")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise RuntimeError("Output directory must be absent or empty; existing builds are preserved")
    for name, digest in INPUTS.items():
        if sha((RELEASE / name).read_bytes()) != digest:
            raise RuntimeError("Release input checksum mismatch: " + name)
    # An explicit recipe prevents previous --output directories from being packed
    # recursively into subsequent builds. Snapshot the exact reviewed sources.
    recipe = {name: (ROOT / name).read_bytes() for name in RECIPE_FILES}
    run(["javac", "-version"], ROOT)
    output.mkdir(parents=True, exist_ok=True)
    scratch = ROOT / ".build"
    scratch.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="network-", dir=scratch) as temporary:
        work = Path(temporary)
        with zipfile.ZipFile(RELEASE / BASE_SOURCES) as archive:
            for name in archive.namelist():
                if not (work / name).resolve().is_relative_to(work):
                    raise RuntimeError("Unsafe source archive path: " + name)
            archive.extractall(work)
        loader = work / "universal-loader"
        deps = loader / ".cache/deps"
        deps.mkdir(parents=True)
        baseline_client = work / "baseline-client.jar"
        with zipfile.ZipFile(RELEASE / BASE_JAR) as archive:
            for dep in json.loads((loader / "deps-lock.json").read_text()):
                data = archive.read("META-INF/n9ezz/dependencies/" + dep["file"])
                if sha(data) != dep["sha256"]:
                    raise RuntimeError("Dependency checksum mismatch: " + dep["file"])
                (deps / dep["file"]).write_bytes(data)
            data = archive.read("embedded/n9ezz-client-1.5.3.jar")
            if sha(data) != BASE_CLIENT_HASH:
                raise RuntimeError("Baseline embedded client checksum mismatch")
            baseline_client.write_bytes(data)
        classpath = os.pathsep.join(str(p) for p in sorted(deps.glob("*.jar")))
        tools = work / "network-tools"
        helpers = work / "network-helpers"
        tools.mkdir()
        helpers.mkdir()
        run(["javac", "--release", "21", "-proc:none", "-encoding", "UTF-8", "-d", helpers,
             ROOT / "src/main/java/pulse/n9ezz/NetworkPacketPolicy.java"], work)
        run(["javac", "--release", "21", "-proc:none", "-encoding", "UTF-8", "-cp", classpath,
             "-d", tools, ROOT / "tools/NetworkPatch.java", ROOT / "tests/NetworkPatchTest.java"], work)
        patch_cp = str(tools) + os.pathsep + classpath
        client = work / "network-client.jar"
        run(["java", "-cp", patch_cp, "NetworkPatch", baseline_client, helpers, client], work,
            output / "patch-report.txt")
        run(["java", "-ea", "-cp", patch_cp, "NetworkPatchTest", baseline_client, client], work,
            output / "network-tests.txt")
        client_bytes = client.read_bytes()
        client_hash = sha(client_bytes)

        # A deliberate new release has a new content pin. All original-input and
        # runtime verification stays enabled; compile the contract for these exact
        # reviewed output bytes rather than disabling the original checks.
        contract = loader / "src/main/java/dev/n9ezz/loader/core/BundledClientContract.java"
        replace_exact(contract, BASE_CLIENT_HASH, client_hash)
        replace_exact(contract, "41_062_124L", str(len(client_bytes)) + "L")
        replace_exact(loader / "src/main/java/dev/n9ezz/loader/launch/Main.java",
                      "0.4.1-experimental", VERSION, count=2)
        installer_test = loader / "scripts/installer_smoke.py"
        replace_exact(installer_test, BASE_CLIENT_HASH, client_hash)
        replace_exact(installer_test, "41_062_124", str(len(client_bytes)))
        replace_exact(loader / "scripts/embedded_hitbox_qa.py", BASE_CLIENT_HASH, client_hash)

        # Reuse the release's packager, dependency lock, compiler and test sources.
        # Its input/source files in the checkout are never edited by this build.
        spec = importlib.util.spec_from_file_location("n9ezz_release_build", loader / "build.py")
        build = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(build)
        build.VERSION = VERSION
        build.CLIENT_SHA256 = client_hash
        build.DIST = output
        dep_paths = build.dependencies(offline=True)
        classes = build.BUILD / "classes"
        build.compile_sources(loader / "src/main/java", classes, dep_paths)
        build.copy_resources(loader / "src/main/resources", classes)
        demo_classes = build.BUILD / "demo-classes"
        build.compile_sources(loader / "src/demo/java", demo_classes, [classes, *dep_paths])
        demo_entries = {p.relative_to(demo_classes).as_posix(): p.read_bytes()
                        for p in demo_classes.rglob("*") if p.is_file()}
        demo_entries["n9ezz.mod.json"] = json.dumps({
            "schemaVersion": 1, "id": "n9ezz_smoke", "version": "1.0.0", "namespace": "none",
            "entrypoints": {"common": ["dev.n9ezz.examples.SmokeMod"]},
            "depends": {"java": ">=21", "n9ezz": ">=0.2.0"}}, sort_keys=True).encode()
        demo = build.BUILD / "native-smoke-mod.jar"
        build.write_zip(demo, demo_entries)
        jar = build.pack_jar(classes, dep_paths, demo, client_bytes, build.embedded_fabric_api())
        # Record the extra transform in the embedded provenance; the base and
        # original overlay checksums remain accurate, unchanged input identities.
        with zipfile.ZipFile(jar) as packaged:
            entries = {n: packaged.read(n) for n in packaged.namelist()}
        info = json.loads(entries["META-INF/n9ezz/embedded-client.json"])
        info["source"] = "Verified 0.4.1 client plus packet-update/tools/NetworkPatch.java"
        # BuiltinModSource intentionally accepts primitive manifest values only.
        info["networkPatchVersion"] = VERSION
        info["networkPatchInputSha256"] = BASE_CLIENT_HASH
        entries["META-INF/n9ezz/embedded-client.json"] = json.dumps(
            info, sort_keys=True, separators=(",", ":")).encode()
        if any((ROOT / name).read_bytes() != content for name, content in recipe.items()):
            raise RuntimeError("Update source changed during compilation; rerun with stable inputs")
        for name, content in recipe.items():
            entries["META-INF/n9ezz/network-update-sources/" + name] = content
        build.write_zip(jar, entries)

        tests = build.BUILD / "test-classes"
        build.compile_sources(loader / "src/test/java", tests, [classes, *dep_paths])
        build.copy_resources(loader / "src/test/resources", tests)
        test_cp = os.pathsep.join(map(str, [tests, jar]))
        for main_class, extra in [
            ("dev.n9ezz.loader.tests.RuntimeTests", []),
            ("dev.n9ezz.loader.tests.MixinIntegrationTests", []),
            ("dev.n9ezz.loader.core.ExternalModPolicyTests", []),
            ("dev.n9ezz.loader.core.BundledClientContractTests",
             [client, loader / "inputs/base-client-1.5.3.jar"]),
            ("dev.n9ezz.loader.resources.ResourcePackTests", [client]),
        ]:
            run(["java", "-ea", "-cp", test_cp, main_class, *extra], loader,
                output / (main_class.rsplit(".", 1)[1] + ".txt"))
        run(["java", "-jar", jar, "--self-test"], loader, output / "self-test.txt")
        run([sys.executable, installer_test, jar], loader, output / "installer-tests.txt")
        run([sys.executable, loader / "scripts/embedded_hitbox_qa.py", "--loader", jar,
             "--java", shutil.which("java"), "--output", work / "geometry-qa"], loader,
            output / "geometry-tests.txt")
        shutil.copyfile(work / "geometry-qa/result.json", output / "geometry-result.json")
        sources = output / ("N9Ezz-" + VERSION + "-patch-sources.zip")
        build.write_zip(sources, recipe)
        report = {"version": VERSION, "inputs": INPUTS, "clientSha256": client_hash,
                  "clientSize": len(client_bytes), "gameplay": "UNRUN",
                  "wireCapture": "UNRUN", "checks": "see current-run test reports",
                  "outputs": {p.name: sha(p.read_bytes()) for p in (jar, sources)}}
        (output / "build-report.json").write_text(json.dumps(report, indent=2) + "\n")
        (output / "SHA256SUMS").write_text("".join(
            digest + "  " + name + "\n" for name, digest in report["outputs"].items()))
        print("ARTIFACT", jar)


if __name__ == "__main__":
    main()
