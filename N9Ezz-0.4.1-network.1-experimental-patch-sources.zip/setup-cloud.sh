#!/usr/bin/env bash
set -euo pipefail

# This task already has an isolated checkout; do not create a Git worktree.
cd /workspace/N9Ezz
sha256sum -c SHA256SUMS

n9ezz_toolchains=/workspace/toolchains
n9ezz_jdk="$n9ezz_toolchains/jdk-21.0.8+9"
if [[ ! -x "$n9ezz_jdk/bin/javac" ]]; then
    mkdir -p "$n9ezz_toolchains"
    n9ezz_download=$(mktemp -d "$n9ezz_toolchains/download-XXXXXXXX")
    trap 'rm -rf -- "$n9ezz_download"' EXIT
    curl --fail --location --retry 2 \
        'https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.8%2B9/OpenJDK21U-jdk_x64_linux_hotspot_21.0.8_9.tar.gz' \
        --output "$n9ezz_download/jdk.tar.gz"
    python3 - "$n9ezz_download/jdk.tar.gz" "$n9ezz_toolchains" <<'PY'
import hashlib, pathlib, sys, tarfile
archive = pathlib.Path(sys.argv[1])
expected = 'f2dc5418092c43003db8f9005c4a286e1c0104fea96ccdd49e8ebd037cac9219'
if hashlib.sha256(archive.read_bytes()).hexdigest() != expected:
    raise SystemExit('Temurin 21 archive checksum mismatch')
with tarfile.open(archive) as source:
    source.extractall(sys.argv[2], filter='data')
PY
fi
export JAVA_HOME="$n9ezz_jdk"
export PATH="$JAVA_HOME/bin:$PATH"
java -version
javac -version

python3 - <<'PY'
from pathlib import Path
import hashlib, json, zipfile
repo = Path('/workspace/N9Ezz')
source = Path('/workspace/n9ezz-dev')
# Never overwrite an existing development tree or user edits.
if not source.exists():
    with zipfile.ZipFile(repo / 'N9Ezz-Universal-Loader-0.4.1-experimental-sources.zip') as archive:
        for name in archive.namelist():
            if not (source / name).resolve().is_relative_to(source):
                raise SystemExit('Unsafe source archive path')
        archive.extractall(source)
loader = source / 'universal-loader'
cache = loader / '.cache/deps'
cache.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(repo / 'N9Ezz-Universal-Loader-0.4.1-experimental.jar') as archive:
    for dependency in json.loads((loader / 'deps-lock.json').read_text()):
        data = archive.read('META-INF/n9ezz/dependencies/' + dependency['file'])
        if hashlib.sha256(data).hexdigest() != dependency['sha256']:
            raise SystemExit('Dependency checksum mismatch: ' + dependency['file'])
        destination = cache / dependency['file']
        if destination.exists() and destination.read_bytes() != data:
            raise SystemExit('Existing dependency differs; inspect before replacing: ' + str(destination))
        if not destination.exists():
            destination.write_bytes(data)
activation = Path('/workspace/toolchains/activate-temurin21.sh')
text = 'export JAVA_HOME=/workspace/toolchains/jdk-21.0.8+9\nexport PATH="$JAVA_HOME/bin:$PATH"\n'
if activation.exists() and activation.read_text() != text:
    raise SystemExit('Existing Java activation file differs; preserving it')
activation.write_text(text)
PY

# Compile and exercise the unchanged baseline using its original pinned inputs.
python3 /workspace/n9ezz-dev/universal-loader/build.py --offline
