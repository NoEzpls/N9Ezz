import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipFile;
import javax.tools.ToolProvider;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.BasicVerifier;
import org.objectweb.asm.util.CheckClassAdapter;
import org.objectweb.asm.util.Textifier;
import org.objectweb.asm.util.TraceMethodVisitor;

/**
 * Exercises the actual output class files against small, isolated dependency
 * stubs. This is a bytecode/transport contract test, not a game or server test.
 * Usage: NetworkPatchTest original-client.jar patched-client.jar
 */
public final class NetworkPatchTest implements Opcodes {
    private static final String CONNECTION = "ru/pulse/mixin/ClientConnectionMixin";
    private static final String ENTITY = "pulse/n9ezz/mixin/CombatEntityMixin";
    private static final String DISPATCH = "pulse/n9ezz/CombatDispatch";
    private static final String POLICY = "pulse/n9ezz/NetworkPacketPolicy";
    private static final Set<String> CHANGED = Set.of(CONNECTION + ".class", ENTITY + ".class", DISPATCH + ".class");
    // Independent expected protocol identities, pinned to Minecraft 1.21.11.
    private static final String[][] REQUIRED_PACKETS = {
        {"class_3944", "s2c.play.OpenScreenS2CPacket"},
        {"class_2645", "s2c.play.CloseScreenS2CPacket"},
        {"class_2651", "s2c.play.ScreenHandlerPropertyUpdateS2CPacket"},
        {"class_2653", "s2c.play.ScreenHandlerSlotUpdateS2CPacket"},
        {"class_9835", "s2c.play.SetPlayerInventoryS2CPacket"},
        {"class_9834", "s2c.play.SetCursorItemS2CPacket"},
        {"class_2708", "s2c.play.PlayerPositionLookS2CPacket"},
        {"class_2743", "s2c.play.EntityVelocityUpdateS2CPacket"},
        {"class_2649", "s2c.play.InventoryS2CPacket"},
        {"class_6373", "s2c.common.CommonPingS2CPacket"},
        {"class_2670", "s2c.common.KeepAliveS2CPacket"},
        {"class_2827", "c2s.common.KeepAliveC2SPacket"},
        {"class_6374", "c2s.common.CommonPongC2SPacket"},
        {"class_2793", "c2s.play.TeleportConfirmC2SPacket"},
        {"class_4463", "s2c.play.PlayerActionResponseS2CPacket"},
        {"class_2664", "s2c.play.ExplosionS2CPacket"}
    };
    private static int checks;

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("Expected original-client.jar patched-client.jar");
        Map<String, byte[]> original = readZip(Path.of(args[0]));
        Map<String, byte[]> patched = readZip(Path.of(args[1]));
        archiveContract(original, patched);
        bytecodeContract(original, patched);
        Path temporary = Files.createTempDirectory("n9ezz-network-contract-");
        try {
            Path classes = compileStubs(temporary);
            writeVelocityHarness(classes, patched.get(ENTITY + ".class"));
            // The platform parent prevents a host game's classes from leaking in.
            try (URLClassLoader loader = new URLClassLoader(new java.net.URL[] {
                    classes.toUri().toURL(), Path.of(args[1]).toUri().toURL()
            }, ClassLoader.getPlatformClassLoader())) {
                connectionContract(loader);
                velocityContract(loader);
                dispatchContract(loader);
            }
        } finally {
            try (var paths = Files.walk(temporary)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
        }
        System.out.println("PASS: " + checks + " archive, annotation, bytecode and isolated runtime assertions.");
        System.out.println("Scope: exact patched transport methods with dependency stubs; no live game/server integration claim.");
    }

    private static Map<String, byte[]> readZip(Path file) throws Exception {
        Map<String, byte[]> result = new HashMap<>();
        try (ZipFile zip = new ZipFile(file.toFile())) {
            var entries = zip.entries();
            while (entries.hasMoreElements()) {
                var entry = entries.nextElement();
                byte[] bytes = zip.getInputStream(entry).readAllBytes();
                check(result.put(entry.getName(), bytes) == null, "Duplicate ZIP entry " + entry.getName());
            }
        }
        return result;
    }

    private static void archiveContract(Map<String, byte[]> before, Map<String, byte[]> after) {
        Set<String> expected = new HashSet<>(before.keySet());
        expected.add(POLICY + ".class");
        check(after.keySet().equals(expected), "Output contains precisely the original entries and one policy class");
        for (String name : before.keySet()) {
            if (CHANGED.contains(name)) {
                check(!Arrays.equals(before.get(name), after.get(name)), "Expected transformed class " + name);
            } else {
                check(Arrays.equals(before.get(name), after.get(name)), "Unrelated resource/module changed: " + name);
            }
        }
        System.out.println("PASS: all unrelated module classes and archive entry contents preserved byte-for-byte.");
    }

    private static void bytecodeContract(Map<String, byte[]> before, Map<String, byte[]> after) throws Exception {
        for (String owner : List.of(CONNECTION, ENTITY, DISPATCH, POLICY)) {
            byte[] bytes = after.get(owner + ".class");
            new ClassReader(bytes).accept(new CheckClassAdapter(new ClassWriter(0), false), 0);
            ClassNode node = parse(bytes);
            for (MethodNode method : node.methods) {
                new Analyzer<>(new BasicVerifier()).analyze(node.name, method);
                checks++;
            }
            if (owner.equals(POLICY)) continue;
            ClassNode old = parse(before.get(owner + ".class"));
            check(annotations(old.visibleAnnotations).equals(annotations(node.visibleAnnotations)), owner + " class visible annotations");
            check(annotations(old.invisibleAnnotations).equals(annotations(node.invisibleAnnotations)), owner + " class invisible annotations");
            Set<String> changedMethods = owner.equals(CONNECTION) ? Set.of("onChannelRead", "onSendPacket")
                    : owner.equals(ENTITY) ? Set.of("n9ezzVelocity") : Set.of("begin", "afterMovement");
            for (MethodNode prior : old.methods) {
                MethodNode current = method(node, prior.name, prior.desc);
                check(prior.access == current.access, owner + "." + prior.name + " visibility/static contract");
                check(annotations(prior.visibleAnnotations).equals(annotations(current.visibleAnnotations)), owner + "." + prior.name + " visible annotations");
                check(annotations(prior.invisibleAnnotations).equals(annotations(current.invisibleAnnotations)), owner + "." + prior.name + " invisible annotations");
                if (!changedMethods.contains(prior.name)) {
                    check(methodText(prior).equals(methodText(current)), "Unrelated method changed: " + owner + "." + prior.name);
                }
            }
            if (owner.equals(DISPATCH)) {
                check(methodText(method(old, "afterMovement", "()V")).equals(
                        methodText(method(node, "n9ezz$dispatchAfterMovement", "()V"))),
                        "Original camera/player/world/vehicle guards and attack order preserved");
            }
        }
        System.out.println("PASS: modified bytecode verifies; mixin annotations and unrelated methods preserved.");
    }

    private static String annotations(List<AnnotationNode> annotations) {
        if (annotations == null) return "[]";
        StringBuilder result = new StringBuilder();
        for (AnnotationNode annotation : annotations) result.append(annotation.desc).append(annotationValue(annotation.values));
        return result.toString();
    }

    private static String annotationValue(Object value) {
        if (value instanceof AnnotationNode node) return node.desc + annotationValue(node.values);
        if (value instanceof List<?> list) return list.stream().map(NetworkPatchTest::annotationValue).toList().toString();
        if (value instanceof String[] strings) return Arrays.toString(strings);
        return String.valueOf(value);
    }

    private static String methodText(MethodNode method) {
        Textifier printer = new Textifier();
        method.accept(new TraceMethodVisitor(printer));
        StringWriter output = new StringWriter();
        printer.print(new PrintWriter(output));
        return output.toString();
    }

    private static ClassNode parse(byte[] bytes) {
        ClassNode result = new ClassNode();
        new ClassReader(bytes).accept(result, 0);
        return result;
    }

    private static MethodNode method(ClassNode node, String name, String descriptor) {
        return node.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(descriptor)).findFirst()
                .orElseThrow(() -> new AssertionError("Missing method " + node.name + "." + name + descriptor));
    }

    private static Path compileStubs(Path temporary) throws Exception {
        Map<String, String> sources = new HashMap<>();
        sources.put("net.minecraft.class_2596", "public interface class_2596<T> {}");
        sources.put("io.netty.channel.ChannelHandlerContext", "public interface ChannelHandlerContext {}");
        sources.put("org.spongepowered.asm.mixin.injection.callback.CallbackInfo", "public class CallbackInfo { public boolean cancelled; public void cancel() { cancelled=true; } }");
        sources.put("meteordevelopment.orbit.ICancellable", "public interface ICancellable {}");
        sources.put("pulse.events.PacketEvent", """
            public class PacketEvent implements meteordevelopment.orbit.ICancellable {
                public enum MessageDirection { RECIEVE, SEND }
                public final net.minecraft.class_2596<?> packet;
                public final MessageDirection direction;
                public boolean cancelled;
                public PacketEvent(net.minecraft.class_2596<?> p, MessageDirection d) { packet=p; direction=d; }
                public boolean c() { return cancelled; }
            }
            """);
        sources.put("meteordevelopment.orbit.EventBus", """
            public class EventBus {
                public boolean cancel;
                public int notifications;
                public pulse.events.PacketEvent last;
                public ICancellable post(ICancellable event) {
                    notifications++;
                    last=(pulse.events.PacketEvent)event;
                    last.cancelled=cancel;
                    return event;
                }
            }
            """);
        sources.put("pulse.events.EventBusService", "public class EventBusService { public static final meteordevelopment.orbit.EventBus EVENT_BUS=new meteordevelopment.orbit.EventBus(); }");
        sources.put("net.minecraft.class_1297", "public class class_1297 { public boolean vehicle; public boolean method_5765() { return vehicle; } }");
        sources.put("net.minecraft.class_1657", "public class class_1657 extends class_1297 {}");
        sources.put("net.minecraft.class_746", "public class class_746 extends class_1657 {}");
        sources.put("net.minecraft.class_1937", "public class class_1937 {}");
        sources.put("net.minecraft.class_638", "public class class_638 extends class_1937 {}");
        sources.put("net.minecraft.class_243", "public class class_243 { public final double x,y,z; public class_243(double x,double y,double z) { this.x=x; this.y=y; this.z=z; } }");
        sources.put("net.minecraft.class_241", "public class class_241 { public float field_1343,field_1342; public class_241(float x,float y) { field_1343=x; field_1342=y; } }");
        sources.put("net.minecraft.class_310", """
            public class class_310 {
                public static final class_310 INSTANCE=new class_310();
                public class_746 field_1724;
                public class_638 field_1687;
                public class_1297 camera;
                public static class_310 method_1551() { return INSTANCE; }
                public class_1297 method_1560() { return camera; }
            }
            """);
        sources.put("net.fabricmc.fabric.api.event.Event", "public class Event<T> { public void register(T callback) {} }");
        sources.put("net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents", """
            public class ClientTickEvents {
                public interface StartTick { void onStartTick(net.minecraft.class_310 client); }
                public static final net.fabricmc.fabric.api.event.Event<StartTick> START_CLIENT_TICK=new net.fabricmc.fabric.api.event.Event<>();
            }
            """);
        sources.put("pulse.n9ezz.e", """
            public class e {
                public static int clearCount, flushCount;
                public static Runnable hook;
                public static final java.util.List<String> order=new java.util.ArrayList<>();
                public static void m1() { clearCount++; }
                public static void m8() { flushCount++; order.add("attack"); if(hook!=null) hook.run(); }
                public static boolean m5() { return false; }
            }
            """);
        sources.put("pulse.n9ezz.u28", """
            public class u28 {
                public int flushCount;
                public Runnable hook;
                public void flush() { flushCount++; e.order.add("crystal"); if(hook!=null) hook.run(); }
            }
            """);
        sources.put("pulse.n9ezz.N9Ezz", "public class N9Ezz { public static u28 CRYSTAL; }");
        for (String[] packet : REQUIRED_PACKETS) {
            packetStub(sources, "net.minecraft." + packet[0]);
            packetStub(sources, "net.minecraft.network.packet." + packet[1]);
        }
        packetStub(sources, "net.minecraft.network.packet.s2c.play.GameMessageS2CPacket");
        packetStub(sources, "net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket");
        packetStub(sources, "fixture.UnrelatedPacket");
        Path classes = Files.createDirectories(temporary.resolve("classes"));
        List<String> arguments = new ArrayList<>(List.of("--release", "21", "-proc:none", "-classpath", classes.toString(), "-d", classes.toString()));
        for (var source : sources.entrySet()) {
            int split = source.getKey().lastIndexOf('.');
            Path file = temporary.resolve("sources/" + source.getKey().replace('.', '/') + ".java");
            Files.createDirectories(file.getParent());
            Files.writeString(file, "package " + source.getKey().substring(0, split) + ";\n" + source.getValue());
            arguments.add(file.toString());
        }
        var compiler = ToolProvider.getSystemJavaCompiler();
        check(compiler != null, "A full JDK is available");
        check(compiler.run(null, System.out, System.err, arguments.toArray(String[]::new)) == 0, "Dependency stubs compile");
        return classes;
    }

    private static void packetStub(Map<String, String> sources, String name) {
        sources.put(name, "public final class " + name.substring(name.lastIndexOf('.') + 1) + " implements net.minecraft.class_2596<Object> {}");
    }

    private static void writeVelocityHarness(Path classes, byte[] entityBytes) throws Exception {
        // Copy the actual output method, including its code and frames. Only its
        // access flag changes for invocation; there is no reimplementation here.
        MethodNode velocity = method(parse(entityBytes), "n9ezzVelocity", "(Lnet/minecraft/class_243;)Lnet/minecraft/class_243;");
        ClassWriter writer = new ClassWriter(0);
        writer.visit(V21, ACC_PUBLIC, "fixture/VelocityHarness", null, "java/lang/Object", null);
        MethodVisitor constructor = writer.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
        constructor.visitCode();
        constructor.visitVarInsn(ALOAD, 0);
        constructor.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        constructor.visitInsn(RETURN);
        constructor.visitMaxs(1, 1);
        constructor.visitEnd();
        velocity.access = ACC_PUBLIC;
        velocity.accept(writer);
        writer.visitEnd();
        Path output = classes.resolve("fixture/VelocityHarness.class");
        Files.createDirectories(output.getParent());
        Files.write(output, writer.toByteArray());
    }

    private static void connectionContract(ClassLoader loader) throws Exception {
        Class<?> connection = loader.loadClass(CONNECTION.replace('/', '.'));
        Object instance = connection.getConstructor().newInstance();
        Method send = namedMethod(connection, "onSendPacket");
        Method receive = namedMethod(connection, "onChannelRead");
        Class<?> callbackClass = loader.loadClass("org.spongepowered.asm.mixin.injection.callback.CallbackInfo");
        Object bus = get(loader.loadClass("pulse.events.EventBusService"), null, "EVENT_BUS");
        Class<?> busClass = bus.getClass();
        List<String> required = new ArrayList<>();
        for (String[] packet : REQUIRED_PACKETS) {
            required.add("net.minecraft." + packet[0]);
            required.add("net.minecraft.network.packet." + packet[1]);
        }
        List<String> unrelated = List.of("fixture.UnrelatedPacket", "net.minecraft.network.packet.s2c.play.GameMessageS2CPacket", "net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket");
        List<String> all = new ArrayList<>(required);
        all.addAll(unrelated);
        for (String name : all) {
            Object packet = loader.loadClass(name).getConstructor().newInstance();
            for (boolean cancelled : List.of(false, true)) {
                set(busClass, bus, "cancel", cancelled);
                for (Method hook : List.of(send, receive)) {
                    int before = (Integer)get(busClass, bus, "notifications");
                    Object callback = callbackClass.getConstructor().newInstance();
                    if (hook == send) invoke(hook, instance, packet, callback);
                    else invoke(hook, instance, null, packet, callback);
                    boolean expected = cancelled && unrelated.contains(name);
                    check(get(callbackClass, callback, "cancelled").equals(expected), name + " cancellation in " + hook.getName());
                    check((Integer)get(busClass, bus, "notifications") == before + 1, name + " observed exactly once");
                    Object event = get(busClass, bus, "last");
                    check(get(event.getClass(), event, "packet") == packet, name + " original packet object preserved");
                    check(get(event.getClass(), event, "direction").toString().equals(hook == send ? "SEND" : "RECIEVE"), name + " event direction preserved");
                }
            }
        }
        Method mayCancel = namedMethod(loader.loadClass(POLICY.replace('/', '.')), "mayCancel");
        check(Boolean.TRUE.equals(invoke(mayCancel, null, new Object[] {null})), "Null policy input is safe");
        System.out.println("PASS: 16 required packet types in both namespaces and directions retain delivery and observers; unrelated filters still cancel.");
    }

    private static void velocityContract(ClassLoader loader) throws Exception {
        Class<?> vectorClass = loader.loadClass("net.minecraft.class_243");
        Class<?> harness = loader.loadClass("fixture.VelocityHarness");
        Object instance = harness.getConstructor().newInstance();
        Method velocity = namedMethod(harness, "n9ezzVelocity");
        for (double[] coordinates : List.of(new double[] {0,0,0}, new double[] {2.5,-1.75,8.125}, new double[] {-12,3,-0.25})) {
            Object vector = vectorClass.getConstructor(double.class, double.class, double.class).newInstance(coordinates[0], coordinates[1], coordinates[2]);
            check(invoke(velocity, instance, vector) == vector, "Server velocity object returned unchanged, including nonzero vectors");
            check(get(vectorClass, vector, "x").equals(coordinates[0]) && get(vectorClass, vector, "y").equals(coordinates[1]) && get(vectorClass, vector, "z").equals(coordinates[2]), "All server velocity components preserved");
        }
        System.out.println("PASS: exact velocity hook preserves server vector identity and components.");
    }

    private static void dispatchContract(ClassLoader loader) throws Exception {
        DispatchFixture f = new DispatchFixture(loader);
        f.reset();
        long firstTick = (Long)invoke(f.tick, null);
        check(!f.claim(), "Cannot claim an attack before movement");
        set(f.attacks, null, "hook", (Runnable)() -> {
            check(f.claim(), "First post-movement claim succeeds");
            check(!f.claim(), "Second claim in the same callback fails");
            invoke(f.afterMovement, null);
        });
        invoke(f.afterMovement, null);
        invoke(f.afterMovement, null);
        check(f.attackCount() == 1 && f.crystalCount() == 1, "Duplicate and recursive callbacks dispatch once");
        check(get(f.attacks, null, "order").equals(List.of("attack", "crystal")), "Original attack then crystal order preserved");
        check(!f.claim(), "Claim window closes after callback");
        f.reset();
        check((Long)invoke(f.tick, null) == firstTick + 1, "Tick advances exactly once on begin");
        invoke(f.afterMovement, null);
        check(f.attackCount() == 1 && f.crystalCount() == 1, "A new tick permits a new callback");

        f.reset();
        Object other = loader.loadClass("net.minecraft.class_1657").getConstructor().newInstance();
        invoke(f.attacked, null, other);
        check(Boolean.TRUE.equals(invoke(f.available, null)), "Other players do not consume the local claim");
        invoke(f.attacked, null, get(f.clientClass, f.client, "field_1724"));
        check(Boolean.FALSE.equals(invoke(f.available, null)), "Manual local attack consumes the tick's claim");
        set(f.attacks, null, "hook", (Runnable)() -> check(!f.claim(), "Automatic claim respects manual attack"));
        invoke(f.afterMovement, null);

        for (boolean throwFromCrystal : List.of(false, true)) {
            f.reset();
            RuntimeException failure = new RuntimeException("expected fixture flush failure");
            Runnable throwing = () -> { throw failure; };
            if (throwFromCrystal) set(f.crystal.getClass(), f.crystal, "hook", throwing);
            else set(f.attacks, null, "hook", throwing);
            try {
                invoke(f.afterMovement, null);
                throw new AssertionError("Flush failure should propagate");
            } catch (RuntimeException actual) {
                check(actual == failure, "Original flush failure preserved");
            }
            check(Boolean.FALSE.equals(get(f.dispatch, null, "f4")), "Claim window cleared after a throwing flush");
            check(!f.claim(), "No claim leaks after a throwing flush");
            invoke(f.afterMovement, null);
            check(f.attackCount() == 1, "Failed callback is not replayed during the same tick");
            f.reset();
            invoke(f.afterMovement, null);
            check(f.attackCount() == 1 && f.crystalCount() == 1, "Next tick recovers after a flush failure");
        }

        for (String guard : List.of("player", "world", "null-player", "camera", "vehicle")) {
            f.reset();
            switch (guard) {
                case "player" -> set(f.clientClass, f.client, "field_1724", loader.loadClass("net.minecraft.class_746").getConstructor().newInstance());
                case "world" -> set(f.clientClass, f.client, "field_1687", loader.loadClass("net.minecraft.class_638").getConstructor().newInstance());
                case "null-player" -> set(f.clientClass, f.client, "field_1724", null);
                case "camera" -> set(f.clientClass, f.client, "camera", loader.loadClass("net.minecraft.class_1297").getConstructor().newInstance());
                case "vehicle" -> set(loader.loadClass("net.minecraft.class_1297"), get(f.clientClass, f.client, "field_1724"), "vehicle", true);
                default -> throw new AssertionError(guard);
            }
            invoke(f.afterMovement, null);
            check(f.attackCount() == 0 && f.crystalCount() == 0, guard + " guard suppresses dispatch");
            check((Integer)get(f.attacks, null, "clearCount") == 2, guard + " guard clears pending attack");
            check(!f.claim(), guard + " guard leaves no claim window");
        }
        f.reset();
        set(f.root, null, "CRYSTAL", null);
        invoke(f.afterMovement, null);
        check(f.attackCount() == 1, "Absent crystal module remains supported");
        System.out.println("PASS: per-tick and recursive dispatch limits, manual claims, original guards, order and exception cleanup.");
    }

    private static final class DispatchFixture {
        final ClassLoader loader;
        final Class<?> dispatch, attacks, root, clientClass;
        final Object client;
        final Method begin, tick, claim, available, attacked, afterMovement;
        Object crystal;
        DispatchFixture(ClassLoader loader) throws Exception {
            this.loader=loader;
            dispatch=loader.loadClass(DISPATCH.replace('/', '.'));
            attacks=loader.loadClass("pulse.n9ezz.e");
            root=loader.loadClass("pulse.n9ezz.N9Ezz");
            clientClass=loader.loadClass("net.minecraft.class_310");
            client=get(clientClass, null, "INSTANCE");
            begin=namedMethod(dispatch,"begin"); tick=namedMethod(dispatch,"tick");
            claim=namedMethod(dispatch,"claim"); available=namedMethod(dispatch,"available");
            attacked=namedMethod(dispatch,"attacked"); afterMovement=namedMethod(dispatch,"afterMovement");
        }
        void reset() throws Exception {
            Object player=loader.loadClass("net.minecraft.class_746").getConstructor().newInstance();
            Object world=loader.loadClass("net.minecraft.class_638").getConstructor().newInstance();
            set(clientClass,client,"field_1724",player);
            set(clientClass,client,"field_1687",world);
            set(clientClass,client,"camera",player);
            set(attacks,null,"clearCount",0); set(attacks,null,"flushCount",0); set(attacks,null,"hook",null);
            ((List<?>)get(attacks,null,"order")).clear();
            crystal=loader.loadClass("pulse.n9ezz.u28").getConstructor().newInstance();
            set(root,null,"CRYSTAL",crystal);
            invoke(begin,null,client);
        }
        boolean claim() { return Boolean.TRUE.equals(invoke(claim,null)); }
        int attackCount() { return (Integer)get(attacks,null,"flushCount"); }
        int crystalCount() { return (Integer)get(crystal.getClass(),crystal,"flushCount"); }
    }

    private static Method namedMethod(Class<?> owner, String name) {
        Method result=Arrays.stream(owner.getDeclaredMethods()).filter(m -> m.getName().equals(name)).findFirst().orElseThrow();
        result.setAccessible(true);
        return result;
    }

    private static Object invoke(Method method, Object instance, Object... arguments) {
        try { return method.invoke(instance,arguments); }
        catch (InvocationTargetException exception) {
            if (exception.getCause() instanceof RuntimeException runtime) throw runtime;
            if (exception.getCause() instanceof Error error) throw error;
            throw new AssertionError(exception.getCause());
        } catch (ReflectiveOperationException exception) { throw new AssertionError(exception); }
    }

    private static Object get(Class<?> owner,Object instance,String name) {
        try { var field=owner.getDeclaredField(name); field.setAccessible(true); return field.get(instance); }
        catch (ReflectiveOperationException exception) { throw new AssertionError(exception); }
    }

    private static void set(Class<?> owner,Object instance,String name,Object value) {
        try { var field=owner.getDeclaredField(name); field.setAccessible(true); field.set(instance,value); }
        catch (ReflectiveOperationException exception) { throw new AssertionError(exception); }
    }

    private static void check(boolean condition,String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
}
