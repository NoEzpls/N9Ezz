package pulse.n9ezz.mixin;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.n9ezz.N9Ezz;
@Mixin(Entity.class)
public abstract class CombatEntityMixin {
    @Unique private Vec3d n9ezzPushBefore;
    @Inject(method="pushAwayFrom",at=@At("HEAD"),cancellable=true)
    private void n9ezzPush(Entity other,CallbackInfo ci){
        n9ezzPushBefore=null;var p=MinecraftClient.getInstance().player;
        if(p!=null&&N9Ezz.NOPUSH!=null&&N9Ezz.NOPUSH.isEnabled()&&((Object)this==p||other==p)){
            double strength=N9Ezz.NOPUSH.strength();
            if(strength>=1)ci.cancel();else if(strength>0)n9ezzPushBefore=p.getVelocity();
        }
    }
    @Inject(method="pushAwayFrom",at=@At("RETURN"))
    private void n9ezzPartialPush(Entity other,CallbackInfo ci){
        var before=n9ezzPushBefore;n9ezzPushBefore=null;var p=MinecraftClient.getInstance().player;
        if(before!=null&&p!=null&&N9Ezz.NOPUSH!=null&&N9Ezz.NOPUSH.isEnabled())
            p.setVelocity(before.add(p.getVelocity().subtract(before).multiply(1-Math.min(1,N9Ezz.NOPUSH.strength()))));
    }
    @ModifyVariable(method="setVelocityClient",at=@At("HEAD"),argsOnly=true)
    private Vec3d n9ezzVelocity(Vec3d velocity) {
        // Apply the complete server impulse. Scaling it here changes the next
        // movement state even though the packet itself reached vanilla.
        // The user explicitly chose server authority over the Velocity effect.
        return velocity;
    }
    @ModifyVariable(method="slowMovement",at=@At("HEAD"),argsOnly=true)
    private Vec3d n9ezzWeb(Vec3d value,BlockState block,Vec3d movement){var p=MinecraftClient.getInstance().player;return p==(Object)this&&block.isOf(Blocks.COBWEB)&&N9Ezz.ANTIWEB!=null&&N9Ezz.ANTIWEB.isEnabled()?N9Ezz.ANTIWEB.multiplier(value):value;}
}
