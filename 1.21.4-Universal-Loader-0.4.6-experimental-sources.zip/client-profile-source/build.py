#!/usr/bin/env python3
"""Offline, pinned build of the N9Ezz / original Pulse menu update and custom loader.

This rebuilds the supplied loader sources and applies reviewed ASM edits to the
supplied binary client. It does not claim to reconstruct unavailable Pulse source.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
VERSION = "0.4.6-experimental"
BASELINE_SHA = "5dbb9f72359d8371b7069dbf4f421c358c28a8c11af23e06c9182ec793aada6a"
LOADER_SHA = "b81855307752b3d20df9bff66175914d2a118e7cce688c15e24b153952c60b3b"
SOURCES_SHA = "b5451d33b11c389cadf1b8d85879a9f625faed60022f6cc9dae87ff9864dc960"
OLD_CLIENT_SHA = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424"
MINECRAFT_SHA = "25810669cc30ab540f997f2af3fd3a4dae006f2275343951d874b19e8ed35d9f"
RELEASE_044_CLIENT_SHA = "289bc41b5878b087d2800e1bac973c137e30245ec96a99ab88f87b2fd4e67bd0"
CLIENT_RESOURCE = "embedded/client-profile-1.5.3.jar"
PRESERVED = (
    "ru/pulse/mixin/ClientConnectionMixin.class",
    "pulse/n9ezz/mixin/CombatEntityMixin.class",
    "pulse/n9ezz/CombatDispatch.class",
    "pulse/n9ezz/NetworkPacketPolicy.class",
)
STAMP = (1980, 1, 2, 0, 0, 0)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pinned(path: Path, expected: str) -> bytes:
    data = path.read_bytes()
    if sha(data) != expected:
        raise RuntimeError(f"Pinned input checksum mismatch: {path}")
    return data


def safe_entries(path: Path) -> dict[str, bytes]:
    result = {}
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = info.filename
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts or "\\" in name:
                raise RuntimeError(f"Unsafe ZIP entry: {name}")
            if info.is_dir():
                continue
            if name in result or (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise RuntimeError(f"Duplicate or symlink ZIP entry: {name}")
            result[name] = archive.read(info)
    return result


def write_zip(path: Path, entries: dict[str, bytes]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compresslevel=9)


def replace_exact(path: Path, old: str, new: str, count: int = 1) -> None:
    text = path.read_text(encoding="utf-8")
    actual = text.count(old)
    if actual != count:
        raise RuntimeError(f"Unexpected source layout in {path}: expected {count}, found {actual}")
    path.write_text(text.replace(old, new), encoding="utf-8")


def code_snapshot() -> dict[str, bytes]:
    result = {}
    for folder in ("src", "tools", "tests", "docs", "loader-overlay"):
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file() and path.suffix in (".java", ".py", ".md", ".json", ".txt"):
                result[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    result["build.py"] = Path(__file__).read_bytes()
    result["loader_brand.py"] = (ROOT / "loader_brand.py").read_bytes()
    for name in ("README.md", "CHANGELOG.md", "README-RU.md", "CHANGELOG-RU.md", "LICENSE"):
        path = ROOT / name
        if path.is_file():
            result[name] = path.read_bytes()
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=Path("/workspace/n9ezz-build-review/client.jar"))
    parser.add_argument("--minecraft", type=Path, default=Path("/workspace/n9ezz-build-review/minecraft.jar"), help="Pinned Minecraft 1.21.11 intermediary compile API; not packaged")
    parser.add_argument("--original-loader", type=Path,
                        default=Path("/workspace/N9Ezz/N9Ezz-Universal-Loader-0.4.1-experimental.jar"))
    parser.add_argument("--original-sources", type=Path,
                        default=Path("/workspace/N9Ezz/N9Ezz-Universal-Loader-0.4.1-experimental-sources.zip"))
    parser.add_argument("--java-home", type=Path, default=Path(os.environ.get("JAVA_HOME", "/workspace/toolchains/jdk-21.0.8+9")))
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    parser.add_argument("--offline", action="store_true", help="Accepted for clarity; all builds are offline.")
    parser.add_argument("--skip-tests", action="store_true", help="Development-only; outputs are marked UNVERIFIED.")
    args = parser.parse_args()
    for key in ("baseline", "minecraft", "original_loader", "original_sources", "java_home", "output"):
        setattr(args, key, getattr(args, key).resolve())
    if args.output.exists() and any(args.output.iterdir()):
        raise RuntimeError("Output directory must be empty; choose a fresh --output directory: " + str(args.output))
    java = args.java_home / "bin/java"
    javac = args.java_home / "bin/javac"
    if not java.is_file() or not javac.is_file():
        raise RuntimeError("A complete JDK 21 is required; use --java-home.")
    env = os.environ.copy()
    env["JAVA_HOME"] = str(args.java_home)
    env["PATH"] = str(args.java_home / "bin") + os.pathsep + env.get("PATH", "")
    version = subprocess.run([str(java), "-version"], capture_output=True, text=True, check=True, env=env).stderr
    if 'version "21.' not in version and 'version "21"' not in version:
        raise RuntimeError("This build requires JDK 21: " + version.splitlines()[0])
    os.environ.update({"JAVA_HOME": env["JAVA_HOME"], "PATH": env["PATH"]})
    pinned(args.baseline, BASELINE_SHA)
    pinned(args.minecraft, MINECRAFT_SHA)
    pinned(args.original_loader, LOADER_SHA)
    pinned(args.original_sources, SOURCES_SHA)
    own = code_snapshot()
    original_sources = safe_entries(args.original_sources)
    build_root = ROOT / "build"
    build_root.mkdir(exist_ok=True)
    # A new staging directory prevents failed rebuilds from reusing old classes.
    stage = Path(tempfile.mkdtemp(prefix="pulsevisuals-", dir=build_root))
    reports = stage / "reports"
    reports.mkdir()
    report = {
        "version": VERSION, "status": "UNVERIFIED" if args.skip_tests else "IN_PROGRESS",
        "jdk": version.splitlines()[0], "tests": [],
        "inputs": {"networkClientSha256": BASELINE_SHA, "minecraftCompileApiSha256": MINECRAFT_SHA, "originalLoaderSha256": LOADER_SHA,
                   "originalSourcesSha256": SOURCES_SHA},
        "realMinecraftLaunch": "UNRUN", "RaidMineServerSession": "UNRUN",
        "networkPacketCapture": "UNRUN", "anticheatBypass": "NOT_CLAIMED",
        "gameVersion": "1.21.11", "registryCount": 90, "artifactLabel": "1.21.4",
        "sourceScope": "Loader source and new ASM patches; original Pulse engine full source is unavailable.",
    }

    def run(label: str, command: list[str | Path], cwd: Path = stage, test: bool = False) -> None:
        command = [str(item) for item in command]
        result = subprocess.run(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (reports / (label + ".txt")).write_text(result.stdout, encoding="utf-8")
        print(f"[{label}] exit={result.returncode}", flush=True)
        if test:
            report["tests"].append({"name": label, "result": "PASS" if result.returncode == 0 else "FAIL",
                                    "report": label + ".txt"})
        if result.returncode:
            print(result.stdout, file=sys.stderr)
            raise subprocess.CalledProcessError(result.returncode, command)

    def compile_java(label: str, source: Path, target: Path, cp: list[Path]) -> None:
        files = sorted(source.rglob("*.java"))
        if not files:
            raise RuntimeError(f"No source files for {label}: {source}")
        target.mkdir(parents=True)
        run(label, [javac, "--release", "21", "-proc:none", "-encoding", "UTF-8", "-Xlint:all",
                    "-cp", os.pathsep.join(map(str, cp)), "-d", target, *files])

    try:
        source_root = stage / "original"
        for name, data in original_sources.items():
            path = source_root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        own_root = stage / "update"
        for name, data in own.items():
            path = own_root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        loader_root = source_root / "universal-loader"
        deps_root = loader_root / ".cache/deps"
        deps_root.mkdir(parents=True)
        with zipfile.ZipFile(args.original_loader) as loader:
            for dep in json.loads((loader_root / "deps-lock.json").read_text()):
                data = loader.read("META-INF/n9ezz/dependencies/" + dep["file"])
                if sha(data) != dep["sha256"]:
                    raise RuntimeError("Dependency checksum mismatch: " + dep["file"])
                (deps_root / dep["file"]).write_bytes(data)
        spec = importlib.util.spec_from_file_location("original_loader_build", loader_root / "build.py")
        upstream = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(upstream)
        deps = upstream.dependencies(True)
        helpers = stage / "helper-classes"
        patch_classes = stage / "patch-classes"
        compile_java("compile-helpers", own_root / "src/main/java", helpers, [args.baseline, args.minecraft, *deps])
        compile_java("compile-patches", own_root / "tools", patch_classes, [helpers, *deps])
        client = stage / "client.jar"
        patch_cp = os.pathsep.join(map(str, [patch_classes, helpers, *deps]))
        run("apply-client-patches", [java, "-cp", patch_cp, "SixPatch", args.baseline, helpers, client])
        with zipfile.ZipFile(args.baseline) as before, zipfile.ZipFile(client) as after:
            for name in PRESERVED:
                if before.read(name) != after.read(name):
                    raise RuntimeError("Mandatory network/physics class changed: " + name)
            # These exact legacy render bridges are the only allowed namespace exceptions.
            for name in ("net/minecraft/client/gl/ShaderProgramKeys.class", "net/minecraft/client/render/BufferRenderer.class"):
                if before.read(name) != after.read(name):
                    raise RuntimeError("Pinned legacy render bridge changed: " + name)
        report["preservedNetworkClasses"] = list(PRESERVED)
        client_data = client.read_bytes()
        client_sha = sha(client_data)
        if client_sha == RELEASE_044_CLIENT_SHA:
            raise RuntimeError("Targeting update unexpectedly reproduced the unchanged 0.4.4 client.")
        report["clientSha256"] = client_sha
        report["clientIdenticalTo044"] = False
        report["clientSize"] = len(client_data)
        if not args.skip_tests:
            own_tests = stage / "update-test-classes"
            compile_java("compile-update-tests", own_root / "tests", own_tests, [helpers, patch_classes, *deps])
            test_cp = os.pathsep.join(map(str, [own_tests, helpers, patch_classes, *deps]))
            run("RewriteTest", [java, "-Xverify:all", "-cp", test_cp, "RewriteTest", args.baseline, client, own_root / "tests/fixtures"], test=True)
            for test_main in ("CombatTest", "ModuleTest", "FeatureTest", "BrandTest", "NetworkTest", "Aura046Test", "Targeting046Test", "Speed046Test"):
                run(test_main, [java, "-Xverify:all", "-cp", test_cp, test_main, args.baseline, client], test=True)
        brand_spec=importlib.util.spec_from_file_location("loader_brand", own_root / "loader_brand.py")
        brand=importlib.util.module_from_spec(brand_spec); brand_spec.loader.exec_module(brand)
        brand.apply(loader_root, own_root / "loader-overlay")
        replace_exact(loader_root / "src/main/java/dev/n9ezz/loader/core/BundledClientContract.java", OLD_CLIENT_SHA, client_sha)
        replace_exact(loader_root / "src/main/java/dev/n9ezz/loader/core/BundledClientContract.java", "41_062_124L", str(len(client_data)) + "L")
        replace_exact(loader_root / "src/main/java/dev/n9ezz/loader/launch/Main.java", "0.4.1-experimental", VERSION, 2)
        replace_exact(loader_root / "src/main/java/dev/n9ezz/loader/core/DependencyResolver.java", '"n9ezz", "0.4.1"', '"n9ezz", "0.4.6"', 2)
        replace_exact(loader_root / "scripts/installer_smoke.py", OLD_CLIENT_SHA, client_sha)
        replace_exact(loader_root / "scripts/installer_smoke.py", "41_062_124", str(len(client_data)))
        # The registry restores 83 original Pulse modules and keeps seven N9Ezz modules.
        # The original 113 also included removed legacy N9Ezz modules.
        replace_exact(loader_root / "scripts/gameplay_smoke.py", 'state.get("registryCount") == "113"',
                      'state.get("registryCount") == "90"')
        replace_exact(loader_root / "scripts/test_gameplay_acceptance.py", "registryCount=113", "registryCount=90", 2)
        replace_exact(loader_root / "scripts/test_gameplay_acceptance.py", "registryCount=83", "registryCount=5")
        upstream.VERSION = VERSION
        upstream.CLIENT_RESOURCE = CLIENT_RESOURCE
        upstream.CLIENT_SHA256 = client_sha
        upstream.DIST = stage / "packaged"
        upstream.DIST.mkdir()
        upstream.STAMP = STAMP
        # Preserve historical base/overlay provenance, then describe the actual new input.
        original_write_zip = upstream.write_zip
        def package_zip(path, entries):
            if "META-INF/MANIFEST.MF" in entries:
                entries["META-INF/MANIFEST.MF"] = entries["META-INF/MANIFEST.MF"].replace(b"Implementation-Title: N9Ezz", b"Implementation-Title: Client Profile Loader")
            if "META-INF/n9ezz/embedded-client.json" in entries:
                metadata = json.loads(entries["META-INF/n9ezz/embedded-client.json"])
                metadata.update({"source": "Pinned network.1 client with independently implemented N9Ezz targeting and menu update",
                                 "networkInputSha256": BASELINE_SHA, "updateVersion": VERSION,
                                 "updateMethod": "ASM patches; no repeat base/overlay merge"})
                entries["META-INF/n9ezz/embedded-client.json"] = json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode()
            original_write_zip(path, entries)
        upstream.write_zip = package_zip
        classes = upstream.BUILD / "classes"
        run("compile-loader", [javac, "--release", "21", "-proc:none", "-encoding", "UTF-8", "-Xlint:all",
                               "-cp", os.pathsep.join(map(str, deps)), "-d", classes,
                               *sorted((loader_root / "src/main/java").rglob("*.java"))])
        upstream.copy_resources(loader_root / "src/main/resources", classes)
        demo_classes = upstream.BUILD / "demo-classes"
        compile_java("compile-demo", loader_root / "src/demo/java", demo_classes, [classes, *deps])
        demo_entries = {p.relative_to(demo_classes).as_posix(): p.read_bytes() for p in demo_classes.rglob("*") if p.is_file()}
        demo_entries["n9ezz.mod.json"] = json.dumps({
            "schemaVersion": 1, "id": "n9ezz_smoke", "version": "1.0.0", "namespace": "none",
            "entrypoints": {"common": ["dev.n9ezz.examples.SmokeMod"]},
            "depends": {"java": ">=21", "n9ezz": ">=0.2.0"}}, sort_keys=True).encode()
        demo = upstream.BUILD / "native-smoke-mod.jar"
        write_zip(demo, demo_entries)
        jar = upstream.pack_jar(classes, deps, demo, client_data, upstream.embedded_fabric_api())
        named = jar.with_name(f"1.21.4-Universal-Loader-{VERSION}.jar"); jar.rename(named); jar = named
        if not args.skip_tests:
            tests = upstream.BUILD / "test-classes"
            compile_java("compile-loader-tests", loader_root / "src/test/java", tests, [classes, *deps])
            upstream.copy_resources(loader_root / "src/test/resources", tests)
            fabric = loader_root / "inputs" / upstream.FABRIC_API_FILE
            base = loader_root / "inputs/base-client-1.5.3.jar"
            suites = (
                ("runtime", "dev.n9ezz.loader.tests.RuntimeTests", []),
                ("mapping", "dev.n9ezz.loader.mapping.MappingTests", []),
                ("access-widener", "dev.n9ezz.loader.mapping.AccessWidenerTests", []),
                ("nested-discovery", "dev.n9ezz.loader.tests.NestedDiscoveryTests", []),
                ("mixin", "dev.n9ezz.loader.tests.MixinIntegrationTests", []),
                ("fabric-compatibility", "dev.n9ezz.loader.tests.FabricCompatibilityTests", [fabric]),
                ("fabric-entrypoint", "dev.n9ezz.loader.compat.FabricEntrypointTests", [fabric]),
                ("fabric-dependency", "dev.n9ezz.loader.tests.FabricDependencyTests", [client, fabric]),
                ("game-integration", "dev.n9ezz.loader.core.GameIntegrationTests", []),
                ("external-mod-policy", "dev.n9ezz.loader.core.ExternalModPolicyTests", []),
                ("universal-game-policy", "dev.n9ezz.loader.core.UniversalGamePolicyTests", []),
                ("quilt-game", "dev.n9ezz.loader.quilt.QuiltCompatibilityTests", []),
                ("fml-game", "dev.n9ezz.loader.fml.FmlCompatibilityTests", []),
                ("local-diagnostics", "dev.n9ezz.loader.tests.LocalDiagnosticsTests", []),
                ("client-contract", "dev.n9ezz.loader.core.BundledClientContractTests", [client, base]),
                ("resource-pack", "dev.n9ezz.loader.resources.ResourcePackTests", [client]),
            )
            for label, test_main, extra in suites:
                cp = [tests, jar] if label == "mixin" else [tests, classes, *deps]
                run(label, [java, "-cp", os.pathsep.join(map(str, cp)), test_main, *extra], cwd=loader_root, test=True)
            run("packaged-self-test", [java, "-jar", jar, "--self-test"], cwd=loader_root, test=True)
            run("installer", [sys.executable, loader_root / "scripts/installer_smoke.py", jar], cwd=loader_root, test=True)
            run("installer-migration", [sys.executable, own_root / "tests/installer_migration.py", jar], cwd=loader_root, test=True)
            for script in ("test_gameplay_acceptance.py", "test_cross_platform_acceptance.py"):
                run(script[:-3], [sys.executable, loader_root / "scripts" / script], cwd=loader_root, test=True)
        # A build can use stable snapshots; never silently publish after sources changed.
        if code_snapshot() != own:
            raise RuntimeError("Update sources/docs changed during the build; rerun to produce matching artifacts.")
        source_entries = {"client-profile-source/" + name: data for name, data in own.items()}
        for name, data in original_sources.items():
            if name.endswith((".jar", ".zip")) and not name.startswith("universal-loader/third-party-sources/"):
                continue
            source_entries["upstream-source/" + name] = data
        source_entries["client-profile-source/INPUTS.json"] = json.dumps(report["inputs"], indent=2).encode() + b"\n"
        sources = stage / f"1.21.4-Universal-Loader-{VERSION}-sources.zip"
        write_zip(sources, source_entries)
        report["status"] = "UNVERIFIED" if args.skip_tests else "PASS"
        report["artifacts"] = {p.name: {"sha256": sha(p.read_bytes()), "size": p.stat().st_size} for p in (jar, sources)}
        (reports / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
        test_archive = stage / f"1.21.4-Universal-Loader-{VERSION}-test-reports.zip"
        write_zip(test_archive, {p.name: p.read_bytes() for p in sorted(reports.iterdir()) if p.is_file()})
        artifacts = [jar, sources, test_archive]
        args.output.mkdir(parents=True, exist_ok=True)
        if any(args.output.iterdir()):
            raise RuntimeError("Output directory changed during build; preserving existing files: " + str(args.output))
        for artifact in artifacts:
            destination = args.output / artifact.name
            with destination.open("xb") as output:
                output.write(artifact.read_bytes())
        with (args.output / "verification.json").open("xb") as output:
            output.write((reports / "verification.json").read_bytes())
        with (args.output / "SHA256SUMS").open("x") as output:
            output.write("".join(f"{sha(p.read_bytes())}  {p.name}\n" for p in artifacts))
        print("ARTIFACTS", args.output)
    except Exception:
        report["status"] = "FAIL"
        (reports / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
        print("Failed build diagnostics:", reports, file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
