package dev.n9ezz.loader.launch;

import dev.n9ezz.loader.core.LocalDiagnostics;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.nio.file.Path;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

/** A single installer/profile flow. No platform selectors or hidden engines. */
final class InstallerWindow {
    private InstallerWindow() { }

    static void open() {
        SwingUtilities.invokeLater(() -> {
            JFrame window = new JFrame("Client profile Installer " + Main.VERSION);
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            window.setLayout(new BorderLayout(12, 12));
            JLabel summary = new JLabel("<html><b>Экспериментальное общее ядро · Minecraft 1.21.11 · Java 21</b><br>"
                    + "Встроенный клиент PulseVisuals · Один профиль для запуска</html>");
            window.add(summary, BorderLayout.NORTH);
            JPanel panel = new JPanel(new BorderLayout(8, 8));
            JTextField path = new JTextField(defaultMinecraftHome().toString());
            JButton browse = new JButton("Папка Minecraft");
            browse.addActionListener(event -> {
                JFileChooser chooser = new JFileChooser(path.getText());
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (chooser.showOpenDialog(window) == JFileChooser.APPROVE_OPTION) path.setText(chooser.getSelectedFile().getAbsolutePath());
            });
            panel.add(path, BorderLayout.CENTER);
            panel.add(browse, BorderLayout.EAST);
            JTextArea log = new JTextArea("Сначала установите vanilla 1.21.11 через ваш лаунчер.\n"
                    + "Будет создан один отдельный профиль и каталог profiles/client-1.21.11; старые профили сохраняются.\n"
                    + "Можно добавлять только моды, разработанные специально для PulseVisuals. Моды других загрузчиков не принимаются.\n"
                    + "Клиент PulseVisuals устанавливается автоматически. Сборка экспериментальная; проверенные версии и ограничения указаны в отчёте.\n");
            log.setEditable(false);
            log.setLineWrap(true);
            log.setWrapStyleWord(true);
            JPanel content = new JPanel(new BorderLayout(8, 8));
            content.add(panel, BorderLayout.NORTH);
            content.add(new JScrollPane(log), BorderLayout.CENTER);
            window.add(content, BorderLayout.CENTER);
            JButton install = new JButton("Установить Client profile (1.21.11)");
            install.addActionListener(event -> {
                install.setEnabled(false);
                new SwingWorker<Map<String, Object>, Void>() {
                    @Override protected Map<String, Object> doInBackground() throws Exception {
                        return InstallService.install(Path.of(path.getText()), Main.ownJar());
                    }
                    @Override protected void done() {
                        try {
                            Map<String, Object> result = get();
                            log.append("\nПрофиль и встроенный клиент установлены.\n"
                                    + "Выберите профиль «" + result.get("profileName")
                                    + "» в вашем лаунчере и нажмите «Играть».\n");
                        } catch (Exception error) {
                            log.append("\nУстановка не завершена: " + LocalDiagnostics.throwableText(error) + "\n");
                        } finally {
                            install.setEnabled(true);
                        }
                    }
                }.execute();
            });
            window.add(install, BorderLayout.SOUTH);
            window.setPreferredSize(new Dimension(800, 380));
            window.pack();
            window.setLocationRelativeTo(null);
            window.setVisible(true);
        });
    }

    private static Path defaultMinecraftHome() {
        String operatingSystem = System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT);
        if (operatingSystem.contains("win")) {
            String appData = System.getenv("APPDATA");
            if (appData != null) return Path.of(appData, ".minecraft");
        }
        Path user = Path.of(System.getProperty("user.home"));
        if (operatingSystem.contains("mac")) return user.resolve("Library/Application Support/minecraft");
        return user.resolve(".minecraft");
    }
}
