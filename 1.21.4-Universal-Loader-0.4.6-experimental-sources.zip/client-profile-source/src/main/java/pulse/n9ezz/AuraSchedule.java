package pulse.n9ezz;

import java.util.concurrent.ThreadLocalRandom;

/** Keeps tempo across target changes. Optional jitter delays the next action, never protocol replies. */
public final class AuraSchedule {
    private long lastAttempt;
    private boolean attempted;
    private long extraDelay;
    public void reset() { attempted = false; extraDelay = 0; }
    public boolean ready(long now, int cps) {
        if (!attempted) return true;
        long elapsed = now - lastAttempt;
        return elapsed >= 0 && elapsed >= 1_000_000_000L / Math.max(1, Math.min(20, cps)) + extraDelay;
    }
    public void attempted(long now, int jitterMilliseconds) {
        int bounded = Math.max(0, Math.min(100, jitterMilliseconds));
        attempted(now, bounded == 0 ? 0 : ThreadLocalRandom.current().nextLong(bounded * 1_000_000L + 1));
    }
    /** Explicit sampled delay makes boundary tests deterministic without replacing runtime randomness. */
    public void attempted(long now, long sampledDelayNanos) {
        lastAttempt = now; attempted = true; extraDelay = Math.max(0, Math.min(100_000_000L, sampledDelayNanos));
    }
    public long extraDelayNanos() { return extraDelay; }
}
