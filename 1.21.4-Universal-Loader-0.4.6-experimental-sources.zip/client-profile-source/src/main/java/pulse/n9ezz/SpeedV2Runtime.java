package pulse.n9ezz;

import net.minecraft.class_1657;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_746;

/** Client movement only. The server remains authoritative and can reject any boost. */
public final class SpeedV2Runtime {
    private static final SpeedV2.State STATE = new SpeedV2.State();
    private static final SpeedV2.ViewFrame VIEW = new SpeedV2.ViewFrame();
    private static int lastTick = Integer.MIN_VALUE;
    private static class_1657 pursuit;
    private static String mode = "свободное движение";
    private SpeedV2Runtime() {}
    public static void enable() { STATE.enable(); lastTick = Integer.MIN_VALUE; pursuit = null; VIEW.clear(); }
    public static void disable() { STATE.disable(); lastTick = Integer.MIN_VALUE; pursuit = null; VIEW.clear(); }
    public static void resume() { enable(); }
    public static String reason() { return STATE.reason(); }
    public static String diagnostics() { return STATE.diagnostics() + "; режим: " + mode; }
    /** Called by automatic aim controllers, never for ordinary mouse input. */
    public static void viewTurn(float beforeYaw, float afterYaw) {
        var mc = class_310.method_1551();
        if (N9Ezz.STRAFE == null || !N9Ezz.STRAFE.isEnabled() || InterfaceMode.hidden()
                || mc.field_1724 == null || mc.field_1687 == null) return;
        // Config activation can bypass onEnable. Arm before recording the first
        // turn so input() does not subsequently erase that same-tick compensation.
        if (!STATE.armed()) enable();
        if (!STATE.ready(mc.field_1687, mc.field_1724, mc.field_1724.field_6012)) return;
        VIEW.turned(beforeYaw, afterYaw, mc.field_1724.field_6012);
    }
    public static class_1657 target() { return pursuit; }
    public static void correction() { STATE.correction(); pursuit = null; VIEW.clear(); }
    public static void disconnect() { STATE.disconnect(); pursuit = null; VIEW.clear(); }
    public static void velocity(class_2743 packet) {
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && packet.method_11818() == player.method_5628()) {
            STATE.velocity(player.field_6012); pursuit = null; VIEW.clear();
        }
    }
    public static class_241 input(class_241 input, double power, boolean pursue, double range, double radius) {
        // Binary compatibility for older entrypoints and externally saved adapters.
        return input(input, power, pursue, range, radius, false);
    }
    public static class_241 input(class_241 input, double power, boolean pursue, double range, double radius, boolean freeMovement) {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (N9Ezz.STRAFE == null || !N9Ezz.STRAFE.isEnabled() || InterfaceMode.hidden()) { disable(); return input; }
        if (!STATE.armed()) enable(); // Quiet config activation still gets a fresh session once.
        if (!STATE.ready(mc.field_1687, player, player == null ? 0 : player.field_6012)) { pursuit = null; VIEW.clear(); return input; }
        if (input == null || mc.field_1755 != null || mc.method_1493() || player.method_6128()
            || player.method_5765() || player.method_6101() || player.method_5799() || player.method_5771()
            || player.method_31549().field_7479 || player.field_5976 || !d.m3(false)) { pursuit = null; VIEW.clear(); return input; }
        boolean applyVelocity = lastTick != player.field_6012;
        lastTick = player.field_6012;
        class_243 velocity = player.method_18798();
        if (!Double.isFinite(velocity.field_1351)) return input;
        double visibleYaw = player.method_36454();
        if (!Double.isFinite(visibleYaw) || !Float.isFinite(input.field_1343) || !Float.isFinite(input.field_1342)) { VIEW.clear(); return input; }
        boolean moving = Math.hypot(input.field_1343, input.field_1342) >= 1e-8;
        double referenceYaw;
        if (freeMovement) referenceYaw = VIEW.inputYaw(visibleYaw, moving, player.field_6012);
        else { VIEW.clear(); referenceYaw = visibleYaw; }
        mode = freeMovement ? "свободное движение" : "движение / преследование";
        double yaw = Math.toRadians(visibleYaw), movementYaw = Math.toRadians(referenceYaw);
        double x = input.field_1343 * Math.cos(movementYaw) - input.field_1342 * Math.sin(movementYaw);
        double z = input.field_1342 * Math.cos(movementYaw) + input.field_1343 * Math.sin(movementYaw);
        double limit = 5;
        // Free movement must win over both the module's pursue toggle and the
        // shared preset. A target selection alone must never take away WASD.
        boolean joint = !freeMovement && CombatSession.juggernaut();
        pursuit = joint ? CombatSession.target() : (!freeMovement && pursue ? lowest(range) : null);
        if (joint && pursuit == null) return input; // Do not chase an unrelated entity when the shared target disappears.
        if (pursuit != null) {
            class_243 from = player.method_73189(), to = pursuit.method_73189();
            x = to.field_1352 - from.field_1352; z = to.field_1350 - from.field_1350;
            double length = Math.hypot(x, z);
            limit = Math.max(0, length - Math.max(1, Math.min(5, radius)));
            if (length > 1e-8) { x /= length; z /= length; }
        }
        if (!Double.isFinite(x) || !Double.isFinite(z)) return input;
        // Base horizontal speed is derived from the player's movement-speed attribute,
        // never from the already boosted velocity. Potion/sprint attributes remain proportional.
        double base = 0.21585 * player.method_6029() / 0.1;
        SpeedV2.Horizontal desired = SpeedV2.desired(x, z, base, power, limit);
        if (Math.hypot(x, z) < 1e-8 && pursuit == null) return input;
        // Preserve vertical motion exactly; no jumps, fake OnGround, teleports, or packet bursts.
        if (applyVelocity) player.method_18799(new class_243(desired.x(), velocity.field_1351, desired.z()));
        if (pursuit == null && !freeMovement) return input;
        if (limit <= 0) return new class_241(0, 0);
        // Vanilla still applies movement input after this callback. Rotate that
        // input into the visible view frame too, otherwise its acceleration would
        // steer back toward Aura's camera despite the corrected velocity above.
        return new class_241((float) (x * Math.cos(yaw) + z * Math.sin(yaw)),
                            (float) (z * Math.cos(yaw) - x * Math.sin(yaw)));
    }
    private static class_1657 lowest(double range) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null || !Double.isFinite(range)) return null;
        range = Math.max(3, Math.min(32, range));
        class_1657 best = null; double bestHealth = Double.POSITIVE_INFINITY, bestDistance = Double.POSITIVE_INFINITY; int bestId = Integer.MAX_VALUE;
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (!d.m21(player, true, true) || !d.m20(player, false)) continue;
            double distance = d.m14(player), health = player.method_6032() + player.method_6067();
            int id = player.method_5628();
            if (distance <= range && SpeedV2.prefer(health, distance, id, bestHealth, bestDistance, bestId)) {
                best = player; bestHealth = health; bestDistance = distance; bestId = id;
            }
        }
        return best;
    }
}
