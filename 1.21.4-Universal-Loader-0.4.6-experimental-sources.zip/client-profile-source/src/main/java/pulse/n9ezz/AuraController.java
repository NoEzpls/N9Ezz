package pulse.n9ezz;

import java.util.Arrays;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_1268;
import pulse.settings.BooleanSetting;
import pulse.settings.SliderSetting;

/** Physical target acquisition, visible rotation and tick-paced native attack dispatch. */
public final class AuraController {
    public final BooleanSetting airCritOnly = new BooleanSetting("В воздухе только криты", "При подъёме или полёте без условий крита ждать настоящего падения и заряда выше 90%; на земле действует обычный порог заряда.", true);
    public final BooleanSetting doubleAttack = new BooleanSetting("Второй удар сразу", "После первого отправленного удара повторить обычную атаку по той же цели без повторной проверки заряда. Дополнительный урон сервером не гарантируется.", true);
    public final BooleanSetting fastRotation = new BooleanSetting("Быстрый поворот", "Повернуться к боковой или задней цели в пределах заданного угла за тик. Поворот камеры видимый.", true);
    public final SliderSetting maxTurn = new SliderSetting("Поворот за тик (°)", "Верхняя граница видимого поворота за 50 мс; смена цели не даёт дополнительного поворота.", 180, 1, 180, 1);
    public final SliderSetting jitterMs = new SliderSetting("Jitter задержки (мс)", "Случайная добавочная задержка 0–N мс между попытками. Таймер применяется только к атакам, без задержки ответов серверу.", 0, 0, 100, 1);
    public final SliderSetting trackingRange = new SliderSetting("Дальность сопровождения", "Заранее выбрать видимую цель и повернуться к ней. Удар отдельно ограничен настройкой дальности и атрибутом сервера.", 5, 1, 12, .1f);
    private static AuraController current;
    private final u0 module;
    private final c clock = new c();
    private final b misses = new b();
    private final AuraSchedule schedule = new AuraSchedule();
    private class_1657 target;
    private Object world, player;
    private long acquiredAt, lastRotation, manualUntil;
    private float expectedYaw, expectedPitch;
    private boolean observed, rotated;
    private String stage = "INACTIVE", detail = "выключено";
    private long submissions, sent;
    private double lastAttackRange, lastTrackingRange;

    public AuraController(u0 module) { this.module = module; current = this; }
    public class_1657 target() { return target; }
    public void reset() {
        target = null; world = player = null; acquiredAt = lastRotation = manualUntil = 0;
        observed = rotated = false; clock.m0(); misses.m0(); schedule.reset(); e.m2();
        submissions = sent = 0; lastAttackRange = lastTrackingRange = 0;
        state("INACTIVE", "сброшено");
    }
    private void state(String next, String why) { stage = next; detail = why; }
    private void clearTarget() {
        target = null; acquiredAt = 0; e.m2();
        // Brief occlusion must not erase attack pacing, manual-input priority or
        // grant another full tick of rotation. Only an explicit lifecycle reset does.
    }
    private boolean active() { return module.isEnabled() && module.powered() && !InterfaceMode.hidden(); }
    public boolean controlsView() {
        return active() && target != null && !"Без поворота".equals(module.rotation.selectedValue());
    }
    private boolean eligible(class_1657 candidate, double range, boolean shared) {
        if (!d.m21(candidate, module.invisible.get(), module.unarmored.get())) return false;
        double distance = d.m14(candidate);
        if (!Double.isFinite(distance) || distance > range) return false;
        if (!shared && !AuraRules.withinFov(d.m13(candidate, false), module.fov.get())) return false;
        // Broaden the former small fallback sample set and check range during
        // point selection, so a reachable exposed face is not lost.
        return TargetV2Runtime.aimPoint(candidate, 1f, range) != null;
    }
    private class_1657 acquire(double range, double attackRange) {
        if (CombatSession.juggernaut()) {
            class_1657 shared = CombatSession.target();
            return shared != null && eligible(shared, 12, true) ? shared : null;
        }
        if (module.lockTarget.get() && target != null && eligible(target, range, false)) return target;
        int priority = Arrays.asList(module.priority.values()).indexOf(module.priority.selectedValue());
        class_1657 best = null; double bestScore = Double.POSITIVE_INFINITY; boolean bestReachable = false;
        // The explicit FOV also applies behind the player. Tracking distance and
        // attack distance are different: acquiring at five blocks is not a five-block hit.
        for (class_1657 candidate : class_310.method_1551().field_1687.method_18456()) {
            if (!eligible(candidate, range, false)) continue;
            double score = CombatRules.targetScore(priority, d.m14(candidate), candidate.method_6032() + candidate.method_6067(), candidate.method_6096(), d.m13(candidate, false));
            boolean reachable = d.m14(candidate) <= attackRange && TargetV2Runtime.aimPoint(candidate, 1f, attackRange) != null;
            // A weaker distant player must not suppress a valid nearby hit solely
            // because tracking now extends beyond attack reach. Explicit lock/shared modes win.
            if (Double.isFinite(score) && (best == null || reachable && !bestReachable || reachable == bestReachable && score < bestScore)) {
                best = candidate; bestScore = score; bestReachable = reachable;
            }
        }
        return best;
    }
    public void tick() { tick(System.nanoTime()); }
    /** Deterministic clock entry point; normal ticks use monotonic time. */
    public void tick(long now) {
        class_310 mc = class_310.method_1551();
        if (world != mc.field_1687 || player != mc.field_1724) {
            reset(); world = mc.field_1687; player = mc.field_1724;
        }
        if (!active()) { clearTarget(); state("INACTIVE", "модуль выключен или скрыт"); return; }
        if (!d.m3(false)) { clearTarget(); state("UNAVAILABLE", "нет игрового состояния или используется предмет"); return; }
        double attackRange = d.m15(module.range.get());
        if (!Double.isFinite(attackRange) || attackRange <= 0) { clearTarget(); state("INVALID_RANGE", "нет допустимой дальности удара"); return; }
        double tracking = AuraRules.trackingRange(trackingRange.get(), attackRange);
        lastAttackRange = attackRange; lastTrackingRange = tracking;
        class_1657 next = acquire(tracking, attackRange);
        if (next != target) {
            target = next; acquiredAt = now; e.m2();
            // Keep rotation accounting when switching: the former reset gave every
            // reacquired target a fresh 50 ms allowance, even in the same instant.
        }
        if (target == null) { state("NO_TARGET", "нет подходящей видимой цели в угле и дальности сопровождения"); return; }
        boolean manualPause = rotate(now, 1f);
        if (!Double.isFinite(module.confirmation.get()) || now - acquiredAt < 0
                || now - acquiredAt < Math.max(0, module.confirmation.get()) * 1_000_000d) {
            state("CONFIRMING", "подтверждение выбранной цели"); return;
        }
        if (d.m14(target) > attackRange) {
            state("OUT_OF_REACH", "цель сопровождается; физическая дистанция больше разрешённой дальности удара"); return;
        }
        if (TargetV2Runtime.aimPoint(target, 1f, attackRange) == null) {
            state("NO_VISIBLE_POINT", "нет видимой физической точки в пределах дальности удара"); return;
        }
        int cps = PowerCurve.cps(module.cps.roundedInt(), module.strength());
        if (!schedule.ready(now, cps)) { state("INTERVAL", "интервал после предыдущей попытки ещё не прошёл"); return; }
        if (d.m28(attackRange, false) != target) {
            if (manualPause) { state("MANUAL_PAUSE", "пауза после движения мыши; прицел вне физического тела"); return; }
            state("ROTATING", controlsView() ? "поворот ещё не довёл луч до физического тела" : "режим без поворота: прицел не на физическом теле"); return;
        }
        state("SUBMITTED", "передано проверкам оружия, заряда и фактического крита; это не подтверждение урона"); submissions++;
        // Express the existing native airborne-only reset policy at the request
        // boundary too. Ground attacks keep sprinting; the final gate still rechecks it.
        boolean resetSprint = module.resetSprint.get() && airCritOnly.get() && !mc.field_1724.method_24828();
        e.m7(target, clock, misses, new Attacks$Options(cps,
                Arrays.asList(module.speed.values()).indexOf(module.speed.selectedValue()),
                module.miss.roundedInt(), module.cooldown.get(), module.range.get(),
                module.weaponsOnly.get(), false, resetSprint, false));
    }
    public void frame(long now, float progress) {
        if (controlsView() && d.m3(false) && d.m21(target, module.invisible.get(), module.unarmored.get())) rotate(now, progress);
    }
    /** Returns whether an explicitly configured manual-input pause is in effect. */
    private boolean rotate(long now, float progress) {
        if (!controlsView()) return false;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return false;
        float yaw = mc.field_1724.method_36454(), pitch = mc.field_1724.method_36455();
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) return false;
        if (observed && (Math.abs(AuraRules.wrap(yaw - expectedYaw)) > .001 || Math.abs(pitch - expectedPitch) > .001))
            manualUntil = now + Math.max(0, module.manualOverride.roundedInt()) * 1_000_000L;
        expectedYaw = yaw; expectedPitch = pitch; observed = true;
        double seconds = !rotated ? .05 : Math.max(0, Math.min(.05, (now - lastRotation) / 1e9));
        if (rotated && now < lastRotation) return now < manualUntil;
        lastRotation = now; rotated = true;
        if (now < manualUntil) return true;
        if (seconds == 0) return false;
        double aimRange = Math.max(lastAttackRange, CombatSession.juggernaut() ? 12 : lastTrackingRange);
        // Prefer a point inside attack reach when available; tracking fallback is
        // used only to face a farther target while approaching it.
        class_243 point = TargetV2Runtime.aimPoint(target, progress, lastAttackRange);
        if (point == null) point = TargetV2Runtime.aimPoint(target, progress, aimRange);
        if (point == null) return false;
        class_243 eye = mc.field_1724.method_33571();
        double dx = point.field_1352 - eye.field_1352, dy = point.field_1351 - eye.field_1351, dz = point.field_1350 - eye.field_1350;
        if (!CombatRules6.meaningfulDirection(dx, dy, dz)) return false;
        double desiredYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90;
        double desiredPitch = -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        double smoothing = fastRotation.get() ? 1 : 1 - .9 * Math.max(0, Math.min(100, module.smoothing.get())) / 100;
        double limit = Math.max(1, Math.min(180, maxTurn.get())) * seconds / .05 * smoothing;
        expectedYaw = AuraRules.turn(yaw, desiredYaw, limit, false);
        expectedPitch = AuraRules.turn(pitch, desiredPitch, limit, true);
        // Free movement compensates this known automatic turn. It never treats
        // player mouse movement as an automatic turn or sends extra look packets.
        SpeedV2Runtime.viewTurn(yaw, expectedYaw);
        mc.field_1724.method_36456(expectedYaw); mc.field_1724.method_36457(expectedPitch);
        return false;
    }
    public static boolean attackAllowed(boolean grounded, double verticalVelocity, double fallDistance,
            float charge, int restrictions, boolean sprinting, boolean pendingSprintReset) {
        AuraController aura = current;
        boolean critOnly = aura == null || !aura.active() || aura.airCritOnly.get();
        boolean allowed = AuraRules.attackAllowed(critOnly, grounded, verticalVelocity, fallDistance, charge, restrictions, sprinting, pendingSprintReset);
        if (!allowed && aura != null && aura.active()) {
            String why = (restrictions & 1) != 0 ? "используется предмет" : !grounded && critOnly
                    ? "ожидание настоящего крита: падение, заряд выше 90%, отсутствие ограничений и спринта"
                    : "некорректное состояние игрока";
            aura.state("PLAYER_STATE", why);
        }
        return allowed;
    }
    public static void attempted(class_1657 target, long now) {
        AuraController aura = current;
        if (aura != null && aura.active() && aura.target == target) {
            aura.schedule.attempted(now, aura.jitterMs.roundedInt());
            aura.state("ATTEMPTED", "попытка обработана клиентом; возможен настроенный пропуск");
        }
    }
    /** Called only after the first native attack AND swing succeeded, never by the polling scheduler. */
    public static int afterAttack(class_1657 source, class_1657 attacked) {
        AuraController aura = current;
        if (aura == null || !aura.active() || aura.target != attacked) return 0;
        aura.sent++; aura.state("SENT", "обычная атака отправлена; получение урона сервером не подтверждено");
        if (!aura.doubleAttack.get()) return 0;
        // Exactly one immediate repeat through the same native attack+swing path.
        // The server still applies weapon cooldown, invulnerability and critical rules.
        class_310.method_1551().field_1761.method_2918(source, attacked);
        source.method_6104(class_1268.field_5808); aura.sent++;
        aura.state("SENT_REPEAT", "отправлены первый и один повторный удар; это не два подтверждённых попадания");
        return 1;
    }
    public static boolean ownsView() {
        AuraController aura = current; class_310 mc = class_310.method_1551();
        return aura != null && aura.module == N9Ezz.AURA && aura.world == mc.field_1687
                && aura.player == mc.field_1724 && aura.controlsView();
    }
    public static String diagnostics() {
        AuraController aura = current;
        if (aura == null) return "KillAura: INACTIVE (контроллер не создан)";
        return "KillAura: " + aura.stage + "; " + aura.detail + "; цель=" + (aura.target == null ? "нет" : aura.target.method_5628())
                + "; сопровождение=" + aura.lastTrackingRange + "; удар=" + aura.lastAttackRange
                + "; запросы=" + aura.submissions + "; отправки=" + aura.sent;
    }
}
