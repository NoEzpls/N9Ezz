package pulse.n9ezz;

/** Pure, finite input rules shared by the rewritten aura and its executable tests. */
public final class AuraRules {
    private AuraRules() {}
    public static double wrap(double degrees) {
        if (!Double.isFinite(degrees)) return Double.NaN;
        double result = degrees % 360;
        return result >= 180 ? result - 360 : result < -180 ? result + 360 : result;
    }
    public static boolean withinFov(double delta, double degrees) {
        return Double.isFinite(delta) && Double.isFinite(degrees)
                && Math.abs(wrap(delta)) <= Math.max(0, Math.min(360, degrees)) * .5 + 1e-7;
    }
    public static float turn(float current, double desired, double limit, boolean pitch) {
        if (!Float.isFinite(current) || !Double.isFinite(desired) || !Double.isFinite(limit) || limit <= 0) return current;
        double difference = pitch ? desired - current : wrap(desired - current);
        double result = current + Math.max(-limit, Math.min(limit, difference));
        return (float)(pitch ? Math.max(-90, Math.min(90, result)) : result);
    }
    public static double trackingRange(double configured, double attackRange) {
        if (!Double.isFinite(attackRange) || attackRange <= 0) return 0;
        return Math.max(attackRange, Double.isFinite(configured) ? Math.max(1, Math.min(12, configured)) : attackRange);
    }
    public static boolean attackAllowed(boolean critOnly, boolean grounded, double verticalVelocity,
            double fallDistance, float charge, int restrictions, boolean sprinting, boolean pendingSprintReset) {
        if (!Double.isFinite(verticalVelocity) || !Double.isFinite(fallDistance)
                || !Float.isFinite(charge) || charge < 0 || (restrictions & 1) != 0) return false;
        // An airborne ordinary strike is permitted only when the user disables the visible
        // air-critical option. No onGround/fall-distance/velocity packet is fabricated.
        if (grounded || !critOnly) return true;
        return restrictions == 0 && charge > .9f && verticalVelocity < 0 && fallDistance > 0
                && (!sprinting || pendingSprintReset);
    }
}
