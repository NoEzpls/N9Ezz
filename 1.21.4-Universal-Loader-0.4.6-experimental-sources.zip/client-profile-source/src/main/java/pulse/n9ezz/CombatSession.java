package pulse.n9ezz;

import net.minecraft.class_1657;
import net.minecraft.class_310;

/** One per-tick target for the coordinated mode; never changes server state. */
public final class CombatSession {
    private static boolean enabled;
    private static Object world, actor;
    private static int evaluatedTick = Integer.MIN_VALUE;
    private static class_1657 selected;
    private static String reason = "Juggernaut выключен";
    private CombatSession() {}

    public static boolean juggernaut() {
        if (!enabled) return false;
        var mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1724 != actor
                || mc.field_1687 != world || InterfaceMode.hidden()) {
            stop("Смена мира, игрока или скрытие интерфейса: требуется ручной запуск");
        }
        return enabled;
    }
    public static void setJuggernaut(boolean value) {
        if (!value) { clear(); return; }
        var mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || InterfaceMode.hidden()) {
            stop("Нет активного игрового мира"); return;
        }
        world = mc.field_1687; actor = mc.field_1724; selected = null;
        evaluatedTick = Integer.MIN_VALUE; enabled = true; reason = "Поиск общей цели";
    }
    public static void clear() { stop("Juggernaut выключен"); }
    private static void stop(String why) {
        enabled = false; selected = null; world = actor = null;
        evaluatedTick = Integer.MIN_VALUE; reason = why;
    }
    public static String status() {
        if (!juggernaut()) return reason;
        var target = target();
        return target == null ? "Juggernaut: видимой цели в радиусе 12 блоков нет"
                : "Juggernaut: общая цель выбрана; приоритет — меньше здоровья";
    }
    public static class_1657 target() {
        if (!juggernaut()) return null;
        var mc = class_310.method_1551();
        int tick = mc.field_1724.field_6012;
        // All consumers see the same choice for this simulation tick. If it dies
        // mid-tick, wait until the next tick rather than switching during an attack.
        if (evaluatedTick == tick) return eligible(selected) ? selected : null;
        evaluatedTick = tick; selected = null;
        double bestHealth = Double.POSITIVE_INFINITY, bestDistance = Double.POSITIVE_INFINITY;
        for (class_1657 candidate : mc.field_1687.method_18456()) {
            if (!eligible(candidate)) continue;
            double health = candidate.method_6032() + candidate.method_6067();
            double distance = d.m14(candidate);
            if (!Double.isFinite(health) || !Double.isFinite(distance)) continue;
            if (health < bestHealth || health == bestHealth && (distance < bestDistance
                    || distance == bestDistance && selected != null
                    && candidate.method_5667().compareTo(selected.method_5667()) < 0)) {
                selected = candidate; bestHealth = health; bestDistance = distance;
            }
        }
        reason = selected == null ? "Нет подходящей цели" : "Общая цель активна";
        return selected;
    }
    private static boolean eligible(class_1657 candidate) {
        return candidate != null && d.m21(candidate, true, true)
                && d.m14(candidate) <= 12 && d.m20(candidate, false);
    }
}
