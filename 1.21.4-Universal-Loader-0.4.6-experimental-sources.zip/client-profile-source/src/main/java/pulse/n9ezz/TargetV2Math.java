package pulse.n9ezz;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/** Acquisition volume is separate from real attack geometry; all coordinates are world-space. */
public final class TargetV2Math {
    private TargetV2Math() {}
    public record Bounds(double minX,double minY,double minZ,double maxX,double maxY,double maxZ) {}
    public record Point(double x,double y,double z) {}
    public static boolean finite(Point p) {
        return p!=null&&Double.isFinite(p.x)&&Double.isFinite(p.y)&&Double.isFinite(p.z);
    }
    public static boolean valid(Bounds b) {
        return b!=null&&finite(new Point(b.minX,b.minY,b.minZ))&&finite(new Point(b.maxX,b.maxY,b.maxZ))
                &&b.minX<=b.maxX&&b.minY<=b.maxY&&b.minZ<=b.maxZ;
    }
    public static double scale(double requested, double power) {
        if (!Double.isFinite(requested) || !Double.isFinite(power)) return 1;
        return Math.min(10, 1 + (Math.max(1,Math.min(5,requested))-1) * Math.max(0,Math.min(1000,power))/100);
    }
    public static Bounds expand(Bounds physical, double x, double y, double z, double power) {
        if(!valid(physical))return physical;
        double cx=physical.minX+(physical.maxX-physical.minX)*.5, cz=physical.minZ+(physical.maxZ-physical.minZ)*.5;
        double hx=(physical.maxX-physical.minX)*.5*scale(x,power);
        double hz=(physical.maxZ-physical.minZ)*.5*scale(z,power);
        double height=(physical.maxY-physical.minY)*scale(y,power);
        Bounds result=new Bounds(cx-hx,physical.minY,cz-hz,cx+hx,physical.minY+height,cz+hz);
        // Feet stay anchored; a larger selector must not grow through the floor.
        return valid(result)?result:physical;
    }
    public static Point clamp(Bounds b,Point p) {
        if(!valid(b)||!finite(p))return null;
        return new Point(Math.max(b.minX,Math.min(b.maxX,p.x)),Math.max(b.minY,Math.min(b.maxY,p.y)),Math.max(b.minZ,Math.min(b.maxZ,p.z)));
    }
    public static double distance(Point a,Point b) {
        return !finite(a)||!finite(b)?Double.POSITIVE_INFINITY:Math.hypot(Math.hypot(a.x-b.x,a.z-b.z),a.y-b.y);
    }
    /** Distance along a normalized ray, inclusive at a real face exactly at maximum reach. */
    public static double rayDistance(Bounds b,Point eye,Point direction,double range) {
        if(!valid(b)||!finite(eye)||!finite(direction)||!Double.isFinite(range)||range<=0)return Double.POSITIVE_INFINITY;
        double length=Math.hypot(Math.hypot(direction.x,direction.z),direction.y);
        if(!Double.isFinite(length)||length<1e-12)return Double.POSITIVE_INFINITY;
        double[] low={b.minX,b.minY,b.minZ},high={b.maxX,b.maxY,b.maxZ};
        double[] origin={eye.x,eye.y,eye.z},dir={direction.x/length,direction.y/length,direction.z/length};
        double near=0,far=range;
        for(int axis=0;axis<3;axis++){
            if(Math.abs(dir[axis])<1e-12){if(origin[axis]<low[axis]||origin[axis]>high[axis])return Double.POSITIVE_INFINITY;continue;}
            double a=(low[axis]-origin[axis])/dir[axis],c=(high[axis]-origin[axis])/dir[axis];
            near=Math.max(near,Math.min(a,c));far=Math.min(far,Math.max(a,c));
            if(near>far)return Double.POSITIVE_INFINITY;
        }
        return near;
    }
    public static Point direction(float yaw,float pitch) {
        if(!Float.isFinite(yaw)||!Float.isFinite(pitch))return null;
        double y=Math.toRadians(yaw),p=Math.toRadians(pitch),c=Math.cos(p);
        return new Point(-Math.sin(y)*c,-Math.sin(p),Math.cos(y)*c);
    }
    public static Point along(Point eye,Point direction,double distance) {
        return new Point(eye.x+direction.x*distance,eye.y+direction.y*distance,eye.z+direction.z*distance);
    }
    /**
     * Preserve a usable preferred point to avoid aim jitter. If it is obstructed,
     * look for an exposed physical surface instead of rejecting the entire player.
     * The exact nearest face is considered too: a fixed inset used to lose reach-edge targets.
     */
    public static Point aim(Bounds physical,Point eye,Point preferred,Point view,double range,Predicate<Point> visible) {
        if(!valid(physical)||!finite(eye)||!finite(view)||!Double.isFinite(range)||range<=0||visible==null)return null;
        Point first=clamp(physical,preferred);
        if(usable(first,eye,range,visible))return first;
        List<Point> candidates=new ArrayList<>(30);
        candidates.add(clamp(physical,eye));
        double[] f={.001,.5,.999};
        for(double x:f)for(double y:f)for(double z:f)candidates.add(new Point(
                physical.minX+(physical.maxX-physical.minX)*x,physical.minY+(physical.maxY-physical.minY)*y,physical.minZ+(physical.maxZ-physical.minZ)*z));
        Point best=null;double score=Double.POSITIVE_INFINITY;
        for(Point p:candidates){
            double distance=distance(eye,p);
            if(distance>range||distance<1e-9||!Double.isFinite(distance))continue;
            // Minimum angular change wins; a tiny distance term provides deterministic ties.
            double cosine=((p.x-eye.x)*view.x+(p.y-eye.y)*view.y+(p.z-eye.z)*view.z)/distance;
            double candidate=1-Math.max(-1,Math.min(1,cosine))+distance*1e-9;
            if(candidate<score&&visible.test(p)){best=p;score=candidate;}
        }
        return best;
    }
    private static boolean usable(Point p,Point eye,double range,Predicate<Point> visible) {
        double length=distance(eye,p);
        return length>1e-9&&length<=range&&visible.test(p);
    }
    public static float turn(float current,double desired,double maximum,boolean pitch) {
        if (!Float.isFinite(current)||!Double.isFinite(desired)||!Double.isFinite(maximum)) return current;
        // Pitch has endpoints, not a circular seam. Wrapping -90 -> +90 as yaw
        // chose the wrong direction and clamped the view back to its starting pole.
        double delta=desired-current;
        if(!pitch){delta%=360;if(delta>=180)delta-=360;if(delta< -180)delta+=360;}
        double limit=Math.max(0,Math.min(180,maximum));
        double result=current+Math.max(-limit,Math.min(limit,delta));
        return (float)(pitch?Math.max(-90,Math.min(90,result)):result);
    }
}
