import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Isolated actual-bytecode comparison: no Minecraft, mod bootstrap or network. */
public final class ComparatorProbe {
    private static int assertions;
    private static void check(boolean ok,String message){assertions++;if(!ok)throw new AssertionError(message);}
    private static ClassNode read(JarFile jar,String name)throws Exception{
        ClassNode c=new ClassNode();try(var in=jar.getInputStream(jar.getJarEntry(name+".class"))){new ClassReader(in).accept(c,0);}return c;
    }
    private static byte[] bytes(ClassNode c){ClassWriter w=new ClassWriter(0);c.accept(w);return w.toByteArray();}
    private static void select(Map<String,byte[]> map,JarFile jar,String name,Set<String> methods)throws Exception{
        ClassNode c=read(jar,name);c.methods.removeIf(m->!methods.contains(m.name));c.innerClasses.clear();c.nestHostClass=null;c.nestMembers=null;
        map.put(name.replace('/','.'),bytes(c));
    }
    private static final class Isolated extends ClassLoader {
        final Map<String,byte[]> map;
        Isolated(Map<String,byte[]> map){super(ClassLoader.getPlatformClassLoader());this.map=map;}
        protected Class<?> findClass(String name)throws ClassNotFoundException{byte[] b=map.get(name);if(b==null)throw new ClassNotFoundException(name);return defineClass(name,b,0,b.length);}
    }
    private static void row(Object... values){System.out.println(String.join("\t",Arrays.stream(values).map(Object::toString).toList()));}
    public static void main(String[] args)throws Exception{
        Path current=Path.of(args[0]),baseline=Path.of(args[1]),expa=Path.of(args[2]),fixtures=Path.of(args[3]);
        Map<String,byte[]> map=new HashMap<>();
        try(var paths=Files.walk(fixtures)){for(Path p:paths.filter(p->p.toString().endsWith(".class")).toList())map.put(fixtures.relativize(p).toString().replace(File.separatorChar,'.').replaceFirst("\\.class$",""),Files.readAllBytes(p));}
        try(JarFile p=new JarFile(current.toFile());JarFile e=new JarFile(expa.toFile());JarFile b=new JarFile(baseline.toFile())){
            for(String name:List.of("pulse/n9ezz/a","pulse/n9ezz/AimSmoothing","pulse/n9ezz/AimSmoothing$Turn","pulse/n9ezz/CombatRules","pulse/n9ezz/CombatRules$CriticalDecision")){
                byte[] now=p.getInputStream(p.getJarEntry(name+".class")).readAllBytes();map.put(name.replace('/','.'),now);
                check(Arrays.equals(now,b.getInputStream(b.getJarEntry(name+".class")).readAllBytes()),"Baseline mathematical class changed: "+name);
            }
            select(map,e,"aethereal/type/GrimRotationMode",Set.of("<init>","process"));
            select(map,e,"aethereal/math/Rotation",Set.of("<init>","getYaw","getPitch"));
            select(map,e,"aethereal/math/RotationMath",Set.of("<init>","<clinit>","calculateRotationDifference"));
            ClassNode aura=new ClassNode();new ClassReader(map.get("aethereal.module.AttackAuraModule")).accept(aura,0);
            MethodNode actual=read(e,"aethereal/module/AttackAuraModule").methods.stream().filter(m->m.name.equals("getAttackDelay")).findFirst().orElseThrow();
            actual.access=Opcodes.ACC_PUBLIC;aura.methods.removeIf(m->m.name.equals("getAttackDelay"));aura.methods.add(actual);map.put("aethereal.module.AttackAuraModule",bytes(aura));
            // Assert the uploaded binary really uses the two independent acquisition
            // gates and the crosshair gate discussed in the report.
            ClassNode u0=read(p,"pulse/n9ezz/u0"),d=read(p,"pulse/n9ezz/d");
            check(hasCall(u0,"tick","pulse/n9ezz/d","m27"),"Expected old crosshair attack gate");
            check(hasCall(d,"m25","pulse/n9ezz/a","m1"),"Expected old hidden cone");
            check(hasConstant(read(e,"aethereal/module/AttackAuraModule"),"findTarget",180d),"Expa 180-degree half-angle evidence");
        }
        Isolated loader=new Isolated(map);Class<?> math=loader.loadClass("pulse.n9ezz.a");
        row("component","case","value","unit","scope");
        for(double power:new double[]{0,20,50,65,90,100,250}){
            double angle=(double)math.getMethod("m1",double.class).invoke(null,power);
            check(Double.isFinite(angle)&&angle>=12&&angle<=180,"Finite cone");row("PulseVisuals_0.4.3","power_cone_"+power,angle,"degrees_half_angle","actual_math");
        }
        Class<?> rules=loader.loadClass("pulse.n9ezz.CombatRules");
        for(double power:new double[]{25,50,65,100,250}){
            long delay=(long)rules.getMethod("reactionDelay",double.class,double.class).invoke(null,power,0d);
            row("PulseVisuals_0.4.3","confirmation_zero_power_"+power,delay/1e6,"ms","actual_math");
        }
        Class<?> smooth=loader.loadClass("pulse.n9ezz.AimSmoothing");Method advance=smooth.getMethod("advance",double.class,double.class,double.class,double.class,double.class);
        for(double angle:new double[]{45,90,135,179})for(double[] options:new double[][]{{100,85},{250,35}}){
            Object state=smooth.getConstructor().newInstance();double remain=angle,first=Double.NaN;int steps=0;
            while(Math.abs(remain)>.1&&steps<400){Object turn=advance.invoke(state,remain,0d,.05,options[0],options[1]);double yaw=(double)turn.getClass().getMethod("yaw").invoke(turn);check(Double.isFinite(yaw),"Finite old rotation");if(steps==0)first=yaw;remain-=yaw;steps++;}
            check(steps<400,"Old rotation converges");row("PulseVisuals_0.4.3","yaw_"+angle+"_power_"+options[0]+"_smooth_"+options[1],steps,"calls_50ms_to_0.1deg","isolated_smoothing_no_input_or_ray");
            row("PulseVisuals_0.4.3","first_yaw_"+angle+"_power_"+options[0]+"_smooth_"+options[1],first,"degrees","isolated_smoothing_no_input_or_ray");
        }
        Class<?> rotation=loader.loadClass("aethereal.math.Rotation"),grim=loader.loadClass("aethereal.type.GrimRotationMode");Object mode=grim.getConstructor().newInstance();
        Method process=grim.getMethod("process",rotation,rotation,loader.loadClass("net.minecraft.class_243"),loader.loadClass("net.minecraft.class_1297"));
        Object target=loader.loadClass("net.minecraft.class_1297").getConstructor().newInstance();
        for(float angle:new float[]{45,90,135,179}){
            Object start=rotation.getConstructor(float.class,float.class).newInstance(0f,0f),goal=rotation.getConstructor(float.class,float.class).newInstance(angle,0f);
            Object result=process.invoke(mode,start,goal,null,target);float yaw=(float)rotation.getMethod("getYaw").invoke(result),pitch=(float)rotation.getMethod("getPitch").invoke(result);
            check(Math.abs(yaw-angle)<.001f&&pitch==0,"Ready Grim reaches yaw in one process call");row("expa_uploaded","ready_Grim_yaw_"+angle,yaw,"degrees_per_call","actual_process_canAttack_true_fixture");
        }
        Class<?> expensive=loader.loadClass("aethereal.Expensive");Object instance=expensive.getField("INSTANCE").get(null),repository=expensive.getField("repository").get(instance),aura=repository.getClass().getField("aura").get(repository);
        Class<?> ac=aura.getClass();Object setting=ac.getField("rotationMode").get(aura);Object[] modes=loader.loadClass("aethereal.type.AuraRotationMode").getEnumConstants();
        for(int i=0;i<modes.length;i++){setting.getClass().getField("value").set(setting,modes[i]);List<String> delays=new ArrayList<>();for(int hit=0;hit<10;hit++){ac.getField("hitCounter").setInt(aura,hit);int delay=(int)ac.getMethod("getAttackDelay").invoke(aura);check(delay>=10&&delay<=13,"Expa delay bounds");delays.add(Integer.toString(delay));}row("expa_uploaded","attack_delay_"+modes[i],String.join(",",delays),"ticks","actual_method_default_array_fixture");}
        System.err.println("PASS "+assertions+" assertions; isolated methods only; no game bootstrap, server or duel.");
    }
    static boolean hasCall(ClassNode c,String method,String owner,String name){return c.methods.stream().filter(m->m.name.equals(method)).flatMap(m->Arrays.stream(m.instructions.toArray())).anyMatch(i->i instanceof MethodInsnNode call&&call.owner.equals(owner)&&call.name.equals(name));}
    static boolean hasConstant(ClassNode c,String method,Object value){return c.methods.stream().filter(m->m.name.equals(method)).flatMap(m->Arrays.stream(m.instructions.toArray())).anyMatch(i->i instanceof LdcInsnNode ldc&&value.equals(ldc.cst));}
}
