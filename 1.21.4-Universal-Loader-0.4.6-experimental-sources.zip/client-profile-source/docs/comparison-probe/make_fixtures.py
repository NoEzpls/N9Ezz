from pathlib import Path

# These are deliberately small test doubles for game state and dependency APIs,
# not copied client implementations. Actual compared methods are read from JARs.
root = Path(__file__).parent / 'fixtures'
sources = {
'net/minecraft/class_243.java': 'package net.minecraft; public class class_243 {}',
'net/minecraft/class_1297.java': 'package net.minecraft; public class class_1297 {}',
'net/minecraft/class_746.java': 'package net.minecraft; public class class_746 extends class_1297 {}',
'net/minecraft/class_3532.java': '''package net.minecraft; public class class_3532 {
public static float method_15363(float v,float a,float b){return Math.max(a,Math.min(b,v));}
public static float method_16439(float t,float a,float b){return a+t*(b-a);}
public static float method_15393(float v){v%=360;if(v>=180)v-=360;if(v< -180)v+=360;return v;}
}''',
'aethereal/type/RotationMode.java': 'package aethereal.type; public class RotationMode {public RotationMode(String label){}}',
'aethereal/type/AuraRotationMode.java': 'package aethereal.type; public enum AuraRotationMode {FUNTIME,SMOOTH,GRIM}',
'aethereal/type/Mc.java': 'package aethereal.type; public class Mc {public static Mc INSTANCE=new Mc();public net.minecraft.class_746 getPlayer(){return new net.minecraft.class_746();}}',
'aethereal/math/Stopwatch.java': 'package aethereal.math; public class Stopwatch {public boolean hasElapsed(long ms){return true;}}',
'aethereal/util/MathUtil.java': 'package aethereal.util; public class MathUtil {public static float getRandom(float a,float b){throw new AssertionError("Random branch is outside this test");}}',
'aethereal/ui/setting/ModeSetting.java': 'package aethereal.ui.setting; public class ModeSetting {public Enum value;public Enum currentValue(){return value;}}',
'aethereal/module/Module.java': 'package aethereal.module; public class Module {}',
'aethereal/module/AttackAuraModule.java': '''package aethereal.module; public class AttackAuraModule extends Module {
public int hitCounter; public int[] funtimeAttackDelays={10,10,10,10,12};public int[] smoothAttackDelays={10,10,10,13};
public aethereal.ui.setting.ModeSetting rotationMode=new aethereal.ui.setting.ModeSetting();
public boolean ready=true;public boolean canAttack(net.minecraft.class_746 player,int lookahead){return ready;}
public aethereal.math.Stopwatch attackTimer(){return new aethereal.math.Stopwatch();}
public int getAttackDelay(){throw new AssertionError("Replace with original JAR method");}
}''',
'aethereal/config/ModuleRepository.java': 'package aethereal.config; public class ModuleRepository {public aethereal.module.AttackAuraModule aura=new aethereal.module.AttackAuraModule();public aethereal.module.Module get(Class type){return aura;}}',
'aethereal/Expensive.java': 'package aethereal; public class Expensive {public static Expensive INSTANCE=new Expensive();public aethereal.config.ModuleRepository repository=new aethereal.config.ModuleRepository();public aethereal.config.ModuleRepository moduleRepository(){return repository;}}',
}
for name, text in sources.items():
    path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text+'\n')
