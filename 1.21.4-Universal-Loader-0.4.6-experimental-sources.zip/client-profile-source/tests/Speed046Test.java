import pulse.n9ezz.SpeedV2;

/** Movement-frame and authoritative-update regressions; no live server claims. */
public final class Speed046Test {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static void near(double actual, double expected, String message) {
        check(Math.abs(actual - expected) < 1e-7, message + ": " + actual + " != " + expected);
    }
    private static void sameDirection(double actual, double expected, String message) {
        near(Math.sin(Math.toRadians(actual)), Math.sin(Math.toRadians(expected)), message + " x");
        near(Math.cos(Math.toRadians(actual)), Math.cos(Math.toRadians(expected)), message + " z");
    }
    public static void main(String[] args) {
        SpeedV2.ViewFrame view = new SpeedV2.ViewFrame();
        near(view.inputYaw(0, true), 0, "first movement uses visible heading");
        view.turned(0, 90);
        sameDirection(view.inputYaw(90, true), 0, "Aura quarter-turn cannot turn held forward movement");
        sameDirection(view.inputYaw(105, true), 15, "manual 15-degree turn still steers");
        view.turned(105, -160);
        sameDirection(view.inputYaw(-160, true), 15, "second automatic turn preserves manual adjustment");
        view.inputYaw(-160, false);
        sameDirection(view.inputYaw(-160, true), -160, "released keys start next movement from visible heading");
        view.clear();
        view.turned(0, 175);
        sameDirection(view.inputYaw(175, true), 175, "standing automatic turns cannot prime stale compensation");
        view.turned(Double.NaN, 0);
        view.turned(0, Double.POSITIVE_INFINITY);
        sameDirection(view.inputYaw(175, true), 175, "invalid rotations ignored");
        near(view.inputYaw(Double.NaN, true), 0, "invalid heading resets frame");
        near(view.compensation(), 0, "invalid heading clears compensation");
        view.turned(0, 90, 3);
        sameDirection(view.inputYaw(90, true, 3), 0, "first-tick Aura turn before input is compensated");
        view.clear(); view.turned(0, 90, 3);
        sameDirection(view.inputYaw(90, true, 4), 90, "older stationary turn never primes new keypress");
        view.clear(); view.turned(0, 45, 3); view.turned(45, 90, 3);
        sameDirection(view.inputYaw(90, true, 3), 0, "same-tick initial turns accumulate");
        view.clear(); view.turned(0, 90, 3); view.inputYaw(90, false, 3);
        sameDirection(view.inputYaw(90, true, 4), 90, "stationary input discards pending compensation");

        // Full circles and the +/-180 seam must preserve world direction without
        // integrating unbounded yaw values. The later manual turn remains visible.
        for (int initial = -180; initial <= 180; initial += 30) {
            view.clear();
            view.inputYaw(initial, true);
            double visible = initial;
            for (int turn = 0; turn < 100; turn++) {
                double next = visible + 127;
                view.turned(visible, next);
                visible = next;
                sameDirection(view.inputYaw(visible, true), initial, "multiple rotations " + initial + "/" + turn);
                check(view.compensation() >= -180 && view.compensation() < 180, "bounded rotation accumulation");
            }
            sameDirection(view.inputYaw(visible + 23, true), initial + 23, "manual turn after full circles");
        }

        SpeedV2.State state = new SpeedV2.State();
        Object world = new Object(), player = new Object();
        state.enable();
        check(state.ready(world, player, 10), "first world binds normally");
        state.correction();
        state.velocity(11);
        check(state.reason().contains("скорректировал"), "velocity cannot hide latched correction reason");
        check(!state.ready(world, player, 10000), "elapsed quiet window cannot resume a correction pause");
        check(state.diagnostics().contains("коррекций: 1"), "correction counted");
        check(state.diagnostics().contains("обновлений скорости: 1"), "velocity counted during pause");
        state.enable();
        check(state.ready(world, player, 20), "explicit resume rebinds");
        check(state.diagnostics().contains("коррекций: 1"), "resume retains session diagnostics");
        state.velocity(20);
        check(!state.ready(world, player, 29), "native velocity gets full quiet window");
        check(state.ready(world, player, 30), "quiet window expires at boundary");
        state.velocity(30);
        state.velocity(35);
        check(!state.ready(world, player, 44), "later velocity extends quiet window");
        check(state.ready(world, player, 45), "extended quiet window exact boundary");
        check(!state.ready(new Object(), player, 46), "world replacement pauses");
        state.velocity(47);
        check(state.reason().contains("мир/сервер"), "velocity cannot hide world-change pause");
        check(!state.ready(world, player, 10000), "world-change never auto-resumes");
        check(state.diagnostics().contains("смен мира: 1"), "world change counted once");
        state.disconnect();
        check(state.diagnostics().contains("смен мира: 1"), "repeated disconnect callback not counted as new world");
        state.disable();
        state.correction();
        check(state.reason().equals("выключено"), "disabled module ignores correction status");
        check(state.diagnostics().contains("коррекций: 1"), "disabled corrections not attributed to Speed");
        System.out.println("Speed046Test: " + checks + " checks passed");
    }
}
