import pulse.n9ezz.TargetV2Math;
import pulse.n9ezz.TargetV2Math.Bounds;
import pulse.n9ezz.TargetV2Math.Point;

/** Pure production geometry: fixtures test candidate selection, not server acceptance. */
public final class Targeting046Test {
    private static int checks;
    private static void check(boolean good,String what){checks++;if(!good)throw new AssertionError(what);}
    private static void near(double actual,double expected,String what){check(Math.abs(actual-expected)<1e-8,what+": "+actual+" != "+expected);}
    public static void main(String[] args){
        near(TargetV2Math.turn(-90,90,35,true),-55,"pitch leaves upper pole toward lower pole");
        near(TargetV2Math.turn(90,-90,35,true),55,"pitch leaves lower pole toward upper pole");
        near(TargetV2Math.turn(-90,90,180,true),90,"pitch full endpoint turn is not wrapped as yaw");
        near(TargetV2Math.turn(179,-179,35,false),181,"yaw still crosses circular seam by shortest path");
        Bounds body=new Bounds(-.3,0,2,.3,1.8,2.6);
        Point eye=new Point(0,1.62,0),forward=new Point(0,0,1),nearest=new Point(0,1.62,2);
        near(TargetV2Math.rayDistance(body,eye,forward,3),2,"physical near-face hit");
        near(TargetV2Math.rayDistance(body,eye,forward,2),2,"exact reach boundary included");
        check(Double.isInfinite(TargetV2Math.rayDistance(body,eye,forward,1.999999)),"beyond boundary excluded");
        Point missEye=new Point(.5,1.62,0);
        check(Double.isInfinite(TargetV2Math.rayDistance(body,missEye,forward,3)),"empty physical margin misses");
        Bounds expanded=TargetV2Math.expand(body,2,2,2,100);
        check(Double.isFinite(TargetV2Math.rayDistance(expanded,missEye,forward,3)),"same ray selects expanded margin");
        near(body.maxX(),.3,"expansion does not mutate physical bounds");
        near(expanded.minY(),0,"feet remain anchored");
        Point ordinary=TargetV2Math.aim(body,eye,nearest,forward,3,p->true);
        check(ordinary.equals(nearest),"usable preferred point stable");
        Point fallback=TargetV2Math.aim(body,eye,nearest,forward,3,p->p.x()>.25);
        check(fallback!=null&&fallback.x()>.25,"exposed shoulder acquired when nearest point obstructed");
        check(fallback.x()<=body.maxX()&&fallback.y()<=body.maxY(),"fallback remains in physical box");
        Point head=TargetV2Math.aim(body,eye,nearest,forward,3,p->p.y()>1.75);
        check(head!=null&&head.y()>1.75,"head above obstruction reachable");
        check(TargetV2Math.aim(body,eye,nearest,forward,3,p->false)==null,"fully covered body rejected");
        Point beyondInset=new Point(0,1.62,2.02);
        Point boundary=TargetV2Math.aim(body,eye,beyondInset,forward,2,p->true);
        check(boundary!=null,"fixed inset does not discard exact reachable face");
        near(TargetV2Math.distance(boundary,eye),2,"boundary point not beyond native range");
        check(TargetV2Math.aim(body,eye,nearest,forward,1.999,p->true)==null,"visible but out-of-reach body rejected");
        check(TargetV2Math.aim(body,eye,nearest,forward,2,p->p.x()>.25)==null,"exposed shoulder beyond reach rejected");
        Point outside=new Point(100,200,300);
        Point clamped=TargetV2Math.aim(body,eye,outside,forward,10,p->true);
        check(clamped!=null&&clamped.x()<=.3&&clamped.y()<=1.8&&clamped.z()<=2.6,"interpolated preference clamped to live box");
        for(double bad:new double[]{Double.NaN,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY,-1,0}){
            check(Double.isInfinite(TargetV2Math.rayDistance(body,eye,forward,bad)),"invalid ray range rejected "+bad);
            check(TargetV2Math.aim(body,eye,nearest,forward,bad,p->true)==null,"invalid aim range rejected "+bad);
        }
        check(TargetV2Math.aim(body,new Point(Double.NaN,0,0),nearest,forward,3,p->true)==null,"non-finite eye fails closed");
        check(TargetV2Math.aim(new Bounds(1,0,0,-1,1,1),eye,nearest,forward,3,p->true)==null,"inverted body rejected");
        check(Double.isInfinite(TargetV2Math.rayDistance(body,eye,new Point(0,0,0),3)),"zero ray rejected");
        for(int yaw=-180;yaw<180;yaw+=10){
            Point direction=TargetV2Math.direction(yaw,0);
            Bounds target=new Bounds(direction.x()*2-.3,0,direction.z()*2-.3,direction.x()*2+.3,1.8,direction.z()*2+.3);
            check(Double.isFinite(TargetV2Math.rayDistance(target,eye,direction,3)),"body ray all yaw directions "+yaw);
            near(Math.hypot(direction.x(),direction.z()),1,"normalized yaw direction "+yaw);
        }
        System.out.println("Targeting046Test PASS: "+checks+" production geometry assertions; no server hit-rate/bypass claim");
    }
}
