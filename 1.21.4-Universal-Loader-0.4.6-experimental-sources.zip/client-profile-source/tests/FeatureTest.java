import java.lang.reflect.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import javax.tools.ToolProvider;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import pulse.n9ezz.ClientCommandText;

/** Executes the new targeting methods with ray-result fixtures; no game/network launch. */
public final class FeatureTest implements Opcodes {
    static int checks;
    static void check(boolean v,String why){checks++;if(!v)throw new AssertionError(why);}
    static ClassNode node(ZipFile z,String n)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(n+".class")).readAllBytes()).accept(c,0);return c;}
    static MethodNode method(ClassNode c,String n){return c.methods.stream().filter(m->m.name.equals(n)).findFirst().orElseThrow();}
    public static void main(String[] args)throws Exception{
        for(String s:List.of("/pv hide"," .PV HIDE "))check(ClientCommandText.action(s)==1,"hide syntax");
        check(ClientCommandText.action("/pv show")==2,"show syntax");check(ClientCommandText.action("/pv combat")==3,"combat syntax");
        for(String s:List.of("/pvp","hello /pv hide","/pvhide","/cfbot start 100",""))check(ClientCommandText.action(s)==0,"unrelated command passes: "+s);
        check(ClientCommandText.action(null)==0,"null passes");check(ClientCommandText.action("/pv unknown")==4,"local help for owned typo");
        Path temp=Files.createTempDirectory("pulsevisuals-feature-test-");
        try(ZipFile zip=new ZipFile(args[1])){
            ClassNode chat=node(zip,"ru/pulse/mixin/ChatScreenMixin");MethodNode send=method(chat,"onSendMessage");
            List<MethodInsnNode> calls=Arrays.stream(send.instructions.toArray()).filter(i->i instanceof MethodInsnNode).map(i->(MethodInsnNode)i).toList();
            check(calls.get(0).name.equals("handleCommand")&&calls.get(1).name.equals("cancel"),"local commands cancelled before chat event/network dispatch");
            ClassNode preset=node(zip,"pulse/n9ezz/NetworkPreset");Map<String,Number> values=new HashMap<>();
            for(AbstractInsnNode i:method(preset,"m0").instructions)if(i instanceof MethodInsnNode m&&m.owner.equals("pulse/settings/SliderSetting")&&m.name.equals("set")){
                AbstractInsnNode v=i.getPrevious(),f=v.getPrevious();if(f instanceof FieldInsnNode field&&v instanceof LdcInsnNode l&&l.cst instanceof Number number)values.put(field.owner+"/"+field.name,number);
            }
            for(String module:List.of("u0","u1")){
                check(values.get("pulse/n9ezz/"+module+"/confirmation").floatValue()==0,"preset removes target confirmation delay");
                check(values.get("pulse/n9ezz/"+module+"/cooldown").floatValue()==95,"preset selects independent 95% charge");
                check(values.get("pulse/n9ezz/"+module+"/power").floatValue()==100,"preset full visible power");
            }
            check(values.get("pulse/n9ezz/u3/x").floatValue()==1.5f,"preset enables bounded selection expansion");
            ClassNode target=node(zip,"pulse/n9ezz/d");target.methods.removeIf(m->!Set.of("pulsevisuals$visiblePoint","m28").contains(m.name));target.fields.clear();target.innerClasses.clear();target.nestMembers=null;
            // Substitute the environment-dependent ray operation only, retaining the actual
            // compiled branch/point-selection code under test.
            for(MethodNode m:target.methods)for(AbstractInsnNode i:m.instructions)if(i instanceof MethodInsnNode call&&call.owner.equals(target.name)){
                if(call.name.equals("m19")){call.owner="fixture/Probe";call.name="visible";}
                if(call.name.equals("pulsevisuals$crosshair")){call.owner="fixture/Probe";call.name="pick";}
            }
            Map<String,String> src=new LinkedHashMap<>();
            src.put("net/minecraft/class_238","package net.minecraft; public class class_238 { public double field_1323=10,field_1322=20,field_1321=30,field_1320=12,field_1325=24,field_1324=32; }");
            src.put("net/minecraft/class_243","package net.minecraft; public class class_243 {public final double x,y,z; public class_243(double x,double y,double z){this.x=x;this.y=y;this.z=z;} }");
            src.put("net/minecraft/class_1297","package net.minecraft; public class class_1297 {}");
            src.put("fixture/Probe","""
                package fixture; import net.minecraft.*;
                public class Probe {
                  public static int mode,calls; public static class_1297 physical,expanded;
                  public static boolean visible(class_243 p){calls++;if(p.x<10||p.x>12||p.y<20||p.y>24||p.z<30||p.z>32)throw new AssertionError("point outside physical box");return mode==1 || (mode==2&&p.y>23.5);}
                  public static class_1297 pick(double range,boolean expand){calls++;return expand?expanded:physical;}
                }
                """);
            Path classes=temp.resolve("classes");Files.createDirectories(classes);List<String> compiler=new ArrayList<>(List.of("--release","21","-proc:none","-d",classes.toString()));
            for(var e:src.entrySet()){Path p=temp.resolve(e.getKey()+".java");Files.createDirectories(p.getParent());Files.writeString(p,e.getValue());compiler.add(p.toString());}
            check(ToolProvider.getSystemJavaCompiler().run(null,null,null,compiler.toArray(String[]::new))==0,"target fixtures compile");
            ClassWriter w=new ClassWriter(0);target.accept(w);Path actual=classes.resolve(target.name+".class");Files.createDirectories(actual.getParent());Files.write(actual,w.toByteArray());
            try(URLClassLoader l=new URLClassLoader(new URL[]{classes.toUri().toURL()},ClassLoader.getPlatformClassLoader())){
                Class<?> probe=l.loadClass("fixture.Probe"),vector=l.loadClass("net.minecraft.class_243"),box=l.loadClass("net.minecraft.class_238"),d=l.loadClass("pulse.n9ezz.d");
                Object b=box.getConstructor().newInstance(),nearest=vector.getConstructor(double.class,double.class,double.class).newInstance(10.1,20.1,30.1);
                Method point=d.getDeclaredMethod("pulsevisuals$visiblePoint",box,vector);point.setAccessible(true);
                probe.getField("mode").setInt(null,1);check(point.invoke(null,b,nearest)==nearest,"visible nearest point kept");check(probe.getField("calls").getInt(null)==1,"no extra rays for clear target");
                probe.getField("mode").setInt(null,2);probe.getField("calls").setInt(null,0);Object head=point.invoke(null,b,nearest);
                check(vector.getField("y").getDouble(head)>23.5,"occluded body can select visible head");check(probe.getField("calls").getInt(null)==3,"bounded nearest/chest/head search");
                probe.getField("mode").setInt(null,0);probe.getField("calls").setInt(null,0);check(point.invoke(null,b,nearest)==nearest,"no synthetic visible point through wall");check(probe.getField("calls").getInt(null)==6,"fully blocked search bounded to six rays");
                Class<?> entity=l.loadClass("net.minecraft.class_1297");Object physical=entity.getConstructor().newInstance(),expanded=entity.getConstructor().newInstance();
                probe.getField("physical").set(null,physical);probe.getField("expanded").set(null,expanded);Method pick=d.getMethod("m28",double.class,boolean.class);
                check(pick.invoke(null,3d,true)==physical,"physical crosshair target wins over expanded neighbour");
                probe.getField("physical").set(null,null);check(pick.invoke(null,3d,true)==expanded,"expanded acquisition works when physical ray misses");check(pick.invoke(null,3d,false)==null,"final physical attack never accepts expansion");
            }
        }finally{try(var walk=Files.walk(temp)){for(Path p:walk.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
        System.out.println("FeatureTest PASS: "+checks+" checks; targeting fixtures, command routing, preset contracts; live game UNRUN");
    }
}
