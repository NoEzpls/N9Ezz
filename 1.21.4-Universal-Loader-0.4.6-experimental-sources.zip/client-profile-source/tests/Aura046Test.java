import pulse.n9ezz.AuraRules;
import pulse.n9ezz.AuraSchedule;

/** Boundary regression tests for tracking, critical conditions and stable pacing. */
public final class Aura046Test {
    private static int checks;
    private static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        check(AuraRules.trackingRange(5,3)==5,"five-block tracking independent from three-block attack range");
        check(AuraRules.trackingRange(1,4.5)==4.5,"server-granted reach cannot be suppressed by lower tracking setting");
        check(AuraRules.trackingRange(Double.NaN,3)==3,"invalid imported tracking falls back to valid native reach");
        check(AuraRules.trackingRange(1000,3)==12,"tracking bounded to local search limit");
        check(AuraRules.trackingRange(5,Double.NaN)==0,"invalid attack reach fails closed");
        for (int restrictions=1;restrictions<256;restrictions++)
            check(!AuraRules.attackAllowed(true,false,-.1,.1,1,restrictions,false,false),"critical rejects restricted flight state "+restrictions);
        for(double vertical:new double[]{0,.001,.1,Double.NaN,Double.POSITIVE_INFINITY})
            check(!AuraRules.attackAllowed(true,false,vertical,.1,1,0,false,false),"no manufactured critical while rising or nonfinite");
        check(AuraRules.attackAllowed(true,false,-.1,.1,.91f,0,false,false),"real charged falling critical permitted");
        check(!AuraRules.attackAllowed(true,false,-.1,0,1,0,false,false),"zero fall distance is not a critical");
        check(!AuraRules.attackAllowed(true,false,-.1,.1,.9f,0,false,false),"strict critical charge threshold");
        check(!AuraRules.attackAllowed(true,false,-.1,.1,1,0,true,false),"final sprint state cannot claim critical");
        check(AuraRules.attackAllowed(true,false,-.1,.1,1,0,true,true),"ordinary sprint reset may be queued before final recheck");
        AuraSchedule clock=new AuraSchedule();clock.attempted(1000L,10_000_000L);
        for(int i=0;i<1000;i++)check(!clock.ready(1_000L+i,20),"polling cannot consume or resample deadline");
        check(clock.ready(60_001_000L,20),"jitter boundary reached regardless of prior polling");
        check(!clock.ready(999L,20),"backwards monotonic input cannot burst");
        System.out.println("Aura046Test PASS: "+checks+" tracking/critical/pacing assertions; no live-server claim");
    }
}
