import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import pulse.n9ezz.BrandPaths;
import com.google.gson.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Actual configuration migration, conflict and path handling. */
public final class BrandTest {
    static int checks;
    static void check(boolean v,String why){checks++;if(!v)throw new AssertionError(why);}
    static void write(Path p,String text)throws Exception{Files.createDirectories(p.getParent());Files.writeString(p,text);}
    public static void main(String[] args)throws Exception {
        Path temp=Files.createTempDirectory("pulsevisuals-brand-test-");
        try {
            Path old=temp.resolve("old"),fresh=temp.resolve("new");
            write(old.resolve("one.properties"),"original");write(old.resolve("nested/pulse.cfg"),"profile");
            check(BrandPaths.copyMissing(old,fresh)==2,"all config files copied");
            check(Files.readString(fresh.resolve("nested/client-profile.cfg")).equals("profile"),"config filename migrated");
            check(Files.readString(old.resolve("nested/pulse.cfg")).equals("profile"),"old config preserved");
            write(fresh.resolve("one.properties"),"user edited");
            check(BrandPaths.copyMissing(old,fresh)==0,"repeat is no-op");check(Files.readString(fresh.resolve("one.properties")).equals("user edited"),"newer settings win");
            Path bad=temp.resolve("bad"),out=temp.resolve("out");write(bad.resolve("a.cfg"),"must not partially copy");
            Files.createSymbolicLink(bad.resolve("z.cfg"),old.resolve("one.properties"));
            try{BrandPaths.copyMissing(bad,out);throw new AssertionError("symlink accepted");}catch(java.io.IOException expected){check(!Files.exists(out),"nested symlink fails before copying any file");}
            Path game=temp.resolve("game");write(game.resolve("config/n9ezz/power.properties"),"mode=hight");write(game.resolve("pulse/config/pulse.cfg"),"settings");write(game.resolve("pulse.cfg"),"rootsettings");
            BrandPaths.migrateGame(game);
            check(Files.readString(game.resolve("config/client-profile/power.properties")).equals("mode=hight"),"per-game power path migrated");
            check(Files.readString(game.resolve("client-profile/config/client-profile.cfg")).equals("settings"),"per-game profile path migrated");
            check(Files.readString(game.resolve("client-profile.cfg")).equals("rootsettings"),"root profile migrated");
            Path modern=temp.resolve("modern");
            write(modern.resolve("config/pulsevisuals/power.properties"),"newer power");
            write(modern.resolve("config/n9ezz/power.properties"),"older power");
            write(modern.resolve("config/n9ezz/friends.json"),"legacy-only friends");
            write(modern.resolve("pulsevisuals/config/pulsevisuals.cfg"),"newer profile");
            write(modern.resolve("pulse/config/pulse.cfg"),"older profile");
            write(modern.resolve("pulsevisuals.cfg"),"newer root");
            write(modern.resolve("pulse.cfg"),"older root");
            BrandPaths.migrateGame(modern);
            check(Files.readString(modern.resolve("config/client-profile/power.properties")).equals("newer power"),"PulseVisuals power takes priority over older N9Ezz");
            check(Files.readString(modern.resolve("config/client-profile/friends.json")).equals("legacy-only friends"),"missing older config still migrates");
            check(Files.readString(modern.resolve("client-profile/config/client-profile.cfg")).equals("newer profile"),"PulseVisuals nested profile takes priority");
            check(Files.readString(modern.resolve("client-profile.cfg")).equals("newer root"),"PulseVisuals root profile takes priority");
            check(Files.readString(modern.resolve("pulsevisuals.cfg")).equals("newer root")&&Files.readString(modern.resolve("pulse.cfg")).equals("older root"),"both previous root profiles preserved");
            Path populated=temp.resolve("populated");
            write(populated.resolve("config/client-profile/power.properties"),"current power");
            write(populated.resolve("config/pulsevisuals/power.properties"),"older power");
            write(populated.resolve("client-profile/config/client-profile.cfg"),"current nested");
            write(populated.resolve("pulsevisuals/config/pulsevisuals.cfg"),"older nested");
            write(populated.resolve("client-profile.cfg"),"current root");
            write(populated.resolve("pulsevisuals.cfg"),"older root");
            BrandPaths.migrateGame(populated);
            check(Files.readString(populated.resolve("config/client-profile/power.properties")).equals("current power"),"existing renamed power wins");
            check(Files.readString(populated.resolve("client-profile/config/client-profile.cfg")).equals("current nested"),"existing renamed nested profile wins");
            check(Files.readString(populated.resolve("client-profile.cfg")).equals("current root"),"existing renamed root profile wins");
            check(BrandPaths.copyMissing(temp.resolve("absent"),temp.resolve("absent-new"))==0,"missing legacy path is harmless");
            try(ZipFile z=new ZipFile(args[1])){
                JsonObject mod=JsonParser.parseString(new String(z.getInputStream(z.getEntry("fabric.mod.json")).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
                check(mod.get("name").getAsString().equals("PulseVisuals"),"visible mod renamed");check(mod.get("id").getAsString().equals("pulse"),"binary mod ID preserved");
                check(z.getEntry("META-INF/client-profile/build.json")!=null,"new provenance path");
                check(strings(z,"pulse/n9ezz/ConfigSnapshots").contains("client-profile/configs"),"packaged snapshot path uses new directory");
                check(strings(z,"pulse/n9ezz/PowerModes").contains("client-profile/power-mode.json"),"packaged power path uses new directory");
                check(strings(z,"pulse/n9ezz/FriendSupport").contains("client-profile/friends.json"),"packaged friends path uses new directory");
                Set<String> local=strings(z,"pulse/config/LocalConfigManager");
                check(local.contains("client-profile")&&local.contains("client-profile.cfg"),"packaged local config directory and filename renamed");
                check(!local.contains("pulse.cfg")&&!local.contains("pulsevisuals.cfg"),"runtime no longer selects old default config filename");
                for(String owner:List.of("pulse/config/ConfigManager","pulse/hud/core/HudElement","pulse/settings/Setting"))
                    check(strings(z,owner).contains("client-profile/config"),"packaged secondary config path renamed: "+owner);
                menuTitle(z);
            }
        }finally{try(var walk=Files.walk(temp)){for(Path p:walk.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
        System.out.println("BrandTest PASS: "+checks+" checks; real filesystem migration, client metadata and actual menu title branches");
    }
    private static Set<String> strings(ZipFile zip,String owner)throws Exception{
        ClassNode node=new ClassNode();
        new ClassReader(zip.getInputStream(zip.getEntry(owner+".class")).readAllBytes()).accept(node,0);
        Set<String> strings=new HashSet<>();
        for(MethodNode method:node.methods)for(AbstractInsnNode instruction:method.instructions)
            if(instruction instanceof LdcInsnNode literal&&literal.cst instanceof String value)strings.add(value.startsWith("\u0001")?decode(value):value);
        return strings;
    }
    /** Inspect the packaged production renderer, including the condition and branch join. */
    private static void menuTitle(ZipFile zip)throws Exception {
        ClassNode logo=new ClassNode();
        new ClassReader(zip.getInputStream(zip.getEntry("pulse/gui/core/PulseLogoOverlay.class")).readAllBytes()).accept(logo,0);
        MethodNode render=logo.methods.stream().filter(m->m.desc.equals("(Lorg/joml/Matrix3x2fStack;Lpulse/render/Renderer2D;FFII)V")).findFirst().orElseThrow();
        List<MethodInsnNode> hiddenCalls=new ArrayList<>();
        for(AbstractInsnNode instruction:render.instructions)if(instruction instanceof MethodInsnNode call
                &&call.owner.equals("pulse/n9ezz/InterfaceMode")&&call.name.equals("hidden"))hiddenCalls.add(call);
        check(hiddenCalls.size()==1,"packaged menu reads actual hidden state exactly once");
        AbstractInsnNode condition=nextCode(hiddenCalls.get(0));
        check(condition instanceof JumpInsnNode&&condition.getOpcode()==Opcodes.IFEQ,"false hidden state chooses normal title branch");
        JumpInsnNode branch=(JumpInsnNode)condition;
        AbstractInsnNode hiddenTitle=nextCode(branch),normalTitle=nextCode(branch.label);
        check(title(hiddenTitle).equals("PulseVisuals"),"hidden production branch renders PulseVisuals");
        check(title(normalTitle).equals("N9Ezz"),"normal production branch renders N9Ezz");
        AbstractInsnNode hiddenDecode=nextCode(hiddenTitle),normalDecode=nextCode(normalTitle);
        check(decoder(hiddenDecode)&&decoder(normalDecode),"both renderer titles use existing string decoder");
        AbstractInsnNode skip=nextCode(hiddenDecode);
        check(skip instanceof JumpInsnNode&&skip.getOpcode()==Opcodes.GOTO,"hidden title skips normal-title branch");
        AbstractInsnNode joined=nextCode(((JumpInsnNode)skip).label);
        check(joined==nextCode(normalDecode)&&joined instanceof VarInsnNode&&joined.getOpcode()==Opcodes.ASTORE,
                "both dynamic titles join at the same rendered string local");
    }
    private static AbstractInsnNode nextCode(AbstractInsnNode instruction){
        do{instruction=instruction.getNext();}while(instruction!=null&&instruction.getOpcode()<0);
        return instruction;
    }
    private static boolean decoder(AbstractInsnNode instruction){
        return instruction instanceof MethodInsnNode call&&call.owner.equals("pulse/n9ezz/StringCodec")
                &&call.name.equals("decode")&&call.desc.equals("(Ljava/lang/String;)Ljava/lang/String;");
    }
    private static String title(AbstractInsnNode instruction){
        check(instruction instanceof LdcInsnNode&&((LdcInsnNode)instruction).cst instanceof String,"production branch has encoded title literal");
        String encoded=(String)((LdcInsnNode)instruction).cst;
        check(encoded.startsWith("\u0001"),"title preserves original encoded string format");
        return decode(encoded);
    }
    private static String decode(String encoded){
        byte[] bytes=Base64.getDecoder().decode(encoded.substring(1));
        for(int i=0;i<bytes.length;i++)bytes[i]^=(byte)(0x59+i*31+(i>>>2)*17);
        return new String(bytes,java.nio.charset.StandardCharsets.UTF_8);
    }
}
