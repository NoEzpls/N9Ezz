import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipFile;
import javax.tools.ToolProvider;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

/**
 * Regression checks against the actual network.1 bytecode, never a Minecraft server.
 * Only dependencies are fixtures: the four network classes execute unchanged.
 * Requires a JDK 21+ (the fixture compiler) and ASM core/tree on the test classpath.
 */
public final class NetworkTest {
    private static int checks;
    private static final String BASE_SHA = "5dbb9f72359d8371b7069dbf4f421c358c28a8c11af23e06c9182ec793aada6a";
    private static final String[] PRESERVED = {
        "ru/pulse/mixin/ClientConnectionMixin.class",
        "pulse/n9ezz/mixin/CombatEntityMixin.class",
        "pulse/n9ezz/CombatDispatch.class",
        "pulse/n9ezz/NetworkPacketPolicy.class"
    };
    // Expected names are independent of NetworkPacketPolicy's private REQUIRED set.
    // Both intermediary and named runtimes are part of the existing loader contract.
    private static final String[] REQUIRED = {
        "net.minecraft.class_3944", "net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket",
        "net.minecraft.class_2645", "net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket",
        "net.minecraft.class_2651", "net.minecraft.network.packet.s2c.play.ScreenHandlerPropertyUpdateS2CPacket",
        "net.minecraft.class_2653", "net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket",
        "net.minecraft.class_9835", "net.minecraft.network.packet.s2c.play.SetPlayerInventoryS2CPacket",
        "net.minecraft.class_9834", "net.minecraft.network.packet.s2c.play.SetCursorItemS2CPacket",
        "net.minecraft.class_2708", "net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket",
        "net.minecraft.class_2743", "net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket",
        "net.minecraft.class_2649", "net.minecraft.network.packet.s2c.play.InventoryS2CPacket",
        "net.minecraft.class_6373", "net.minecraft.network.packet.s2c.common.CommonPingS2CPacket",
        "net.minecraft.class_2670", "net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket",
        "net.minecraft.class_2827", "net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket",
        "net.minecraft.class_6374", "net.minecraft.network.packet.c2s.common.CommonPongC2SPacket",
        "net.minecraft.class_2793", "net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket",
        "net.minecraft.class_4463", "net.minecraft.network.packet.s2c.play.PlayerActionResponseS2CPacket",
        "net.minecraft.class_2664", "net.minecraft.network.packet.s2c.play.ExplosionS2CPacket"
    };

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("NetworkTest baseline.jar updated.jar");
        Path baseline = Path.of(args[0]), updated = Path.of(args[1]);
        check(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(baseline))).equals(BASE_SHA), "pinned network.1 input");
        try (ZipFile old = new ZipFile(baseline.toFile()); ZipFile next = new ZipFile(updated.toFile())) {
            for (String name : PRESERVED) check(Arrays.equals(entry(old, name), entry(next, name)), "unchanged " + name);
            hook(next, "pulse/n9ezz/mixin/CombatTickMixin.class", "n9ezzAfterMovement", "method_3136", "TAIL", "afterMovement");
            hook(next, "pulse/n9ezz/mixin/AttackCallbackMixin.class", "n9ezzUnshield", "method_2918", "HEAD", "attacked");
        }
        Path temporary = Files.createTempDirectory("n9ezz-network-fixtures-");
        try {
            Path classes = compileFixtures(temporary, updated);
            // Platform parent prevents the build's real client/MC jars from leaking into fixtures.
            try (URLClassLoader loader = new URLClassLoader(new URL[]{classes.toUri().toURL(), updated.toUri().toURL()}, ClassLoader.getPlatformClassLoader())) {
                cancellation(loader);
                velocity(loader);
                dispatch(loader);
            }
        } finally {
            try (var paths = Files.walk(temporary)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
        }
        System.out.println("NetworkTest: PASS (" + checks + " checks; unchanged production classes, isolated dependency fixtures; no live network)");
    }

    private static byte[] entry(ZipFile zip, String name) throws IOException {
        var found = zip.getEntry(name);
        if (found == null) throw new AssertionError("Missing " + name);
        return zip.getInputStream(found).readAllBytes();
    }

    private static void hook(ZipFile zip, String path, String method, String target, String at, String dispatchMethod) throws IOException {
        ClassNode node = new ClassNode();
        new ClassReader(entry(zip, path)).accept(node, 0);
        MethodNode found = node.methods.stream().filter(m -> m.name.equals(method)).findFirst().orElseThrow();
        AnnotationNode inject = found.visibleAnnotations.stream().filter(a -> a.desc.endsWith("/Inject;")).findFirst().orElseThrow();
        check(((List<?>) annotation(inject, "method")).equals(List.of(target)), path + " target method");
        var positions = (List<?>) annotation(inject, "at");
        check(positions.size() == 1 && at.equals(annotation((AnnotationNode) positions.get(0), "value")), path + " hook position");
        long calls = Arrays.stream(found.instructions.toArray()).filter(i -> i instanceof MethodInsnNode m && m.owner.equals("pulse/n9ezz/CombatDispatch") && m.name.equals(dispatchMethod)).count();
        check(calls == 1, path + " one dispatch call");
    }

    private static Object annotation(AnnotationNode node, String key) {
        for (int i = 0; i < node.values.size(); i += 2) if (key.equals(node.values.get(i))) return node.values.get(i + 1);
        throw new AssertionError("Missing annotation field " + key);
    }

    private static void cancellation(ClassLoader loader) throws Exception {
        Class<?> policy = loader.loadClass("pulse.n9ezz.NetworkPacketPolicy");
        Method mayCancel = policy.getMethod("mayCancel", Object.class);
        Class<?> connection = loader.loadClass("ru.pulse.mixin.ClientConnectionMixin");
        Object receiver = connection.getConstructor().newInstance();
        Class<?> packetType = loader.loadClass("net.minecraft.class_2596");
        Class<?> callbackType = loader.loadClass("org.spongepowered.asm.mixin.injection.callback.CallbackInfo");
        Method incoming = connection.getDeclaredMethod("onChannelRead", loader.loadClass("io.netty.channel.ChannelHandlerContext"), packetType, callbackType);
        Method outgoing = connection.getDeclaredMethod("onSendPacket", packetType, callbackType);
        incoming.setAccessible(true); outgoing.setAccessible(true);
        Object bus = loader.loadClass("pulse.events.EventBusService").getField("EVENT_BUS").get(null);
        set(bus, "cancelRequested", true);
        for (String name : REQUIRED) {
            Object packet = instance(loader, name);
            check(!(boolean) mayCancel.invoke(null, packet), "mandatory policy: " + name);
            for (boolean receive : new boolean[]{true, false}) {
                Object callback = callbackType.getConstructor().newInstance();
                if (receive) incoming.invoke(receiver, null, packet, callback); else outgoing.invoke(receiver, packet, callback);
                check(!(boolean) get(callback, "cancelled"), "mandatory callback continues: " + name + "/" + receive);
                check(get(bus, "lastPacket") == packet, "event observes original packet identity");
            }
        }
        Object ordinary = instance(loader, "fixture.OrdinaryPacket");
        check((boolean) mayCancel.invoke(null, ordinary), "non-mandatory policy remains cancellable");
        check((boolean) mayCancel.invoke(null, new Object[]{null}), "null policy retains existing behavior");
        for (boolean cancelled : new boolean[]{false, true}) {
            set(bus, "cancelRequested", cancelled);
            for (boolean receive : new boolean[]{true, false}) {
                Object callback = callbackType.getConstructor().newInstance();
                if (receive) incoming.invoke(receiver, null, ordinary, callback); else outgoing.invoke(receiver, ordinary, callback);
                check((boolean) get(callback, "cancelled") == cancelled, "ordinary packet cancellation reflects event");
            }
        }
    }

    private static void velocity(ClassLoader loader) throws Exception {
        Class<?> vector = loader.loadClass("net.minecraft.class_243");
        Object mixin = instance(loader, "fixture.EntityMixinInstance");
        Method velocity = loader.loadClass("pulse.n9ezz.mixin.CombatEntityMixin").getDeclaredMethod("n9ezzVelocity", vector);
        velocity.setAccessible(true);
        double[][] samples = {{0, 0, 0}, {1, -2, 3}, {-0.25, 0.42, 0.01}, {Double.MIN_VALUE, -0.0, Double.MAX_VALUE}};
        for (double[] sample : samples) {
            Object input = vector.getConstructor(double.class, double.class, double.class).newInstance(sample[0], sample[1], sample[2]);
            check(velocity.invoke(mixin, input) == input, "server velocity object and all components preserved");
        }
        check(velocity.invoke(mixin, new Object[]{null}) == null, "velocity method is pure identity");
    }

    private static void dispatch(ClassLoader loader) throws Exception {
        Class<?> dispatch = loader.loadClass("pulse.n9ezz.CombatDispatch");
        Class<?> clientType = loader.loadClass("net.minecraft.class_310");
        Class<?> attacks = loader.loadClass("pulse.n9ezz.e");
        Object client = clientType.getField("INSTANCE").get(null);
        Object player = instance(loader, "net.minecraft.class_746");
        Object world = instance(loader, "net.minecraft.class_638");
        set(client, "field_1724", player); set(client, "field_1687", world); set(client, "camera", player);
        Method begin = dispatch.getMethod("begin", clientType);
        Method after = dispatch.getMethod("afterMovement");
        Method claim = dispatch.getMethod("claim");
        Method available = dispatch.getMethod("available");
        Method attacked = dispatch.getMethod("attacked", loader.loadClass("net.minecraft.class_1657"));
        begin.invoke(null, client);
        long firstTick = (long) dispatch.getMethod("tick").invoke(null);
        check(firstTick > 0 && count(attacks, "clears") == 1, "tick starts by discarding stale pending attack");
        check((boolean) available.invoke(null), "tick has unclaimed budget");
        check(!(boolean) claim.invoke(null), "no automatic claim before movement callback");
        after.invoke(null);
        check(count(attacks, "flushes") == 1 && flag(attacks, "firstClaim") && !flag(attacks, "secondClaim"), "single successful claim during dispatch window");
        after.invoke(null);
        check(count(attacks, "flushes") == 1, "duplicate movement callback never dispatches twice");
        check(!(boolean) claim.invoke(null), "dispatch window is closed after return");

        begin.invoke(null, client);
        check((long) dispatch.getMethod("tick").invoke(null) == firstTick + 1, "monotonic tick counter");
        attacked.invoke(null, player);
        after.invoke(null);
        check(!flag(attacks, "firstClaim") && !(boolean) available.invoke(null), "manual local attack consumes same tick budget");
        begin.invoke(null, client);
        attacked.invoke(null, instance(loader, "net.minecraft.class_1657"));
        after.invoke(null);
        check(flag(attacks, "firstClaim"), "another player's attack does not consume local budget");

        for (String change : List.of("world", "player", "camera", "spectator", "disconnect")) {
            set(client, "field_1724", player); set(client, "field_1687", world); set(client, "camera", player); set(player, "spectator", false);
            begin.invoke(null, client);
            int before = count(attacks, "flushes"), cleared = count(attacks, "clears");
            switch (change) {
                case "world" -> set(client, "field_1687", instance(loader, "net.minecraft.class_638"));
                case "player" -> set(client, "field_1724", instance(loader, "net.minecraft.class_746"));
                case "camera" -> set(client, "camera", instance(loader, "net.minecraft.class_1297"));
                case "spectator" -> set(player, "spectator", true);
                case "disconnect" -> set(client, "field_1724", null);
            }
            after.invoke(null);
            check(count(attacks, "flushes") == before && count(attacks, "clears") == cleared + 1, change + " discards queued autoattack");
            check(!(boolean) claim.invoke(null), change + " leaves no dispatch window");
        }

        set(client, "field_1724", player); set(client, "field_1687", world); set(client, "camera", player); set(player, "spectator", false);
        begin.invoke(null, client); attacks.getField("fail").setBoolean(null, true);
        int before = count(attacks, "flushes");
        try { after.invoke(null); throw new AssertionError("Expected fixture exception"); }
        catch (InvocationTargetException expected) { check(expected.getCause() instanceof IllegalStateException, "fixture failure propagates"); }
        check(!(boolean) claim.invoke(null), "finally closes dispatch window on flush failure");
        after.invoke(null);
        check(count(attacks, "flushes") == before + 1, "failed dispatch is not retried in same tick");
        attacks.getField("fail").setBoolean(null, false);
        begin.invoke(null, client); after.invoke(null);
        check(flag(attacks, "firstClaim"), "new tick resets dispatch gate after previous error");
    }

    private static int count(Class<?> type, String name) throws Exception { return type.getField(name).getInt(null); }
    private static boolean flag(Class<?> type, String name) throws Exception { return type.getField(name).getBoolean(null); }
    private static Object instance(ClassLoader loader, String name) throws Exception { return loader.loadClass(name).getConstructor().newInstance(); }
    private static Object get(Object receiver, String name) throws Exception { return receiver.getClass().getField(name).get(receiver); }
    private static void set(Object receiver, String name, Object value) throws Exception { receiver.getClass().getField(name).set(receiver, value); }
    private static void check(boolean condition, String description) { checks++; if (!condition) throw new AssertionError(description); }

    private static Path compileFixtures(Path root, Path updated) throws IOException {
        Map<String, String> sources = new LinkedHashMap<>();
        sources.put("net.minecraft.class_1297", "public class class_1297 {}");
        sources.put("net.minecraft.class_1657", "public class class_1657 extends class_1297 {}");
        sources.put("net.minecraft.class_746", "public class class_746 extends class_1657 { public boolean spectator; public boolean method_5765(){return spectator;} public class_243 method_18798(){return new class_243(0,0,0);} public void method_18799(class_243 v){} }");
        sources.put("net.minecraft.class_1937", "public class class_1937 {}");
        sources.put("net.minecraft.class_638", "public class class_638 extends class_1937 {}");
        sources.put("net.minecraft.class_310", "public class class_310 { public static final class_310 INSTANCE=new class_310(); public class_746 field_1724; public class_638 field_1687; public class_1297 camera; public static class_310 method_1551(){return INSTANCE;} public class_1297 method_1560(){return camera;} }");
        sources.put("net.minecraft.class_241", "public class class_241 { public final float field_1343,field_1342; public class_241(float x,float y){field_1343=x;field_1342=y;} }");
        sources.put("net.minecraft.class_243", "public class class_243 { public final double x,y,z; public class_243(double x,double y,double z){this.x=x;this.y=y;this.z=z;} public class_243 method_1020(class_243 v){return this;} public class_243 method_1019(class_243 v){return this;} public class_243 method_1021(double a){return this;} }");
        sources.put("net.minecraft.class_2248", "public class class_2248 {}");
        sources.put("net.minecraft.class_2246", "public class class_2246 {public static class_2248 field_10343=new class_2248();}");
        sources.put("net.minecraft.class_2680", "public class class_2680 {public boolean method_27852(class_2248 b){return false;}}");
        sources.put("net.minecraft.class_2596", "public interface class_2596<T> {}");
        sources.put("io.netty.channel.ChannelHandlerContext", "public interface ChannelHandlerContext {}");
        sources.put("org.spongepowered.asm.mixin.injection.callback.CallbackInfo", "public class CallbackInfo {public boolean cancelled; public void cancel(){cancelled=true;}}");
        sources.put("meteordevelopment.orbit.ICancellable", "public interface ICancellable {}");
        sources.put("pulse.events.PacketEvent", "public class PacketEvent implements meteordevelopment.orbit.ICancellable { public enum MessageDirection {RECIEVE,SEND} public final net.minecraft.class_2596<?> packet; public boolean cancelled; public PacketEvent(net.minecraft.class_2596<?> packet,MessageDirection direction){this.packet=packet;} public boolean c(){return cancelled;} }");
        sources.put("meteordevelopment.orbit.EventBus", "public class EventBus { public boolean cancelRequested; public Object lastPacket; public ICancellable post(ICancellable event){pulse.events.PacketEvent p=(pulse.events.PacketEvent)event; lastPacket=p.packet; p.cancelled=cancelRequested; return event;} }");
        sources.put("pulse.events.EventBusService", "public class EventBusService {public static final meteordevelopment.orbit.EventBus EVENT_BUS=new meteordevelopment.orbit.EventBus();}");
        sources.put("pulse.n9ezz.e", "public class e { public static int clears,flushes; public static boolean firstClaim,secondClaim,fail; public static void m1(){clears++;} public static boolean m5(){return false;} public static void m8(){flushes++;if(fail)throw new IllegalStateException(\"fixture flush failure\");firstClaim=CombatDispatch.claim();secondClaim=CombatDispatch.claim();} }");
        sources.put("pulse.n9ezz.u28", "public class u28 {public void flush(){}}");
        sources.put("pulse.n9ezz.u22", "public class u22 {public boolean isEnabled(){return false;} public double strength(){return 0;}}");
        sources.put("pulse.n9ezz.u24", "public class u24 {public boolean isEnabled(){return false;} public net.minecraft.class_243 multiplier(net.minecraft.class_243 v){return v;}}");
        sources.put("pulse.n9ezz.N9Ezz", "public class N9Ezz {public static u28 CRYSTAL;public static u22 NOPUSH;public static u24 ANTIWEB;}");
        sources.put("net.fabricmc.fabric.api.event.Event", "public class Event<T> {public void register(T listener){}}");
        sources.put("net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents", "public class ClientTickEvents {public interface StartTick {void onStartTick(net.minecraft.class_310 client);} public static final net.fabricmc.fabric.api.event.Event<StartTick> START_CLIENT_TICK=new net.fabricmc.fabric.api.event.Event<>();}");
        sources.put("fixture.EntityMixinInstance", "public class EntityMixinInstance extends pulse.n9ezz.mixin.CombatEntityMixin {}");
        sources.put("fixture.OrdinaryPacket", "public class OrdinaryPacket implements net.minecraft.class_2596<Object> {}");
        for (String name : REQUIRED) sources.put(name, "public class " + name.substring(name.lastIndexOf('.') + 1) + " implements net.minecraft.class_2596<Object> {}");
        Path classes = Files.createDirectories(root.resolve("classes"));
        List<String> arguments = new ArrayList<>(List.of("--release", "21", "-proc:none", "-nowarn", "-classpath", updated.toAbsolutePath().toString(), "-d", classes.toString()));
        for (var source : sources.entrySet()) {
            Path file = root.resolve("src").resolve(source.getKey().replace('.', '/') + ".java");
            Files.createDirectories(file.getParent());
            String packageName = source.getKey().substring(0, source.getKey().lastIndexOf('.'));
            Files.writeString(file, "package " + packageName + ";\n" + source.getValue() + "\n");
            arguments.add(file.toString());
        }
        var compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("NetworkTest requires a complete JDK 21+ to compile isolated fixtures");
        check(compiler.run(null, null, null, arguments.toArray(String[]::new)) == 0, "fixture compilation");
        return classes;
    }
}
