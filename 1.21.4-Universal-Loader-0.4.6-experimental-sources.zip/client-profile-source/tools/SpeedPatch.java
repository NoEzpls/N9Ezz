import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Reuses the registered TargetStrafe slot and native input callback for Speed. */
public final class SpeedPatch implements Opcodes {
    static final String U="pulse/n9ezz/u20", R="pulse/n9ezz/SpeedV2Runtime", SL="pulse/settings/SliderSetting", BO="pulse/settings/BooleanSetting";
    static ClassNode read(Map<String,byte[]> f,String n){ClassNode c=new ClassNode();new ClassReader(f.get(n+".class")).accept(c,0);return c;}
    static void write(Map<String,byte[]> f,ClassNode c){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);f.put(c.name+".class",w.toByteArray());}
    static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;}
    static MethodInsnNode call(String owner,String name,String desc){return new MethodInsnNode(INVOKESTATIC,owner,name,desc,false);}
    static void slider(InsnList p,String field,String label,String tooltip,float value,float min,float max,float step){
        p.add(new VarInsnNode(ALOAD,0));p.add(new TypeInsnNode(NEW,SL));p.add(new InsnNode(DUP));p.add(new LdcInsnNode(label));p.add(new LdcInsnNode(tooltip));
        for(float f:new float[]{value,min,max,step})p.add(new LdcInsnNode(f));
        p.add(new MethodInsnNode(INVOKESPECIAL,SL,"<init>","(Ljava/lang/String;Ljava/lang/String;FFFF)V",false));p.add(new FieldInsnNode(PUTFIELD,U,field,"L"+SL+";"));
    }
    public static void apply(Map<String,byte[]> files){
        ClassNode c=read(files,U);
        for(AnnotationNode a:c.visibleAnnotations)if(a.desc.equals("Lpulse/module/ModuleInfo;"))for(int k=0;k<a.values.size();k+=2){
            if(a.values.get(k).equals("a"))a.values.set(k+1,"Speed");
            if(a.values.get(k).equals("b"))a.values.set(k+1,"Горизонтальный разгон и преследование цели. Мощность 1–100: множитель базовой скорости 1.04–5. Сервер может отклонить разгон; коррекция ставит Speed на паузу.");
        }
        c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,"speedPower","L"+SL+";",null,null));
        c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,"pursue","L"+BO+";",null,null));
        c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,"freeMovement","L"+BO+";",null,null));
        c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,"targetRange","L"+SL+";",null,null));
        MethodNode init=c.methods.stream().filter(m->m.name.equals("<init>")).findFirst().orElseThrow();
        for(AbstractInsnNode i:init.instructions.toArray()) {
            if(i instanceof LdcInsnNode l&&"Радиус".equals(l.cst))l.cst="Дистанция остановки";
            if(i.getOpcode()==RETURN){InsnList p=new InsnList();
                slider(p,"speedPower","Сила Speed (1–100)","1 = ×1.04, 100 = ×5 базовой горизонтальной скорости. Уровни Hight/Extra не меняют эту шкалу.",15,1,100,1);
                p.add(new VarInsnNode(ALOAD,0));p.add(new TypeInsnNode(NEW,BO));p.add(new InsnNode(DUP));p.add(new LdcInsnNode("Преследовать слабую цель"));p.add(new InsnNode(ICONST_0));p.add(new MethodInsnNode(INVOKESPECIAL,BO,"<init>","(Ljava/lang/String;Z)V",false));p.add(new FieldInsnNode(PUTFIELD,U,"pursue","L"+BO+";"));
                p.add(new VarInsnNode(ALOAD,0));p.add(new TypeInsnNode(NEW,BO));p.add(new InsnNode(DUP));p.add(new LdcInsnNode("Свободное движение"));p.add(new LdcInsnNode("WASD без преследования. Пока клавиши удерживаются, автоповороты KillAura/Triggerbot не меняют направление ходьбы; мышь остаётся управлением. Отпустите клавиши, чтобы выбрать направление камеры заново."));p.add(new InsnNode(ICONST_1));p.add(new MethodInsnNode(INVOKESPECIAL,BO,"<init>","(Ljava/lang/String;Ljava/lang/String;Z)V",false));p.add(new FieldInsnNode(PUTFIELD,U,"freeMovement","L"+BO+";"));
                slider(p,"targetRange","Радиус поиска цели","Видимые подходящие игроки; сначала меньше здоровья с поглощением, затем ближе. Juggernaut использует общую цель.",12,3,32,1);
                init.instructions.insertBefore(i,p);
            }
        }
        MethodNode input=c.methods.stream().filter(m->m.name.equals("input")).findFirst().orElseThrow();reset(input);InsnList p=input.instructions;
        p.add(new VarInsnNode(ALOAD,1));
        p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,U,"speedPower","L"+SL+";"));p.add(new MethodInsnNode(INVOKEVIRTUAL,SL,"get","()F",false));p.add(new InsnNode(F2D));
        p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,U,"pursue","L"+BO+";"));p.add(new MethodInsnNode(INVOKEVIRTUAL,BO,"get","()Z",false));
        for(String field:List.of("targetRange","radius")){p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,U,field,"L"+SL+";"));p.add(new MethodInsnNode(INVOKEVIRTUAL,SL,"get","()F",false));p.add(new InsnNode(F2D));}
        p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,U,"freeMovement","L"+BO+";"));p.add(new MethodInsnNode(INVOKEVIRTUAL,BO,"get","()Z",false));
        p.add(call(R,"input","(Lnet/minecraft/class_241;DZDDZ)Lnet/minecraft/class_241;"));p.add(new InsnNode(ARETURN));
        for(String name:List.of("onEnable","onDisable")){
            MethodNode m=new MethodNode(ACC_PUBLIC,name,"()V",null,null);p=m.instructions;p.add(call(R,name.equals("onEnable")?"enable":"disable","()V"));p.add(new VarInsnNode(ALOAD,0));p.add(new MethodInsnNode(INVOKESPECIAL,c.superName,name,"()V",false));p.add(new InsnNode(RETURN));c.methods.add(m);
        }
        MethodNode collect=new MethodNode(ACC_PUBLIC,"collectSettings","()V",null,null);p=collect.instructions;p.add(new VarInsnNode(ALOAD,0));p.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"collectSettings","()V",false));
        // Keep old fields for existing config compatibility, but do not show controls
        // which the replacement movement controller no longer consumes.
        for(String field:List.of("power","direction")){p.add(new VarInsnNode(ALOAD,0));p.add(new MethodInsnNode(INVOKEVIRTUAL,U,"settings","()Ljava/util/List;",false));p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,U,field,field.equals("power")?"L"+SL+";":"Lpulse/settings/ModeSetting;"));p.add(new MethodInsnNode(INVOKEINTERFACE,"java/util/List","remove","(Ljava/lang/Object;)Z",true));p.add(new InsnNode(POP));}p.add(new InsnNode(RETURN));c.methods.add(collect);write(files,c);
        c=read(files,"ru/pulse/mixin/MixinClientPlayNetworkHandler");
        hook(c,"pulsevisuals$speedCorrection","net/minecraft/class_2708","method_11157","correction",false);
        hook(c,"pulsevisuals$speedVelocity","net/minecraft/class_2743","method_11132","velocity",true);
        for(MethodNode m:c.methods)if(m.name.equals("onClearWorld")){InsnList q=new InsnList();q.add(call(R,"disconnect","()V"));m.instructions.insert(q);}
        write(files,c);
    }
    static void hook(ClassNode c,String name,String packet,String method,String callback,boolean passPacket){
        MethodNode m=new MethodNode(ACC_PRIVATE,name,"(L"+packet+";Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V",null,null);
        AnnotationNode inject=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/Inject;");inject.values=new ArrayList<>();inject.values.add("method");inject.values.add(List.of(method+"(L"+packet+";)V"));inject.values.add("require");inject.values.add(1);
        AnnotationNode at=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/At;");at.values=new ArrayList<>(List.of("value","TAIL"));inject.values.add("at");inject.values.add(List.of(at));m.visibleAnnotations=new ArrayList<>(List.of(inject));
        // TAIL observes the native applied update. Never cancels, mutates, delays, or
        // acknowledges packets itself; the vanilla handler retains full ownership.
        if(passPacket)m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(call(R,callback,passPacket?"(L"+packet+";)V":"()V"));m.instructions.add(new InsnNode(RETURN));c.methods.add(m);
    }
}
