import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Targeted patch of the verified network.1 binary. Unknown layouts fail the build. */
public final class CombatPatch implements Opcodes {
    public static final Set<String> CHANGED = Set.of(
            "pulse/n9ezz/e.class", "pulse/n9ezz/d.class", "pulse/n9ezz/u5.class",
            "pulse/n9ezz/u0.class", "pulse/n9ezz/u1.class",
            "pulse/n9ezz/N9Ezz.class", "pulse/n9ezz/ViewMotion.class",
            "pulse/n9ezz/mixin/ProjectileTargetMixin.class");
    private static final String RULES = "pulse/n9ezz/CombatRules6";
    private static final String READY = "n9ezz$automaticAttackAllowed";
    private static final String PLAYER = "net/minecraft/class_746";
    private CombatPatch() {}

    public static void apply(Map<String, byte[]> entries) {
        patchAttacks(entries);
        patchAimPoint(entries);
        patchDamage(entries);
        patchView(entries);
        patchManualPicking(entries);
        patchAttackLabels(entries);
    }

    private static ClassNode read(Map<String, byte[]> entries, String name) {
        byte[] bytes = entries.get(name + ".class");
        if (bytes == null) throw new IllegalArgumentException("Missing " + name);
        ClassNode n = new ClassNode(); new ClassReader(bytes).accept(n, ClassReader.EXPAND_FRAMES); return n;
    }
    private static void write(Map<String, byte[]> entries, ClassNode n) {
        // Existing frames are kept; each inserted branch below supplies its own frame.
        // This avoids class loading untrusted Minecraft/mod code during the build.
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS); n.accept(w);
        entries.put(n.name + ".class", w.toByteArray());
    }
    private static MethodNode method(ClassNode c, String name, String desc) {
        return c.methods.stream().filter(m -> m.name.equals(name) && (desc == null || m.desc.equals(desc)))
                .reduce((a, b) -> { throw new IllegalArgumentException("Ambiguous " + c.name + "." + name); })
                .orElseThrow(() -> new IllegalArgumentException("Missing " + c.name + "." + name));
    }
    private static List<MethodInsnNode> calls(MethodNode m, String owner, String name) {
        List<MethodInsnNode> out = new ArrayList<>();
        for (AbstractInsnNode i : m.instructions) if (i instanceof MethodInsnNode n
                && n.owner.equals(owner) && n.name.equals(name)) out.add(n);
        return out;
    }
    private static void count(int actual, int expected, String what) {
        if (actual != expected) throw new IllegalArgumentException(what + ": expected " + expected + ", got " + actual);
    }
    private static MethodInsnNode call(String owner, String name, String desc) {
        return new MethodInsnNode(INVOKESTATIC, owner, name, desc, false);
    }
    private static InsnList gate(boolean finalCheck) {
        InsnList p = new InsnList(); LabelNode ok = new LabelNode();
        if (finalCheck) p.add(new InsnNode(ICONST_0));
        else {
            p.add(new VarInsnNode(ALOAD, 1));
            p.add(new MethodInsnNode(INVOKEVIRTUAL, "pulse/n9ezz/Attacks$Options", "resetSprint", "()Z", false));
        }
        p.add(call("pulse/n9ezz/e", READY, "(Z)Z"));
        p.add(new JumpInsnNode(IFNE, ok));
        if (finalCheck) {
            p.add(new LdcInsnNode("Автоудар отложен: предмет, заряд или условия настоящего крита"));
            p.add(call("pulse/n9ezz/e", "m4", "(Ljava/lang/String;)V"));
            p.add(new InsnNode(RETURN));
        } else { p.add(new InsnNode(ICONST_0)); p.add(new InsnNode(IRETURN)); }
        Object[] locals = finalCheck
                ? new Object[]{"pulse/n9ezz/Attacks$Pending", "net/minecraft/class_310", "pulse/n9ezz/Attacks$Options", "net/minecraft/class_1657", LONG}
                : new Object[]{"net/minecraft/class_1657", "pulse/n9ezz/Attacks$Options"};
        p.add(ok); p.add(new FrameNode(F_NEW, locals.length, locals, 0, null)); return p;
    }
    private static void patchAttacks(Map<String, byte[]> entries) {
        ClassNode c = read(entries, "pulse/n9ezz/e");
        if (c.methods.stream().anyMatch(m -> m.name.equals(READY))) throw new IllegalArgumentException("Combat patch already applied");
        // valid() is used at queue time AND after vanilla movement is sent. This
        // catches taking off, beginning to eat, a slot change, or landing mid-tick.
        MethodNode valid = method(c, "m6", "(Lnet/minecraft/class_1657;Lpulse/n9ezz/Attacks$Options;)Z");
        valid.instructions.insert(gate(false));
        MethodNode flush = method(c, "m8", "()V");
        var rays = calls(flush, "pulse/n9ezz/d", "m28"); count(rays.size(), 1, "Final ray");
        // An enlarged selection box is a client aid, not the server's collision box.
        // The final attack ray must intersect the actual entity within native reach.
        InsnList physical = new InsnList(); physical.add(new InsnNode(POP)); physical.add(new InsnNode(ICONST_0));
        flush.instructions.insertBefore(rays.get(0), physical);
        var claims = calls(flush, "pulse/n9ezz/CombatDispatch", "claim"); count(claims.size(), 1, "Attack budget claim");
        // Pending sprint reset is only an intention. Do not claim a budget or send
        // an attack until the actual player state permits a non-sprinting critical.
        flush.instructions.insertBefore(claims.get(0), gate(true));
        // Keep diagnostics factual even if the acquisition option requested an expanded box.
        for (AbstractInsnNode i : flush.instructions) if (i instanceof LdcInsnNode l && "Расширенный".equals(l.cst)) l.cst = "Физический";
        // Force the diagnostic's legacy expanded conditional false as well, so
        // encoded string constants in another binary layout cannot claim a larger hit.
        var expanded = calls(flush, "pulse/n9ezz/Attacks$Options", "expanded");
        count(expanded.size(), 2, "Final ray and diagnostic expanded options");
        InsnList diagnostic = new InsnList(); diagnostic.add(new InsnNode(POP)); diagnostic.add(new InsnNode(ICONST_0));
        flush.instructions.insert(expanded.get(1), diagnostic);
        c.methods.add(readyMethod());
        write(entries, c);
    }
    private static MethodNode readyMethod() {
        MethodNode m = new MethodNode(ACC_PRIVATE | ACC_STATIC, READY, "(Z)Z", null, null);
        InsnList p = m.instructions;
        p.add(call("net/minecraft/class_310", "method_1551", "()Lnet/minecraft/class_310;"));
        p.add(new FieldInsnNode(GETFIELD, "net/minecraft/class_310", "field_1724", "L" + PLAYER + ";"));
        p.add(new InsnNode(DUP)); p.add(new VarInsnNode(ASTORE, 1));
        LabelNode present = new LabelNode(); p.add(new JumpInsnNode(IFNONNULL, present));
        p.add(new InsnNode(ICONST_0)); p.add(new InsnNode(IRETURN)); p.add(present);
        p.add(new FrameNode(F_NEW, 2, new Object[]{INTEGER, PLAYER}, 0, null));
        p.add(new InsnNode(ICONST_0)); p.add(new VarInsnNode(ISTORE, 2));
        // These names were checked against the supplied 1.21.11 Minecraft bytecode.
        String[] prohibitions = {"method_6115", "method_6101", "method_5799", "method_5771",
                "method_74025", "method_5765", "method_6128"};
        for (int bit = 0; bit < prohibitions.length; bit++) {
            p.add(new VarInsnNode(ILOAD, 2)); playerCall(p, prohibitions[bit], "()Z");
            p.add(new IntInsnNode(BIPUSH, bit)); p.add(new InsnNode(ISHL)); p.add(new InsnNode(IOR));
            p.add(new VarInsnNode(ISTORE, 2));
        }
        p.add(new VarInsnNode(ILOAD, 2)); playerCall(p, "method_31549", "()Lnet/minecraft/class_1656;");
        p.add(new FieldInsnNode(GETFIELD, "net/minecraft/class_1656", "field_7479", "Z"));
        p.add(new IntInsnNode(BIPUSH, 7)); p.add(new InsnNode(ISHL)); p.add(new InsnNode(IOR));
        p.add(new VarInsnNode(ISTORE, 2));
        playerCall(p, "method_24828", "()Z");
        playerCall(p, "method_18798", "()Lnet/minecraft/class_243;");
        p.add(new FieldInsnNode(GETFIELD, "net/minecraft/class_243", "field_1351", "D"));
        p.add(new VarInsnNode(ALOAD, 1)); p.add(new FieldInsnNode(GETFIELD, PLAYER, "field_6017", "D"));
        p.add(new VarInsnNode(ALOAD, 1)); p.add(new InsnNode(FCONST_0));
        p.add(new MethodInsnNode(INVOKEVIRTUAL, PLAYER, "method_7261", "(F)F", false));
        p.add(new VarInsnNode(ILOAD, 2)); playerCall(p, "method_5624", "()Z"); p.add(new VarInsnNode(ILOAD, 0));
        p.add(call(RULES, "automaticAttackAllowed", "(ZDDFIZZ)Z")); p.add(new InsnNode(IRETURN));
        return m;
    }
    private static void playerCall(InsnList p, String name, String desc) {
        p.add(new VarInsnNode(ALOAD, 1)); p.add(new MethodInsnNode(INVOKEVIRTUAL, PLAYER, name, desc, false));
    }
    private static void patchAimPoint(Map<String, byte[]> entries) {
        ClassNode c = read(entries, "pulse/n9ezz/d");
        MethodNode m = method(c, "m18", "(Lnet/minecraft/class_1657;FIZ)Lnet/minecraft/class_243;");
        count(calls(m, "pulse/n9ezz/d", "m5").size(), 1, "Aim box lookup");
        // Aim inside physical geometry. Expanded geometry remains available for
        // outlining/acquiring targets; aiming at its empty margin causes misses.
        InsnList p = new InsnList(); p.add(new InsnNode(ICONST_0)); p.add(new VarInsnNode(ISTORE, 3));
        m.instructions.insert(p); write(entries, c);
    }
    private static void patchDamage(Map<String, byte[]> entries) {
        ClassNode u = read(entries, "pulse/n9ezz/u5"); MethodNode ctor = method(u, "<init>", "()V");
        var sliders = calls(ctor, "pulse/settings/SliderSetting", "<init>"); count(sliders.size(), 1, "Damage slider");
        AbstractInsnNode max = previousCode(previousCode(sliders.get(0)));
        if (max.getOpcode() != FCONST_1) throw new IllegalArgumentException("Unexpected damage slider maximum");
        ctor.instructions.set(max, new LdcInsnNode(8.0f));
        if (u.visibleAnnotations != null) for (AnnotationNode a : u.visibleAnnotations) if (a.desc.equals("Lpulse/module/ModuleInfo;")) {
            for (int i = 0; i < a.values.size(); i += 2) if ("b".equals(a.values.get(i)))
                a.values.set(i + 1, "Дополнительные 0.2–8 единиц урона только в одиночном мире. На удалённом сервере бонус равен нулю.");
        }
        write(entries, u);
        ClassNode n = read(entries, "pulse/n9ezz/N9Ezz"); MethodNode tick = method(n, "tick", null);
        int changed = 0;
        for (AbstractInsnNode i : tick.instructions.toArray()) if (i instanceof FieldInsnNode f
                && f.getOpcode() == PUTSTATIC && f.name.equals("localBonus") && f.desc.equals("D")) {
            tick.instructions.insertBefore(f, call(RULES, "localDamageBonus", "(D)D")); changed++;
        }
        count(changed, 1, "Local damage assignment");
        // Preserve the original mc.getServer()!=null guard and PlayerDamageMixin;
        // a multiplayer client cannot assign server damage via an attack packet.
        write(entries, n);
    }
    private static AbstractInsnNode previousCode(AbstractInsnNode n) {
        do { n = n.getPrevious(); } while (n != null && n.getOpcode() < 0); return n;
    }
    private static void patchView(Map<String, byte[]> entries) {
        ClassNode c = read(entries, "pulse/n9ezz/ViewMotion"); MethodNode m = method(c, "frame", null);
        var subtract = calls(m, "net/minecraft/class_243", "method_1020"); count(subtract.size(), 1, "View direction delta");
        AbstractInsnNode store = subtract.get(0).getNext();
        if (!(store instanceof VarInsnNode v) || v.getOpcode() != ASTORE || v.var != 15)
            throw new IllegalArgumentException("Unexpected view delta local");
        InsnList p = new InsnList();
        for (String axis : new String[]{"field_1352", "field_1351", "field_1350"}) {
            p.add(new VarInsnNode(ALOAD, 15)); p.add(new FieldInsnNode(GETFIELD, "net/minecraft/class_243", axis, "D"));
        }
        p.add(call(RULES, "meaningfulDirection", "(DDD)Z")); LabelNode meaningful = new LabelNode();
        p.add(new JumpInsnNode(IFNE, meaningful));
        // Reset stale easing/remainders too: a later target must not inherit a turn
        // calculated from a coincident or non-finite vector.
        p.add(new VarInsnNode(ALOAD, 0)); p.add(new MethodInsnNode(INVOKEVIRTUAL, c.name, "reset", "()V", false));
        p.add(new InsnNode(RETURN)); p.add(meaningful);
        Object[] locals = {c.name, "net/minecraft/class_243", LONG, FLOAT, DOUBLE, DOUBLE,
                INTEGER, "net/minecraft/class_310", FLOAT, FLOAT, DOUBLE, "net/minecraft/class_243"};
        p.add(new FrameNode(F_NEW, locals.length, locals, 0, null));
        m.instructions.insert(store, p); write(entries, c);
    }
    private static void patchManualPicking(Map<String, byte[]> entries) {
        ClassNode c = read(entries, "pulse/n9ezz/mixin/ProjectileTargetMixin");
        MethodNode m = method(c, "n9ezz$targetBox", "(Lnet/minecraft/class_1297;)Lnet/minecraft/class_238;");
        count(calls(m, "pulse/n9ezz/d", "m4").size(), 1, "Manual picking expanded hook");
        // Vanilla/manual picking must not produce attacks on the empty expanded
        // margin either. Preserve the redirect annotation but return physical geometry.
        m.instructions.clear(); m.tryCatchBlocks.clear(); if (m.localVariables != null) m.localVariables.clear();
        m.instructions.add(new VarInsnNode(ALOAD, 0));
        m.instructions.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/class_1297", "method_5829", "()Lnet/minecraft/class_238;", false));
        m.instructions.add(new InsnNode(ARETURN)); m.maxLocals = 1; m.maxStack = 1;
        write(entries, c);
    }
    private static void patchAttackLabels(Map<String, byte[]> entries) {
        for (String name : List.of("pulse/n9ezz/u0", "pulse/n9ezz/u1")) {
            ClassNode c = read(entries, name); MethodNode ctor = method(c, "<init>", "()V");
            int changed = 0;
            for (AbstractInsnNode i : ctor.instructions) if (i instanceof LdcInsnNode l
                    && "Базовый лимит при силе 1. Уровень и мощность меняют его до 20; заряд оружия сохраняется".equals(l.cst)) {
                l.cst = "Базовый лимит при силе 1. Уровень и мощность масштабируют темп до 20 попыток/с; отдельно действует порог заряда оружия.";
                changed++;
            }
            count(changed, 1, name + " CPS tooltip");
            // Setting names are persisted as profile keys. Keep their names and fields,
            // while explaining the stricter shared gate even for old imported values.
            tooltip(ctor, "Заряд удара (%)", "pulse/settings/SliderSetting", "(Ljava/lang/String;FFFF)V",
                    "Рабочий порог заряда на земле: 50–100%. Для настоящего крита в воздухе нужно больше 90%.");
            tooltip(ctor, "Отпускать свой щит", "pulse/settings/BooleanSetting", "(Ljava/lang/String;Z)V",
                    "Совместимость профиля: автоудар не отпускает свой щит и ждёт завершения использования предмета.");
            tooltip(ctor, "Обычное попадание", "pulse/settings/BooleanSetting", "(Ljava/lang/String;Z)V",
                    "Выбор геометрии поиска цели. Сам удар всегда проверяется по физическому хитбоксу и обычной дальности.");
            write(entries, c);
        }
    }
    private static void tooltip(MethodNode ctor, String setting, String owner, String oldDesc, String text) {
        int changed = 0;
        for (AbstractInsnNode i : ctor.instructions.toArray()) if (i instanceof LdcInsnNode l && setting.equals(l.cst)) {
            MethodInsnNode init = null;
            for (AbstractInsnNode n = i.getNext(); n != null; n = n.getNext()) {
                if (n instanceof FieldInsnNode) break;
                if (n instanceof MethodInsnNode call) { init = call; break; }
            }
            if (init == null || !init.owner.equals(owner) || !init.name.equals("<init>") || !init.desc.equals(oldDesc))
                throw new IllegalArgumentException("Unexpected setting constructor: " + setting);
            ctor.instructions.insert(i, new LdcInsnNode(text));
            init.desc = oldDesc.replace("(Ljava/lang/String;", "(Ljava/lang/String;Ljava/lang/String;");
            changed++;
        }
        count(changed, 1, setting + " compatibility tooltip");
    }
}
