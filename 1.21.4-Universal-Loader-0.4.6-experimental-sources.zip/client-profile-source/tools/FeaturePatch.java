import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Responsive combat and reversible local commands. Never manufactures network movement. */
public final class FeaturePatch implements Opcodes {
    static final String IM="pulse/n9ezz/InterfaceMode", MC="net/minecraft/class_310", P="net/minecraft/class_746";
    static final String V="net/minecraft/class_243", B="net/minecraft/class_238";
    public static void apply(Map<String,byte[]> files) {
        sprint(files); points(files); preset(files); commands(files);
    }
    static ClassNode read(Map<String,byte[]> f,String n){ClassNode c=new ClassNode();new ClassReader(f.get(n+".class")).accept(c,ClassReader.EXPAND_FRAMES);return c;}
    static void write(Map<String,byte[]> f,ClassNode c){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);f.put(c.name+".class",w.toByteArray());}
    static MethodNode method(ClassNode c,String n){return c.methods.stream().filter(m->m.name.equals(n)).findFirst().orElseThrow();}
    static MethodInsnNode call(String owner,String n,String d){return new MethodInsnNode(INVOKESTATIC,owner,n,d,false);}
    static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;}
    static void frame(InsnList p,Object... locals){p.add(new FrameNode(F_NEW,locals.length,locals,0,null));}
    static void player(InsnList p){p.add(call(MC,"method_1551","()L"+MC+";"));p.add(new FieldInsnNode(GETFIELD,MC,"field_1724","L"+P+";"));}
    static void sprint(Map<String,byte[]> f){
        ClassNode c=read(f,"pulse/n9ezz/e");
        MethodNode airborne=new MethodNode(ACC_PRIVATE|ACC_STATIC,"pulsevisuals$airborne","()Z",null,null);
        InsnList p=airborne.instructions;player(p);p.add(new VarInsnNode(ASTORE,0));p.add(new VarInsnNode(ALOAD,0));LabelNode missing=new LabelNode();p.add(new JumpInsnNode(IFNULL,missing));
        p.add(new VarInsnNode(ALOAD,0));p.add(new MethodInsnNode(INVOKEVIRTUAL,P,"method_24828","()Z",false));p.add(new InsnNode(ICONST_1));p.add(new InsnNode(IXOR));p.add(new InsnNode(IRETURN));p.add(missing);frame(p,P);p.add(new InsnNode(ICONST_0));p.add(new InsnNode(IRETURN));c.methods.add(airborne);
        // Ground attacks do not need a sprint reset. The old unconditional reset cost
        // movement and a tick of damage even when no critical was possible.
        for(AbstractInsnNode i:method(c,"m5").instructions.toArray())if(i.getOpcode()==IRETURN){InsnList q=new InsnList();q.add(call(c.name,airborne.name,"()Z"));q.add(new InsnNode(IAND));method(c,"m5").instructions.insertBefore(i,q);}
        int found=0;MethodNode flush=method(c,"m8");
        for(AbstractInsnNode i:flush.instructions.toArray())if(i instanceof MethodInsnNode m&&m.owner.equals("pulse/n9ezz/Attacks$Options")&&m.name.equals("resetSprint")){InsnList q=new InsnList();q.add(call(c.name,airborne.name,"()Z"));q.add(new InsnNode(IAND));flush.instructions.insert(i,q);found++;}
        if(found!=1)throw new IllegalStateException("Sprint gate layout changed");write(f,c);
    }
    static void coordinate(InsnList p,String min,String max,double t){p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,B,min,"D"));p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,B,max,"D"));p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,B,min,"D"));p.add(new InsnNode(DSUB));p.add(new LdcInsnNode(t));p.add(new InsnNode(DMUL));p.add(new InsnNode(DADD));}
    static void points(Map<String,byte[]> f){
        ClassNode c=read(f,"pulse/n9ezz/d");MethodNode visible=new MethodNode(ACC_PRIVATE|ACC_STATIC,"pulsevisuals$visiblePoint","(L"+B+";L"+V+";)L"+V+";",null,null);InsnList p=visible.instructions;
        p.add(new VarInsnNode(ALOAD,1));p.add(new VarInsnNode(ASTORE,2));
        // Keep the nearest physical point when visible. Only an occluded point needs
        // a bounded five-sample search; every sample stays inside the real box.
        double[][] samples={{.5,.65,.5},{.5,.9,.5},{.2,.65,.5},{.8,.65,.5},{.5,.2,.5}};
        for(int k=-1;k<samples.length;k++){
            if(k>=0){p.add(new TypeInsnNode(NEW,V));p.add(new InsnNode(DUP));coordinate(p,"field_1323","field_1320",samples[k][0]);coordinate(p,"field_1322","field_1325",samples[k][1]);coordinate(p,"field_1321","field_1324",samples[k][2]);p.add(new MethodInsnNode(INVOKESPECIAL,V,"<init>","(DDD)V",false));p.add(new VarInsnNode(ASTORE,2));}
            p.add(new VarInsnNode(ALOAD,2));p.add(call(c.name,"m19","(L"+V+";)Z"));LabelNode next=new LabelNode();p.add(new JumpInsnNode(IFEQ,next));p.add(new VarInsnNode(ALOAD,2));p.add(new InsnNode(ARETURN));p.add(next);frame(p,B,V,V);
        }
        p.add(new VarInsnNode(ALOAD,1));p.add(new InsnNode(ARETURN));c.methods.add(visible);
        MethodNode aim=method(c,"m18");for(AbstractInsnNode i:aim.instructions.toArray())if(i.getOpcode()==ARETURN){InsnList q=new InsnList();q.add(new VarInsnNode(ALOAD,5));q.add(new InsnNode(SWAP));q.add(call(c.name,visible.name,visible.desc));aim.instructions.insertBefore(i,q);}
        MethodNode canSee=method(c,"m20");reset(canSee);p=canSee.instructions;p.add(new VarInsnNode(ALOAD,0));p.add(new InsnNode(FCONST_1));p.add(new InsnNode(ICONST_0));p.add(new InsnNode(ICONST_0));p.add(call(c.name,"m18","(Lnet/minecraft/class_1657;FIZ)L"+V+";"));p.add(call(c.name,"m19","(L"+V+";)Z"));p.add(new InsnNode(IRETURN));
        // An enlarged neighbour must not steal an actual crosshair hit. A physical
        // target wins; expanded boxes are considered only when that ray missed.
        MethodNode original=method(c,"m28");original.name="pulsevisuals$crosshair";
        MethodNode pick=new MethodNode(ACC_PUBLIC|ACC_STATIC,"m28",original.desc,null,null);p=pick.instructions;p.add(new VarInsnNode(DLOAD,0));p.add(new InsnNode(ICONST_0));p.add(call(c.name,original.name,original.desc));p.add(new VarInsnNode(ASTORE,3));p.add(new VarInsnNode(ALOAD,3));LabelNode miss=new LabelNode();p.add(new JumpInsnNode(IFNULL,miss));p.add(new VarInsnNode(ALOAD,3));p.add(new InsnNode(ARETURN));p.add(miss);frame(p,DOUBLE,INTEGER,"net/minecraft/class_1297");p.add(new VarInsnNode(DLOAD,0));p.add(new VarInsnNode(ILOAD,2));p.add(call(c.name,original.name,original.desc));p.add(new InsnNode(ARETURN));c.methods.add(pick);write(f,c);
    }
    static AbstractInsnNode previous(AbstractInsnNode i){do{i=i.getPrevious();}while(i!=null&&i.getOpcode()<0);return i;}
    static void preset(Map<String,byte[]> f){
        ClassNode c=read(f,"pulse/n9ezz/NetworkPreset");int changes=0;
        Map<String,Float> values=Map.ofEntries(Map.entry("power",100f),Map.entry("range",3f),Map.entry("cps",10f),Map.entry("cooldown",95f),Map.entry("smoothing",35f),Map.entry("fov",180f),Map.entry("confirmation",0f),Map.entry("manualOverride",50f));
        for(MethodNode m:c.methods)for(AbstractInsnNode i:m.instructions.toArray()){
            if(i instanceof FieldInsnNode field&&field.owner.equals("pulse/n9ezz/PowerCurve$Level")&&field.name.equals("LEGIT"))field.name="HIGHT";
            if(i instanceof MethodInsnNode set&&set.owner.equals("pulse/settings/SliderSetting")&&set.name.equals("set")){
                AbstractInsnNode value=previous(i),before=previous(value);if(before instanceof FieldInsnNode field&&values.containsKey(field.name)){m.instructions.set(value,new LdcInsnNode(values.get(field.name)));changes++;}
            }
            if(i instanceof MethodInsnNode set&&set.owner.equals("pulse/settings/BooleanSetting")&&set.name.equals("set")){
                AbstractInsnNode value=previous(i),before=previous(value);if(before instanceof FieldInsnNode field&&Set.of("exactHit","resetSprint").contains(field.name))m.instructions.set(value,new InsnNode(field.name.equals("resetSprint")?ICONST_1:ICONST_0));
            }
            if(i instanceof MethodInsnNode set&&set.owner.equals("pulse/settings/ModeSetting")&&set.name.equals("select")){
                AbstractInsnNode value=previous(i),before=previous(value);if(before instanceof FieldInsnNode field&&field.name.equals("speed"))m.instructions.set(value,new InsnNode(ICONST_0));
            }
            if(i instanceof LdcInsnNode l&&"Сетевая".equals(l.cst))l.cst="Быстрый бой";
        }
        if(changes<15)throw new IllegalStateException("Preset layout changed");
        // Add the selection/outline aid, without changing final physical reach or hit tests.
        MethodNode config=c.methods.stream().filter(m->m.name.equals("m0")&&m.desc.equals("(Z)V")).findFirst().orElseThrow();
        for(AbstractInsnNode i:config.instructions.toArray())if(i.getOpcode()==RETURN){InsnList q=new InsnList();slider(q,"HITBOXES","u3","power",50);slider(q,"HITBOXES","u3","x",1.5f);slider(q,"HITBOXES","u3","z",1.5f);q.add(new FieldInsnNode(GETSTATIC,"pulse/n9ezz/N9Ezz","HITBOXES","Lpulse/n9ezz/u3;"));q.add(new InsnNode(ICONST_1));q.add(new MethodInsnNode(INVOKEVIRTUAL,"pulse/n9ezz/u3","setEnabledStateQuiet","(Z)V",false));config.instructions.insertBefore(i,q);}
        write(f,c);
    }
    static void slider(InsnList p,String field,String type,String setting,float value){p.add(new FieldInsnNode(GETSTATIC,"pulse/n9ezz/N9Ezz",field,"Lpulse/n9ezz/"+type+";"));p.add(new FieldInsnNode(GETFIELD,"pulse/n9ezz/"+type,setting,"Lpulse/settings/SliderSetting;"));p.add(new LdcInsnNode(value));p.add(new MethodInsnNode(INVOKEVIRTUAL,"pulse/settings/SliderSetting","set","(F)V",false));}
    static void commands(Map<String,byte[]> f){
        ClassNode c=read(f,IM);
        // Keep original hide semantics: disable N9Ezz combat, close its menu and
        // expose the original Pulse tabs. Visual/HUD/utility state is preserved.
        // This is presentation/state handling, not removal of loaded code or files.
        MethodNode handle=new MethodNode(ACC_PUBLIC|ACC_STATIC,"handleCommand","(Ljava/lang/String;)Z",null,null);InsnList p=handle.instructions;
        p.add(new VarInsnNode(ALOAD,0));p.add(call("pulse/n9ezz/ClientCommandText","action","(Ljava/lang/String;)I"));p.add(new VarInsnNode(ISTORE,1));p.add(new VarInsnNode(ILOAD,1));LabelNode own=new LabelNode();p.add(new JumpInsnNode(IFNE,own));p.add(new InsnNode(ICONST_0));p.add(new InsnNode(IRETURN));p.add(own);frame(p,"java/lang/String",INTEGER);
        LabelNode a=new LabelNode(),b=new LabelNode(),d=new LabelNode(),help=new LabelNode(),reply=new LabelNode();p.add(new VarInsnNode(ILOAD,1));p.add(new LookupSwitchInsnNode(help,new int[]{1,2,3},new LabelNode[]{a,b,d}));
        Object[][] actions={{a,IM,"hide","PulseVisuals: вкладка N9Ezz скрыта, боевые модули выключены. Модули Pulse сохраняют состояние. /pv show — вернуть вкладку."},{b,IM,"reveal","N9Ezz: вкладка доступна. Боевые модули включаются вручную или /pv combat."},{d,"pulse/n9ezz/NetworkPreset","apply","PulseVisuals: быстрый бой применён. Hight ×2.5, заряд 95%, подтверждение 0 мс. /pv hide — пауза."}};
        for(Object[] action:actions){p.add((LabelNode)action[0]);frame(p,"java/lang/String",INTEGER);p.add(call((String)action[1],(String)action[2],"()V"));p.add(new LdcInsnNode(action[3]));p.add(new JumpInsnNode(GOTO,reply));}
        p.add(help);frame(p,"java/lang/String",INTEGER);p.add(new LdcInsnNode("PulseVisuals: /pv hide, /pv show, /pv combat. Команды выполняются локально."));
        p.add(reply);p.add(new FrameNode(F_NEW,2,new Object[]{"java/lang/String",INTEGER},1,new Object[]{"java/lang/String"}));p.add(new VarInsnNode(ASTORE,2));player(p);p.add(new VarInsnNode(ASTORE,3));p.add(new VarInsnNode(ALOAD,3));LabelNode done=new LabelNode();p.add(new JumpInsnNode(IFNULL,done));p.add(new VarInsnNode(ALOAD,3));p.add(new VarInsnNode(ALOAD,2));p.add(new MethodInsnNode(INVOKESTATIC,"net/minecraft/class_2561","method_43470","(Ljava/lang/String;)Lnet/minecraft/class_5250;",true));p.add(new InsnNode(ICONST_0));p.add(new MethodInsnNode(INVOKEVIRTUAL,P,"method_7353","(Lnet/minecraft/class_2561;Z)V",false));p.add(done);frame(p,"java/lang/String",INTEGER,"java/lang/String",P);p.add(new InsnNode(ICONST_1));p.add(new InsnNode(IRETURN));c.methods.add(handle);write(f,c);
        c=read(f,"ru/pulse/mixin/ChatScreenMixin");MethodNode send=method(c,"onSendMessage");p=new InsnList();p.add(new VarInsnNode(ALOAD,1));p.add(call(IM,"handleCommand","(Ljava/lang/String;)Z"));LabelNode pass=new LabelNode();p.add(new JumpInsnNode(IFEQ,pass));p.add(new VarInsnNode(ALOAD,3));p.add(new MethodInsnNode(INVOKEVIRTUAL,"org/spongepowered/asm/mixin/injection/callback/CallbackInfo","cancel","()V",false));p.add(new InsnNode(RETURN));p.add(pass);frame(p,c.name,"java/lang/String",INTEGER,"org/spongepowered/asm/mixin/injection/callback/CallbackInfo");send.instructions.insert(p);write(f,c);
    }
}
