import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Replaces Aura's behavior with readable runtime source, retaining its public binary API. */
public final class AuraRewritePatch implements Opcodes {
    public static final Set<String> CHANGED=Set.of("pulse/n9ezz/u0.class","pulse/n9ezz/e.class");
    private static final String OWNER="pulse/n9ezz/u0", CONTROL="pulse/n9ezz/AuraController";
    private static final String FIELD="pulsevisuals$aura";
    private static ClassNode read(Map<String,byte[]> entries,String n){ClassNode c=new ClassNode();new ClassReader(entries.get(n+".class")).accept(c,ClassReader.EXPAND_FRAMES);return c;}
    private static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow();}
    private static void write(Map<String,byte[]> entries,ClassNode c){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);entries.put(c.name+".class",w.toByteArray());}
    private static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;}
    private static void controller(InsnList p){p.add(new VarInsnNode(ALOAD,0));p.add(new FieldInsnNode(GETFIELD,OWNER,FIELD,"L"+CONTROL+";"));}
    private static MethodInsnNode call(String owner,String name,String desc){return new MethodInsnNode(INVOKESTATIC,owner,name,desc,false);}
    private static void require(boolean b,String why){if(!b)throw new IllegalStateException(why);}
    public static void apply(Map<String,byte[]> entries){aura(entries);attacks(entries);}
    private static void aura(Map<String,byte[]> entries){
        ClassNode c=read(entries,OWNER);require(c.fields.stream().noneMatch(f->f.name.equals(FIELD)),"Aura rewrite already applied");
        c.fields.add(new FieldNode(ACC_PRIVATE|ACC_FINAL,FIELD,"L"+CONTROL+";",null,null));
        LinkedHashMap<String,String> settings=new LinkedHashMap<>();
        for(String n:List.of("airCritOnly","doubleAttack","fastRotation"))settings.put(n,"pulse/settings/BooleanSetting");
        for(String n:List.of("maxTurn","jitterMs","trackingRange"))settings.put(n,"pulse/settings/SliderSetting");
        for(var e:settings.entrySet())c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,e.getKey(),"L"+e.getValue()+";",null,null));
        MethodNode ctor=method(c,"<init>");
        // These defaults are visible and still overwritten by saved user profiles.
        Map<String,Float> defaults=Map.of("Угол поиска (°)",360f,"Подтверждение цели (мс)",0f,
            "Пауза после мыши (мс)",0f,"Плавность (%)",35f,"Удары/сек",10f,"Заряд удара (%)",95f);
        int changed=0;
        for(AbstractInsnNode i:ctor.instructions.toArray())if(i instanceof LdcInsnNode l&&l.cst instanceof String label&&defaults.containsKey(label)){
            AbstractInsnNode cursor=i.getNext();
            while(cursor!=null&&(cursor.getOpcode()<0||cursor instanceof LdcInsnNode text&&text.cst instanceof String))cursor=cursor.getNext();
            require(cursor!=null&&(cursor instanceof LdcInsnNode number&&number.cst instanceof Float||cursor.getOpcode()==FCONST_0||cursor.getOpcode()==FCONST_1||cursor.getOpcode()==FCONST_2),"Aura slider default layout: "+label);
            ctor.instructions.set(cursor,new LdcInsnNode(defaults.get(label)));changed++;
        }
        require(changed==defaults.size(),"Aura defaults count");
        int returns=0;
        for(AbstractInsnNode i:ctor.instructions.toArray())if(i.getOpcode()==RETURN){
            InsnList p=new InsnList();p.add(new VarInsnNode(ALOAD,0));p.add(new TypeInsnNode(NEW,CONTROL));p.add(new InsnNode(DUP));p.add(new VarInsnNode(ALOAD,0));p.add(new MethodInsnNode(INVOKESPECIAL,CONTROL,"<init>","(L"+OWNER+";)V",false));p.add(new FieldInsnNode(PUTFIELD,OWNER,FIELD,"L"+CONTROL+";"));
            // Public aliases let the existing setting collector/config serializer discover
            // the real controller settings without a new UI or profile file format.
            for(var e:settings.entrySet()){p.add(new VarInsnNode(ALOAD,0));controller(p);p.add(new FieldInsnNode(GETFIELD,CONTROL,e.getKey(),"L"+e.getValue()+";"));p.add(new FieldInsnNode(PUTFIELD,OWNER,e.getKey(),"L"+e.getValue()+";"));}
            ctor.instructions.insertBefore(i,p);returns++;
        }
        require(returns==1,"Aura constructor exit layout");
        for(String n:List.of("target","reset","controlsView","frame","tick")){
            MethodNode m=method(c,n);reset(m);InsnList p=m.instructions;controller(p);
            if(n.equals("frame")){p.add(new VarInsnNode(LLOAD,1));p.add(new VarInsnNode(FLOAD,3));}
            String descriptor=switch(n){case "target"->"()Lnet/minecraft/class_1657;";case "controlsView"->"()Z";case "frame"->"(JF)V";default->"()V";};
            p.add(new MethodInsnNode(INVOKEVIRTUAL,CONTROL,n,descriptor,false));p.add(new InsnNode(n.equals("target")?ARETURN:n.equals("controlsView")?IRETURN:RETURN));
        }
        // Preserve the original mutually-exclusive module activation, but reset the
        // new scheduler too. Disable already calls reset(), whose body is replaced above.
        for(AbstractInsnNode i:method(c,"onEnable").instructions.toArray())if(i.getOpcode()==RETURN){InsnList p=new InsnList();controller(p);p.add(new MethodInsnNode(INVOKEVIRTUAL,CONTROL,"reset","()V",false));method(c,"onEnable").instructions.insertBefore(i,p);}
        write(entries,c);
    }
    private static void attacks(Map<String,byte[]> entries){
        ClassNode c=read(entries,"pulse/n9ezz/e");int gates=0;
        for(AbstractInsnNode i:method(c,"n9ezz$automaticAttackAllowed").instructions)if(i instanceof MethodInsnNode m&&m.owner.equals("pulse/n9ezz/CombatRules6")&&m.name.equals("automaticAttackAllowed")){m.owner=CONTROL;m.name="attackAllowed";gates++;}
        require(gates==1,"Aura charge/critical gate layout");
        MethodNode flush=method(c,"m8");int clocks=0,attacks=0;
        for(AbstractInsnNode i:flush.instructions.toArray()){
            if(i instanceof MethodInsnNode m&&m.owner.equals("pulse/n9ezz/c")&&m.name.equals("m3")){
                // Record an actual committed attempt, including selected misses. Failed
                // readiness polls do not sample jitter or push the next deadline away.
                InsnList p=new InsnList();p.add(new VarInsnNode(ALOAD,3));p.add(new VarInsnNode(LLOAD,4));p.add(call(CONTROL,"attempted","(Lnet/minecraft/class_1657;J)V"));flush.instructions.insert(i,p);clocks++;
            }
            if(i instanceof MethodInsnNode m&&m.owner.equals("net/minecraft/class_636")&&m.name.equals("method_2918")){
                AbstractInsnNode swing=i.getNext();while(swing!=null&&!(swing instanceof MethodInsnNode s&&s.name.equals("method_6104")))swing=swing.getNext();
                require(swing!=null,"First native attack swing missing");
                // The repeat is explicit and bounded to exactly one extra native call.
                // It bypasses a second readiness check, not server invulnerability or damage rules.
                // Keep diagnostic count accurate rather than silently reporting one call as two.
                InsnList p=new InsnList();p.add(new FieldInsnNode(GETSTATIC,c.name,"f1","J"));p.add(new VarInsnNode(ALOAD,1));p.add(new FieldInsnNode(GETFIELD,"net/minecraft/class_310","field_1724","Lnet/minecraft/class_746;"));p.add(new VarInsnNode(ALOAD,3));p.add(call(CONTROL,"afterAttack","(Lnet/minecraft/class_1657;Lnet/minecraft/class_1657;)I"));p.add(new InsnNode(I2L));p.add(new InsnNode(LADD));p.add(new FieldInsnNode(PUTSTATIC,c.name,"f1","J"));flush.instructions.insert(swing,p);attacks++;
            }
        }
        require(clocks==1&&attacks==1,"Attack pipeline anchors changed");write(entries,c);
    }
}
