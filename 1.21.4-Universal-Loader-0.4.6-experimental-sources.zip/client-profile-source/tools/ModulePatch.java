import java.io.InputStream;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Preserve original Pulse modules/menu while restricting N9Ezz to the selected combat set. */
public final class ModulePatch implements Opcodes {
    private static final String RULES = "pulse/n9ezz/ModuleRules6";
    private static final String MODULE = "pulse/module/ClientModule";
    private static final String ARRAY = "[L" + MODULE + ";";

    public static void apply(Map<String, byte[]> entries) {
        edit(entries, "pulse/module/ModuleRegistry", false, c -> {
            // Filtering before collectSettings prevents excluded classes entering config/UI lists.
            MethodNode m = method(c, "register", "(" + ARRAY + ")V");
            InsnList filter = new InsnList();
            filter.add(new VarInsnNode(ALOAD, 0)); retain(filter);
            filter.add(new VarInsnNode(ASTORE, 0)); m.instructions.insert(filter);
        });
        edit(entries, "pulse/n9ezz/N9Ezz", false, c -> {
            MethodNode m = method(c, "modules", "()" + ARRAY);
            int count = 0;
            for (AbstractInsnNode n : m.instructions.toArray()) if (n.getOpcode() == ARETURN) {
                InsnList filter = new InsnList(); retain(filter); m.instructions.insertBefore(n, filter); count++;
            }
            require(count == 1, "N9Ezz.modules return layout");
        });
        edit(entries, "pulse/n9ezz/InterfaceMode", false, c -> {
            // Preserve the original hidden-mode rule: ordinary Pulse modules remain
            // available, while CHEATS cannot activate. Add only the N9Ezz allowlist.
            MethodNode m = method(c, "allowActivation", "(ZL" + MODULE + ";)Z");
            int returns=0;
            for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==IRETURN){
                InsnList guard=new InsnList();guard.add(new VarInsnNode(ALOAD,1));
                guard.add(new MethodInsnNode(INVOKESTATIC,RULES,"state","(ZLjava/lang/Object;)Z",false));
                m.instructions.insertBefore(n,guard);returns++;
            }
            require(returns==1,"Original hidden activation return layout");
            // visibleNames stays original: Visuals/HUD/Utilities remain while the
            // fourth CHEATS tab is hidden. visibleEntries already filters its cards.

        });
        edit(entries, MODULE, false, c -> {
            // Defensive reads also cover state restored before migration or by old integrations.
            for (String name : List.of("isEnabled", "isSubscribed", "isActive")) {
                MethodNode m = method(c, name, "()Z");
                for (AbstractInsnNode n : m.instructions.toArray()) if (n.getOpcode() == IRETURN) {
                    InsnList guard = new InsnList(); guard.add(new VarInsnNode(ALOAD, 0));
                    guard.add(new MethodInsnNode(INVOKESTATIC, RULES, "state", "(ZLjava/lang/Object;)Z", false));
                    m.instructions.insertBefore(n, guard);
                }
            }
            // Verify all mutation paths really call the hook; fail on an unknown input binary.
            for (String name : List.of("setEnabledState", "setEnabledStateQuiet", "setSubscribed")) {
                MethodNode m = method(c, name, "(Z)V");
                require(hasCall(m, "pulse/n9ezz/InterfaceMode", "allowActivation"), "Missing activation hook: " + name);
            }
        });
        edit(entries, "pulse/n9ezz/PowerCurve", false, c -> {
            MethodNode m = method(c, "strength", "(DLpulse/n9ezz/PowerCurve$Level;)D");
            reset(m); m.instructions.add(new VarInsnNode(DLOAD, 0));
            m.instructions.add(new MethodInsnNode(INVOKESTATIC, RULES, "strength", "(D)D", false));
            m.instructions.add(new VarInsnNode(ALOAD, 2));
            m.instructions.add(new MethodInsnNode(INVOKEVIRTUAL, "pulse/n9ezz/PowerCurve$Level", "multiplier", "()D", false));
            m.instructions.add(new InsnNode(DMUL)); m.instructions.add(new InsnNode(DRETURN));
        });
        edit(entries, "pulse/n9ezz/CheatModule", false, c -> {
            require(replaceText(c, "Доля базовой силы выбранного уровня: Legit ×1, Hight ×2.5, Extra ×10",
                "Сила × выбранный уровень: Legit ×1, Hight ×2.5, Extra ×10. Лимит автоатак 20/с и реальная дальность сохраняются.") == 1, "Power tooltip layout");
        });
        // ModulesTab stays byte-identical to the original menu: Visuals, HUD,
        // Utilities and CHEATS, with its existing search/settings/grid layout.
        edit(entries, "pulse/n9ezz/Stars", false, c -> {
            // Keep power-level controls visible: amplification is now an explicit choice again.
            replaceText(c,"Отключить все читы","Отключить бой");
            replaceText(c,"Скрыть всё","Скрыть /pv hide");
        });
    }

    private static void retain(InsnList insn) {
        insn.add(new MethodInsnNode(INVOKESTATIC, RULES, "retain", "([Ljava/lang/Object;)[Ljava/lang/Object;", false));
        insn.add(new TypeInsnNode(CHECKCAST, ARRAY));
    }
    private static int replaceText(ClassNode c, String before, String after) {
        int count = 0;
        for (MethodNode m : c.methods) for (AbstractInsnNode n : m.instructions) if (n instanceof LdcInsnNode ldc && before.equals(ldc.cst)) {
            ldc.cst = after; count++;
        }
        return count;
    }
    private static void reset(MethodNode m) {
        m.instructions.clear(); m.tryCatchBlocks.clear();
        if (m.localVariables != null) m.localVariables.clear();
        m.visibleLocalVariableAnnotations = null; m.invisibleLocalVariableAnnotations = null;
    }
    private static MethodNode method(ClassNode c, String name, String desc) {
        return c.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(desc)).findFirst()
            .orElseThrow(() -> new IllegalStateException("Missing " + c.name + "." + name + desc));
    }
    private static boolean hasCall(MethodNode m, String owner, String name) {
        for (AbstractInsnNode n : m.instructions) if (n instanceof MethodInsnNode call && call.owner.equals(owner) && call.name.equals(name)) return true;
        return false;
    }
    private static AbstractInsnNode fieldAfter(AbstractInsnNode from, String owner, String name, int opcode) {
        for (AbstractInsnNode n = from; n != null; n = n.getNext()) if (n instanceof FieldInsnNode field
            && field.getOpcode() == opcode && field.owner.equals(owner) && field.name.equals(name)) return n;
        throw new IllegalStateException("Missing field anchor " + owner + "." + name);
    }
    private static void removeRange(MethodNode m, AbstractInsnNode from, AbstractInsnNode until) {
        Set<AbstractInsnNode> removed = Collections.newSetFromMap(new IdentityHashMap<>());
        for (AbstractInsnNode n = from; n != until; n = n.getNext()) {
            require(n != null, "Invalid removal range"); removed.add(n);
        }
        // External jumps to an old boundary now enter the following surviving block.
        LabelNode next = new LabelNode(); m.instructions.insertBefore(until, next);
        for (AbstractInsnNode n : m.instructions) if (!removed.contains(n) && n instanceof JumpInsnNode jump && removed.contains(jump.label)) jump.label = next;
        for (AbstractInsnNode n : removed) m.instructions.remove(n);
        if (m.localVariables != null) m.localVariables.clear();
        m.visibleLocalVariableAnnotations = null; m.invisibleLocalVariableAnnotations = null;
    }
    private static void require(boolean okay, String message) {
        if (!okay) throw new IllegalStateException(message);
    }
    private static void edit(Map<String, byte[]> entries, String name, boolean frames, java.util.function.Consumer<ClassNode> change) {
        byte[] original = entries.get(name + ".class"); require(original != null, "Missing class " + name);
        ClassNode node = new ClassNode(); new ClassReader(original).accept(node, 0); change.accept(node);
        ClassWriter writer = frames ? new HierarchyWriter(entries) : new ClassWriter(ClassWriter.COMPUTE_MAXS);
        node.accept(writer); entries.put(name + ".class", writer.toByteArray());
    }
    private static final class HierarchyWriter extends ClassWriter {
        private final Map<String, byte[]> entries;
        private final Map<String, ClassNode> cache = new HashMap<>();
        HierarchyWriter(Map<String, byte[]> entries) { super(COMPUTE_FRAMES | COMPUTE_MAXS); this.entries = entries; }
        private ClassNode info(String name) {
            return cache.computeIfAbsent(name, n -> {
                byte[] bytes = entries.get(n + ".class");
                if (bytes == null) try (InputStream in = ClassLoader.getPlatformClassLoader().getResourceAsStream(n + ".class")) {
                    if (in != null) bytes = in.readAllBytes();
                } catch (Exception e) { throw new IllegalStateException("Read hierarchy " + n, e); }
                if (bytes == null) throw new IllegalStateException("Unknown UI merge type " + n);
                ClassNode c = new ClassNode(); new ClassReader(bytes).accept(c, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES); return c;
            });
        }
        private boolean assignable(String to, String from, Set<String> visited) {
            if (to.equals(from) || to.equals("java/lang/Object")) return true;
            if (!visited.add(from)) return false;
            ClassNode c = info(from);
            if (c.superName != null && assignable(to, c.superName, visited)) return true;
            for (String i : c.interfaces) if (assignable(to, i, visited)) return true;
            return false;
        }
        @Override protected String getCommonSuperClass(String a, String b) {
            if (assignable(a, b, new HashSet<>())) return a;
            if (assignable(b, a, new HashSet<>())) return b;
            if ((info(a).access & ACC_INTERFACE) != 0 || (info(b).access & ACC_INTERFACE) != 0) return "java/lang/Object";
            do { a = info(a).superName; } while (a != null && !assignable(a, b, new HashSet<>()));
            return a == null ? "java/lang/Object" : a;
        }
    }
}
