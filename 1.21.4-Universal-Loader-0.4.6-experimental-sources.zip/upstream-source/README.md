# N9Ezz Universal Loader 0.4.1 experimental

Собственное общее ядро на Java 21 для Minecraft 1.21.11: один bootstrap,
один classloader игры и модов, один установочный JAR и один профиль
`N9Ezz-Universal-1.21.11`. Выбора платформ в интерфейсе нет. Движки
Fabric Loader, Quilt Loader, Forge и NeoForge не запускаются.

**Начиная с 0.4.1 внешние моды принимаются только в собственном формате
`n9ezz.mod.json`.** Обычные Fabric, Quilt, Forge и NeoForge моды отклоняются
до выполнения их кода, в том числе архивы, содержащие одновременно собственный
и сторонний descriptor. Вложенные JAR внешнего мода также не поддерживаются.
Встроенный N9Ezz и выбранные Fabric API компоненты остаются зафиксированными
зависимостями установщика с проверкой SHA-256.

Собственный descriptor обозначает принятие API-контракта N9Ezz. Он не
подтверждает автора мода и не является цифровой подписью или защитной
песочницей. Переименование обычного мода или добавление JSON не переносит
его код на API N9Ezz. Правила и пример Java-мода — в
[native-mod-policy.md](docs/native-mod-policy.md).

## Установка и сборка

Для установщика и игры нужны Minecraft 1.21.11 и Java 21 runtime.
Установочный JAR содержит полный клиент N9Ezz 1.5.3-n9ezz и выбранные
компоненты Fabric API; вручную класть N9Ezz в `mods` не требуется.
Minecraft и его ресурсы устанавливаются обычным лаунчером и в установщик
не входят.

```bash
java -jar N9Ezz-Universal-Loader-0.4.1-experimental.jar
# установка без графического интерфейса:
java -jar N9Ezz-Universal-Loader-0.4.1-experimental.jar --install --game-dir /path/to/.minecraft
```

Установщик создаёт один профиль и отдельный каталог `n9ezz-universal`.
Запуск выполняется кнопкой «Играть» выбранного профиля в лаунчере.
Совместимые собственные моды помещаются в `.minecraft/n9ezz-universal/mods`.
Сторонний архив вызывает диагностику с его путём; он не удаляется и не
исполняется. Обновляемые launcher metadata имеют резервные копии.
Старые профили и проверенные сборки сохранены.

Для исходников нужен полный JDK 21 и Python 3:

```bash
# в подготовленной облачной среде:
source /workspace/toolchains/activate-temurin21.sh
cd /workspace/N9Ezz/universal-loader
python3 build.py --offline
java -jar dist/N9Ezz-Universal-Loader-0.4.1-experimental.jar --self-test
```

В другой среде активируйте JDK 21 через `JAVA_HOME`/`PATH` и выполните
`python3 build.py`. URL и SHA-256 зависимостей зафиксированы в
`universal-loader/deps-lock.json`. Runtime, installer, updater и клиентские
дополнения написаны на Java. Python организует сборку и проверки.
Сборка использует `--release 21`, фиксированные timestamps и порядок ZIP
entries. Результаты находятся в `dist/` и `universal-loader/dist/`.

`--self-test` исполняет встроенный native test-mod через общий runtime.
`--run` и `--verify` — отдельный API-only путь, также принимающий только
собственные внешние моды; это не команды запуска Minecraft.
`--verify-bundled` сохраняет строгую диагностику game-механизмов.
Игра запускается через установленный профиль и `GameBootstrap`.

## Общее ядро и встроенная совместимость

| Механизм | Реализация и граница |
| --- | --- |
| Внешние моды | Только `n9ezz.mod.json`, собственный initializer/context/events; обычные platform descriptors и вложенные JAR отклоняются |
| Discovery и зависимости | Собственный Java resolver, provenance, проверка ID/alias/class collisions до entrypoints; отдельные проверенные встроенные источники |
| Mappings | Tiny index/cache и TinyRemapper 0.13.0 для точно зафиксированного официального клиента 1.21.11 → intermediary |
| Трансформации | `MAPPING → ACCESS → CORE → MIXIN → POST`; собственная служба Sponge Mixin и общий classloader |
| Встроенный Fabric API | Шесть исходных модулей из 0.141.3+1.21.11: base, commands, keybindings, lifecycle, networking, rendering |
| Ресурсы N9Ezz | Собственный provider добавляет 398 исходных assets в native ResourceManager |
| Quilt/FML adapters | Ограниченные внутренние контракты, сохранённые для низкоуровневых проверок; внешние platform archives через них больше не допускаются |

Общее ядро не стало полным Forge/NeoForge или QSL. Ранние registries, game
patches FML, general mod/refmap remapping, AT/JarJar/module semantics и
полный Fabric API/QSL не реализованы. Подробности и история проверок — в
[compatibility.md](docs/compatibility.md), [аудите исходников](docs/source-loader-audit.md)
и [runtime status](docs/latest-runtime-status.md).

## Проверки и сохранённые версии

Статус проверок именно 0.4.1 фиксируется в
[release-test-report-0.4.1.md](docs/release-test-report-0.4.1.md).
Исторический 0.4.0 запуск подтвердил N9Ezz и четыре явно адаптированных
platform fixtures в одном runtime. В 0.4.1 этот способ подключения внешних
platform fixtures намеренно закрыт; прежний запуск не является проверкой
нового JAR. Его [отчёт](docs/release-test-report-0.4.md) сохранён без изменений.
Старые 0.3.1, 0.3.0 и baseline-сборки также сохранены.

Встроенный клиент, логика модулей и packets в 0.4.1 не меняются. SHA-256
полного встроенного клиента:
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
Предыдущие geometry/ABI проверки описаны в
[аудите клиента](docs/client-hitbox-audit.md) и
[local QA](docs/client-hitbox-local-qa.md); они не доказывают attacks,
other-player target acquisition или PvP.

Переданные установщики платформ исследуются как материалы для аудита,
а не как разрешённые внешние моды. Результат — в
[uploaded-platforms-0.4.1.md](docs/uploaded-platforms-0.4.1.md).

## Исходники и лицензии

`universal-loader/` содержит ядро, installer и build; `client/` — исходники
дополнений N9Ezz; `loader/` — старый installer 0.1.0; `baseline/` и `docs/` —
provenance и проверки. Исходники базового Pulse отсутствуют: клиентская
сборка использует зафиксированный бинарный input. Исходный upstream проект:
`NoEzpls/N9Ezzz`, commit `07a77dd4dc3c2a909e3ec1b082c6d67c83684255`.

Новый код — MIT. Переиспользованные компоненты сохраняют свои лицензии,
notice и dependency archives. Соответствующие исходники и build files
TinyRemapper LGPL-3.0-or-later включены в архив исходников и установочный JAR.
Лицензия ядра не меняет лицензии клиента и зависимостей. Список:
[THIRD-PARTY-NOTICES](universal-loader/THIRD-PARTY-NOTICES.md).
