# Components and provenance

This distribution is a transparent prototype bootstrap and installer. It is not an official Fabric, Quilt, Forge or NeoForge release and does not implement a universal compatibility layer.

The supplied N9Ezz 1.5.3-n9ezz JAR is included byte-for-byte, with its existing metadata, license declarations, native library, resources and classes unchanged. Its declared mod ID is `pulse`, visible name `N9Ezz`. The original ZIP of N9Ezz add-on sources is not modified by this project. No claim of ownership over Pulse or other third-party material is made.

Official binary components are fetched from the Fabric and Quilt repositories. Their archives and included license notices are preserved without modification. Exact URLs, sizes, publisher-provided checksums and SHA-256 fingerprints are recorded in `dependencies.lock.json` and in the embedded `bundle/index.json`.

- Fabric Loader and Fabric API: https://github.com/FabricMC
- Quilt Loader, Quilt Config, Quilt JSON5 and hashed mappings: https://github.com/QuiltMC
- Sponge Mixin: https://github.com/SpongePowered/Mixin
- ASM: https://asm.ow2.io/
- Minecraft is not bundled. The user installs Minecraft 1.21.11 through their existing licensed launcher; account authentication remains with that launcher.

Forge and NeoForge code is not included. Their compatibility entries are explicitly blocked.

The prototype's own Java sources and build/test scripts are provided under the MIT license in `LICENSE`. That license does not grant rights to third-party components.
