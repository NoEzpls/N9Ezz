package dev.n9ezz.loader;

import java.nio.file.*;
import java.util.*;

public final class UnitChecks {
    private static int count;
    private static void check(boolean value, String label) { if (!value) throw new AssertionError(label); count++; }
    private static void fails(Throwing action, String label) throws Exception {
        try { action.run(); } catch (IllegalArgumentException | java.io.IOException expected) { count++; return; }
        throw new AssertionError(label);
    }
    @FunctionalInterface interface Throwing { void run() throws Exception; }
    public static void main(String[] args) throws Exception {
        var value = Json.object(Json.parse("\ufeff{\"текст\":\"C:\\\\Игры\\\\N9Ezz\\n\\u2764\",\"array\":[true,false,null,-12.5e2]}"));
        check(value.get("текст").equals("C:\\Игры\\N9Ezz\n❤"), "Unicode JSON and BOM");
        check(Json.object(Json.parse(Json.encode(value))).equals(value), "JSON round trip");
        check(Json.encode(Map.of("z", 1, "a", 2)).equals("{\"a\":2,\"z\":1}"), "Stable canonical JSON key order");
        for (String bad : List.of("{\"x\":1,\"x\":2}", "{\"x\":null,\"x\":2}", "[1,]", "{\"x\":1} x", "01", "-.5", "[true", "\"\\uXYZZ\""))
            fails(() -> Json.parse(bad), "Reject invalid JSON: " + bad);
        Path root = Path.of("test-root").toAbsolutePath();
        for (String path : List.of("../file", "/tmp/file", "a/../../file", "a//b", "a\\b", "C:/file", "a/./b"))
            fails(() -> SafeFiles.resolve(root, path), "Reject escaping path");
        check(SafeFiles.resolve(root, "mods/test.jar").startsWith(root), "Contained path");
        Path game = Path.of("Папка с пробелами").toAbsolutePath();
        check(Bootstrap.gameDir(new String[]{"--gameDir", game.toString(), "--username", "fixture"}).equals(game), "Game path spaces");
        check(Bootstrap.gameDir(new String[]{"--gameDir=" + game}).equals(game), "Equals game path");
        fails(() -> Bootstrap.gameDir(new String[]{"--gameDir"}), "Missing game path");
        fails(() -> Bootstrap.gameDir(new String[]{"--gameDir", "a", "--gameDir", "b"}), "Ambiguous game paths");
        Bundle bundle = new Bundle();
        fails(() -> bundle.backend("forge", true), "Forge blocked");
        fails(() -> bundle.backend("neoforge", true), "NeoForge blocked");
        fails(() -> bundle.backend("quilt", false), "Quilt explicit choice");
        check(bundle.backend("fabric", false).get("status").equals("prototype"), "Fabric status honest");
        System.out.println("UNIT_CHECKS_PASS " + count);
    }
}
