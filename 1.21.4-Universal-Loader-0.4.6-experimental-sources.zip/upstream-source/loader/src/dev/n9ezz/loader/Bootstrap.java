package dev.n9ezz.loader;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipFile;

/** Explicit game entrypoint. N9Ezz remains a registered, visible Fabric mod. */
public final class Bootstrap {
    public static void main(String[] args) throws Throwable {
        Bundle bundle = new Bundle();
        String backendId = System.getProperty("n9ezz.backend", "fabric");
        Map<String,Object> backend = bundle.backend(backendId, Boolean.getBoolean("n9ezz.experimental"));
        if (Runtime.version().feature() < Json.number(bundle.index.get("minimumGameJava")))
            throw new IllegalStateException("Для Minecraft 1.21.11 и N9Ezz нужна Java 21 или новее. В лаунчере выбран Java " + Runtime.version().feature());
        Path gameDir = gameDir(args);
        checkExistingMods(gameDir, bundle, backendId);
        for (Bundle.Asset asset : bundle.mods) {
            asset.verifyResource();
            Path target = SafeFiles.resolve(gameDir, asset.path());
            if (SafeFiles.exists(target) && !asset.matches(target)) throw new IOException("Изменён встроенный компонент: " + target + ". Автоматическая перезапись отключена.");
        }
        for (Bundle.Asset asset : bundle.mods) asset.extractNew(SafeFiles.resolve(gameDir, asset.path()));
        checkExistingMods(gameDir, bundle, backendId);
        System.out.println("[N9Ezz Loader " + bundle.version + "] N9Ezz " + bundle.index.get("payloadVersion") + "; backend=" + backendId + "; Minecraft=" + bundle.minecraft);
        System.out.println("[N9Ezz Loader] Компоненты открыто установлены в " + gameDir.resolve("mods"));
        System.out.println("[N9Ezz Loader] Прототип: совместимость четырёх систем не реализована; запуск игры этой сборки не был проверен автором сборки.");
        try {
            Class<?> main = Class.forName(Json.string(backend.get("mainClass")));
            main.getMethod("main", String[].class).invoke(null, (Object)args);
        } catch (InvocationTargetException e) { throw e.getCause(); }
        catch (ClassNotFoundException e) { throw new IllegalStateException("Отсутствует движок " + backendId + ". Повтори установку N9Ezz Loader в каталог этого лаунчера.", e); }
    }

    static Path gameDir(String[] args) throws IOException {
        Path result = null;
        for (int i = 0; i < args.length; i++) {
            String value = null;
            if (args[i].equals("--gameDir")) {
                if (++i == args.length) throw new IOException("Нет значения --gameDir");
                value = args[i];
            } else if (args[i].startsWith("--gameDir=")) value = args[i].substring(10);
            if (value != null) {
                if (value.isBlank()) throw new IOException("Пустой каталог игры");
                Path next = Path.of(value).toAbsolutePath().normalize();
                if (result != null && !result.equals(next)) throw new IOException("Переданы разные каталоги --gameDir");
                result = next;
            }
        }
        if (result == null) throw new IOException("Запускай установленный профиль через Minecraft Launcher: отсутствует --gameDir.");
        return result;
    }

    static void checkExistingMods(Path gameDir, Bundle bundle, String backend) throws IOException {
        Path modsDir = SafeFiles.resolve(gameDir, "mods");
        if (!SafeFiles.exists(modsDir)) return;
        if (!Files.isDirectory(modsDir)) throw new IOException("mods должен быть каталогом");
        Map<String,Path> seen = new HashMap<>();
        Map<String,Path> managed = Map.of("pulse", SafeFiles.resolve(gameDir, bundle.mods.get(0).path()),
                "fabric-api", SafeFiles.resolve(gameDir, bundle.mods.get(1).path()));
        try (var files = Files.list(modsDir)) {
            for (Path path : files.toList()) {
                if (!path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")) continue;
                if (Files.isSymbolicLink(path)) throw new IOException("В профиле есть ссылка вместо файла мода: " + path.getFileName());
                try (ZipFile jar = new ZipFile(path.toFile())) {
                    var metadata = jar.getEntry("fabric.mod.json");
                    if (metadata == null) {
                        boolean quilt = jar.getEntry("quilt.mod.json") != null;
                        boolean forge = jar.getEntry("META-INF/mods.toml") != null || jar.getEntry("META-INF/neoforge.mods.toml") != null;
                        if (forge || (quilt && backend.equals("fabric"))) throw new IOException("Мод для другой платформы: " + path.getFileName() + ". Перемести его из этого профиля перед запуском.");
                        continue;
                    }
                    Map<String,Object> info;
                    try (InputStream in = jar.getInputStream(metadata)) {
                        info = Json.object(Json.parse(new String(SafeFiles.readLimited(in, 262144), StandardCharsets.UTF_8)));
                    }
                    String id = Json.string(info.get("id"));
                    if (managed.containsKey(id) && !path.toAbsolutePath().normalize().equals(managed.get(id)))
                        throw new IOException("Лишняя копия " + id + ": " + path.getFileName() + ". N9Ezz и Fabric API уже включены в профиль; файл оставлен без изменений.");
                    Path other = seen.putIfAbsent(id, path);
                    if (other != null) throw new IOException("Повторяется ID мода " + id + ": " + other.getFileName() + " и " + path.getFileName());
                } catch (IllegalArgumentException e) { throw new IOException("Некорректные метаданные мода: " + path.getFileName(), e); }
            }
        }
    }
}
