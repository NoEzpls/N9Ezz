package dev.n9ezz.loader;

import java.math.BigDecimal;
import java.util.*;

/** Small strict JSON codec. No reflection, scripts, or external dependencies. */
final class Json {
    static Object parse(String text) {
        Parser p = new Parser(text);
        Object value = p.value(0);
        p.space();
        if (p.pos != p.text.length()) throw p.error("Trailing data");
        return value;
    }
    @SuppressWarnings("unchecked")
    static Map<String, Object> object(Object value) {
        if (!(value instanceof Map<?, ?>)) throw new IllegalArgumentException("Expected JSON object");
        return (Map<String, Object>) value;
    }
    @SuppressWarnings("unchecked")
    static List<Object> array(Object value) {
        if (!(value instanceof List<?>)) throw new IllegalArgumentException("Expected JSON array");
        return (List<Object>) value;
    }
    static String string(Object value) {
        if (!(value instanceof String s)) throw new IllegalArgumentException("Expected JSON string");
        return s;
    }
    static long number(Object value) {
        if (!(value instanceof Number)) throw new IllegalArgumentException("Expected JSON number");
        return new BigDecimal(value.toString()).longValueExact();
    }
    static String encode(Object value) {
        if (value == null) return "null";
        if (value instanceof String s) {
            StringBuilder b = new StringBuilder("\"");
            for (char c : s.toCharArray()) switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> { if (c < 32) b.append(String.format("\\u%04x", (int)c)); else b.append(c); }
            }
            return b.append('"').toString();
        }
        if (value instanceof Boolean || value instanceof Number) return value.toString();
        StringJoiner j;
        if (value instanceof Map<?, ?> m) {
            j = new StringJoiner(",", "{", "}");
            // Map.of iteration order is deliberately randomized between JVM processes.
            // Canonical keys make version files and install receipts stable across runs.
            Map<String,Object> sorted = new TreeMap<>();
            for (var e : m.entrySet()) sorted.put(string(e.getKey()), e.getValue());
            for (var e : sorted.entrySet()) j.add(encode(e.getKey()) + ":" + encode(e.getValue()));
        } else if (value instanceof List<?> list) {
            j = new StringJoiner(",", "[", "]");
            for (Object item : list) j.add(encode(item));
        } else throw new IllegalArgumentException("Unsupported JSON value");
        return j.toString();
    }
    private static final class Parser {
        private final String text;
        private int pos;
        Parser(String text) { this.text = text.startsWith("\ufeff") ? text.substring(1) : text; }
        IllegalArgumentException error(String message) { return new IllegalArgumentException(message + " at JSON offset " + pos); }
        void space() { while (pos < text.length() && " \r\n\t".indexOf(text.charAt(pos)) >= 0) pos++; }
        boolean take(char c) { space(); if (pos < text.length() && text.charAt(pos) == c) { pos++; return true; } return false; }
        Object value(int depth) {
            if (depth > 64) throw error("JSON too deeply nested");
            space();
            if (pos == text.length()) throw error("Missing value");
            char c = text.charAt(pos);
            if (c == '"') return quoted();
            if (take('{')) {
                Map<String,Object> m = new LinkedHashMap<>();
                if (take('}')) return m;
                do {
                    space(); String key = quoted();
                    if (!take(':')) throw error("Expected colon");
                    if (m.containsKey(key)) throw error("Duplicate key");
                    m.put(key, value(depth + 1));
                } while (take(','));
                if (!take('}')) throw error("Expected closing brace");
                return m;
            }
            if (take('[')) {
                List<Object> a = new ArrayList<>();
                if (take(']')) return a;
                do { a.add(value(depth + 1)); } while (take(','));
                if (!take(']')) throw error("Expected closing bracket");
                return a;
            }
            for (String literal : List.of("true", "false", "null")) if (text.startsWith(literal, pos)) {
                pos += literal.length(); return literal.equals("null") ? null : Boolean.valueOf(literal);
            }
            int start = pos;
            if (pos < text.length() && text.charAt(pos) == '-') pos++;
            if (pos < text.length() && text.charAt(pos) == '0') pos++;
            else digits();
            if (pos < text.length() && text.charAt(pos) == '.') { pos++; digits(); }
            if (pos < text.length() && "eE".indexOf(text.charAt(pos)) >= 0) {
                pos++; if (pos < text.length() && "+-".indexOf(text.charAt(pos)) >= 0) pos++; digits();
            }
            try { return new BigDecimal(text.substring(start, pos)); }
            catch (NumberFormatException e) { throw error("Invalid number"); }
        }
        void digits() {
            int start = pos;
            while (pos < text.length() && text.charAt(pos) >= '0' && text.charAt(pos) <= '9') pos++;
            if (pos == start) throw error("Expected digit");
        }
        String quoted() {
            if (pos == text.length() || text.charAt(pos++) != '"') throw error("Expected string");
            StringBuilder b = new StringBuilder();
            while (pos < text.length()) {
                char c = text.charAt(pos++);
                if (c == '"') return b.toString();
                if (c < 32) throw error("Unescaped control character");
                if (c != '\\') { b.append(c); continue; }
                if (pos == text.length()) throw error("Truncated escape");
                char escaped = text.charAt(pos++);
                switch (escaped) {
                    case '"', '\\', '/' -> b.append(escaped);
                    case 'b' -> b.append('\b'); case 'f' -> b.append('\f');
                    case 'n' -> b.append('\n'); case 'r' -> b.append('\r'); case 't' -> b.append('\t');
                    case 'u' -> {
                        if (pos + 4 > text.length()) throw error("Truncated Unicode escape");
                        try { b.append((char)Integer.parseInt(text.substring(pos, pos + 4), 16)); }
                        catch (NumberFormatException e) { throw error("Invalid Unicode escape"); }
                        pos += 4;
                    }
                    default -> throw error("Invalid escape");
                }
            }
            throw error("Unterminated string");
        }
    }
}
