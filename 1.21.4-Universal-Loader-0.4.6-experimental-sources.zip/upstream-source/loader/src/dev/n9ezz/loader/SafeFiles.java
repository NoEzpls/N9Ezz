package dev.n9ezz.loader;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.HexFormat;

final class SafeFiles {
    static String hash(Path path, String algorithm) throws IOException {
        try (InputStream in = Files.newInputStream(path)) { return hash(in, algorithm); }
    }
    static String hash(InputStream in, String algorithm) throws IOException {
        try {
            MessageDigest d = MessageDigest.getInstance(algorithm);
            byte[] buffer = new byte[65536]; int n;
            while ((n = in.read(buffer)) != -1) d.update(buffer, 0, n);
            return HexFormat.of().formatHex(d.digest());
        } catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }
    static Path resolve(Path root, String relative) throws IOException {
        if (relative.isBlank() || relative.contains("\\") || relative.contains(":") || relative.startsWith("/"))
            throw new IOException("Некорректный относительный путь");
        for (String part : relative.split("/", -1)) if (part.isEmpty() || part.equals(".") || part.equals(".."))
            throw new IOException("Некорректный компонент пути");
        Path base = root.toAbsolutePath().normalize();
        Path dest = base.resolve(relative).normalize();
        if (!dest.startsWith(base)) throw new IOException("Путь выходит за выбранный каталог");
        Path current = base;
        for (Path part : base.relativize(dest)) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current)) throw new IOException("Символическая ссылка в каталоге установки: " + current);
        }
        return dest;
    }
    static byte[] readLimited(InputStream in, int limit) throws IOException {
        byte[] bytes = in.readNBytes(limit + 1);
        if (bytes.length > limit) throw new IOException("Слишком большой файл метаданных");
        return bytes;
    }
    static void atomicReplace(Path source, Path dest) throws IOException {
        try { Files.move(source, dest, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException e) { Files.move(source, dest, StandardCopyOption.REPLACE_EXISTING); }
    }
    static boolean exists(Path path) { return Files.exists(path, LinkOption.NOFOLLOW_LINKS); }
}
