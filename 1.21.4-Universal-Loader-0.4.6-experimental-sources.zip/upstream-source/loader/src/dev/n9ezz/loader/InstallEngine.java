package dev.n9ezz.loader;

import java.io.*;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

/** Offline installation into a dedicated, labelled Minecraft Launcher profile. */
final class InstallEngine {
    private final Bundle bundle;
    InstallEngine(Bundle bundle) { this.bundle = bundle; }
    record Result(Path root, Path gameDir, String versionId, int filesCreated, Path profileBackup) {}
    @FunctionalInterface private interface Copier { void copy(Path target) throws IOException; }
    private record Planned(Path path, long size, String hash, Copier copy) {
        boolean matches() throws IOException {
            return Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) && Files.size(path) == size
                    && SafeFiles.hash(path, "SHA-256").equals(hash);
        }
    }

    Result install(Path selectedRoot, String backendId, boolean experimental) throws Exception {
        Map<String,Object> backend = bundle.backend(backendId, experimental);
        Path root = selectedRoot.toAbsolutePath().normalize();
        requireVanilla(root);
        Path lockPath = SafeFiles.resolve(root, "n9ezz-installer.lock");
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             FileLock lock = channel.tryLock()) {
            if (lock == null) throw new IOException("Уже запущена другая установка N9Ezz");
            return installLocked(root, backendId, backend);
        }
    }

    private Result installLocked(Path root, String backendId, Map<String,Object> backend) throws Exception {
        Path self = selfJar();
        String selfSha256 = SafeFiles.hash(self, "SHA-256");
        String selfSha1 = SafeFiles.hash(self, "SHA-1");
        Path gameDir = SafeFiles.resolve(root, "n9ezz-instances/" + backendId + "-" + bundle.minecraft);
        String versionId = Json.string(backend.get("versionId"));
        List<Bundle.Asset> libraries = Bundle.assets(backend.get("components"));
        List<Planned> plan = new ArrayList<>();
        for (Bundle.Asset a : libraries) addAsset(plan, root, a);
        for (Bundle.Asset a : bundle.mods) addAsset(plan, gameDir, a);
        String ownPath = "libraries/dev/n9ezz/n9ezz-loader/" + bundle.version + "/n9ezz-loader-" + bundle.version + ".jar";
        plan.add(new Planned(SafeFiles.resolve(root, ownPath), Files.size(self), selfSha256,
                target -> Files.copy(self, target, StandardCopyOption.REPLACE_EXISTING)));
        Map<String,Object> version = Json.object(Json.parse(Bundle.text(Json.string(backend.get("profile")))));
        version.put("id", versionId);
        version.put("mainClass", "dev.n9ezz.loader.Bootstrap");
        List<Object> versionLibraries = new ArrayList<>();
        for (Bundle.Asset a : libraries) {
            Map<String,Object> artifact = new LinkedHashMap<>();
            artifact.put("path", a.path().substring("libraries/".length()));
            artifact.put("sha1", a.sha1()); artifact.put("size", a.size()); artifact.put("url", a.source());
            versionLibraries.add(Map.of("name", a.name(), "downloads", Map.of("artifact", artifact)));
        }
        Map<String,Object> localArtifact = new LinkedHashMap<>();
        localArtifact.put("path", ownPath.substring("libraries/".length()));
        localArtifact.put("sha1", selfSha1); localArtifact.put("size", Files.size(self)); localArtifact.put("url", "");
        versionLibraries.add(Map.of("name", "dev.n9ezz:n9ezz-loader:" + bundle.version,
                "downloads", Map.of("artifact", localArtifact)));
        version.put("libraries", versionLibraries);
        Map<String,Object> arguments = Json.object(version.computeIfAbsent("arguments", k -> new LinkedHashMap<>()));
        List<Object> jvm = new ArrayList<>(Json.array(arguments.getOrDefault("jvm", new ArrayList<>())));
        jvm.add("-Dn9ezz.backend=" + backendId);
        if (backendId.equals("quilt")) jvm.add("-Dn9ezz.experimental=true");
        arguments.put("jvm", jvm);
        addBytes(plan, SafeFiles.resolve(root, "versions/" + versionId + "/" + versionId + ".json"), jsonBytes(version));
        Map<String,Object> receipt = new LinkedHashMap<>();
        receipt.put("schema", 1); receipt.put("loaderVersion", bundle.version); receipt.put("backend", backendId);
        receipt.put("minecraft", bundle.minecraft); receipt.put("payloadVersion", bundle.index.get("payloadVersion"));
        receipt.put("gameLaunchTested", false); receipt.put("fourLoaderCompatibility", false);
        receipt.put("versionId", versionId);
        receipt.put("files", plan.stream().map(p -> Map.of("path", root.relativize(p.path()).toString().replace('\\','/'),
                "sha256", p.hash(), "size", p.size())).toList());
        addBytes(plan, SafeFiles.resolve(root, "n9ezz-installations/" + backendId + ".json"), jsonBytes(receipt));

        Path profiles = SafeFiles.resolve(root, "launcher_profiles.json");
        byte[] originalProfiles = SafeFiles.exists(profiles) ? Files.readAllBytes(profiles) : null;
        if (originalProfiles != null && originalProfiles.length > 8 * 1024 * 1024) throw new IOException("Слишком большой launcher_profiles.json");
        Map<String,Object> profilesJson = originalProfiles == null ? new LinkedHashMap<>()
                : Json.object(Json.parse(new String(originalProfiles, StandardCharsets.UTF_8)));
        Map<String,Object> entries = Json.object(profilesJson.computeIfAbsent("profiles", k -> new LinkedHashMap<>()));
        boolean updateProfiles = !entries.containsKey(versionId);
        if (updateProfiles) {
            Map<String,Object> entry = new LinkedHashMap<>();
            entry.put("name", "N9Ezz 1.21.11 / " + (backendId.equals("fabric") ? "Fabric" : "Quilt (experimental)"));
            entry.put("type", "custom"); entry.put("lastVersionId", versionId); entry.put("gameDir", gameDir.toString());
            entry.put("created", Instant.now().toString()); entry.put("icon", "Grass");
            entries.put(versionId, entry);
        } else {
            Map<String,Object> existing = Json.object(entries.get(versionId));
            if (!versionId.equals(existing.get("lastVersionId")) || !gameDir.toString().equals(existing.get("gameDir")))
                throw new IOException("Профиль с таким ID уже занят. Он не изменён: " + versionId);
        }
        // Refuse conflicts and bad resources before installing any component.
        for (Planned p : plan) if (SafeFiles.exists(p.path()) && !p.matches())
            throw new IOException("Конфликт с существующим файлом; он не перезаписан: " + p.path());
        for (Bundle.Asset a : libraries) a.verifyResource();
        for (Bundle.Asset a : bundle.mods) a.verifyResource();
        Bootstrap.checkExistingMods(gameDir, bundle, backendId);

        Path stage = Files.createTempDirectory(root, "n9ezz-staging-");
        Map<Planned,Path> staged = new LinkedHashMap<>();
        List<Path> created = new ArrayList<>();
        Path backup = null;
        try {
            for (Planned p : plan) if (!SafeFiles.exists(p.path())) {
                Path temp = Files.createTempFile(stage, "component-", ".tmp");
                p.copy().copy(temp);
                if (Files.size(temp) != p.size() || !SafeFiles.hash(temp, "SHA-256").equals(p.hash()))
                    throw new IOException("Не прошла проверка временного файла: " + p.path().getFileName());
                staged.put(p, temp);
            }
            Path stagedProfiles = null;
            if (updateProfiles) {
                stagedProfiles = Files.createTempFile(stage, "profiles-", ".json");
                Files.write(stagedProfiles, jsonBytes(profilesJson));
            }
            checkProfilesUnchanged(profiles, originalProfiles);
            for (var e : staged.entrySet()) {
                Path target = e.getKey().path();
                SafeFiles.resolve(root, root.relativize(target).toString().replace('\\','/'));
                Files.createDirectories(target.getParent());
                Files.move(e.getValue(), target); // Never replace existing component files.
                created.add(target);
            }
            if (updateProfiles) {
                checkProfilesUnchanged(profiles, originalProfiles);
                if (originalProfiles != null) {
                    Path backups = SafeFiles.resolve(root, "n9ezz-backups");
                    Files.createDirectories(backups);
                    backup = Files.createTempFile(backups, "launcher-profiles-", ".json");
                    Files.write(backup, originalProfiles);
                }
                SafeFiles.atomicReplace(stagedProfiles, profiles);
            }
            return new Result(root, gameDir, versionId, created.size(), backup);
        } catch (Exception failure) {
            Collections.reverse(created);
            for (Path p : created) {
                try { Files.deleteIfExists(p); } catch (IOException cleanup) { failure.addSuppressed(cleanup); }
            }
            throw failure;
        } finally {
            try (var files = Files.list(stage)) { for (Path p : files.toList()) Files.deleteIfExists(p); }
            Files.deleteIfExists(stage);
        }
    }

    void verify(Path selectedRoot, String backendId) throws Exception {
        bundle.backend(backendId, true);
        Path root = selectedRoot.toAbsolutePath().normalize();
        requireVanilla(root);
        Path receipt = SafeFiles.resolve(root, "n9ezz-installations/" + backendId + ".json");
        Map<String,Object> installed = Json.object(Json.parse(Files.readString(receipt)));
        if (!bundle.version.equals(installed.get("loaderVersion")) || !backendId.equals(installed.get("backend")))
            throw new IOException("Установлена другая версия загрузчика");
        for (Object item : Json.array(installed.get("files"))) {
            var entry = Json.object(item);
            Path p = SafeFiles.resolve(root, Json.string(entry.get("path")));
            if (!Files.isRegularFile(p) || Files.size(p) != Json.number(entry.get("size"))
                    || !SafeFiles.hash(p, "SHA-256").equals(entry.get("sha256")))
                throw new IOException("Проверка установки не пройдена: " + p);
        }
        Path game = SafeFiles.resolve(root, "n9ezz-instances/" + backendId + "-" + bundle.minecraft);
        Bootstrap.checkExistingMods(game, bundle, backendId);
        for (Bundle.Asset a : bundle.mods) if (!a.matches(SafeFiles.resolve(game, a.path())))
            throw new IOException("Отсутствует или изменён компонент " + a.name());
    }
    private void requireVanilla(Path root) throws IOException {
        Path dir = SafeFiles.resolve(root, "versions/" + bundle.minecraft);
        Path metadata = dir.resolve(bundle.minecraft + ".json");
        Path jar = dir.resolve(bundle.minecraft + ".jar");
        if (!Files.isRegularFile(metadata) || !Files.isRegularFile(jar))
            throw new IOException("Сначала установи и запусти обычный Minecraft " + bundle.minecraft + " через Minecraft Launcher. Затем закрой лаунчер и повтори установку.");
        var base = Json.object(Json.parse(Files.readString(metadata)));
        if (!bundle.minecraft.equals(base.get("id"))) throw new IOException("Не совпадает версия базового Minecraft");
    }
    private static void checkProfilesUnchanged(Path path, byte[] original) throws IOException {
        if ((original == null && SafeFiles.exists(path)) || (original != null && (!SafeFiles.exists(path) || !Arrays.equals(original, Files.readAllBytes(path)))))
            throw new IOException("Профили лаунчера изменились во время установки. Закрой лаунчер и повтори попытку.");
    }
    private static byte[] jsonBytes(Object object) { return (Json.encode(object) + "\n").getBytes(StandardCharsets.UTF_8); }
    private static void addBytes(List<Planned> plan, Path path, byte[] bytes) throws IOException {
        plan.add(new Planned(path, bytes.length, SafeFiles.hash(new ByteArrayInputStream(bytes), "SHA-256"), target -> Files.write(target, bytes)));
    }
    private static void addAsset(List<Planned> plan, Path root, Bundle.Asset asset) throws IOException {
        plan.add(new Planned(SafeFiles.resolve(root, asset.path()), asset.size(), asset.sha256(), target -> {
            try (InputStream in = Bundle.open(asset.resource())) { Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING); }
        }));
    }
    static Path selfJar() throws Exception {
        Path self = Path.of(InstallEngine.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        if (!Files.isRegularFile(self) || !self.getFileName().toString().endsWith(".jar")) throw new IOException("Установщик нужно запускать из собранного JAR");
        return self;
    }
}
