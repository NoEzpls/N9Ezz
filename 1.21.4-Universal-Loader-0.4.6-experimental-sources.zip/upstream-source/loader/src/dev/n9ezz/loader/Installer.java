package dev.n9ezz.loader;

import java.awt.*;
import java.nio.file.*;
import java.util.*;
import javax.swing.*;

public final class Installer {
    private static final Color BG = new Color(20, 21, 29);
    private static final Color PANEL = new Color(31, 32, 43);
    private static final Color ACCENT = new Color(160, 125, 255);
    private static final Color TEXT = new Color(234, 234, 243);
    public static void main(String[] args) {
        try {
            Bundle bundle = new Bundle();
            if (args.length == 0) {
                if (GraphicsEnvironment.isHeadless()) throw new IllegalStateException("Графический экран недоступен. Используй --help.");
                SwingUtilities.invokeLater(() -> showWindow(bundle));
                return;
            }
            if (args.length == 1 && args[0].equals("--help")) {
                System.out.println("N9Ezz Loader 0.1.0 — prototype, Minecraft 1.21.11 / Java 21\n"
                        + "  --check-bundle\n  --platforms\n"
                        + "  --install --root <minecraft-directory> --backend fabric\n"
                        + "  --install --root <minecraft-directory> --backend quilt --allow-experimental\n"
                        + "  --verify --root <minecraft-directory> --backend fabric|quilt\n"
                        + "No launch-time test of the bundled Minecraft client has been performed.");
                return;
            }
            if (args.length == 1 && args[0].equals("--platforms")) {
                for (var b : bundle.backends()) System.out.println(b.get("id") + ": " + b.get("status") + "; gameLaunchTested=false");
                return;
            }
            if (args.length == 1 && args[0].equals("--check-bundle")) {
                bundle.verifyAll();
                System.out.println("BUNDLE_CHECK_OK — embedded file integrity only; Minecraft was not started.");
                return;
            }
            String action = args[0];
            if (!action.equals("--install") && !action.equals("--verify")) throw new IllegalArgumentException("Неизвестная команда. Используй --help.");
            Map<String,String> options = new HashMap<>();
            boolean experimental = false;
            for (int i = 1; i < args.length; i++) {
                if (args[i].equals("--allow-experimental")) { experimental = true; continue; }
                String key = args[i];
                if ((!key.equals("--root") && !key.equals("--backend")) || ++i == args.length || options.putIfAbsent(key, args[i]) != null)
                    throw new IllegalArgumentException("Некорректные или повторяющиеся параметры. Используй --help.");
            }
            if (!options.containsKey("--root") || !options.containsKey("--backend")) throw new IllegalArgumentException("Нужны --root и --backend.");
            Path root = Path.of(options.get("--root"));
            InstallEngine engine = new InstallEngine(bundle);
            if (action.equals("--verify")) {
                engine.verify(root, options.get("--backend"));
                System.out.println("INSTALL_CHECK_OK — installed file integrity only; Minecraft was not started.");
            } else {
                InstallEngine.Result result = engine.install(root, options.get("--backend"), experimental);
                System.out.println("INSTALLED " + result.versionId() + "; new files=" + result.filesCreated());
                System.out.println("Профиль игры: " + result.gameDir());
                System.out.println("Открой Minecraft Launcher и выбери профиль N9Ezz. Запуск игры в этой среде не проверен.");
                if (result.profileBackup() != null) System.out.println("Резервная копия профилей: " + result.profileBackup());
            }
        } catch (Exception e) {
            System.err.println("N9Ezz: " + e.getMessage());
            System.exit(2);
        }
    }
    private static Path defaultRoot() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("win") && System.getenv("APPDATA") != null) return Path.of(System.getenv("APPDATA"), ".minecraft");
        if (os.contains("mac")) return Path.of(System.getProperty("user.home"), "Library", "Application Support", "minecraft");
        return Path.of(System.getProperty("user.home"), ".minecraft");
    }
    private static void showWindow(Bundle bundle) {
        UIManager.put("Panel.background", BG); UIManager.put("Label.foreground", TEXT);
        UIManager.put("OptionPane.background", BG); UIManager.put("OptionPane.messageForeground", TEXT);
        JFrame frame = new JFrame("N9Ezz Loader · 0.1.0 prototype");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel content = new JPanel(); content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(26, 28, 26, 28));
        JLabel title = new JLabel("N9Ezz Loader"); title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30)); title.setForeground(ACCENT);
        content.add(title); content.add(Box.createVerticalStrut(10));
        content.add(new JLabel("Minecraft 1.21.11  /  N9Ezz 1.5.3 встроен в комплект"));
        content.add(Box.createVerticalStrut(18));
        JTextArea note = new JTextArea("Прототип личного загрузчика. Выбирается один движок запуска.\nСовместная работа четырёх систем пока не реализована.\nЗапуск Minecraft в этой сборке ещё не проверен.");
        note.setEditable(false); note.setOpaque(false); note.setForeground(TEXT);
        note.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13)); note.setFocusable(false);
        content.add(note); content.add(Box.createVerticalStrut(18));
        content.add(new JLabel("Каталог Minecraft Launcher")); content.add(Box.createVerticalStrut(6));
        JTextField path = new JTextField(defaultRoot().toString()); path.setBackground(PANEL); path.setForeground(TEXT); path.setCaretColor(TEXT);
        JPanel pathRow = new JPanel(new BorderLayout(8, 0)); pathRow.add(path, BorderLayout.CENTER);
        JButton browse = new JButton("Выбрать…"); pathRow.add(browse, BorderLayout.EAST); pathRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        content.add(pathRow); content.add(Box.createVerticalStrut(16));
        String[] labels = {"Fabric 0.19.2 — прототип", "Quilt 0.30.1 — эксперимент", "Forge — перенос N9Ezz не реализован", "NeoForge — совместимость не реализована"};
        JComboBox<String> backend = new JComboBox<>(labels); backend.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34)); content.add(backend);
        JCheckBox experimental = new JCheckBox("Разрешить экспериментальную установку Quilt");
        experimental.setBackground(BG); experimental.setForeground(TEXT); content.add(experimental);
        content.add(Box.createVerticalStrut(15));
        JLabel hint = new JLabel("Закрой лаунчер. Обычный Minecraft 1.21.11 должен быть уже установлен."); hint.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12)); content.add(hint);
        content.add(Box.createVerticalStrut(12));
        JButton install = new JButton("Установить отдельный профиль N9Ezz");
        install.setBackground(ACCENT); install.setForeground(new Color(15, 15, 22)); install.setFocusPainted(false);
        content.add(install); content.add(Box.createVerticalStrut(12));
        JLabel status = new JLabel("Настройки, миры и моды других профилей сохранятся."); content.add(status);
        backend.addActionListener(e -> install.setEnabled(backend.getSelectedIndex() < 2));
        browse.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(path.getText()); chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) path.setText(chooser.getSelectedFile().getAbsolutePath());
        });
        install.addActionListener(e -> {
            String id = backend.getSelectedIndex() == 0 ? "fabric" : "quilt";
            Path selected;
            try { selected = Path.of(path.getText()); } catch (InvalidPathException ex) { status.setText("Некорректный путь"); return; }
            boolean allow = experimental.isSelected();
            install.setEnabled(false); browse.setEnabled(false); backend.setEnabled(false); path.setEnabled(false); experimental.setEnabled(false);
            status.setText("Проверка компонентов и установка…");
            new SwingWorker<InstallEngine.Result, Void>() {
                protected InstallEngine.Result doInBackground() throws Exception { return new InstallEngine(bundle).install(selected, id, allow); }
                protected void done() {
                    install.setEnabled(backend.getSelectedIndex() < 2); browse.setEnabled(true); backend.setEnabled(true); path.setEnabled(true); experimental.setEnabled(true);
                    try {
                        get(); status.setText("Установлено. Открой Minecraft Launcher и выбери профиль N9Ezz.");
                        JOptionPane.showMessageDialog(frame, "Профиль N9Ezz создан.\nОткрой Minecraft Launcher и выбери его в списке установок.\nЭто прототип: игровой запуск ещё требует проверки.", "N9Ezz", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        Throwable cause = ex.getCause() == null ? ex : ex.getCause(); status.setText("Установка остановлена: " + cause.getMessage());
                        JOptionPane.showMessageDialog(frame, cause.getMessage(), "N9Ezz — установка остановлена", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }.execute();
        });
        frame.setContentPane(content); frame.setSize(750, 495); frame.setMinimumSize(new Dimension(720, 495));
        frame.setLocationRelativeTo(null); frame.setVisible(true);
    }
}
