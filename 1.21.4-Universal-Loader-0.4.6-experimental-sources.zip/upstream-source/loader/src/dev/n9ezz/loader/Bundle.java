package dev.n9ezz.loader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

final class Bundle {
    final Map<String,Object> index;
    final String version;
    final String minecraft;
    final List<Asset> mods;
    Bundle() throws IOException {
        index = Json.object(Json.parse(text("bundle/index.json")));
        if (Json.number(index.get("schema")) != 1) throw new IOException("Неподдерживаемый формат сборки");
        version = Json.string(index.get("version"));
        minecraft = Json.string(index.get("minecraft"));
        mods = assets(index.get("mods"));
    }
    static InputStream open(String name) throws IOException {
        if (!name.startsWith("bundle/") || name.contains("..") || name.contains("\\")) throw new IOException("Некорректный ресурс");
        InputStream in = Bundle.class.getResourceAsStream("/" + name);
        if (in == null) throw new IOException("В сборке отсутствует ресурс: " + name);
        return in;
    }
    static String text(String name) throws IOException {
        try (InputStream in = open(name)) { return new String(SafeFiles.readLimited(in, 2 * 1024 * 1024), StandardCharsets.UTF_8); }
    }
    List<Map<String,Object>> backends() {
        return Json.array(index.get("backends")).stream().map(Json::object).toList();
    }
    Map<String,Object> backend(String id, boolean allowExperimental) throws IOException {
        Map<String,Object> backend = backends().stream().filter(b -> id.equals(b.get("id"))).findFirst()
                .orElseThrow(() -> new IOException("Неизвестная платформа: " + id));
        String status = Json.string(backend.get("status"));
        if (status.equals("blocked")) throw new IOException(id + ": нужен отдельный перенос N9Ezz или проверенный слой совместимости для 1.21.11. Эта платформа в прототипе недоступна.");
        if (status.equals("experimental") && !allowExperimental) throw new IOException("Quilt не проверен запуском игры. Для экспериментальной установки нужен --allow-experimental.");
        return backend;
    }
    static List<Asset> assets(Object array) {
        return Json.array(array).stream().map(Json::object).map(Asset::new).toList();
    }
    void verifyAll() throws IOException {
        Set<String> checked = new HashSet<>();
        List<Asset> all = new ArrayList<>(mods);
        for (var b : backends()) if (b.containsKey("components")) all.addAll(assets(b.get("components")));
        for (Asset a : all) if (checked.add(a.resource())) a.verifyResource();
    }
    record Asset(String path, String resource, String sha256, String sha1, long size, String name, String source) {
        Asset(Map<String,Object> m) {
            this(Json.string(m.get("path")), Json.string(m.get("resource")), Json.string(m.get("sha256")),
                    Json.string(m.get("sha1")), Json.number(m.get("size")), Json.string(m.get("name")), Json.string(m.get("source")));
            if (!sha256.matches("[0-9a-f]{64}") || !sha1.matches("[0-9a-f]{40}") || size <= 0 || size > 128L * 1024 * 1024
                    || !resource.equals("bundle/blobs/" + sha256 + ".jar")) throw new IllegalArgumentException("Invalid bundle asset");
        }
        void verifyResource() throws IOException {
            try (InputStream in = open(resource)) {
                if (!SafeFiles.hash(in, "SHA-256").equals(sha256)) throw new IOException("Повреждён встроенный компонент: " + name);
            }
        }
        boolean matches(Path target) throws IOException {
            return Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && Files.size(target) == size && SafeFiles.hash(target, "SHA-256").equals(sha256);
        }
        void extractNew(Path target) throws IOException {
            if (SafeFiles.exists(target)) {
                if (!matches(target)) throw new IOException("Файл отличается от комплекта; он не перезаписан: " + target);
                return;
            }
            Files.createDirectories(target.getParent());
            Path tmp = Files.createTempFile(target.getParent(), "n9ezz-copy-", ".tmp");
            try {
                try (InputStream in = open(resource)) { Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING); }
                if (!matches(tmp)) throw new IOException("Не прошла проверка записи: " + name);
                Files.move(tmp, target);
            } finally { Files.deleteIfExists(tmp); }
        }
    }
}
