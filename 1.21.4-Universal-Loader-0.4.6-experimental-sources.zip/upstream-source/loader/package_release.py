#!/usr/bin/env python3
"""Package one self-contained reviewable prototype archive after validation."""
import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
JAR = ROOT / "dist/N9Ezz-Loader-0.1.0.jar"
OUTPUT = ROOT.parent / "N9Ezz-Loader-0.1.0-prototype.zip"


def main():
    results = json.loads((ROOT / "build/test-results.json").read_text())
    if len(results["passed"]) != 13 or results["minecraft_executed"] is not False:
        raise SystemExit("Expected the documented completed installer test run")
    members = []
    for name in ("README.md", "TEST_RESULTS.md", "THIRD_PARTY.md", "LICENSE", "Install-Windows.cmd"):
        members.append((ROOT / name, name))
    for name in ("build.py", "test_installer.py", "package_release.py", "dependencies.lock.json", "THIRD_PARTY.md", "LICENSE"):
        members.append((ROOT / name, "source/" + name))
    for folder in ("src", "tests"):
        for path in sorted((ROOT / folder).rglob("*.java")):
            members.append((path, "source/" + path.relative_to(ROOT).as_posix()))
    members.append((ROOT / "build/test-results.json", "source/build/test-results.json"))
    manifest = {
        "version": "0.1.0", "kind": "prototype", "minecraft_game_launch_tested": False,
        "four_loader_compatibility": False, "integration_checks_passed": 13, "unit_checks_passed": 27,
        "jar": JAR.name, "jar_sha256": hashlib.sha256(JAR.read_bytes()).hexdigest(),
        "sources": {name: hashlib.sha256(path.read_bytes()).hexdigest() for path, name in members},
    }
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
        out.write(JAR, JAR.name, compress_type=zipfile.ZIP_STORED)
        for path, name in members:
            out.write(path, name)
        out.writestr("release-manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(OUTPUT) as check:
        bad = check.testzip()
        if bad:
            raise SystemExit("Archive CRC failed: " + bad)
    print(json.dumps({"file": str(OUTPUT), "bytes": OUTPUT.stat().st_size,
                      "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(), "members": len(members) + 2}))


if __name__ == "__main__":
    main()
