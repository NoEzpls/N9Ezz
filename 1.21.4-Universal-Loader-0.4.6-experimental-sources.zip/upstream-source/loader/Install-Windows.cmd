@echo off
setlocal
set "N9EZZ_JAVA="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "N9EZZ_JAVA=%JAVA_HOME%\bin\java.exe"
if not defined N9EZZ_JAVA for /f "delims=" %%J in ('where java 2^>nul') do if not defined N9EZZ_JAVA set "N9EZZ_JAVA=%%J"
if not defined N9EZZ_JAVA if exist "%APPDATA%\.minecraft\runtime" for /r "%APPDATA%\.minecraft\runtime" %%J in (java.exe) do if exist "%%J" set "N9EZZ_JAVA=%%J"
if not defined N9EZZ_JAVA (
  echo Java was not found. Install Java 21, or open this JAR with an existing Java 21 runtime.
  pause
  exit /b 2
)
"%N9EZZ_JAVA%" -jar "%~dp0N9Ezz-Loader-0.1.0.jar"
if errorlevel 1 (
  echo Installer needs Java 17 or newer. Minecraft 1.21.11 needs Java 21 or newer.
  pause
)
endlocal
