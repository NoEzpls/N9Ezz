#!/usr/bin/env python3
"""Build a transparent N9Ezz bootstrap/installer with pinned embedded components."""
import argparse
import concurrent.futures
import hashlib
import json
import pathlib
import shutil
import subprocess
import urllib.parse
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
BUILD = ROOT / "build"
RES = BUILD / "resources"
VERSION = "0.1.0"
MC = "1.21.11"
PROFILES = {
    "fabric": "https://meta.fabricmc.net/v2/versions/loader/1.21.11/0.19.2/profile/json",
    "quilt": "https://meta.quiltmc.org/v3/versions/loader/1.21.11/0.30.1/profile/json",
}
HOSTS = {"meta.fabricmc.net", "meta.quiltmc.org", "maven.fabricmc.net", "maven.quiltmc.org"}
API_URL = "https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/0.141.3+1.21.11/fabric-api-0.141.3+1.21.11.jar"
API_SHA256 = "86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5"


def fetch(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in HOSTS:
        raise ValueError("Unapproved dependency host: " + url)
    req = urllib.request.Request(url, headers={"User-Agent": "N9Ezz-Loader-Build/0.1"})
    with urllib.request.urlopen(req, timeout=35) as response:
        if urllib.parse.urlparse(response.url).hostname not in HOSTS:
            raise ValueError("Unexpected dependency redirect")
        return response.read()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def component(data, path, source, kind, name):
    digest = hashlib.sha256(data).hexdigest()
    resource = "bundle/blobs/" + digest + ".jar"
    target = RES / resource
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return {"path": path, "resource": resource, "sha256": digest,
            "sha1": hashlib.sha1(data).hexdigest(), "size": len(data),
            "source": source, "kind": kind, "name": name}


def library_path(name):
    parts = name.split(":")
    if len(parts) not in (3, 4) or any("/" in p or "\\" in p or p in ("", ".", "..") for p in parts):
        raise ValueError("Unsupported Maven coordinate: " + name)
    group, artifact, version = parts[:3]
    suffix = "-" + parts[3] if len(parts) == 4 else ""
    return group.replace(".", "/") + "/" + artifact + "/" + version + "/" + artifact + "-" + version + suffix + ".jar"


def download_library(lib):
    path = library_path(lib["name"])
    url = lib["url"].rstrip("/") + "/" + path
    data = fetch(url)
    algorithm = "sha256"
    expected = lib.get("sha256")
    if not expected:
        try:
            expected = fetch(url + ".sha256").decode("ascii").strip().split()[0]
        except Exception:
            algorithm = "sha1"
            expected = fetch(url + ".sha1").decode("ascii").strip().split()[0]
    actual = hashlib.new(algorithm, data).hexdigest()
    if actual.lower() != expected.lower():
        raise ValueError("Checksum mismatch: " + lib["name"])
    if "size" in lib and len(data) != lib["size"]:
        raise ValueError("Size mismatch: " + lib["name"])
    result = component(data, "libraries/" + path, url, "library", lib["name"])
    result["publisherChecksum"] = algorithm + ":" + expected
    return result


def prepare(payload):
    index_file = RES / "bundle/index.json"
    if index_file.exists():
        index = json.loads(index_file.read_text(encoding="utf-8"))
        if hashlib.sha256(payload.read_bytes()).hexdigest() != index["mods"][0]["sha256"]:
            raise ValueError("Payload changed; use a new clean build directory")
        print("Reusing prepared, pinned bundle", flush=True)
        return
    with zipfile.ZipFile(payload) as jar:
        mod = json.loads(jar.read("fabric.mod.json"))
    if mod.get("id") != "pulse" or mod.get("version") != "1.5.3-n9ezz" or mod.get("depends", {}).get("minecraft") != MC:
        raise ValueError("Expected the supplied N9Ezz 1.5.3 client for Minecraft 1.21.11")
    profiles = {name: json.loads(fetch(url)) for name, url in PROFILES.items()}
    coordinates = {}
    for profile in profiles.values():
        if profile.get("inheritsFrom") != MC:
            raise ValueError("Unexpected Minecraft profile")
        for lib in profile["libraries"]:
            coordinates.setdefault(lib["name"], lib)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        libraries = list(pool.map(download_library, coordinates.values()))
    by_name = {lib["name"]: lib for lib in libraries}
    api = fetch(API_URL)
    if hashlib.sha256(api).hexdigest() != API_SHA256:
        raise ValueError("Fabric API checksum mismatch")
    mods = [component(payload.read_bytes(), "mods/N9Ezz-1.5.3.jar", "user-supplied", "mod", "N9Ezz 1.5.3"),
            component(api, "mods/fabric-api-0.141.3+1.21.11.jar", API_URL, "mod", "Fabric API 0.141.3")]
    backends = []
    for name, profile in profiles.items():
        components = [by_name[lib["name"]] for lib in profile["libraries"]]
        profile_resource = "bundle/profiles/" + name + ".json"
        write_json(RES / profile_resource, profile)
        backends.append({"id": name, "versionId": "n9ezz-" + name + "-1.21.11-0.1.0",
                         "mainClass": profile["mainClass"], "profile": profile_resource,
                         "status": "prototype" if name == "fabric" else "experimental",
                         "gameLaunchTested": False, "components": components})
    for name in ("forge", "neoforge"):
        backends.append({"id": name, "status": "blocked", "gameLaunchTested": False,
                         "reason": "N9Ezz 1.5.3 requires Fabric APIs and intermediary mappings. No verified compatibility layer for 1.21.11 is included."})
    index = {"schema": 1, "version": VERSION, "minecraft": MC, "minimumGameJava": 21,
             "payloadVersion": "1.5.3-n9ezz", "backends": backends, "mods": mods,
             "description": "Explicit N9Ezz bootstrap and offline installer; not a four-loader compatibility layer."}
    write_json(index_file, index)
    write_json(ROOT / "dependencies.lock.json", index)
    print("Prepared", len(libraries), "verified libraries and", len(mods), "mods", flush=True)


def restore_resources(archive):
    with zipfile.ZipFile(archive) as jar:
        for entry in jar.infolist():
            if not entry.filename.startswith("bundle/") or entry.is_dir():
                continue
            relative = pathlib.PurePosixPath(entry.filename)
            if ".." in relative.parts or relative.is_absolute():
                raise ValueError("Invalid embedded resource path")
            dest = RES.joinpath(*relative.parts)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(jar.read(entry))


def build():
    index = json.loads((RES / "bundle/index.json").read_text(encoding="utf-8"))
    for c in index["mods"] + [c for b in index["backends"] for c in b.get("components", [])]:
        if hashlib.sha256((RES / c["resource"]).read_bytes()).hexdigest() != c["sha256"]:
            raise ValueError("Prepared resource changed: " + c["name"])
    classes = BUILD / "classes"
    classes.mkdir(parents=True, exist_ok=True)
    sources = sorted((ROOT / "src").rglob("*.java"))
    compiler = ["javac"] if shutil.which("javac") else ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
    subprocess.run(compiler + ["--release", "17", "-encoding", "UTF-8", "-d", str(classes)] + [str(p) for p in sources], check=True)
    out = ROOT / "dist" / ("N9Ezz-Loader-" + VERSION + ".jar")
    out.parent.mkdir(parents=True, exist_ok=True)
    manifest = ("Manifest-Version: 1.0\r\nMain-Class: dev.n9ezz.loader.Installer\r\n"
                "Implementation-Title: N9Ezz Loader Prototype\r\nImplementation-Version: " + VERSION +
                "\r\nN9Ezz-Payload-Version: 1.5.3-n9ezz\r\n\r\n")
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as jar:
        jar.writestr("META-INF/MANIFEST.MF", manifest)
        for root in (classes, RES):
            for p in sorted(root.rglob("*")):
                if p.is_file():
                    jar.write(p, p.relative_to(root).as_posix())
        jar.write(ROOT / "THIRD_PARTY.md", "THIRD_PARTY.md")
    print("Built", out.name, out.stat().st_size, "bytes", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload", type=pathlib.Path)
    parser.add_argument("--from-bundle", type=pathlib.Path)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    if args.from_bundle:
        restore_resources(args.from_bundle)
    elif args.payload:
        prepare(args.payload)
    elif not (RES / "bundle/index.json").exists():
        parser.error("Use --payload ORIGINAL.jar or --from-bundle N9Ezz-Loader-0.1.0.jar")
    if not args.prepare_only:
        build()


if __name__ == "__main__":
    main()
