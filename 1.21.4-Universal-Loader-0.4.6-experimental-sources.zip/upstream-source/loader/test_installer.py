#!/usr/bin/env python3
"""Exercise the real installer JAR on disposable launcher fixtures, never the game."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
JAR = ROOT / "dist/N9Ezz-Loader-0.1.0.jar"
PASSED = []


def run(*args, code=0, jar=JAR):
    result = subprocess.run(["java", "-Djava.awt.headless=true", "-jar", str(jar), *map(str, args)], capture_output=True, text=True, timeout=90)
    if result.returncode != code:
        raise AssertionError(f"Expected {code}, got {result.returncode}: {result.stdout}\n{result.stderr}")
    return result.stdout + result.stderr


def passed(label):
    PASSED.append(label)
    print("PASS", label, flush=True)


def fixture(path):
    base = path / "versions/1.21.11"
    base.mkdir(parents=True)
    (base / "1.21.11.json").write_text(json.dumps({"id": "1.21.11", "javaVersion": {"majorVersion": 21}}))
    with zipfile.ZipFile(base / "1.21.11.jar", "w") as out:
        out.writestr("FIXTURE.txt", "Not Minecraft. Installation test only.")
    profiles = {"profiles": {"user-profile": {"name": "Existing", "lastVersionId": "1.21.11", "gameDir": "unchanged"}},
                "selectedProfile": "user-profile", "settings": {"keepLauncherOpen": True},
                "authenticationDatabase": {"fixture-account": {"accessToken": "not-a-real-token"}}}
    original = json.dumps(profiles, ensure_ascii=False, indent=2).encode()
    (path / "launcher_profiles.json").write_bytes(original)
    (path / "options.txt").write_text("user settings stay unchanged\n")
    return profiles, original


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    with zipfile.ZipFile(JAR) as jar:
        index = json.loads(jar.read("bundle/index.json"))
        payload = jar.read(index["mods"][0]["resource"])
        assert hashlib.sha256(payload).hexdigest() == index["mods"][0]["sha256"]
        with zipfile.ZipFile(__import__("io").BytesIO(payload)) as mod:
            metadata = json.loads(mod.read("fabric.mod.json"))
            assert metadata["name"] == "N9Ezz" and metadata["id"] == "pulse"
    assert "BUNDLE_CHECK_OK" in run("--check-bundle")
    passed("all embedded components match their SHA-256 fingerprints; N9Ezz remains labelled")
    states = run("--platforms")
    assert "forge: blocked" in states and "neoforge: blocked" in states and "quilt: experimental" in states
    passed("platform statuses do not claim four-loader compatibility")

    compiler = ["javac"] if shutil.which("javac") else ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
    test_classes = ROOT / "build/test-classes"
    test_classes.mkdir(parents=True, exist_ok=True)
    subprocess.run(compiler + ["--release", "17", "-encoding", "UTF-8", "-cp", str(JAR), "-d", str(test_classes)]
                   + [str(p) for p in (ROOT / "tests").rglob("*.java")], check=True)
    unit = subprocess.run(["java", "-cp", str(JAR) + os.pathsep + str(test_classes), "dev.n9ezz.loader.UnitChecks"], capture_output=True, text=True, check=True)
    print(unit.stdout.strip(), flush=True)
    passed("strict JSON, Unicode/BOM, path traversal, game argument ambiguity and backend gates")

    with tempfile.TemporaryDirectory(prefix="n9ezz-installer-tests-") as temp:
        root = pathlib.Path(temp) / "Тест Minecraft с пробелами"
        profiles, original = fixture(root)
        for backend in ("forge", "neoforge", "quilt"):
            before = sorted(str(p.relative_to(root)) for p in root.rglob("*"))
            run("--install", "--root", root, "--backend", backend, code=2)
            assert before == sorted(str(p.relative_to(root)) for p in root.rglob("*"))
        passed("unsupported backends and unapproved Quilt cause no installation writes")
        no_game = pathlib.Path(temp) / "missing-game"
        run("--install", "--root", no_game, "--backend", "fabric", code=2)
        assert not no_game.exists()
        passed("missing base Minecraft fails without creating a substitute game")

        run("--install", "--root", root, "--backend", "fabric")
        installed_profiles = json.loads((root / "launcher_profiles.json").read_text())
        for key in ("selectedProfile", "settings", "authenticationDatabase"):
            assert installed_profiles[key] == profiles[key]
        assert installed_profiles["profiles"]["user-profile"] == profiles["profiles"]["user-profile"]
        backups = list((root / "n9ezz-backups").glob("*.json"))
        assert len(backups) == 1 and backups[0].read_bytes() == original
        assert (root / "options.txt").read_text() == "user settings stay unchanged\n"
        game = root / "n9ezz-instances/fabric-1.21.11"
        assert (game / "mods/N9Ezz-1.5.3.jar").read_bytes() == payload
        version_id = next(b["versionId"] for b in index["backends"] if b["id"] == "fabric")
        version = json.loads((root / "versions" / version_id / (version_id + ".json")).read_text())
        assert version["mainClass"] == "dev.n9ezz.loader.Bootstrap" and version["inheritsFrom"] == "1.21.11"
        assert installed_profiles["profiles"][version_id]["gameDir"] == str(game)
        assert "INSTALL_CHECK_OK" in run("--verify", "--root", root, "--backend", "fabric")
        passed("Fabric installation, isolated profile, byte-identical mod, exact profile backup and preserved unrelated settings")

        profile_before = (root / "launcher_profiles.json").read_bytes()
        mod_mtime = (game / "mods/N9Ezz-1.5.3.jar").stat().st_mtime_ns
        output = run("--install", "--root", root, "--backend", "fabric")
        assert "new files=0" in output
        assert (root / "launcher_profiles.json").read_bytes() == profile_before
        assert (game / "mods/N9Ezz-1.5.3.jar").stat().st_mtime_ns == mod_mtime
        assert len(list((root / "n9ezz-backups").glob("*.json"))) == 1
        passed("repeated installation is idempotent and does not rewrite profiles or components")

        duplicate = game / "mods/duplicate-pulse.jar"
        duplicate.write_bytes(payload)
        output = run("--verify", "--root", root, "--backend", "fabric", code=2)
        assert "Лишняя копия" in output and duplicate.exists()
        duplicate.unlink()
        foreign = game / "mods/forge-fixture.jar"
        with zipfile.ZipFile(foreign, "w") as out:
            out.writestr("META-INF/mods.toml", 'modLoader="javafml"\n')
        assert "другой платформы" in run("--verify", "--root", root, "--backend", "fabric", code=2)
        foreign.unlink()
        passed("duplicate Pulse and wrong-platform mods are detected without deleting user files")

        run("--install", "--root", root, "--backend", "quilt", "--allow-experimental")
        assert "INSTALL_CHECK_OK" in run("--verify", "--root", root, "--backend", "quilt")
        assert (root / "n9ezz-instances/quilt-1.21.11/mods/N9Ezz-1.5.3.jar").read_bytes() == payload
        passed("experimental Quilt installs to a separate profile with verified components; game not executed")

        conflict = pathlib.Path(temp) / "conflict"
        _, conflict_original = fixture(conflict)
        old_mod = conflict / "n9ezz-instances/fabric-1.21.11/mods/N9Ezz-1.5.3.jar"
        old_mod.parent.mkdir(parents=True)
        old_mod.write_bytes(b"User file must not be overwritten")
        output = run("--install", "--root", conflict, "--backend", "fabric", code=2)
        assert "Конфликт" in output and old_mod.read_bytes() == b"User file must not be overwritten"
        assert (conflict / "launcher_profiles.json").read_bytes() == conflict_original
        assert not (conflict / "libraries").exists()
        passed("conflicting existing files stop installation before component writes")

        changed_mod = game / "mods/N9Ezz-1.5.3.jar"
        changed_mod.write_bytes(b"changed")
        assert "не пройдена" in run("--verify", "--root", root, "--backend", "fabric", code=2)
        changed_mod.write_bytes(payload)
        passed("post-install component corruption is detected")

        corrupted = pathlib.Path(temp) / "damaged-bundle.jar"
        small = min((c for b in index["backends"] for c in b.get("components", [])), key=lambda c: c["size"])
        with zipfile.ZipFile(JAR) as source, zipfile.ZipFile(corrupted, "w", compression=zipfile.ZIP_DEFLATED) as out:
            for entry in source.infolist():
                data = source.read(entry)
                if entry.filename == small["resource"]:
                    data = bytes([data[0] ^ 1]) + data[1:]
                out.writestr(entry, data)
        assert "Повреждён" in run("--check-bundle", jar=corrupted, code=2)
        passed("tampered embedded dependency is rejected")

        java_properties = subprocess.run(["java", "-XshowSettings:properties", "-version"], capture_output=True, text=True).stderr
        if "java.specification.version = 17" in java_properties:
            result = subprocess.run(["java", "-cp", str(JAR), "dev.n9ezz.loader.Bootstrap", "--gameDir", str(game)], capture_output=True, text=True)
            assert result.returncode != 0 and "нужна Java 21" in result.stderr
            passed("game bootstrap refuses Java 17 before executing Minecraft or N9Ezz")
    print("RESULT", len(PASSED), "integration checks passed; Minecraft not executed", flush=True)
    (ROOT / "build/test-results.json").write_text(json.dumps({"passed": PASSED, "minecraft_executed": False}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
