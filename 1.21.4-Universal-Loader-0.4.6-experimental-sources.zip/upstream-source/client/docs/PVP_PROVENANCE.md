# Происхождение PvP-функций N9Ezz 1.5.0

Дата: 2026-10-06.

## Использованные файлы

- `Pulse visuals 1.21.11 BETA.jar` — предоставленная основа. Итоговый клиент сохраняет визуалы, интерфейс и ресурсы. `MergeClient` добавляет хуки регистрации/интерфейса и исправляет пустые обработчики FriendsPanel.
- `zenith-fix.jar` — предоставленный донор под Minecraft 1.21.4. Анализировались ZIP-структура, метаданные, константы и байткод. Донор не запускался; его классы и ресурсы не копируются в итоговый JAR.
- Исходники дополнений N9Ezz предыдущих версий — продолжены с сохранением профилей, конфигов, визуалов и команд.

## Статически распознанные модули Zenith

Названия определены по строковым константам и связям классов предоставленного JAR.

| Модуль | Класс в доноре |
|---|---|
| Aura | `zenith/lIIl1lI11l111lIl1lIIII1Ill.class` |
| TriggerBot | `zenith/I1lIII1I1l1I.class` |
| Criticals | `zenith/l1I1llll1llIIl11llll.class` |
| AutoTotem | `zenith/I11IIllll1l1IllII1l.class` |
| AntiBot | `zenith/IIlIIIIl1llI.class` |
| AimAssist | `zenith/IllI1l11I1lIIIIlI1lllllll.class` |
| Reach | `zenith/I111111I11l1IIlI11l1.class` |
| NoPush | `zenith/lII1llI1Ill1lllIlll11ll11I1l.class` |
| NoSlow | `zenith/lIl1ll1IIIl11IIll1Il1lll1I1.class` |
| Velocity | `zenith/llllII11l1111IlI1l.class` |

В Aura/TriggerBot найдены варианты приоритета по расстоянию, HP, броне и направлению прицела, фильтры, работа со щитом/топором, заряд удара и CPS. Эти идеи учтены в самостоятельно написанной общей логике N9Ezz. Версия Minecraft и API отличаются; прямой бинарный перенос не выполнялся.

## Остальные названные клиенты

Для Doomsday, Wexide, Delta, Nursultan и Catlavan не были предоставлены и проверены соответствующие исходники. Публичные описания функций не считаются исходным кодом. Совпадение названия модуля не подтверждает перенос из конкретного клиента.

21 новый модуль — собственные реализации: Auto Weapon, Auto Shield, Auto Gapple, Auto Heal, Auto Armor, Auto Refill, Auto Mace, Bow Release, Projectile Aim, Pearl Throw, W Tap, Target Strafe, Velocity, No Push, No Slow, Anti Web, Anti Bot, Team Check, Reach, Crystal Aura, Web Trap.

## Проверка

Дополнения собраны для Minecraft 1.21.11 / Fabric / Java 21. Проверки выполнялись локально в отдельном мире с тестовым игроком. Совместимость с конкретными PvP-серверами, античитами и изменёнными правилами боя не проверена. Упаковка кода и скрытие интерфейса не устанавливают такую совместимость.
