import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Reproducible overlay merge. The original file is never modified. */
public final class MergeClient implements Opcodes {
    private static final String MATRIX="Lorg/joml/Matrix3x2fStack;";
    private static final String RENDER="Lpulse/render/Renderer2D;";
    private static final String MODULE="Lpulse/module/ClientModule;";
    private static final String CAT="Lpulse/module/ModuleCategory;";
    public static void main(String[] args) throws Exception {
        if(args.length!=3) throw new IllegalArgumentException("original.jar overlay.jar output.jar");
        Map<String,byte[]> files=read(args[0]);
        Map<String,byte[]> overlay=read(args[1]);
        for(var entry:overlay.entrySet()) {
            String name=entry.getKey();
            if(name.startsWith("pulse/n9ezz/") || name.equals("pulse/module/ModuleCategory.class") || name.equals("pulse/gui/core/PulseLogoOverlay.class") || name.equals("n9ezz.mixins.json") || name.contains("refmap"))
                files.put(name,entry.getValue());
        }
        for(String name:List.of("pulse/module/ModuleRegistry.class","pulse/module/ClientModule.class","pulse/gui/modules/ModulesTab.class","pulse/gui/modules/ModuleCard.class","pulse/gui/modules/ModuleRowRenderer.class","pulse/gui/core/ClickGuiFrameOverlay.class","pulse/hud/notifications/HudNotificationCenter.class","pulse/gui/friends/FriendsPanel.class")) {
            byte[] bytes=files.get(name);
            if(bytes==null) throw new IllegalStateException("Missing "+name);
            files.put(name,patch(name,bytes));
        }
        String metadata=new String(files.get("fabric.mod.json"),StandardCharsets.UTF_8);
        metadata=metadata.replace("\"name\": \"pulse\"","\"name\": \"N9Ezz\"")
                         .replace("\"version\": \"1.0-SNAPSHOT\"","\"version\": \"1.5.3-n9ezz\"")
                         .replace("pulse client for Minecraft (no native protection stubbed)","N9Ezz combat modules integrated with the supplied Pulse visuals")
                         .replace("\"pulse.mixins.json\"","\"pulse.mixins.json\", \"n9ezz.mixins.json\"");
        files.put("fabric.mod.json",metadata.getBytes(StandardCharsets.UTF_8));
        // The supplied client's frame asks for this texture under a second path.
        if(!files.containsKey("assets/pulse/textures/icon.png") && files.containsKey("assets/pulse/icon.png"))
            files.put("assets/pulse/textures/icon.png",files.get("assets/pulse/icon.png"));
        files.put("N9EZZ-README.txt",("N9Ezz / Fabric 1.21.11 / Java 21\n"+
            "Integrated with user-supplied Pulse. Do not install the original Pulse jar alongside this jar.\n"+
            "Menu: original Pulse menu key (Right Shift), Modules > Читы. Right-click a module for settings.\n"+
            "All combat modules start disabled. Native Pulse activation-key settings are supported.\n"+
            "Modules > Читы > Отключить все читы disables every added module and saves states.\n"+
            "The category background and stars transition smoothly over 500 ms.\n"+
            "Скрыть всё or either Ctrl + Delete: disable and hide the added category; Ctrl + Delete again restores it with modules off.\n"+
            "Profiles: the Профиль button applies compatible module combinations and settings.\n"+
            "Local commands: /cfg create <name>, /cfg load <name or preset>, /cfg list. Names may contain spaces.\n"+
            "Configs include module states, binds, settings, HUD, friends, markers and client theme.\n"+
            "Hitboxes draw configurable outlines matching the expanded targeting area.\n"+
            "Aim Bot turns each rendered frame with velocity easing; Плавность (%) defaults to 85.\n"+
            "Friends: existing Friends tab; shared exclusion in all targeting modules.\n"+
            "Damage bonus affects only the integrated single-player server. Remote servers validate damage and reach.\n"+
            "No promise of anti-cheat invisibility.\n").getBytes(StandardCharsets.UTF_8));
        files.entrySet().removeIf(e->e.getKey().matches("META-INF/[^/]+\\.(SF|RSA|DSA)"));
        Path output=Path.of(args[2]);Files.createDirectories(output.getParent());
        try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(output))) {
            for(var entry:files.entrySet()) {
                ZipEntry ze=new ZipEntry(entry.getKey());ze.setTime(0);zip.putNextEntry(ze);zip.write(entry.getValue());zip.closeEntry();
            }
        }
        System.out.println("Merged client: "+files.size()+" entries, "+Files.size(output)+" bytes");
    }
    private static Map<String,byte[]> read(String file) throws IOException {
        Map<String,byte[]> out=new TreeMap<>();
        try(ZipFile zip=new ZipFile(file)) {
            var entries=zip.entries();
            while(entries.hasMoreElements()) {
                var e=entries.nextElement();if(!e.isDirectory()) out.put(e.getName(),zip.getInputStream(e).readAllBytes());
            }
        }
        return out;
    }
    private static byte[] patch(String name,byte[] bytes) {
        ClassNode node=new ClassNode();new ClassReader(bytes).accept(node,0);
        int changes=0;
        if(name.endsWith("ModuleRegistry.class")) {
            for(MethodNode method:node.methods) if(method.name.equals("init") && method.desc.equals("()V")) {
                for(AbstractInsnNode in:method.instructions.toArray()) if(in.getOpcode()==RETURN) {
                    InsnList hook=new InsnList();
                    hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/N9Ezz","modules","()["+MODULE,false));
                    hook.add(new MethodInsnNode(INVOKESTATIC,node.name,"register","(["+MODULE+")V",false));
                    method.instructions.insertBefore(in,hook);changes++;
                }
            }
        } else if(name.endsWith("FriendsPanel.class")) {
            for(MethodNode method:node.methods){
                String target=null;boolean entry=method.desc.equals("(Lpulse/gui/friends/HistoryEntry;)V");
                if(entry&&method.name.equals("a"))target="add";else if(entry&&method.name.equals("b"))target="remove";
                else if(method.name.equals("b")&&method.desc.equals("()V"))target="clear";
                if(target==null)continue;
                method.instructions.clear();method.tryCatchBlocks.clear();if(method.localVariables!=null)method.localVariables.clear();
                method.instructions.add(new VarInsnNode(ALOAD,0));if(entry)method.instructions.add(new VarInsnNode(ALOAD,1));
                method.instructions.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/FriendSupport",target,"(Lpulse/gui/friends/FriendsPanel;"+(entry?"Lpulse/gui/friends/HistoryEntry;":"")+")V",false));
                method.instructions.add(new InsnNode(RETURN));method.maxStack=entry?2:1;changes++;
            }
        } else if(name.endsWith("HudNotificationCenter.class")) {
            for(MethodNode method:node.methods) if(method.name.equals("a") && method.desc.equals("("+MATRIX+RENDER+")V")) {
                InsnList hook=new InsnList();hook.add(new VarInsnNode(ALOAD,0));hook.add(new VarInsnNode(ALOAD,0));
                hook.add(new FieldInsnNode(GETFIELD,node.name,"k","Ljava/util/Queue;"));hook.add(new VarInsnNode(ALOAD,0));
                hook.add(new FieldInsnNode(GETFIELD,node.name,"l","Lpulse/hud/notifications/HudNotification;"));
                hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/InterfaceMode","visibleNotices","(Ljava/util/Queue;Lpulse/hud/notifications/HudNotification;)Lpulse/hud/notifications/HudNotification;",false));
                hook.add(new FieldInsnNode(PUTFIELD,node.name,"l","Lpulse/hud/notifications/HudNotification;"));
                method.instructions.insert(hook);changes++;
            }
        } else if(name.endsWith("ClientModule.class")) {
            for(MethodNode method:node.methods) {
                if(method.name.equals("<init>")) for(AbstractInsnNode in:method.instructions.toArray()) {
                    if(in instanceof MethodInsnNode call && call.owner.equals("pulse/module/ModuleInfo") && call.desc.equals("()Ljava/lang/String;")) {
                        method.instructions.insert(in,new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/StringCodec","decode","(Ljava/lang/String;)Ljava/lang/String;",false));changes++;
                    }
                }
                if(Set.of("setEnabledState","setEnabledStateQuiet","setSubscribed").contains(method.name) && method.desc.equals("(Z)V")) {
                    InsnList hook=new InsnList();hook.add(new VarInsnNode(ILOAD,1));hook.add(new VarInsnNode(ALOAD,0));
                    hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/InterfaceMode","allowActivation","(Z"+MODULE+")Z",false));
                    hook.add(new VarInsnNode(ISTORE,1));method.instructions.insert(hook);changes++;
                }
            }
        } else if(name.endsWith("ModulesTab.class")) {
            for(MethodNode method:node.methods) if(method.name.equals("<clinit>")) {
                method.instructions.clear();method.tryCatchBlocks.clear();
                if(method.localVariables!=null) method.localVariables.clear();
                InsnList code=method.instructions;
                code.add(new InsnNode(ICONST_4));code.add(new TypeInsnNode(ANEWARRAY,"java/lang/String"));
                String[] names={"Visuals","HUD","Utilities","Читы"};
                for(int i=0;i<4;i++) { code.add(new InsnNode(DUP));code.add(new InsnNode(ICONST_0+i));code.add(new LdcInsnNode(names[i]));code.add(new InsnNode(AASTORE)); }
                code.add(new FieldInsnNode(PUTSTATIC,node.name,"a","[Ljava/lang/String;"));
                code.add(new InsnNode(ICONST_4));code.add(new TypeInsnNode(ANEWARRAY,"pulse/module/ModuleCategory"));
                String[] cats={"VISUALS","HUD","UTILITIES","CHEATS"};
                for(int i=0;i<4;i++) { code.add(new InsnNode(DUP));code.add(new InsnNode(ICONST_0+i));code.add(new FieldInsnNode(GETSTATIC,"pulse/module/ModuleCategory",cats[i],CAT));code.add(new InsnNode(AASTORE)); }
                code.add(new FieldInsnNode(PUTSTATIC,node.name,"b","["+CAT));code.add(new InsnNode(RETURN));changes++;
            }
            for(MethodNode method:node.methods) {
                if(method.name.equals("c") && method.desc.equals("()[Ljava/lang/String;")) {
                    for(AbstractInsnNode in:method.instructions.toArray()) if(in.getOpcode()==ARETURN) {
                        method.instructions.insertBefore(in,new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/InterfaceMode","visibleNames","([Ljava/lang/String;)[Ljava/lang/String;",false));changes++;
                    }
                }
                if(method.name.equals("e") && method.desc.equals("()Ljava/util/List;")) {
                    for(AbstractInsnNode in:method.instructions.toArray()) if(in.getOpcode()==ARETURN) {
                        method.instructions.insertBefore(in,new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/InterfaceMode","visibleEntries","(Ljava/util/List;)Ljava/util/List;",false));changes++;
                    }
                }
                if(method.name.equals("a") && method.desc.equals("("+MATRIX+RENDER+"FFII)V")) {
                    for(AbstractInsnNode in:method.instructions.toArray()) if(in.getOpcode()==RETURN) {
                        InsnList hook=new InsnList();
                        for(int i=0;i<=2;i++) hook.add(new VarInsnNode(ALOAD,i));
                        hook.add(new VarInsnNode(FLOAD,3));hook.add(new VarInsnNode(FLOAD,4));
                        hook.add(new VarInsnNode(ILOAD,5));hook.add(new VarInsnNode(ILOAD,6));
                        hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","drawButton","(Lpulse/gui/modules/ModulesTab;Ljava/lang/Object;"+RENDER+"FFII)V",false));
                        method.instructions.insertBefore(in,hook);changes++;
                    }
                } else if((method.name.equals("a") || method.name.equals("b")) && method.desc.equals("(FFII)V")) {
                    InsnList hook=new InsnList();LabelNode original=new LabelNode();
                    hook.add(new VarInsnNode(ALOAD,0));hook.add(new VarInsnNode(FLOAD,1));hook.add(new VarInsnNode(FLOAD,2));
                    hook.add(new VarInsnNode(ILOAD,3));hook.add(new VarInsnNode(ILOAD,4));
                    hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","clickButton","(Lpulse/gui/modules/ModulesTab;FFII)Z",false));
                    hook.add(new JumpInsnNode(IFEQ,original));hook.add(new InsnNode(RETURN));
                    hook.add(original);hook.add(new FrameNode(F_SAME,0,null,0,null));
                    method.instructions.insert(hook);changes++;
                }
            }
        } else if(name.endsWith("ClickGuiFrameOverlay.class")) {
            for(MethodNode method:node.methods) if(method.name.equals("a") && method.desc.equals("("+MATRIX+RENDER+"FFII)V")) {
                method.instructions.insert(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","beginFrame","()V",false));changes++;
                for(AbstractInsnNode in:method.instructions.toArray()) {
                    if(in instanceof FieldInsnNode field && field.getOpcode()==GETSTATIC && field.owner.equals("pulse/theme/Theme") && field.desc.equals("Ljava/awt/Color;")) {
                        method.instructions.insert(in,new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","sectionColor","(Ljava/awt/Color;)Ljava/awt/Color;",false));changes++;
                    } else if(in.getOpcode()==RETURN) {
                        InsnList hook=new InsnList();
                        hook.add(new VarInsnNode(ALOAD,1));hook.add(new VarInsnNode(ALOAD,2));
                        hook.add(new VarInsnNode(FLOAD,3));hook.add(new VarInsnNode(FLOAD,4));
                        hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/gui/core/PulseClickGuiScreen","d","()F",false));
                        hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/gui/core/PulseClickGuiScreen","e","()F",false));
                        hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","section","(Ljava/lang/Object;"+RENDER+"FFFF)V",false));
                        method.instructions.insertBefore(in,hook);changes++;
                    }
                }
            }
        } else if(name.endsWith("ModuleRowRenderer.class")) {
            for(MethodNode method:node.methods) if(method.name.equals("a") && method.desc.contains("Lpulse/gui/core/GuiEntry;")) {
                for(AbstractInsnNode in:method.instructions.toArray()) if(in instanceof MethodInsnNode call
                    && call.owner.equals("java/awt/Color") && call.name.equals("<init>") && call.desc.equals("(III)V")) {
                    InsnList hook=new InsnList();hook.add(new VarInsnNode(ALOAD,3));
                    hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","label","(Ljava/awt/Color;Lpulse/gui/core/GuiEntry;)Ljava/awt/Color;",false));
                    method.instructions.insert(in,hook);changes++;
                }
            }
        } else if(name.endsWith("ModuleCard.class")) {
            String anchored="("+MATRIX+RENDER+"FFIIFFI)V";
            String floating="("+MATRIX+RENDER+"FFIIFFFI)V";
            for(MethodNode method:node.methods) if(method.name.equals("a") && (method.desc.equals(anchored)||method.desc.equals(floating))) {
                if(method.desc.equals(floating)) {
                    for(AbstractInsnNode in:method.instructions.toArray()) if(in instanceof FieldInsnNode field
                        && field.getOpcode()==PUTFIELD && field.owner.equals(node.name) && field.name.equals("w") && field.desc.equals("F")) {
                        InsnList position=new InsnList();
                        position.add(new VarInsnNode(ALOAD,0));position.add(new FieldInsnNode(GETFIELD,node.name,"n",MODULE));
                        position.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","positionX","(F"+MODULE+")F",false));
                        method.instructions.insertBefore(in,position);changes++;
                    }
                }
                int draw=0;
                for(AbstractInsnNode in:method.instructions.toArray()) if(in instanceof MethodInsnNode call
                    && call.owner.equals("pulse/render/Renderer2D") && call.name.equals("a") && call.desc.startsWith("(FFFFFLjava/awt/Color;")) {
                    if(++draw!=2) continue;
                    InsnList hook=new InsnList();
                    hook.add(new VarInsnNode(ALOAD,0));hook.add(new FieldInsnNode(GETFIELD,node.name,"n",MODULE));
                    hook.add(new VarInsnNode(ALOAD,1));hook.add(new VarInsnNode(ALOAD,2));
                    hook.add(new VarInsnNode(ALOAD,0));hook.add(new FieldInsnNode(GETFIELD,node.name,"w","F"));
                    hook.add(new VarInsnNode(ALOAD,0));hook.add(new FieldInsnNode(GETFIELD,node.name,"x","F"));
                    boolean anchor=method.desc.equals(anchored);
                    hook.add(new LdcInsnNode(anchor?150f:160f));
                    if(anchor) hook.add(new VarInsnNode(FLOAD,7));else hook.add(new LdcInsnNode(200f));
                    hook.add(new VarInsnNode(FLOAD,anchor?8:9));
                    hook.add(new MethodInsnNode(INVOKESTATIC,"pulse/n9ezz/Stars","paint","("+MODULE+"Ljava/lang/Object;"+RENDER+"FFFFF)V",false));
                    method.instructions.insert(in,hook);changes++;
                }
            }
        }
        int expected=name.endsWith("ModuleCard.class")||name.endsWith("FriendsPanel.class") ? 3 : name.endsWith("ModulesTab.class") ? 7 : name.endsWith("ClickGuiFrameOverlay.class") ? 10 : name.endsWith("ClientModule.class") ? 5 : 1;
        if(changes!=expected) throw new IllegalStateException(name+": expected "+expected+" patches, found "+changes);
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);node.accept(writer);
        System.out.println("Patched "+name+": "+changes+" hook(s)");
        return writer.toByteArray();
    }
}
