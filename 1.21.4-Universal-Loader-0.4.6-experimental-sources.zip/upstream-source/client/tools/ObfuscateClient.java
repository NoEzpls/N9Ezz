import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.net.URLClassLoader;
import org.objectweb.asm.*;
import org.objectweb.asm.commons.*;
import org.objectweb.asm.tree.*;

/** Renames added implementation details; public hooks, settings and mixins remain stable. */
public final class ObfuscateClient implements Opcodes {
    private static final String PREFIX="pulse/n9ezz/";
    private static final List<String> HELPERS=List.of("CombatMath","MissSequence","AttackClock","Targeting","Attacks","SectionTransition");
    private static final List<String> MODULES=List.of("KillAura","Triggerbot","AimBot","Hitboxes","AutoTotem","IncreasedDamage","Friends","Criticals","ShieldBreaker","AutoWeapon","AutoShield","AutoGapple","AutoHeal","AutoArmor","AutoRefill","AutoMace","BowRelease","ProjectileAim","PearlThrow","WTap","TargetStrafe","Velocity","NoPush","NoSlow","AntiWeb","AntiBot","TeamCheck","Reach","CrystalAura","WebTrap");
    private static final Map<String,String> strings=new LinkedHashMap<>();
    private static String pack(String text) {
        if(text.isEmpty()) return text;
        return strings.computeIfAbsent(text,value->{
            byte[] data=value.getBytes(StandardCharsets.UTF_8);
            for(int i=0;i<data.length;i++) data[i]^=(byte)(0x59+i*31+(i>>>2)*17);
            return "\u0001"+Base64.getEncoder().encodeToString(data);
        });
    }
    private static void protectStrings(ClassNode node,boolean added) {
        if(added && !node.name.equals(PREFIX+"StringCodec")) {
            if(node.visibleAnnotations!=null) for(AnnotationNode annotation:node.visibleAnnotations) {
                if(annotation.desc.equals("Lpulse/module/ModuleInfo;")) {
                    for(int i=0;i<annotation.values.size();i+=2) {
                        if(Set.of("a","b").contains(annotation.values.get(i))) annotation.values.set(i+1,pack((String)annotation.values.get(i+1)));
                    }
                }
            }
        }
        if(node.name.equals(PREFIX+"StringCodec") || node.name.startsWith(PREFIX+"mixin/")) return;
        for(MethodNode method:node.methods) for(AbstractInsnNode in:method.instructions.toArray()) {
            if(in instanceof LdcInsnNode ldc && ldc.cst instanceof String text && !text.isEmpty()
                && (added || node.name.equals("pulse/gui/core/PulseLogoOverlay") || text.equals("Читы"))) {
                ldc.cst=pack(text);
                method.instructions.insert(in,new MethodInsnNode(INVOKESTATIC,PREFIX+"StringCodec","decode","(Ljava/lang/String;)Ljava/lang/String;",false));
            }
        }
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=3) throw new IllegalArgumentException("input.jar output.jar mapping.txt");
        Map<String,byte[]> files=new TreeMap<>();
        try(ZipFile zip=new ZipFile(args[0])) {
            var entries=zip.entries();
            while(entries.hasMoreElements()) {
                var entry=entries.nextElement();
                if(!entry.isDirectory()) files.put(entry.getName(),zip.getInputStream(entry).readAllBytes());
            }
        }
        Map<String,String> classes=new TreeMap<>(),fields=new TreeMap<>(),methods=new TreeMap<>();
        for(int i=0;i<HELPERS.size();i++) classes.put(PREFIX+HELPERS.get(i),PREFIX+(char)('a'+i));
        for(int i=0;i<MODULES.size();i++) classes.put(PREFIX+MODULES.get(i),PREFIX+"u"+i);
        for(var entry:files.entrySet()) {
            if(!entry.getKey().endsWith(".class") || !entry.getKey().startsWith(PREFIX) || entry.getKey().startsWith(PREFIX+"mixin/")) continue;
            ClassNode node=new ClassNode();new ClassReader(entry.getValue()).accept(node,ClassReader.SKIP_CODE);
            int f=0,m=0;
            for(FieldNode field:node.fields) if((field.access&ACC_PRIVATE)!=0)
                fields.put(node.name+"."+field.name+":"+field.desc,"f"+f++);
            for(MethodNode method:node.methods) if(!method.name.startsWith("<") && ((method.access&ACC_PRIVATE)!=0 || HELPERS.contains(node.name.substring(PREFIX.length()))))
                methods.put(node.name+"."+method.name+method.desc,"m"+m++);
        }
        Remapper remapper=new Remapper() {
            @Override public String map(String name) { return classes.getOrDefault(name,name); }
            @Override public String mapFieldName(String owner,String name,String descriptor) { return fields.getOrDefault(owner+"."+name+":"+descriptor,name); }
            @Override public String mapMethodName(String owner,String name,String descriptor) { return methods.getOrDefault(owner+"."+name+descriptor,name); }
        };
        Map<String,byte[]> output=new TreeMap<>();
        int rewritten=0;
        for(var entry:files.entrySet()) {
            String name=entry.getKey();byte[] bytes=entry.getValue();
            if(name.endsWith(".class") && (name.startsWith(PREFIX) || name.equals("pulse/gui/core/PulseLogoOverlay.class") || name.equals("pulse/gui/modules/ModulesTab.class"))) {
                ClassReader reader=new ClassReader(bytes);
                ClassNode node=new ClassNode();reader.accept(node,0);
                protectStrings(node,name.startsWith(PREFIX) && !name.startsWith(PREFIX+"mixin/"));
                ClassWriter writer=new ClassWriter(0);
                ClassVisitor visitor=new ClassRemapper(writer,remapper);
                if(name.startsWith(PREFIX) && !name.startsWith(PREFIX+"mixin/")) {
                    visitor=new ClassVisitor(ASM9,visitor) {
                        @Override public void visitSource(String source,String debug) {}
                        @Override public MethodVisitor visitMethod(int access,String method,String descriptor,String signature,String[] exceptions) {
                            return new MethodVisitor(ASM9,super.visitMethod(access,method,descriptor,signature,exceptions)) {
                                @Override public void visitLineNumber(int line,Label start) {}
                                @Override public void visitLocalVariable(String name,String desc,String sig,Label start,Label end,int index) {}
                            };
                        }
                    };
                    rewritten++;
                }
                node.accept(visitor);
                bytes=writer.toByteArray();
                name=remapper.map(reader.getClassName())+".class";
            }
            if(output.put(name,bytes)!=null) throw new IllegalStateException("Duplicate output entry: "+name);
        }
        Path jar=Path.of(args[1]);Files.createDirectories(jar.getParent());
        try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(jar))) {
            for(var entry:output.entrySet()) {
                ZipEntry item=new ZipEntry(entry.getKey());item.setTime(0);
                zip.putNextEntry(item);zip.write(entry.getValue());zip.closeEntry();
            }
        }
        StringBuilder mapping=new StringBuilder("Added code only. Mixins, public hooks and settings preserve names.\n");
        for(var group:List.of(classes,fields,methods)) group.forEach((a,b)->mapping.append(a).append(" -> ").append(b).append('\n'));
        Path map=Path.of(args[2]);Files.createDirectories(map.getParent());Files.writeString(map,mapping,StandardCharsets.UTF_8);
        try(URLClassLoader loader=new URLClassLoader(new java.net.URL[]{jar.toUri().toURL()},ClassLoader.getPlatformClassLoader())) {
            var decode=loader.loadClass("pulse.n9ezz.StringCodec").getMethod("decode",String.class);
            for(var string:strings.entrySet()) if(!string.getKey().equals(decode.invoke(null,string.getValue()))) throw new IllegalStateException("String round-trip failed");
        }
        System.out.println("Obfuscation: "+classes.size()+" internal/module classes, "+fields.size()+" private fields, "+methods.size()+" internal methods; "+rewritten+" added classes stripped of debug names");
        System.out.println("PASS: "+strings.size()+" packed strings round-trip through the shipped decoder, including module annotations");
        System.out.println("Client: "+jar.getFileName()+", "+Files.size(jar)+" bytes");
    }
}
