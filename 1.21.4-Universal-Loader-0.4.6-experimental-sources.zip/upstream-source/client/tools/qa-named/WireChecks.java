package qa;

import java.nio.file.*;
import java.util.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import pulse.n9ezz.*;

/** Multi-tick regression scenarios inspect actual outgoing Minecraft packets. */
public final class WireChecks {
    private static int checks,stage,wait;
    private static PlayerEntity target;
    private static Runnable completed;
    private static final Object slotOwner=new Object();
    private static double beyondVanilla;
    private static boolean active,manual;
    private static void ok(boolean condition,String name){checks++;if(!condition)throw new AssertionError(name+"; wire="+WireLog.events);}
    private static void fail(Throwable e){
        try{var s=new java.io.StringWriter();e.printStackTrace(new java.io.PrintWriter(s));Files.writeString(Path.of("wire-result.txt"),"WIRE QA FAIL after "+checks+" checks\n"+s);}catch(Exception ignored){}
        System.exit(4);
    }
    public static void start(Object client,Object remote,Runnable end) {
        target=(PlayerEntity)remote;completed=end;stage=0;wait=0;active=true;
        var mc=(MinecraftClient)client;InterfaceMode.reveal();N9Ezz.disableAll();
        mc.player.getInventory().setSelectedSlot(0);mc.player.getInventory().setStack(0,new ItemStack(Items.DIAMOND_SWORD));
        syncItems(mc);
        mc.options.forwardKey.setPressed(false);mc.options.sprintKey.setPressed(false);
        ClientTickEvents.START_CLIENT_TICK.register(m->{
            if(!active)return;WireLog.tick++;
            if(manual){manual=false;m.interactionManager.attackEntity(m.player,target);}
        });
        ClientTickEvents.END_CLIENT_TICK.register(WireChecks::tick);
    }
    private static void setup(MinecraftClient mc,boolean trigger) {
        N9Ezz.disableAll();var p=mc.player;p.setYaw(0);p.setPitch(0);
        if(trigger){N9Ezz.TRIGGER.power.set(100);N9Ezz.TRIGGER.confirmation.set(0);N9Ezz.TRIGGER.range.set(3);N9Ezz.TRIGGER.cooldown.set(100);N9Ezz.TRIGGER.speed.select(1);N9Ezz.TRIGGER.miss.set(0);N9Ezz.TRIGGER.resetSprint.set(false);N9Ezz.TRIGGER.exactHit.set(true);N9Ezz.TRIGGER.setEnabled(true);}
        else{N9Ezz.AURA.power.set(100);N9Ezz.AURA.confirmation.set(0);N9Ezz.AURA.range.set(3);N9Ezz.AURA.cooldown.set(100);N9Ezz.AURA.speed.select(1);N9Ezz.AURA.miss.set(0);N9Ezz.AURA.resetSprint.set(false);N9Ezz.AURA.exactHit.set(true);N9Ezz.AURA.rotation.select(1);N9Ezz.AURA.fov.set(90);N9Ezz.AURA.setEnabled(true);}
    }
    private static void warmup(MinecraftClient mc,int next) {
        N9Ezz.disableAll();mc.options.forwardKey.setPressed(false);mc.options.sprintKey.setPressed(false);
        mc.player.getInventory().setSelectedSlot(0);mc.player.getInventory().setStack(0,new ItemStack(Items.DIAMOND_SWORD));
        syncItems(mc);
        mc.player.setYaw(0);mc.player.setPitch(0);WireLog.enabled=false;stage=next;wait=0;
    }
    private static void syncItems(MinecraftClient mc) {
        var server=mc.getServer();if(server==null)return;var uuid=mc.player.getUuid();
        server.execute(()->{var p=server.getPlayerManager().getPlayer(uuid);if(p!=null){p.getInventory().setStack(0,new ItemStack(Items.DIAMOND_SWORD));p.getInventory().setStack(2,new ItemStack(Items.IRON_AXE));p.playerScreenHandler.sendContentUpdates();}});
    }
    private static void aligned(MinecraftClient mc){target.setPosition(mc.player.getX(),mc.player.getY(),mc.player.getZ()+2);}
    private static void tick(MinecraftClient mc) {
        if(!active||mc.player==null||mc.world==null)return;
        try {
            wait++;
            if(stage<8 && stage!=5 && stage!=6)aligned(mc);
            switch(stage){
            case 0 -> {if(wait>=35){ok(mc.player.getAttackCooldownProgress(0)>.99f,"sword is charged before rotation test");setup(mc,false);mc.player.setYaw(5);WireLog.clear();stage=1;wait=0;}}
            case 1 -> {
                if(WireLog.count("ATTACK")>0){
                    int attack=-1,look=-1;for(int i=0;i<WireLog.events.size();i++){var e=WireLog.events.get(i);if(e.kind().equals("ATTACK")&&attack<0)attack=i;if(e.kind().equals("LOOK")&&Math.abs(e.yaw()-5)<.01&&look<0)look=i;}
                    ok(look>=0&&look<attack,"updated rotation must precede automatic attack");
                    ok(WireLog.count("ATTACK")==1,"one aura attack in the observed tick");warmup(mc,2);
                    Files.writeString(Path.of("wire-rotation-after.txt"),WireLog.events.toString());
                }else ok(wait<15,"aura eventually attacks an ordinary visible target");
            }
            case 2 -> {if(wait>=35){setup(mc,false);WireLog.clear();mc.player.getInventory().setStack(2,new ItemStack(Items.IRON_AXE));ok(CombatInventory.select(slotOwner,50,2),"axe slot is selected");stage=3;wait=0;}}
            case 3 -> {CombatInventory.select(slotOwner,50,2);if(wait>=3){ok(mc.player.getAttackCooldownProgress(0)<.25f,"native equipment tick resets charge before attack delivery");ok(WireLog.count("SLOT")==1,"vanilla slot sync does not duplicate the selected-slot packet");ok(WireLog.count("ATTACK")==0,"freshly selected axe cannot use the previous sword charge");CombatInventory.release(slotOwner,true);ok(mc.player.getInventory().getSelectedSlot()==0,"slot release restores weapon");warmup(mc,4);}}
            case 4 -> {if(wait>=35){setup(mc,false);N9Ezz.AURA.speed.select(0);WireLog.clear();manual=true;stage=40;wait=0;}}
            case 40 -> {if(wait>=1){ok(WireLog.count("ATTACK")==1,"manual attack prevents an automatic attack in the same client tick");warmup(mc,5);}}
            case 5 -> {if(wait>=35){setup(mc,false);target.setPosition(mc.player.getX()+.8,mc.player.getY(),mc.player.getZ()+2);N9Ezz.HITBOXES.x.set(5);N9Ezz.HITBOXES.y.set(1);N9Ezz.HITBOXES.z.set(1);N9Ezz.HITBOXES.power.set(100);N9Ezz.HITBOXES.setEnabled(true);N9Ezz.AURA.exactHit.set(false);WireLog.clear();stage=6;wait=0;}}
            case 6 -> {if(wait>=3){ok(N9Ezz.AURA.target()==target,"aura acquires the enlarged-box test target");ok(WireLog.count("ATTACK")==1,"visible enlarged box authorizes one charged aura packet");warmup(mc,61);}}
            case 61 -> {aligned(mc);if(wait>=35){setup(mc,true);target.setPosition(mc.player.getX()+.8,mc.player.getY(),mc.player.getZ()+2);N9Ezz.HITBOXES.setEnabled(true);N9Ezz.TRIGGER.exactHit.set(false);WireLog.clear();stage=60;wait=0;}}
            case 60 -> {target.setPosition(mc.player.getX()+.8,mc.player.getY(),mc.player.getZ()+2);if(wait>=3){ok(N9Ezz.TRIGGER.target()==target,"trigger acquires the enlarged-box test target");ok(WireLog.count("ATTACK")==1,"visible enlarged box authorizes one charged trigger packet");warmup(mc,62);}}
            case 62 -> {aligned(mc);if(wait>=35){setup(mc,true);target.setPosition(mc.player.getX()+.8,mc.player.getY(),mc.player.getZ()+2);N9Ezz.HITBOXES.setEnabled(true);N9Ezz.TRIGGER.exactHit.set(true);WireLog.clear();stage=63;wait=0;}}
            case 63 -> {target.setPosition(mc.player.getX()+.8,mc.player.getY(),mc.player.getZ()+2);if(wait>=3){ok(WireLog.count("ATTACK")==0,"explicit ordinary-box mode rejects the same trigger near-miss");warmup(mc,7);}}
            case 7 -> {if(wait>=35){setup(mc,false);beyondVanilla=mc.player.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.ENTITY_INTERACTION_RANGE)+.75;N9Ezz.REACH.range.set(6);N9Ezz.REACH.power.set(100);N9Ezz.REACH.setEnabled(true);N9Ezz.AURA.range.set(6);target.setPosition(mc.player.getX(),mc.player.getY(),mc.player.getZ()+beyondVanilla);WireLog.clear();stage=8;wait=0;}}
            case 8 -> {target.setPosition(mc.player.getX(),mc.player.getY(),mc.player.getZ()+beyondVanilla);if(wait>=3){ok(mc.player.getEntityInteractionRange()>5.9,"extended local selection is actually active");ok(WireLog.count("ATTACK")==0,"extended client selection cannot extend automated attack distance");warmup(mc,9);}}
            case 9 -> {aligned(mc);if(wait>=35){mc.options.forwardKey.setPressed(true);mc.options.sprintKey.setPressed(true);mc.player.setSprinting(true);WireLog.clear();stage=10;wait=0;}}
            case 10 -> {aligned(mc);if(wait>=1){ok(WireLog.count("START_SPRINTING")>0&&mc.player.isSprinting(),"native sprint was sent before the reset scenario");setup(mc,false);N9Ezz.AURA.resetSprint.set(true);WireLog.clear();stage=11;wait=0;}}
            case 11 -> {aligned(mc);if(WireLog.count("ATTACK")>0){ok(WireLog.count("STOP_SPRINTING")>0,"native input sends a real sprint stop before attack");var attack=WireLog.events.stream().filter(e->e.kind().equals("ATTACK")).findFirst().orElseThrow();ok(WireLog.events.stream().noneMatch(e->e.tick()==attack.tick()&&e.kind().equals("START_SPRINTING")),"no stop/attack/start packet burst in one tick");ok(mc.options.forwardKey.isPressed()&&mc.options.sprintKey.isPressed(),"sprint reset preserves the physical key states");warmup(mc,12);}else ok(wait<15,"sprint reset completes without starving attacks");}
            case 12 -> {aligned(mc);if(wait>=35){setup(mc,false);mc.player.setYaw(3);WireLog.clear();WireLog.beforeMovement=()->mc.world.removeEntity(target.getId(),Entity.RemovalReason.DISCARDED);stage=13;wait=0;}}
            case 13 -> {if(wait>=1){
                ok(target.isRemoved(),"target was removed between module tick and delivery");ok(WireLog.count("ATTACK")==0,"removed target is rejected at delivery");
                var revive=Entity.class.getDeclaredMethod("method_31482");revive.setAccessible(true);revive.invoke(target);mc.world.addEntity(target);warmup(mc,14);
            }}
            case 14 -> {aligned(mc);if(wait>=35){PowerModes.set(PowerCurve.Level.LEGIT);setup(mc,true);N9Ezz.TRIGGER.confirmation.set(500);WireLog.clear();stage=15;wait=0;}}
            case 15 -> {aligned(mc);if(wait>=3){ok(WireLog.count("ATTACK")==0,"100% Legit observes the configured target confirmation");PowerModes.set(PowerCurve.Level.HIGHT);N9Ezz.TRIGGER.power.set(40);WireLog.clear();stage=16;wait=0;}}
            case 16 -> {aligned(mc);if(wait>=3){ok(WireLog.count("ATTACK")==0,"40% Hight has the same actual confirmation behavior");PowerModes.set(PowerCurve.Level.EXTRA);N9Ezz.TRIGGER.power.set(10);WireLog.clear();stage=17;wait=0;}}
            case 17 -> {aligned(mc);if(wait>=3){ok(WireLog.count("ATTACK")==0,"10% Extra has the same actual confirmation behavior");PowerModes.set(PowerCurve.Level.HIGHT);N9Ezz.TRIGGER.power.set(100);N9Ezz.TRIGGER.confirmation.set(50);WireLog.clear();stage=18;wait=0;}}
            case 18 -> {aligned(mc);if(wait>=1){ok(WireLog.count("ATTACK")==1,"100% Hight actually attacks on the first acquisition tick");ok(N9Ezz.TRIGGER.power.get()==100&&N9Ezz.TRIGGER.confirmation.get()==50&&N9Ezz.TRIGGER.cooldown.get()==100,"Hight strengthens behavior without rewriting percentages or confirmation");PowerModes.set(PowerCurve.Level.EXTRA);WireLog.clear();stage=19;wait=0;}}
            case 19 -> {aligned(mc);if(wait>=3){ok(WireLog.count("ATTACK")==0,"100% Extra still honors a weapon that has not recharged");warmup(mc,20);}}
            case 20 -> {aligned(mc);if(wait>=35){setup(mc,true);N9Ezz.TRIGGER.confirmation.set(50);mc.player.setYaw(5);WireLog.clear();stage=21;wait=0;}}
            case 21 -> {aligned(mc);if(wait>=1){
                ok(WireLog.count("ATTACK")==1,"100% Extra actually attacks on the first acquisition tick");
                int look=-1,attack=-1;for(int i=0;i<WireLog.events.size();i++){var event=WireLog.events.get(i);if(event.kind().equals("LOOK")&&Math.abs(event.yaw()-5)<.01&&look<0)look=i;if(event.kind().equals("ATTACK")&&attack<0)attack=i;}
                ok(look>=0&&look<attack,"Extra Triggerbot preserves rotation-before-attack packet order");
                ok(N9Ezz.TRIGGER.power.get()==100&&N9Ezz.TRIGGER.effectiveCps()<=20,"Extra keeps slider at 100 and respects 20 Hz action budget");
                WireLog.enabled=false;N9Ezz.disableAll();PowerModes.set(PowerCurve.Level.LEGIT);active=false;
                Files.writeString(Path.of("wire-result.txt"),"WIRE WORLD PASS: "+checks+" actual packet checks including equivalent base levels, first-tick Hight/Extra reactions, weapon charge, rotation, sprint, slots and stale targets");completed.run();
            }}
            }
        }catch(Throwable e){fail(e);}
    }
}
