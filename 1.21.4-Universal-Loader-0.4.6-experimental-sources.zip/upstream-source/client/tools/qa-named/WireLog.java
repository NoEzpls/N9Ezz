package qa;

import java.util.*;
import net.minecraft.network.packet.c2s.play.*;

/** Outbound packet observation in the QA mod only; not included in the release. */
public final class WireLog {
    public record Event(int tick,String kind,float yaw) {}
    public static final List<Event> events=new ArrayList<>();
    public static int tick;
    public static boolean enabled;
    public static Runnable beforeMovement;
    public static void clear(){events.clear();enabled=true;beforeMovement=null;}
    public static long count(String kind){return events.stream().filter(e->e.kind().equals(kind)).count();}
    public static void capture(Object packet) {
        if(!enabled)return;
        if(packet instanceof PlayerMoveC2SPacket movement){
            if(beforeMovement!=null){var action=beforeMovement;beforeMovement=null;action.run();}
            events.add(new Event(tick,movement.changesLook()?"LOOK":"MOVE",movement.getYaw(Float.NaN)));
        } else if(packet instanceof PlayerInteractEntityC2SPacket) events.add(new Event(tick,"ATTACK",Float.NaN));
        else if(packet instanceof UpdateSelectedSlotC2SPacket) events.add(new Event(tick,"SLOT",Float.NaN));
        else if(packet instanceof ClientCommandC2SPacket command) events.add(new Event(tick,command.getMode().name(),Float.NaN));
        else if(packet instanceof HandSwingC2SPacket) events.add(new Event(tick,"SWING",Float.NaN));
    }
}
