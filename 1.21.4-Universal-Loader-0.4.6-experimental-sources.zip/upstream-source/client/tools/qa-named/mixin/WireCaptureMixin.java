package qa.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.network.ClientConnection;
import qa.WireLog;

@Mixin(value=ClientConnection.class,remap=false)
public abstract class WireCaptureMixin {
    @Inject(method="method_10743(Lnet/minecraft/class_2596;)V",at=@At("HEAD"),require=1,remap=false)
    private void qaPacket(@Coerce Object packet,CallbackInfo ci) { WireLog.capture(packet); }
}
