package qa;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.block.Blocks;
import net.minecraft.util.Hand;
import net.minecraft.util.math.*;
import pulse.n9ezz.*;
import pulse.module.*;
import pulse.gui.core.PulseClickGuiScreen;
import pulse.gui.friends.HistoryEntry;
import ru.pulse.Pulse;
/** Runs in a real client world against the obfuscated release and actual injected game methods. */
public final class PvpChecks {
 private static int checks;
 private static void ok(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
 public static void run(Object clientObject,Object targetObject)throws Exception {
  var mc=(MinecraftClient)clientObject;var target=(PlayerEntity)targetObject;var p=mc.player;
  InterfaceMode.reveal();N9Ezz.disableAll();mc.setScreen(null);
  PowerModes.set(PowerCurve.Level.LEGIT);
  for(var module:N9Ezz.modules())if(module instanceof PvPModule helper)helper.power.set(100);
  Set<String> names=new HashSet<>();
  for(var module:N9Ezz.modules()){
   ok(names.add(module.name()),"unique registered module "+module.name());
   ok(ModuleRegistry.all().contains(module),"module participates in native registry: "+module.name());
   Set<String> settings=new HashSet<>();for(var s:module.settings())ok(settings.add(s.name()),"unique setting "+module.name()+" / "+s.name());
  }
  var inv=p.getInventory();inv.setSelectedSlot(1);N9Ezz.TOTEM.setEnabled(false);
  Object weapon=new Object(),healing=new Object();
  ok(CombatInventory.select(weapon,50,2)&&inv.getSelectedSlot()==2,"actual hotbar lease selects weapon");
  ok(!CombatInventory.select(healing,40,3)&&inv.getSelectedSlot()==2,"low priority cannot override");
  ok(CombatInventory.select(healing,90,4),"healing preempts weapon");
  CombatInventory.release(weapon,true);ok(inv.getSelectedSlot()==4,"stale release cannot restore over healing");
  CombatInventory.release(healing,true);ok(inv.getSelectedSlot()==1,"normal release restores original slot");
  CombatInventory.select(weapon,50,2);inv.setSelectedSlot(5);CombatInventory.release(weapon,true);ok(inv.getSelectedSlot()==5,"manual hotbar choice persists");
  target.setPosition(p.getX(),p.getY(),p.getZ()+2);p.setYaw(0);p.setPitch(0);
  ok(Targeting.underCrosshair(3,false)==target,"ordinary crosshair picks visible target");
  double physicalWidth=target.getBoundingBox().getLengthX();
  N9Ezz.HITBOXES.x.set(5);N9Ezz.HITBOXES.y.set(1);N9Ezz.HITBOXES.z.set(1);N9Ezz.HITBOXES.power.set(100);N9Ezz.HITBOXES.onlyTarget.set(false);N9Ezz.HITBOXES.setEnabled(true);
  target.setPosition(p.getX()+.8,p.getY(),p.getZ()+2);
  ok(Targeting.underCrosshair(3,false)==null,"ordinary picking misses lateral player fixture");
  ok(Targeting.underCrosshair(3,true)==target,"expanded picking hits the outlined lateral player");
  ok(Targeting.acquire(null,3,100,0,true,true,t->t==target)==target,"expanded aura acquisition uses the same geometry");
  target.setPosition(p.getX()+1.4,p.getY(),p.getZ()+2);
  ok(Targeting.underCrosshair(3,true)==target,"expanded candidate outside vanilla broad-phase is discovered");
  target.setPosition(p.getX()+.8,p.getY(),p.getZ()+2);
  ok(target.getBoundingBox().getLengthX()==physicalWidth,"client expansion never changes physical entity bounds");
  CombatTargets.clear();N9Ezz.HITBOXES.onlyTarget.set(true);
  ok(Targeting.box(target).equals(target.getBoundingBox()),"only-target setting does not expand an untracked player");
  CombatTargets.attacked(target);ok(Targeting.underCrosshair(3,true)==target,"tracked player alone receives only-target expansion");
  CombatTargets.clear();N9Ezz.HITBOXES.onlyTarget.set(false);N9Ezz.HITBOXES.setEnabled(false);
  ok(Targeting.underCrosshair(3,true)==null,"disabling Hitboxes immediately removes expanded selection");
  target.setPosition(p.getX(),p.getY(),p.getZ()+2);
  N9Ezz.ANTIBOT.spawnDelay.set(0);N9Ezz.ANTIBOT.tab.set(true);N9Ezz.ANTIBOT.setEnabled(true);
  ok(!Targeting.combatTarget(target,true,true),"anti-bot rejects fake player absent from server list");
  N9Ezz.ANTIBOT.tab.set(false);ok(Targeting.combatTarget(target,true,true),"optional tab check can be disabled");N9Ezz.ANTIBOT.setEnabled(false);
  N9Ezz.AURA.power.set(100);N9Ezz.AURA.setEnabled(true);N9Ezz.AURA.tick(null);ok(CombatTargets.tracked()==target,"aura supplies the shared combat target");
  var history=((PulseClickGuiScreen)Pulse.getInstance().getClickGui()).h().e();history.a(new HistoryEntry(target.getName().getString()));
  ok(!Targeting.combatTarget(target,true,true)&&Targeting.underCrosshair(3,false)==null,"friend at crosshair blocks targeting");
  ok(CombatTargets.tracked()==null,"new friend invalidates cached target before the next aura tick");N9Ezz.AURA.setEnabled(false);history.b();
  mc.world.removeEntity(target.getId(),Entity.RemovalReason.DISCARDED);ok(!Targeting.eligible(target),"unloaded target is ineligible even if its object survives");
  var restoreEntity=Entity.class.getDeclaredMethod("method_31482");restoreEntity.setAccessible(true);restoreEntity.invoke(target);mc.world.addEntity(target);
  var scoreboard=mc.world.getScoreboard();var team=scoreboard.addTeam("QA_N9_pvp");
  scoreboard.addScoreHolderToTeam(p.getName().getString(),team);scoreboard.addScoreHolderToTeam(target.getName().getString(),team);
  N9Ezz.TEAMS.setEnabled(true);ok(!Targeting.combatTarget(target,true,true),"scoreboard teammates are excluded");N9Ezz.TEAMS.setEnabled(false);scoreboard.removeTeam(team);
  manualView(mc);
  var wall=BlockPos.ofFloored(p.getX(),p.getEyeY(),p.getZ()+1);var previous=mc.world.getBlockState(wall);mc.world.setBlockState(wall,Blocks.STONE.getDefaultState());
  ok(Targeting.underCrosshair(3,false)==null,"solid wall blocks targeting");mc.world.setBlockState(wall,previous);
  mc.world.setBlockState(wall,Blocks.STONE.getDefaultState());N9Ezz.HITBOXES.z.set(5);N9Ezz.HITBOXES.setEnabled(true);
  ok(Targeting.underCrosshair(3,true)==null,"physical-body LOS rejects expanded volume protruding in front of wall");
  ok(Targeting.acquire(null,3,100,0,true,true,t->t==target)==null,"expanded aura acquisition cannot target hidden player through wall");
  N9Ezz.HITBOXES.setEnabled(false);mc.world.setBlockState(wall,previous);
  inv.setSelectedSlot(1);inv.setStack(1,new ItemStack(Items.STICK));inv.setStack(2,new ItemStack(Items.DIAMOND_SWORD));inv.setStack(3,new ItemStack(Items.NETHERITE_SWORD));
  N9Ezz.WEAPON.setEnabled(true);N9Ezz.WEAPON.tick(null);ok(inv.getSelectedSlot()==3,"auto-weapon chooses strongest hotbar sword");N9Ezz.WEAPON.setEnabled(false);ok(inv.getSelectedSlot()==1,"auto-weapon returns original slot");
  inv.setStack(2,new ItemStack(Items.DIAMOND_AXE));target.setYaw(180);target.setHeadYaw(180);target.setStackInHand(Hand.OFF_HAND,new ItemStack(Items.SHIELD));target.setCurrentHand(Hand.OFF_HAND);
  // Remote players receive these flags from server tracking; this isolated fixture has no server twin.
  var livingFlag=LivingEntity.class.getDeclaredMethod("method_6085",int.class,boolean.class);livingFlag.setAccessible(true);livingFlag.invoke(target,1,true);livingFlag.invoke(target,2,true);
  var remaining=LivingEntity.class.getDeclaredField("field_6222");remaining.setAccessible(true);remaining.setInt(target,target.getActiveItem().getMaxUseTime(target)-10);
  ok(target.isBlocking(),"remote shield fixture includes replicated use flags");
  N9Ezz.SHIELD.switchDelay.set(0);N9Ezz.SHIELD.power.set(100);N9Ezz.SHIELD.setEnabled(true);
  boolean shieldReady=N9Ezz.SHIELD.prepare(target,System.nanoTime());
  ok(shieldReady&&inv.getSelectedSlot()==2,"shield breaker selects axe against facing active shield");
  N9Ezz.SHIELD.afterAttempt();ok(inv.getSelectedSlot()==1,"shield breaker returns original slot after attack");
  N9Ezz.SHIELD.prepare(target,System.nanoTime());inv.setSelectedSlot(5);N9Ezz.SHIELD.cancel();ok(inv.getSelectedSlot()==5,"shield cancellation preserves manual weapon change");N9Ezz.SHIELD.setEnabled(false);target.clearActiveItem();inv.setSelectedSlot(1);
  p.setOnGround(true);p.setVelocity(Vec3d.ZERO);p.fallDistance=0;N9Ezz.CRITICALS.mode.select(1);N9Ezz.CRITICALS.autoJump.set(false);N9Ezz.CRITICALS.setEnabled(true);
  ok(!N9Ezz.CRITICALS.ready(System.nanoTime(),true),"strict critical helper refuses grounded attack");N9Ezz.CRITICALS.setEnabled(false);
  for(int i=0;i<9;i++)inv.setStack(i,new ItemStack(Items.STICK));inv.setStack(12,new ItemStack(Items.DIAMOND_CHESTPLATE));p.playerScreenHandler.getSlot(6).setStack(new ItemStack(Items.LEATHER_CHESTPLATE));
  N9Ezz.ARMOR.delay.set(100);N9Ezz.ARMOR.setEnabled(true);N9Ezz.ARMOR.tick(null);
  for(int i=0;i<2;i++){Thread.sleep(120);p.age++;N9Ezz.ARMOR.tick(null);}
  ok(p.playerScreenHandler.getSlot(6).getStack().isOf(Items.DIAMOND_CHESTPLATE),"armor equips upgrade even with full hotbar");
  ok(inv.getStack(2).isOf(Items.STICK)&&inv.getStack(12).isOf(Items.LEATHER_CHESTPLATE),"armor transaction restores buffer and retains old equipment");N9Ezz.ARMOR.setEnabled(false);
  inv.setStack(5,new ItemStack(Items.GOLDEN_APPLE));inv.setStack(10,new ItemStack(Items.GOLDEN_APPLE,16));N9Ezz.REFILL.setEnabled(true);N9Ezz.REFILL.tick(null);inv.setStack(5,ItemStack.EMPTY);p.age++;N9Ezz.REFILL.tick(null);
  ok(inv.getStack(5).isOf(Items.GOLDEN_APPLE)&&inv.getStack(5).getCount()==16,"refill replaces depleted consumable from inventory");N9Ezz.REFILL.setEnabled(false);
  N9Ezz.VELOCITY.horizontal.set(0);N9Ezz.VELOCITY.vertical.set(100);N9Ezz.VELOCITY.power.set(100);N9Ezz.VELOCITY.setEnabled(true);
  p.setVelocity(new Vec3d(1,1,1));p.setVelocityClient(new Vec3d(3,3,3));
  ok(p.getVelocity().equals(new Vec3d(1,3,1)),"incoming velocity hook scales only selected axes");N9Ezz.VELOCITY.setEnabled(false);p.setVelocityClient(new Vec3d(2,2,2));ok(p.getVelocity().equals(new Vec3d(2,2,2)),"disabled velocity restores original behavior");
  double vanillaRange=p.getEntityInteractionRange();N9Ezz.REACH.range.set(6);N9Ezz.REACH.power.set(100);N9Ezz.REACH.setEnabled(true);
  ok(Math.abs(p.getEntityInteractionRange()-6)<.001,"reach affects local picking range");
  var serverPlayer=mc.getServer().getPlayerManager().getPlayer(p.getUuid());ok(serverPlayer!=null&&serverPlayer.getEntityInteractionRange()<6,"reach leaves integrated server attribute unchanged");
  N9Ezz.REACH.setEnabled(false);ok(p.getEntityInteractionRange()==vanillaRange,"reach disable restores vanilla range");
  p.setStackInHand(Hand.OFF_HAND,new ItemStack(Items.SHIELD));p.setCurrentHand(Hand.OFF_HAND);
  var movement=ClientPlayerEntity.class.getDeclaredMethod("method_67270",Vec2f.class);movement.setAccessible(true);
  float slowed=((Vec2f)movement.invoke(p,new Vec2f(0,1))).y;
  N9Ezz.NOSLOW.speed.set(100);N9Ezz.NOSLOW.power.set(100);N9Ezz.NOSLOW.setEnabled(true);
  float faster=((Vec2f)movement.invoke(p,new Vec2f(0,1))).y;ok(faster>slowed+.1&&faster<=1,"no-slow hook changes native item-use factor");N9Ezz.NOSLOW.setEnabled(false);p.clearActiveItem();
  var multiplier=Entity.class.getDeclaredField("field_17046");multiplier.setAccessible(true);
  N9Ezz.ANTIWEB.speed.set(100);N9Ezz.ANTIWEB.power.set(100);N9Ezz.ANTIWEB.setEnabled(true);
  p.slowMovement(Blocks.COBWEB.getDefaultState(),new Vec3d(.25,.05,.25));ok(multiplier.get(p).equals(new Vec3d(1,1,1)),"anti-web changes native cobweb multiplier");
  p.slowMovement(Blocks.SWEET_BERRY_BUSH.getDefaultState(),new Vec3d(.8,.75,.8));ok(multiplier.get(p).equals(new Vec3d(.8,.75,.8)),"anti-web leaves other slowing blocks unchanged");N9Ezz.ANTIWEB.setEnabled(false);multiplier.set(p,Vec3d.ZERO);
  target.setPosition(p.getX()+.2,p.getY(),p.getZ());p.setVelocity(Vec3d.ZERO);N9Ezz.NOPUSH.setEnabled(true);p.pushAwayFrom(target);ok(p.getVelocity().equals(Vec3d.ZERO),"no-push hook cancels entity collision impulse");N9Ezz.NOPUSH.setEnabled(false);
  target.setPosition(p.getX(),p.getY(),p.getZ()+2);p.setYaw(0);p.setPitch(0);
  N9Ezz.WTAP.groundOnly.set(false);N9Ezz.WTAP.setEnabled(true);N9Ezz.WTAP.attacked();ok(N9Ezz.WTAP.input(new Vec2f(0,1)).y==0,"w-tap pauses forward motion");
  mc.options.forwardKey.setPressed(true);p.input.tick();ok(p.input.getMovementInput().y==0&&!p.input.playerInput.forward(),"keyboard hook updates actual movement and sent input flags");
  N9Ezz.WTAP.setEnabled(false);p.input.tick();ok(p.input.getMovementInput().y==1&&mc.options.forwardKey.isPressed(),"w-tap disable preserves physical key state");mc.options.forwardKey.setPressed(false);p.input.tick();
  ok(N9Ezz.WTAP.input(new Vec2f(0,1)).y==1,"w-tap releases cleanly");
  N9Ezz.STRAFE.power.set(100);N9Ezz.STRAFE.setEnabled(true);p.horizontalCollision=false;var strafe=N9Ezz.STRAFE.input(new Vec2f(0,1));ok(Math.abs(strafe.length()-1)<.0001,"strafe preserves movement magnitude");N9Ezz.STRAFE.setEnabled(false);
  inv.setSelectedSlot(1);inv.setStack(4,new ItemStack(Items.GOLDEN_APPLE));N9Ezz.GAPPLE.hp.set(20);N9Ezz.GAPPLE.absorption.set(false);N9Ezz.GAPPLE.setEnabled(true);N9Ezz.GAPPLE.tick(null);
  ok(ConsumableUse.active()&&inv.getSelectedSlot()==4,"gapple controller starts normal item use");N9Ezz.GAPPLE.setEnabled(false);ok(!ConsumableUse.active()&&inv.getSelectedSlot()==1,"disabling consumption releases use and slot");
  N9Ezz.disableAll();ok(!CombatInventory.busy()&&!p.isUsingItem(),"global disable clears inventory and held item actions");
  modeEffects(mc,target);
  String result="PVP WORLD PASS: "+checks+" real registry, filtering, inventory, movement and injected-method checks";java.nio.file.Files.writeString(java.nio.file.Path.of("pvp-result.txt"),result);System.out.println(result);
 }
 private static void modeEffects(MinecraftClient mc,PlayerEntity target)throws Exception{
  N9Ezz.disableAll();mc.setScreen(null);var p=mc.player;
  target.setPosition(p.getX()+.2,p.getY(),p.getZ());target.setVelocity(Vec3d.ZERO);
  p.setVelocity(Vec3d.ZERO);p.pushAwayFrom(target);double nativePush=p.getVelocity().length();
  ok(nativePush>0,"native push fixture has a real collision impulse");
  N9Ezz.NOPUSH.power.set(30);N9Ezz.NOPUSH.setEnabled(true);
  N9Ezz.VELOCITY.horizontal.set(70);N9Ezz.VELOCITY.vertical.set(100);N9Ezz.VELOCITY.power.set(100);N9Ezz.VELOCITY.setEnabled(true);
  N9Ezz.NOSLOW.speed.set(40);N9Ezz.NOSLOW.power.set(100);N9Ezz.NOSLOW.setEnabled(true);
  N9Ezz.ANTIWEB.speed.set(50);N9Ezz.ANTIWEB.power.set(100);N9Ezz.ANTIWEB.setEnabled(true);
  N9Ezz.HITBOXES.x.set(1.8f);N9Ezz.HITBOXES.power.set(100);N9Ezz.HITBOXES.setEnabled(true);
  N9Ezz.REACH.range.set(6);N9Ezz.REACH.power.set(100);N9Ezz.REACH.setEnabled(true);
  var modeBefore=ConfigSnapshots.capture();double lastPush=Double.POSITIVE_INFINITY,lastVelocity=Double.POSITIVE_INFINITY,lastMove=0,lastWidth=0,lastReach=0;
  for(var level:PowerCurve.Level.values()){
   PowerModes.set(level);p.setVelocity(Vec3d.ZERO);target.setVelocity(Vec3d.ZERO);p.pushAwayFrom(target);double push=p.getVelocity().length();
   ok(push<lastPush,"base level changes the actual entity push: "+level);lastPush=push;
   p.setVelocity(Vec3d.ZERO);p.setVelocityClient(new Vec3d(1,1,1));double velocity=p.getVelocity().x;
   ok(velocity<lastVelocity&&velocity>=0&&p.getVelocity().y==1,"base level changes native knockback without reversing or touching unselected axis: "+level);lastVelocity=velocity;
   float move=N9Ezz.NOSLOW.multiplier(.2f);ok(move>lastMove&&move<=1,"base level changes item-use movement: "+level);lastMove=move;
   var web=N9Ezz.ANTIWEB.multiplier(new Vec3d(.25,.05,.25));ok(web.x>=.25&&web.x<=1&&web.y>=.05&&web.y<=1,"base web coefficients remain physical: "+level);
   double width=Targeting.box(target).getLengthX();ok(width>lastWidth&&target.getBoundingBox().getLengthX()<.61,"base level changes picking box but preserves physical bounds: "+level);lastWidth=width;
   double reach=p.getEntityInteractionRange();ok(reach>lastReach&&reach<=12,"base level changes actual native selection range: "+level);lastReach=reach;
   ok(modeBefore.get("pulse").equals(ConfigSnapshots.capture().get("pulse")),"every numeric value, bind and enabled state survives runtime mode switch: "+level);
  }
  var noPush=N9Ezz.NOPUSH;noPush.power.set(0);p.setVelocity(Vec3d.ZERO);target.setVelocity(Vec3d.ZERO);p.pushAwayFrom(target);
  ok(Math.abs(p.getVelocity().length()-nativePush)<.0001,"zero power restores native push immediately");
  N9Ezz.disableAll();PowerModes.set(PowerCurve.Level.LEGIT);p.setVelocity(Vec3d.ZERO);
  double[] equivalent=new double[3];int index=0;
  for(var level:PowerCurve.Level.values()){
   PowerModes.set(level);N9Ezz.TRIGGER.power.set(level==PowerCurve.Level.LEGIT?100:level==PowerCurve.Level.HIGHT?40:10);
   N9Ezz.TRIGGER.cps.set(5);equivalent[index++]=N9Ezz.TRIGGER.strength();
   ok(N9Ezz.TRIGGER.effectiveCps()==5,"real Triggerbot equal-strength rate in "+level);
  }
  ok(equivalent[0]==equivalent[1]&&equivalent[1]==equivalent[2],"real registered Triggerbot: 100% Legit = 40% Hight = 10% Extra");
  PowerModes.set(PowerCurve.Level.LEGIT);N9Ezz.TRIGGER.power.set(100);
 }
 private static void manualView(MinecraftClient mc){
  var p=mc.player;float originalYaw=p.getYaw(),originalPitch=p.getPitch();double sensitivity=mc.options.getMouseSensitivity().getValue();
  try{
   mc.options.getMouseSensitivity().setValue(0.0);
   var point=p.getCameraPosVec(1).add(-4,0,0);
   for(int fps:new int[]{30,60,144,300}){
    var motion=new ViewMotion();long now=System.nanoTime();long frame=1_000_000_000L/fps;p.setYaw(0);p.setPitch(0);
    motion.frame(point,now,1,100,1,200);
    for(int i=0;i<fps/2;i++){
     now+=frame;float manual=p.getYaw()-.1f;p.setYaw(manual);motion.frame(point,now,1,100,1,200);
     ok(p.getYaw()==manual,"continuous manual view retains priority at "+fps+" FPS, frame "+i);
    }
    float manual=p.getYaw();now+=100_000_000L;motion.frame(point,now,1,100,1,200);
    ok(p.getYaw()==manual,"manual pause lasts after the final mouse movement at "+fps+" FPS");
    now+=101_000_000L;motion.frame(point,now,1,100,1,200);
    ok(p.getYaw()>manual,"view resumes after the final movement's full pause at "+fps+" FPS");
    for(int i=0;i<5;i++){float previous=p.getYaw();now+=frame;motion.frame(point,now,1,100,1,200);ok(p.getYaw()>previous,"own view updates are not mistaken for manual input at "+fps+" FPS");}
   }
   var motion=new ViewMotion();long now=System.nanoTime();p.setYaw(0);p.setPitch(0);motion.frame(point,now,1,100,85,200);
   p.setYaw(.001f);motion.frame(point,now+50_000_000L,1,100,85,200);ok(p.getYaw()==.001f,"small manual yaw changes retain priority at low sensitivity");
   p.setPitch(.002f);motion.frame(point,now+100_000_000L,1,100,85,200);ok(p.getYaw()==.001f&&p.getPitch()==.002f,"manual pitch extends the pause as well");
   motion.reset();p.setYaw(0);p.setPitch(0);motion.frame(point,now+110_000_000L,1,100,85,200);motion.frame(point,now+160_000_000L,1,100,85,200);
   ok(p.getYaw()>0,"reset clears the previous manual pause");
   motion.reset();p.setYaw(0);motion.frame(point,now+200_000_000L,1,100,85,0);p.setYaw(.001f);motion.frame(point,now+250_000_000L,1,100,85,0);
   ok(p.getYaw()>.001f,"zero pause remains an explicit automatic-view setting");
  }finally{p.setYaw(originalYaw);p.setPitch(originalPitch);mc.options.getMouseSensitivity().setValue(sensitivity);}
 }
}
