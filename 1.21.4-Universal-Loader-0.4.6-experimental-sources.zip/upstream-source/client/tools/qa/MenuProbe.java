package qa;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.*;
import pulse.gui.core.*;
import pulse.gui.modules.ModulesTab;
import pulse.module.*;
import pulse.n9ezz.*;
import ru.pulse.Pulse;
import java.io.File;
import java.util.Arrays;
import java.nio.file.*;
import com.google.gson.JsonObject;
import pulse.gui.friends.HistoryEntry;
import pulse.hud.core.HudElementManager;
import pulse.hud.notifications.*;
import pulse.markers.MarkerOptions;
public final class MenuProbe implements ClientModInitializer {
 private int ticks;
 private PulseClickGuiScreen gui;
 private ModulesTab tab;
 private int checks;
 private void require(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 public void onInitializeClient(){ClientTickEvents.END_CLIENT_TICK.register(this::tick);}
 private void image(class_310 mc,String name){class_318.method_1663(mc.method_1522(),im->{try{im.method_4325(new File("screenshots/"+name+".png"));System.out.println("QA screenshot "+name);}catch(Exception e){throw new RuntimeException(e);}finally{im.close();}});}
 private void click(class_310 mc,int button){
  clickAt(mc,button,411-19-71,243.5f-19-12);
 }
 private void clickAt(class_310 mc,int button,float x,float y){
  double scale=mc.method_22683().method_4495();
  double px=(mc.method_22683().method_4480()/4.0-205.5+x)*2/scale;
  double py=(mc.method_22683().method_4507()/4.0-121.75+y)*2/scale;
  class_11909 mouse=new class_11909(px,py,new class_11910(button,0));
  gui.method_25402(mouse,false);gui.method_25406(mouse);
 }
 private void tick(class_310 mc){
  try{
   if(Pulse.getInstance()==null || Pulse.getInstance().getClickGui()==null || !mc.method_53466() || mc.method_18506()!=null)return;
   ticks++;
   if(ticks==12){
    require(N9Ezz.modules().length==30,"thirty cheat modules");
    require(Arrays.stream(N9Ezz.modules()).noneMatch(ClientModule::isEnabled),"new modules start disabled");
    gui=(PulseClickGuiScreen)Pulse.getInstance().getClickGui();gui.a(ClickGuiTabType.MODULES);tab=(ModulesTab)gui.a();tab.a(ModuleCategory.VISUALS);mc.method_1507(gui);
   }
   if(ticks==25){image(mc,"before");tab.a(ModuleCategory.CHEATS);}
   if(ticks==26)image(mc,"opening");
   if(ticks==29)image(mc,"middle");
   if(ticks==40)image(mc,"cheats");
   if(ticks==44){
    N9Ezz.AURA.power.set(37);N9Ezz.AURA.setBindKey(66);
    N9Ezz.AURA.setEnabled(true);N9Ezz.AIM.setEnabled(true);N9Ezz.HITBOXES.setEnabled(true);
    N9Ezz.TOTEM.setEnabled(true);N9Ezz.DAMAGE.setEnabled(true);N9Ezz.FRIENDS.setEnabled(true);
    require(Arrays.stream(N9Ezz.modules()).filter(ClientModule::isEnabled).count()==6,"six enabled modules");
    click(mc,1);require(Arrays.stream(N9Ezz.modules()).filter(ClientModule::isEnabled).count()==6,"right click does not disable");
    N9Ezz.localBonus=1;N9Ezz.FRIENDS.open.set(true);click(mc,0);
    require(Arrays.stream(N9Ezz.modules()).noneMatch(ClientModule::isEnabled),"left button click disables every cheat");
    require(N9Ezz.localBonus==0,"bonus cleared immediately");require(!N9Ezz.FRIENDS.open.get(),"pending Friends navigation cleared");
    require(N9Ezz.AURA.power.get()==37 && N9Ezz.AURA.bindKey()==66,"settings and bind retained");
   }
   if(ticks==46)image(mc,"disabled");
   if(ticks==52){N9Ezz.TRIGGER.setEnabled(true);N9Ezz.AURA.setEnabled(true);require(N9Ezz.AURA.isEnabled()&&!N9Ezz.TRIGGER.isEnabled(),"aura excludes trigger after obfuscation");N9Ezz.TRIGGER.setEnabled(true);require(!N9Ezz.AURA.isEnabled()&&N9Ezz.TRIGGER.isEnabled(),"trigger excludes aura after obfuscation");click(mc,0);require(!N9Ezz.TRIGGER.isEnabled(),"button disables trigger too");}
   if(ticks==58){tab.openSettings(N9Ezz.AURA);}
   if(ticks==70)image(mc,"settings");
   if(ticks==76){click(mc,0);require(!tab.hasOpenSettingsAt(20,80),"button closes settings");tab.a(ModuleCategory.VISUALS);}
   if(ticks==77)image(mc,"closing");
   if(ticks==90)image(mc,"closed");
   if(ticks==95){tab.a(ModuleCategory.CHEATS);mc.method_1507(null);}
   if(ticks==100){mc.method_1507(gui);}
   if(ticks==101)image(mc,"reopened");
   if(ticks==118){
    N9Ezz.AURA.setEnabled(true);InterfaceMode.keyState(true);
    require(InterfaceMode.hidden(),"panic chord hides category");
    require(Arrays.stream(N9Ezz.modules()).noneMatch(ClientModule::isEnabled),"panic disables modules");
    require(!(mc.field_1755 instanceof PulseClickGuiScreen),"panic closes client menu");
    require(tab.c().length==3,"hidden category label removed");
    InterfaceMode.keyState(true);require(InterfaceMode.hidden(),"held chord does not toggle twice");InterfaceMode.keyState(false);
    N9Ezz.AURA.setEnabled(true);N9Ezz.TRIGGER.setEnabledStateQuiet(true);N9Ezz.AIM.setSubscribed(true);
    require(!N9Ezz.AURA.isEnabled()&&!N9Ezz.TRIGGER.isEnabled()&&!N9Ezz.AIM.isSubscribed(),"hidden mode blocks normal, quiet and subscription activation");
    require(InterfaceMode.allowActivation(true,ModuleRegistry.byCategory(ModuleCategory.VISUALS).getFirst()),"visual modules remain allowed");
    java.lang.reflect.Method search=ModulesTab.class.getDeclaredMethod("a",String.class);search.setAccessible(true);search.invoke(tab,"Kill");
    require(tab.e().stream().noneMatch(e->e instanceof ModulesTab.ModuleEntry m && m.i()==ModuleCategory.CHEATS),"global search excludes hidden cheats");
    search.invoke(tab,"");mc.method_1507(gui);
    java.util.Queue<pulse.hud.notifications.HudNotification> notices=new java.util.ArrayDeque<>();
    var own=new pulse.hud.notifications.ToggleTextNotification("Kill Aura",false);
    var other=new pulse.hud.notifications.ToggleTextNotification("Test visual notice",false);notices.add(own);notices.add(other);
    require(InterfaceMode.visibleNotices(notices,own)==null && notices.size()==1 && notices.peek()==other,"only cheat notices suppressed");
   }
   if(ticks==130)image(mc,"hidden");
   if(ticks==136){InterfaceMode.keyState(true);InterfaceMode.keyState(false);require(!InterfaceMode.hidden()&&tab.c().length==4,"second chord restores category");require(Arrays.stream(N9Ezz.modules()).noneMatch(ClientModule::isEnabled),"restoring category keeps functions off");tab.a(ModuleCategory.CHEATS);}
   if(ticks==142){clickAt(mc,0,190,23);}
   if(ticks==146)image(mc,"levels");
   if(ticks==149){
    JsonObject untouched=ConfigSnapshots.capture();
    clickAt(mc,1,190,81);require(PowerModes.current()==PowerCurve.Level.LEGIT,"right click does not select a level");
    clickAt(mc,0,190,81);require(PowerModes.current()==PowerCurve.Level.EXTRA,"actual header dropdown selects Extra");
    require(untouched.get("pulse").equals(ConfigSnapshots.capture().get("pulse")),"selecting Extra preserves every module setting, power percentage, bind and enabled state");
    require(untouched.get("profile").equals(ConfigSnapshots.capture().get("profile")),"base level does not replace selected preset");
    require(Files.readString(Path.of("config/n9ezz/power-mode.json")).contains("extra"),"selected level persists independently of snapshots");
    PowerModes.set(PowerCurve.Level.LEGIT);PowerModes.initialize();require(PowerModes.current()==PowerCurve.Level.EXTRA,"initialization restores the saved base level");
    for(var level:new PowerCurve.Level[]{PowerCurve.Level.HIGHT,PowerCurve.Level.LEGIT}){
     clickAt(mc,0,190,23);clickAt(mc,0,190,36+level.ordinal()*18+9);
     require(PowerModes.current()==level,"actual dropdown selects "+level.label());
     require(untouched.get("pulse").equals(ConfigSnapshots.capture().get("pulse")),"level switch preserves all native settings: "+level.label());
    }
   }
   if(ticks==150)image(mc,"restored");
   if(ticks==155){clickAt(mc,0,40,212.5f);}
   if(ticks==160)image(mc,"profiles");
   if(ticks==165){
    clickAt(mc,0,40,200.5f-8*18-4+7*18+9);
    require(PowerProfiles.selected().equals("ultra"),"real dropdown click applies ultra");
    require(N9Ezz.AURA.isEnabled()&&!N9Ezz.TRIGGER.isEnabled(),"ultra uses aura");
    require(N9Ezz.HITBOXES.x.get()==5&&N9Ezz.HITBOXES.outline.get(),"ultra enables 5x outlined hitboxes");
    for(var profile:PowerProfiles.ALL){
     PowerProfiles.apply(profile);
     require(PowerProfiles.selected().equals(profile.name()),profile.name()+" selected");
     require(N9Ezz.AURA.isEnabled()==profile.aura()&&N9Ezz.TRIGGER.isEnabled()!=profile.aura(),profile.name()+" attack choice");
     require(N9Ezz.AIM.isEnabled()==profile.aim()&&N9Ezz.HITBOXES.isEnabled()==profile.hitboxes()&&N9Ezz.DAMAGE.isEnabled()==profile.damage(),profile.name()+" compatible modules");
     require(N9Ezz.AURA.power.get()==profile.power()&&N9Ezz.TOTEM.power.get()==profile.power(),profile.name()+" strength");
     require(N9Ezz.AURA.cps.get()==profile.cps()&&N9Ezz.TRIGGER.miss.get()==profile.misses(),profile.name()+" speed and misses");
     require(Math.abs(N9Ezz.HITBOXES.x.get()-profile.horizontal())<.0001&&Math.abs(N9Ezz.HITBOXES.y.get()-profile.vertical())<.0001&&N9Ezz.TOTEM.hp.get()==profile.hp(),profile.name()+" dimensions and HP");
     require(N9Ezz.TOTEM.isEnabled()&&N9Ezz.FRIENDS.isEnabled(),profile.name()+" totem and friends");
     require(Math.abs(N9Ezz.AIM.smoothing.get()-(95-profile.power()*.2))<=.51,profile.name()+" smooth aim strength");
    }
    require(PowerProfiles.find("  LeGiT MeDiUm  ").name().equals("legit medium"),"case insensitive preset lookup");
    N9Ezz.AURA.power.set(37);N9Ezz.AURA.setBindKey(66);N9Ezz.HITBOXES.lineWidth.set(3);
    var friends=gui.h().e();friends.a(new HistoryEntry("QA_Friend"));
    var h=HudElementManager.a().i();h.f().a(1.5f);
    MarkerOptions.setShowHiddenMarkers(true);
    var marker=new Notification("QA marker",1,65,2,new java.awt.Color(40,90,150),Notification.Icon.values()[0]);marker.setVisible(false);marker.setPriority(4);marker.setSource("QA source");NotificationStore.a(marker);
    PowerModes.select(PowerCurve.Level.EXTRA);
    JsonObject saved=ConfigSnapshots.capture();ConfigSnapshots.create("QA все настройки");
    require(ConfigSnapshots.names().contains("QA все настройки"),"config name with spaces and Cyrillic");
    PowerModes.select(PowerCurve.Level.LEGIT);PowerProfiles.apply(PowerProfiles.find("low"));N9Ezz.AURA.setBindKey(71);N9Ezz.HITBOXES.lineWidth.set(1);friends.b();h.f().a(2);MarkerOptions.setShowHiddenMarkers(false);NotificationStore.b(marker);
    ConfigSnapshots.load("QA все настройки");
    JsonObject restored=ConfigSnapshots.capture();
    if(!saved.equals(restored)){Files.writeString(Path.of("cfg-before.json"),saved.toString());Files.writeString(Path.of("cfg-after.json"),restored.toString());}
    require(saved.equals(restored),"complete snapshot round-trip: modules, binds, every setting, HUD, friends, markers and theme");
    require(N9Ezz.AURA.bindKey()==66&&N9Ezz.AURA.power.get()==37,"bind and custom power restored");
    for(String bad:new String[]{"../escape","CON","a/b","", "NUL.txt"}){
     boolean rejected=false;try{ConfigSnapshots.name(bad);}catch(IllegalArgumentException e){rejected=true;}require(rejected,"invalid config name rejected: "+bad);
    }
    boolean reserved=false;try{ConfigSnapshots.create("ultra");}catch(IllegalArgumentException e){reserved=true;}require(reserved,"built-in preset cannot be overwritten");
    Files.writeString(Path.of("config/n9ezz/configs/QA broken.json"),"{\"schema\":99}");
    JsonObject before=ConfigSnapshots.capture();boolean rejected=false;try{ConfigSnapshots.load("QA broken");}catch(java.io.IOException e){rejected=true;}
    require(rejected&&before.equals(ConfigSnapshots.capture()),"broken snapshot leaves current settings intact");
    java.util.List<java.util.function.Consumer<JsonObject>> corruptions=java.util.List.of(
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").addProperty("enabled","broken"),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").addProperty("bindKey",66.5),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").addProperty("bindKey",4294967362L),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").remove("Kill Aura"),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").getAsJsonObject("settings").getAsJsonObject("Мощность (%)").addProperty("value",101),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").getAsJsonObject("settings").getAsJsonObject("Мощность (%)").addProperty("value",1e80),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").getAsJsonObject("settings").getAsJsonObject("Мощность (%)").addProperty("type","key"),
     j->j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Kill Aura").getAsJsonObject("settings").getAsJsonObject("Скорость").addProperty("value",999),
     j->j.getAsJsonObject("pulse").getAsJsonObject("hud").getAsJsonObject("potions").addProperty("scale",0),
     j->j.getAsJsonObject("pulse").getAsJsonObject("hud").getAsJsonObject("potions").addProperty("x","NaN"),
     j->j.addProperty("powerLevel","unknown"),
     j->j.remove("powerLevel"),
     j->j.addProperty("friends","broken"),
     j->j.getAsJsonArray("friends").add("broken"),
     j->j.getAsJsonObject("notificationSettings").addProperty("c","false"),
     j->j.getAsJsonObject("markerOptions").addProperty("d",1.5),
     j->j.getAsJsonObject("clientColor").addProperty("d",1.1),
     j->j.getAsJsonObject("clientColor").remove("e"),
     j->{var a=new com.google.gson.JsonArray();a.add(999);j.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Particles").getAsJsonObject("settings").getAsJsonObject("Условия").add("selected",a);}
    );
    int corruption=0;
    for(var corrupt:corruptions){
     JsonObject intact=ConfigSnapshots.capture(),bad=intact.deepCopy();corrupt.accept(bad);
     Files.writeString(Path.of("config/n9ezz/configs/QA invalid.json"),bad.toString());
     boolean refused=false;try{ConfigSnapshots.load("QA invalid");}catch(java.io.IOException e){refused=true;}
     require(refused&&intact.equals(ConfigSnapshots.capture()),"invalid snapshot rejected without partial changes, case "+corruption++);
    }
    InterfaceMode.hide();JsonObject hiddenState=ConfigSnapshots.capture();
    boolean hiddenRefused=false;try{ConfigSnapshots.load("QA invalid");}catch(java.io.IOException e){hiddenRefused=true;}
    require(hiddenRefused&&InterfaceMode.hidden()&&hiddenState.equals(ConfigSnapshots.capture()),"bad config never reveals hidden interface or changes modules");
    ConfigSnapshots.load("QA все настройки");
    require(!InterfaceMode.hidden()&&saved.equals(ConfigSnapshots.capture()),"valid old config restores all settings from hidden mode");
    for(int version:new int[]{1,2}){
     JsonObject legacy=saved.deepCopy();legacy.addProperty("schema",version);var legacyModules=legacy.getAsJsonObject("pulse").getAsJsonObject("modules");
     for(String module:LegacyConfigs.ADDED)legacyModules.remove(module);
     java.util.Map<String,java.util.List<String>> additions=java.util.Map.of(
      "Kill Aura",java.util.List.of("Поворот камеры","Плавность (%)","Угол поиска (°)","Подтверждение цели (мс)","Пауза после мыши (мс)","Обычное попадание"),
      "Triggerbot",java.util.List.of("Обычное попадание"),"Aim Bot",java.util.List.of("Угол поиска (°)","Пауза после мыши (мс)","Только при атаке","Только с оружием","Точка наведения"),
      "Hitboxes",java.util.List.of("Дальность расширения","Только текущая цель"));
     additions.forEach((module,keys)->keys.forEach(k->legacyModules.getAsJsonObject(module).getAsJsonObject("settings").remove(k)));
     if(version==1){legacyModules.remove("Criticals");legacyModules.remove("Shield Breaker");
      for(String key:java.util.List.of("Дальность (блоки)","Приоритет цели","Удерживать цель"))legacyModules.getAsJsonObject("Kill Aura").getAsJsonObject("settings").remove(key);
      legacyModules.getAsJsonObject("Triggerbot").getAsJsonObject("settings").remove("Подтверждение цели (мс)");
      for(String module:java.util.List.of("Kill Aura","Triggerbot"))for(String key:java.util.List.of("Невидимые игроки","Игроки без брони","Только с оружием","Заряд удара (%)","Отпускать свой щит","Сбрасывать спринт"))legacyModules.getAsJsonObject(module).getAsJsonObject("settings").remove(key);
     }
     Files.writeString(Path.of("config/n9ezz/configs/QA legacy.json"),legacy.toString());N9Ezz.HEAL.hp.set(15);ConfigSnapshots.load("QA legacy");var migrated=ConfigSnapshots.capture();
     require(migrated.get("schema").getAsInt()==4&&PowerModes.current()==PowerCurve.Level.LEGIT,"schema "+version+" migrates to schema 4 with Legit level");
     require(Arrays.stream(N9Ezz.modules()).filter(m->LegacyConfigs.ADDED.contains(m.name())).noneMatch(ClientModule::isEnabled),"migration keeps all new modules disabled");
     require(N9Ezz.HEAL.hp.get()==8,"migration uses fresh defaults rather than current mutable settings");
     var loadedModules=migrated.getAsJsonObject("pulse").getAsJsonObject("modules");
     for(var entry:legacyModules.entrySet()){
      var oldModule=entry.getValue().getAsJsonObject();var loaded=loadedModules.getAsJsonObject(entry.getKey());
      require(oldModule.get("enabled").equals(loaded.get("enabled"))&&oldModule.get("bindKey").equals(loaded.get("bindKey")),"legacy state and bind preserved: "+entry.getKey());
      for(var setting:oldModule.getAsJsonObject("settings").entrySet())require(setting.getValue().equals(loaded.getAsJsonObject("settings").get(setting.getKey())),"legacy setting preserved: "+entry.getKey()+" / "+setting.getKey());
     }
    }
    JsonObject oldThree=saved.deepCopy();oldThree.addProperty("schema",3);oldThree.remove("powerLevel");
    for(String name:new String[]{"Auto Weapon","Auto Gapple","Auto Heal","Auto Armor","Auto Refill","Auto Mace","Bow Release","Pearl Throw","W Tap","No Push","Anti Bot","Crystal Aura","Web Trap"})
     oldThree.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject(name).getAsJsonObject("settings").remove("Мощность (%)");
    Files.writeString(Path.of("config/n9ezz/configs/QA three.json"),oldThree.toString());ConfigSnapshots.load("QA three");
    require(PowerModes.current()==PowerCurve.Level.LEGIT&&N9Ezz.ARMOR.power.get()==100,"schema 3 gains Legit and complete base strength for old timing-only modules");
    require(N9Ezz.AURA.power.get()==37,"migration never rewrites old power percentages");
    ConfigSnapshots.load("QA все настройки");require(saved.equals(ConfigSnapshots.capture())&&PowerModes.current()==PowerCurve.Level.EXTRA,"schema 4 restores Extra after all legacy migrations");
    mc.method_1507(gui);tab.a(ModuleCategory.CHEATS);
    clickAt(mc,1,170,212.5f);require(!InterfaceMode.hidden(),"hide button right click does nothing");
    clickAt(mc,0,170,212.5f);require(InterfaceMode.hidden()&&Arrays.stream(N9Ezz.modules()).noneMatch(ClientModule::isEnabled),"actual hide button hides and disables every cheat");
    require(!(mc.field_1755 instanceof PulseClickGuiScreen)&&tab.c().length==3,"hide button closes menu and removes category");
    String result="QA PASS: "+checks+" runtime checks, actual button/dropdown mouse dispatch and full config round-trip";Files.writeString(Path.of("menu-result.txt"),result);System.out.println(result);System.exit(0);
   }
  }catch(Throwable t){try{var out=new java.io.StringWriter();t.printStackTrace(new java.io.PrintWriter(out));Files.writeString(Path.of("menu-result.txt"),"QA FAIL after "+checks+" checks\n"+out);}catch(Exception ignored){}t.printStackTrace();System.out.println("QA FAIL: "+t);System.exit(3);}
 }
}
