package qa;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import java.io.File;
import java.lang.reflect.Field;
import java.util.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.*;
import pulse.n9ezz.*;

/** Real offline world: command registration and box render extraction. Never shipped in the client. */
public final class WorldProbe implements ClientModInitializer {
    private int ticks,worldTicks,checks,boxes;
    private float startYaw;
    private boolean requested,created,ready;
    private CommandDispatcher<FabricClientCommandSource> commands;
    private void require(boolean condition,String name) {checks++;if(!condition) throw new AssertionError(name);}
    private void fail(Throwable error) {try{var out=new java.io.StringWriter();error.printStackTrace(new java.io.PrintWriter(out));java.nio.file.Files.writeString(java.nio.file.Path.of("world-result.txt"),"WORLD QA FAIL after "+checks+" checks\n"+out);}catch(Exception ignored){}error.printStackTrace();System.out.println("WORLD QA FAIL: "+error);System.exit(3);}
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher,registries)->commands=dispatcher);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        WorldRenderEvents.START_MAIN.register(context->{
            if(!ready) return;
            try {
                Field collectorField=class_761.class.getDeclaredField("field_63574");collectorField.setAccessible(true);
                Object collector=collectorField.get(context.worldRenderer());
                Field pending=class_12185.class.getDeclaredField("field_63661");pending.setAccessible(true);
                for(Object entry:(List<?>)pending.get(collector)) {
                    // Entries expose their gizmo; one blue outlined box should be collected for our fake player.
                    for(var m:entry.getClass().getDeclaredMethods()) if(m.getParameterCount()==0 && m.getReturnType()==class_12175.class) {
                        m.setAccessible(true);Object gizmo=m.invoke(entry);
                        if(gizmo instanceof class_12174 box) {
                            double width=box.comp_5097().method_17939();
                            if(Math.abs(width-1.08)<.002) boxes++;
                        }
                    }
                }
            } catch(Throwable e) {fail(e);}
        });
    }
    private void tick(class_310 mc) {
        try {
            if(!mc.method_53466()||mc.method_18506()!=null)return;
            if(!requested) {
                if(++ticks<15)return;
                requested=true;N9Ezz.disableAll();
                class_525.method_64248(mc,()->{});
            }
            if(!created && mc.field_1755 instanceof class_525 screen) {
                created=true;
                var method=class_525.class.getDeclaredMethod("method_2736");method.setAccessible(true);method.invoke(screen);
            }
            if(mc.field_1687==null||mc.field_1724==null)return;
            worldTicks++;
            if(worldTicks==30) {
                mc.method_1507(null);mc.field_1724.method_36456(0);mc.field_1724.method_36457(0);
                var player=new class_745(mc.field_1687,new GameProfile(UUID.fromString("12345678-0000-0000-0000-123456789abc"),"QA_Target"));
                player.method_5838(99999);
                player.method_5814(mc.field_1724.method_23317(),mc.field_1724.method_23318(),mc.field_1724.method_23321()+3);
                player.method_36456(180);player.method_36457(0);mc.field_1687.method_53875(player);
                N9Ezz.HITBOXES.power.set(100);N9Ezz.HITBOXES.x.set(1.8f);N9Ezz.HITBOXES.y.set(1.2f);N9Ezz.HITBOXES.z.set(1.8f);N9Ezz.HITBOXES.outline.set(true);N9Ezz.HITBOXES.setEnabled(true);ready=true;
                require(commands!=null&&commands.getRoot().getChild("cfg")!=null,"cfg registered as a client command");
                var source=(FabricClientCommandSource)mc.method_1562().method_2875();
                require(commands.execute("cfg load legit medium",source)==1&&N9Ezz.TRIGGER.isEnabled()&&!N9Ezz.AURA.isEnabled(),"client cfg loads spaced preset");
                require(commands.execute("cfg create QA command",source)==1,"client cfg creates spaced config");
                require(commands.execute("cfg load ultra",source)==1&&N9Ezz.AURA.isEnabled()&&!N9Ezz.TRIGGER.isEnabled(),"client cfg applies ultra");
                require(commands.execute("cfg load QA command",source)==1&&N9Ezz.TRIGGER.isEnabled()&&!N9Ezz.AURA.isEnabled(),"client cfg restores saved combination");
                N9Ezz.disableAll();N9Ezz.HITBOXES.power.set(100);N9Ezz.HITBOXES.x.set(1.8f);N9Ezz.HITBOXES.y.set(1.2f);N9Ezz.HITBOXES.z.set(1.8f);N9Ezz.HITBOXES.setEnabled(true);
            }
            if(worldTicks==90) {
                if(boxes==0) System.out.println("BOX DEBUG: players="+mc.field_1687.method_18456().size()+", hitboxes="+N9Ezz.HITBOXES.isEnabled()+", outline="+N9Ezz.HITBOXES.outline.get());
                require(boxes>0,"actual world renderer collects widened boxes");
                class_318.method_1663(mc.method_1522(),image->{try{image.method_4325(new File("screenshots/hitboxes.png"));}catch(Exception e){fail(e);}finally{image.close();}});
                mc.field_1724.method_36456(-30);startYaw=mc.field_1724.method_36454();
                N9Ezz.AIM.range.set(5);N9Ezz.AIM.power.set(50);N9Ezz.AIM.smoothing.set(85);N9Ezz.AIM.setEnabled(true);
            }
            if(worldTicks==110) {
                float turned=mc.field_1724.method_36454();
                require(turned>startYaw+1&&turned<1,"per-frame aim turns toward the target without snapping");
                N9Ezz.AIM.setEnabled(false);float stopped=mc.field_1724.method_36454();
                require(Math.abs(stopped-turned)<.001,"disabling aim does not snap the view");
                var target=mc.field_1687.method_18456().stream().filter(p->p.method_5628()==99999).findFirst().orElseThrow();
                target.method_5814(mc.field_1724.method_23317(),mc.field_1724.method_23318()+4,mc.field_1724.method_23321()+2);
                var original=target.method_5829();
                var from=mc.field_1724.method_33571();var to=from.method_1031(0,0,3);
                var search=mc.field_1724.method_5829().method_1012(0,0,3).method_1014(1);
                require(!original.method_994(search),"regression target lies outside vanilla candidate search");
                N9Ezz.HITBOXES.y.set(5);N9Ezz.HITBOXES.power.set(100);
                var hit=class_1675.method_18075(mc.field_1724,from,to,search,e->e==target,9);
                require(hit!=null&&hit.method_17782()==target,"manual raycast reaches visible enlarged box outside vanilla search");
                require(original.equals(target.method_5829()),"expanded picking never changes physical bounding box");
                require(class_1675.method_18075(mc.field_1724,from,to,search,e->false,9)==null,"candidate expansion respects caller predicate");
                require(class_1675.method_18075(mc.field_1724,from,to,search,e->e==target,.01)==null,"candidate expansion respects maximum hit distance");
                N9Ezz.HITBOXES.power.set(0);
                require(class_1675.method_18075(mc.field_1724,from,to,search,e->e==target,9)==null,"zero power restores vanilla targeting");
                N9Ezz.HITBOXES.power.set(100);InterfaceMode.hide();
                require(class_1675.method_18075(mc.field_1724,from,to,search,e->e==target,9)==null,"hide immediately restores vanilla targeting");
                if(!Boolean.getBoolean("n9.qa.wireOnly")) {
                    var source=(FabricClientCommandSource)mc.method_1562().method_2875();
                    require(commands.execute("cfg pvp",source)==1&&N9Ezz.AURA.isEnabled()&&!N9Ezz.TRIGGER.isEnabled(),"network command preserves the selected aura mode");
                    require(!N9Ezz.HITBOXES.isEnabled()&&!N9Ezz.REACH.isEnabled()&&!N9Ezz.VELOCITY.isEnabled()&&!N9Ezz.NOSLOW.isEnabled(),"network command disables extended picking and altered physics");
                    require(commands.execute("cfg combat",source)==1,"combat diagnostics is a local client command");
                    var modeBefore=ConfigSnapshots.capture();
                    for(String level:new String[]{"legit","hight","extra"}){
                        require(commands.execute("cfg mode "+level,source)==1&&PowerModes.current()==PowerCurve.Level.parse(level),"mode command selects "+level);
                        require(modeBefore.get("pulse").equals(ConfigSnapshots.capture().get("pulse")),"mode command preserves all settings and module states: "+level);
                    }
                    require(commands.execute("cfg mode",source)==1,"mode command reports the current effective strength");
                    require(commands.execute("cfg mode invalid",source)==0&&PowerModes.current()==PowerCurve.Level.EXTRA,"invalid mode preserves the current level");
                    commands.execute("cfg mode legit",source);
                    require(commands.execute("cfg create QA network",source)==1,"network setup can be saved as a normal config");
                    require(commands.execute("cfg load ultra",source)==1,"original profiles remain available");
                    require(commands.execute("cfg load QA network",source)==1&&N9Ezz.AURA.isEnabled()&&!N9Ezz.HITBOXES.isEnabled(),"saved network setup restores its module states");
                    N9Ezz.TRIGGER.setEnabled(true);
                    require(commands.execute("cfg pvp",source)==1&&N9Ezz.TRIGGER.isEnabled()&&!N9Ezz.AURA.isEnabled(),"network command preserves the selected trigger mode");
                    Class.forName("qa.PvpChecks").getMethod("run",Object.class,Object.class).invoke(null,mc,target);
                }
                String result="WORLD QA PASS: "+checks+" checks; "+boxes+" box extraction frames; aim yaw "+startYaw+" -> "+turned;
                java.nio.file.Files.writeString(java.nio.file.Path.of("world-result.txt"),result);System.out.println(result);
                Class.forName("qa.WireChecks").getMethod("start",Object.class,Object.class,Runnable.class).invoke(null,mc,target,(Runnable)()->System.exit(0));
            }
        } catch(Throwable e) {fail(e);}
    }
}
