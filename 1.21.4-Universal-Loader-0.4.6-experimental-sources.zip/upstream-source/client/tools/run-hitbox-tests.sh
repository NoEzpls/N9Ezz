#!/usr/bin/env bash
set -euo pipefail
n9ezz_client_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
n9ezz_java_bin=${N9EZZ_JAVA_BIN:-java}
n9ezz_javac_bin=${N9EZZ_JAVAC_BIN:-javac}
n9ezz_test_output="$n9ezz_client_root/build/hitbox-tests"
mkdir -p "$n9ezz_test_output"
"$n9ezz_javac_bin" --release 21 -encoding UTF-8 -d "$n9ezz_test_output" \
  "$n9ezz_client_root/src/main/java/pulse/n9ezz/TargetGeometry.java" \
  "$n9ezz_client_root/src/test/java/pulse/n9ezz/TargetGeometryTest.java"
"$n9ezz_java_bin" -ea -cp "$n9ezz_test_output" pulse.n9ezz.TargetGeometryTest
