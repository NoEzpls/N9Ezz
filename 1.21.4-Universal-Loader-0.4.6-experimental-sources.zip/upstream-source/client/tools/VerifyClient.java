import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Checks the shipped, remapped JAR against actual intermediary Minecraft classes. */
public final class VerifyClient implements Opcodes {
    private final Map<String,ZipFile> locations=new HashMap<>();
    private final Map<String,ClassNode> classes=new HashMap<>();
    private final List<ZipFile> opened=new ArrayList<>();
    private int methods,links;
    private void index(String file) throws IOException {
        ZipFile zip=new ZipFile(file);opened.add(zip);
        var entries=zip.entries();
        while(entries.hasMoreElements()) {
            var entry=entries.nextElement();String name=entry.getName();
            if(name.endsWith(".class")) locations.putIfAbsent(name.substring(0,name.length()-6),zip);
        }
    }
    private ClassNode load(String name) throws IOException {
        if(classes.containsKey(name)) return classes.get(name);
        ZipFile zip=locations.get(name);InputStream in=zip==null ? ClassLoader.getSystemResourceAsStream(name+".class") : zip.getInputStream(zip.getEntry(name+".class"));
        if(in==null) return null;
        ClassNode node=new ClassNode();try(in){new ClassReader(in).accept(node,0);}classes.put(name,node);return node;
    }
    private boolean member(String owner,String name,String desc,boolean field,Set<String> visited) throws IOException {
        if(!visited.add(owner)) return false;
        ClassNode node=load(owner);if(node==null)return false;
        if(field) {for(FieldNode f:node.fields)if(f.name.equals(name)&&f.desc.equals(desc))return true;}
        else {for(MethodNode m:node.methods)if(m.name.equals(name)&&m.desc.equals(desc))return true;}
        if(node.superName!=null && member(node.superName,name,desc,field,visited))return true;
        for(String iface:node.interfaces)if(member(iface,name,desc,field,visited))return true;
        return false;
    }
    private void checkReference(String owner,String name,String desc,boolean field) throws IOException {
        if(!owner.startsWith("pulse/") && !owner.startsWith("ru/pulse/") && !owner.startsWith("net/minecraft/"))return;
        links++;
        if(!member(owner,name,desc,field,new HashSet<>()))throw new IllegalStateException("Unresolved "+owner+"."+name+desc);
    }
    private void check(String name,boolean references) throws Exception {
        ClassNode node=load(name);if(node==null)throw new IllegalStateException("Missing "+name);
        for(MethodNode method:node.methods) {
            if((method.access&(ACC_ABSTRACT|ACC_NATIVE))==0) {
                new Analyzer<>(new BasicVerifier()).analyze(node.name,method);methods++;
            }
            if(references)for(AbstractInsnNode instruction:method.instructions) {
                if(instruction instanceof MethodInsnNode m)checkReference(m.owner,m.name,m.desc,false);
                else if(instruction instanceof FieldInsnNode f)checkReference(f.owner,f.name,f.desc,true);
            }
        }
    }
    public static void main(String[] args) throws Exception {
        if(args.length<2)throw new IllegalArgumentException("client.jar intermediary-minecraft.jar [dependency.jar ...]");
        VerifyClient verifier=new VerifyClient();
        try {
            for(String file:args)verifier.index(file);
            List<String> added=verifier.locations.keySet().stream().filter(n->n.startsWith("pulse/n9ezz/")).sorted().toList();
            for(String name:added)verifier.check(name,true);
            for(String name:List.of("pulse/module/ModuleCategory","pulse/gui/core/PulseLogoOverlay","pulse/gui/friends/FriendsPanel"))verifier.check(name,true);
            for(String name:List.of("pulse/module/ModuleRegistry","pulse/module/ClientModule","pulse/gui/modules/ModulesTab","pulse/gui/modules/ModuleCard","pulse/gui/modules/ModuleRowRenderer","pulse/gui/core/ClickGuiFrameOverlay","pulse/hud/notifications/HudNotificationCenter"))verifier.check(name,false);
            System.out.println("PASS: "+verifier.methods+" methods analyzed, "+verifier.links+" Minecraft/Pulse references resolved in the shipped JAR");
        } finally {for(ZipFile zip:verifier.opened)zip.close();}
    }
}
