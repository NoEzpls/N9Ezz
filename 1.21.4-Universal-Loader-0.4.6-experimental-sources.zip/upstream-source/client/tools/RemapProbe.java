import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.commons.*;
/** Applies the shipped implementation mapping to test-only callers, never to game classes. */
public final class RemapProbe {
 public static void main(String[] args)throws Exception {
  Map<String,String> classes=new HashMap<>(),members=new HashMap<>();
  for(String line:Files.readAllLines(Path.of(args[2]))){String[] p=line.split(" -> ",2);if(p.length!=2)continue;if(p[0].contains("."))members.put(p[0],p[1]);else classes.put(p[0],p[1]);}
  Remapper r=new Remapper(){public String map(String n){return classes.getOrDefault(n,n);}public String mapMethodName(String o,String n,String d){return members.getOrDefault(o+"."+n+d,n);}public String mapFieldName(String o,String n,String d){return members.getOrDefault(o+"."+n+":"+d,n);}};
  Path out=Path.of(args[1]);Files.createDirectories(out.getParent());
  try(ZipFile in=new ZipFile(args[0]);ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(out))){var e=in.entries();while(e.hasMoreElements()){var n=e.nextElement();byte[] b=in.getInputStream(n).readAllBytes();if(n.getName().endsWith(".class")){ClassWriter w=new ClassWriter(0);new ClassReader(b).accept(new ClassRemapper(w,r),0);b=w.toByteArray();}z.putNextEntry(new ZipEntry(n.getName()));z.write(b);z.closeEntry();}}
  System.out.println("Test-only callers remapped against shipped N9Ezz");
 }
}
