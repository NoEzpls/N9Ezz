package pulse.n9ezz;

import com.google.gson.*;

/** Fast, dependency-free policy and migration checks. */
public final class CombatRulesTest {
    private static int checks;
    private static void ok(boolean v,String s){checks++;if(!v)throw new AssertionError(s);}
    public static void main(String[] args){
        ok(CombatRules.targetScore(0,1,20,10,40)<CombatRules.targetScore(0,2,1,1,1),"distance priority");
        ok(CombatRules.targetScore(1,4,2,10,40)<CombatRules.targetScore(1,1,8,1,1),"health priority");
        ok(CombatRules.targetScore(2,4,2,2,40)<CombatRules.targetScore(2,1,8,8,1),"armor priority");
        ok(CombatRules.targetScore(3,4,2,2,2)<CombatRules.targetScore(3,1,8,8,8),"angle priority");
        long previous=Long.MAX_VALUE;for(int p=0;p<=100;p++){long d=CombatRules.reactionDelay(p,0);ok(d<=previous,"reaction monotonic");previous=d;}
        ok(CombatRules.reactionDelay(0,0)==250_000_000L&&CombatRules.reactionDelay(100,0)==0,"reaction endpoints");
        ok(CombatRules.critical(true,false,true,1,false,true,true,false)==CombatRules.CriticalDecision.ATTACK,"falling crit");
        ok(CombatRules.critical(true,true,false,1,false,true,true,false)==CombatRules.CriticalDecision.WAIT,"strict ground");
        ok(CombatRules.critical(true,true,false,1,false,true,true,true)==CombatRules.CriticalDecision.JUMP,"strict jump");
        ok(CombatRules.critical(false,false,true,1,false,true,true,false)==CombatRules.CriticalDecision.WAIT,"incapable strict");
        JsonObject old=new JsonObject();old.addProperty("schema",1);old.add("pulse",new JsonObject());
        JsonObject pulse=old.getAsJsonObject("pulse"),mods=new JsonObject();pulse.add("modules",mods);
        for(String name:new String[]{"Kill Aura","Triggerbot"}){JsonObject m=new JsonObject();m.addProperty("enabled",false);m.addProperty("bindKey",0);m.add("settings",new JsonObject());mods.add(name,m);}
        JsonObject migrated=LegacyConfigs.upgrade(old);ok(migrated.get("schema").getAsInt()==2,"schema migration");ok(!migrated.getAsJsonObject("pulse").getAsJsonObject("modules").getAsJsonObject("Criticals").get("enabled").getAsBoolean(),"critical disabled");ok(old.get("schema").getAsInt()==1,"source immutable");
        System.out.println("PASS: "+checks+" combat policy and config migration checks");
    }
}
