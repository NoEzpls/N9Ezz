package pulse.n9ezz;

/** Checks user-visible equivalence, timing, motion and physical bounds. */
public final class PowerCurveTest {
    private static int checks;
    private static void ok(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static void close(double a,double b,String message){ok(Math.abs(a-b)<1e-8,message);}
    public static void main(String[] args){
        double legit=PowerCurve.strength(100,PowerCurve.Level.LEGIT);
        double high=PowerCurve.strength(40,PowerCurve.Level.HIGHT);
        double extra=PowerCurve.strength(10,PowerCurve.Level.EXTRA);
        close(legit,high,"100% Legit = 40% Hight");close(legit,extra,"100% Legit = 10% Extra");
        for(double s:new double[]{legit,high,extra}){
            ok(PowerCurve.cps(5,s)==5,"equal strength has equal trigger rate");
            ok(PowerCurve.delay(300,s,50)==300_000_000L,"equal inventory delay");
            ok(CombatRules.reactionDelay(s*100,50)==50_000_000L,"equal target reaction");
            close(CombatMath.scale(1.8,s*100),1.8,"equal hitbox extension");
            close(PowerCurve.blend(1,.7,s,0,1),.7,"equal knockback reduction");
        }
        for(var level:PowerCurve.Level.values()){
            double previous=-1;
            for(int percent=0;percent<=100;percent++){
                double s=PowerCurve.strength(percent,level);ok(s>=previous,"strength grows within each level");previous=s;
                ok(PowerCurve.blend(.2,.8,s,.2,1)>=.2&&PowerCurve.blend(.2,.8,s,.2,1)<=1,"movement remains bounded");
                ok(PowerCurve.blend(1,0,s,0,1)>=0,"knockback does not invert");
            }
            ok(PowerCurve.delay(250,0,50)==Long.MAX_VALUE,"zero power suspends timed actions");
        }
        ok(PowerCurve.cps(5,2.5)>PowerCurve.cps(5,1),"higher level increases actual attack rate limit");
        ok(PowerCurve.cps(5,10)==20,"extra respects one attack per 20 Hz client tick");
        ok(CombatRules.reactionDelay(250,50)==0,"hight can react on the first target tick");
        ok(CombatRules.reactionDelay(1000,500)==0,"extra removes confirmation lag at full power");
        ok(PowerCurve.delay(300,2.5,50)==120_000_000L,"hight shortens inventory interval");
        ok(PowerCurve.delay(300,10,50)==50_000_000L,"extra respects minimum operation interval");
        ok(PowerCurve.ticks(45,10,32)==32,"consumption retry preserves normal item-use time");
        close(CombatMath.scale(5,1000),10,"hitboxes have a finite upper bound");
        var slow=new AimSmoothing();var fast=new AimSmoothing();
        double slowTurn=0,fastTurn=0;
        for(int frame=0;frame<20;frame++){
            slowTurn+=slow.advance(90-slowTurn,0,1.0/60,100,85).yaw();
            fastTurn+=fast.advance(90-fastTurn,0,1.0/60,250,85).yaw();
        }
        ok(fastTurn>slowTurn&&fastTurn<=90,"higher base strength changes the real aim trajectory without overshoot");
        var a=new AimSmoothing();var b=new AimSmoothing();var c=new AimSmoothing();
        for(int frame=0;frame<60;frame++){
            var ta=a.advance(45,12,1.0/144,legit*100,94);
            var tb=b.advance(45,12,1.0/144,high*100,94);
            var tc=c.advance(45,12,1.0/144,extra*100,94);
            close(ta.yaw(),tb.yaw(),"equivalent aim yaw");close(ta.pitch(),tc.pitch(),"equivalent aim pitch");
        }
        var clock=new AttackClock();
        ok(!clock.ready(0,20,0,.99f,1),"Extra never ignores the selected full weapon charge");
        ok(clock.ready(0,20,0,1,1),"Extra permits a fully charged weapon");clock.attempted(0);
        ok(!clock.ready(49_999_999,20,0,1,1)&&clock.ready(50_000_000,20,0,1,1),"actual 20 CPS limiter");
        ok(PowerCurve.Level.parse(" HiGh ")==PowerCurve.Level.HIGHT,"high alias");
        boolean rejected=false;try{PowerCurve.Level.parse("ultra");}catch(IllegalArgumentException e){rejected=true;}
        ok(rejected,"presets and base levels are separate");
        System.out.println("PASS: "+checks+" base-power equivalence, timing, motion and limit checks");
    }
}
