package pulse.n9ezz;

public final class SectionTransitionTest {
    private static int checks;
    private static void require(boolean condition,String message) {
        checks++;
        if(!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        SectionTransition animation=new SectionTransition();
        require(animation.update(true,0)==0,"opening starts at the original theme");
        require(animation.update(true,250_000_000)==0.5,"half-second transition midpoint");
        require(animation.update(true,500_000_000)==1,"opening completes");
        require(animation.update(false,500_000_000)==1,"closing has no jump");
        require(animation.update(false,750_000_000)==0.5,"closing midpoint");
        require(animation.update(false,1_000_000_000)==0,"closing completes");
        animation.reset();
        animation.update(true,0);
        double before=animation.update(true,200_000_000);
        require(animation.update(false,200_000_000)==before,"reversal is continuous");
        require(animation.update(false,300_000_000)<before,"reversal moves toward the original theme");
        require(animation.update(false,700_000_000)==0,"reversal reaches zero");
        animation.reset();
        require(animation.value()==0 && animation.update(true,900_000_000)==0,"reopening starts smoothly");
        for(int fps:new int[]{20,30,60,144,240}) {
            SectionTransition sampled=new SectionTransition();
            sampled.update(true,0);
            double previous=0;
            for(int frame=1;frame<=fps;frame++) {
                long time=frame*1_000_000_000L/fps;
                double actual=sampled.update(true,time);
                double t=Math.min(1,time/500_000_000.0);
                require(Math.abs(actual-t*t*(3-2*t))<1e-12,"frame-rate independent easing");
                require(actual>=previous && actual<=1,"bounded monotonic opening");
                previous=actual;
            }
            require(previous==1,"every frame rate completes");
        }
        System.out.println("PASS: "+checks+" section transition checks");
    }
}
