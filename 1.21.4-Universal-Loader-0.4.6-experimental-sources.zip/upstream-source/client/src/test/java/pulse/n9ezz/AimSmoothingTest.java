package pulse.n9ezz;

public final class AimSmoothingTest {
    private static int checks;
    private static void require(boolean ok,String why) {checks++;if(!ok) throw new AssertionError(why);}
    private static double simulate(int fps,int power) {
        AimSmoothing motion=new AimSmoothing();double angle=0,pitch=0;
        double limit=25+110*power/100.0;
        double first=0,largest=0;
        for(int frame=0;frame<fps*5;frame++) {
            var turn=motion.advance(90-angle,20-pitch,1.0/fps,power,85);
            if(frame==0) first=turn.yaw();largest=Math.max(largest,turn.yaw());
            require(Double.isFinite(turn.yaw())&&Double.isFinite(turn.pitch()),"finite movement");
            require(Math.abs(turn.yaw())<=limit/fps+1e-9,"bounded yaw speed");
            require(Math.abs(turn.pitch())<=limit*.7/fps+1e-9,"bounded pitch speed");
            angle+=turn.yaw();pitch+=turn.pitch();
            require(angle<=90.00001&&pitch<=20.00001,"no overshoot on a stationary target");
        }
        require(Math.abs(90-angle)<.2&&Math.abs(20-pitch)<.2,"settles close to target");
        require(first<largest*.5,"accelerates gradually");
        motion.reset();var reset=motion.advance(-90,0,1.0/fps,power,85);
        require(reset.yaw()<0&&Math.abs(reset.yaw())<limit/fps,"reset clears previous velocity");
        return angle;
    }
    public static void main(String[] args) {
        for(int power:new int[]{20,50,100}) {
            double low=simulate(30,power),normal=simulate(60,power),high=simulate(144,power);
            require(Math.abs(low-normal)<.2&&Math.abs(normal-high)<.2,"consistent across frame rates");
        }
        AimSmoothing motion=new AimSmoothing();
        require(motion.advance(.01,-.01,.016,50,85).equals(new AimSmoothing.Turn(0,0)),"dead zone avoids micro jitter");
        require(motion.advance(90,20,0,50,85).yaw()==0,"zero elapsed time");
        require(Math.abs(CombatMath.wrapDegrees(-179-179))==2,"uses shortest direction across yaw boundary");
        System.out.println("PASS: "+checks+" smooth aim checks");
    }
}
