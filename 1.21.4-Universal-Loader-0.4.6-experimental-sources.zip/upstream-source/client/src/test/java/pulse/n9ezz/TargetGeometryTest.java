package pulse.n9ezz;

import java.util.Random;
import pulse.n9ezz.TargetGeometry.Bounds;
import pulse.n9ezz.TargetGeometry.Point;

/** Scenario and invariance tests for the geometry used by the real client targeting path. */
public final class TargetGeometryTest {
    private static int checks;
    private static void require(boolean condition,String name){checks++;if(!condition)throw new AssertionError(name);}
    private static void close(double actual,double expected,String name){require(Math.abs(actual-expected)<1e-8,name+": "+actual+" != "+expected);}
    private static double hit(Bounds box,Point from,Point to){return TargetGeometry.rayHitDistanceSquared(box,from,to);}
    public static void main(String[] args) {
        Point eye=new Point(0,1.62,0),end=new Point(0,1.62,3);
        Bounds body=new Bounds(.5,0,1.7,1.1,1.8,2.3);
        Bounds expanded=TargetGeometry.scale(body,5,1,1);
        require(Double.isInfinite(hit(body,eye,end)),"ordinary ray misses lateral player");
        close(hit(expanded,eye,end),1.7*1.7,"expanded lateral near-miss hits matching outline");
        require(TargetGeometry.pickable(hit(expanded,eye,end),3,Double.POSITIVE_INFINITY),"expanded mode authorizes visible near-miss selection");
        require(!TargetGeometry.pickable(hit(body,eye,end),3,Double.POSITIVE_INFINITY),"ordinary mode rejects same near-miss");
        Bounds outsideBroadPhase=new Bounds(1.1,0,1.7,1.7,1.8,2.3);
        require(outsideBroadPhase.minX()>1,"fixture ordinary bounds are outside vanilla ray search expanded by one block");
        require(TargetGeometry.pickable(hit(TargetGeometry.scale(outsideBroadPhase,5,1,1),eye,end),3,Double.POSITIVE_INFINITY),"expanded bbox still intersects despite ordinary broad-phase miss");
        Bounds grazing=new Bounds(0,1.62,1.7,.6,1.8,2.3);
        close(hit(grazing,eye,end),1.7*1.7,"own slab convention includes a ray grazing a box face");
        Bounds miss=new Bounds(2,0,1.7,2.6,1.8,2.3);
        require(Double.isInfinite(hit(miss,eye,end)),"miss outside even selected geometry");
        require(!TargetGeometry.pickable(hit(expanded,eye,end),3,1.2*1.2),"wall before expanded target blocks selection");
        require(!TargetGeometry.pickable(hit(expanded,eye,end),3,1.7*1.7),"wall at target surface wins exact tie");
        require(TargetGeometry.pickable(hit(expanded,eye,end),3,2.5*2.5),"wall behind selected surface does not occlude ray");
        Bounds nearEntity=new Bounds(-.2,0,.8,.2,1.8,1.2);
        double nearHit=hit(nearEntity,eye,end),farHit=hit(expanded,eye,end);
        require(nearHit<farHit,"nearer non-player entity must own the pick before farther player");
        Bounds containsEye=new Bounds(-1,1,-1,1,2,1);
        close(hit(containsEye,eye,end),0,"eye inside expanded box is a zero-distance hit");
        Bounds endpoint=new Bounds(-.2,0,3,.2,1.8,3.6);
        close(hit(endpoint,eye,end),9,"entity at exact segment endpoint intersects");
        require(TargetGeometry.pickable(hit(endpoint,eye,end),3,Double.POSITIVE_INFINITY),"range endpoint allowed without wall");
        require(!TargetGeometry.pickable(hit(endpoint,eye,end),2.99,Double.POSITIVE_INFINITY),"configured range cannot be rounded upward");
        require(Double.isInfinite(hit(endpoint,eye,new Point(0,1.62,2.99))),"segment shorter than range cannot hit farther box");
        close(hit(expanded,new Point(0,1.62,3),new Point(0,1.62,0)),.7*.7,"reverse ray returns first face");
        close(hit(containsEye,eye,eye),0,"zero length ray inside box");
        require(Double.isInfinite(hit(body,eye,eye)),"zero length ray outside box misses");
        close(TargetGeometry.distanceSquared(body,eye),.5*.5+1.7*1.7,"nearest physical range includes lateral distance");
        require(TargetGeometry.distanceSquared(expanded,eye)<TargetGeometry.distanceSquared(body,eye),"selected expanded range and original physical reach are distinct");
        Bounds beyondReach=new Bounds(-.3,0,3.3,.3,1.8,3.9);
        Bounds extended=TargetGeometry.scale(beyondReach,1,1,4);
        require(TargetGeometry.withinRange(extended,eye,3),"expanded Z shape enters requested range");
        require(!TargetGeometry.withinRange(beyondReach,eye,3),"independent physical reach guard still rejects body beyond attribute");
        Bounds hidden=new Bounds(-.3,0,2.2,.3,1.8,2.8);
        Bounds protruding=TargetGeometry.scale(hidden,1,1,4);
        double wall=1.5*1.5;
        require(TargetGeometry.pickable(hit(protruding,eye,end),3,wall),"fixture expanded shape protrudes in front of wall");
        require(!TargetGeometry.visible(TargetGeometry.distanceSquared(hidden,eye),wall),"physical-body LOS rejects through-wall protrusion");
        require(TargetGeometry.visible(2.25,2.25),"destination surface may coincide with block collision");
        require(!TargetGeometry.visible(4,2.25),"block before requested aim point hides it");
        require(TargetGeometry.visible(4,Double.POSITIVE_INFINITY),"no block is visible");
        Bounds translated=TargetGeometry.translate(body,new Point(-.8,0,0));
        Point nearest=TargetGeometry.nearestPoint(translated,eye);
        close(nearest.x(),0,"interpolated bbox translated BEFORE computing nearest aim point");
        require(Math.abs(TargetGeometry.nearestPoint(body,eye).x()-.8)>0,"old nearest-then-translate would aim outside true nearest point");
        Bounds identity=TargetGeometry.scale(body,1,1,1);
        require(identity.equals(body),"disabled/zero-power expansion preserves exact physical bounds");
        require(!TargetGeometry.pickable(Double.NaN,3,Double.POSITIVE_INFINITY),"invalid hit cannot authorize action");
        require(!TargetGeometry.pickable(1,Double.NaN,Double.POSITIVE_INFINITY),"invalid range cannot authorize action");
        require(!TargetGeometry.withinRange(body,eye,-1),"negative range rejected");
        boolean rejected=false;try{TargetGeometry.scale(body,Double.NaN,1,1);}catch(IllegalArgumentException expected){rejected=true;}
        require(rejected,"non-finite expansion rejected");
        // Translation and ray reversal are independent invariants, with non-axis-aligned segments.
        Random random=new Random(92111);
        for(int i=0;i<1000;i++) {
            double x=random.nextDouble()*20-10,y=random.nextDouble()*20-10,z=random.nextDouble()*20-10;
            Bounds b=new Bounds(x,y,z,x+.6,y+1.8,z+.6);
            Point from=new Point(x-2,y+.4,z-3),to=new Point(x+2,y+1.4,z+3);
            Point shift=new Point(random.nextDouble()*200-100,random.nextDouble()*200-100,random.nextDouble()*200-100);
            Point shiftedFrom=new Point(from.x()+shift.x(),from.y()+shift.y(),from.z()+shift.z());
            Point shiftedTo=new Point(to.x()+shift.x(),to.y()+shift.y(),to.z()+shift.z());
            close(hit(TargetGeometry.translate(b,shift),shiftedFrom,shiftedTo),hit(b,from,to),"translated diagonal intersection "+i);
            require(hit(TargetGeometry.scale(b,2,1,3),from,to)<=hit(b,from,to),"expansion cannot move first ray intersection farther "+i);
            close(TargetGeometry.distanceSquared(TargetGeometry.translate(b,shift),shiftedFrom),TargetGeometry.distanceSquared(b,from),"translated nearest distance "+i);
        }
        System.out.println("PASS: "+checks+" shared targeting geometry checks");
    }
}
