package pulse.n9ezz;

import java.util.Random;

public final class CombatLogicTest {
    private static int checks;
    private static void require(boolean ok,String reason) { checks++;if(!ok) throw new AssertionError(reason); }
    public static void main(String[] args) {
        for(int count=0;count<=50;count++) {
            MissSequence misses=new MissSequence(new Random(13));
            for(int block=0;block<30;block++) {
                int actual=0;for(int i=0;i<100;i++) if(misses.next(count)) actual++;
                require(actual==count,"misses "+count+" actual "+actual);
            }
        }
        require(CombatMath.halfAngle(0)<45,"narrow angle");
        require(CombatMath.halfAngle(50)>90,"side angle");
        require(CombatMath.halfAngle(90)==180 && CombatMath.halfAngle(100)==180,"full 360 angle");
        double last=0;for(int p=0;p<=100;p++) { double now=CombatMath.halfAngle(p);require(now>=last,"angle monotonic");last=now; }
        require(Math.abs(CombatMath.approachAngle(179,-179,1)-180)<.001,"aim wrap");
        require(CombatMath.scale(5,100)==5 && CombatMath.scale(5,0)==1,"hitbox scale");
        require(CombatMath.playerSlot(0)==36 && CombatMath.playerSlot(8)==44 && CombatMath.playerSlot(9)==9 && CombatMath.playerSlot(35)==35,"slot mapping");
        require(CombatMath.totemDelay(100)==0 && CombatMath.totemDelay(0)==400_000_000L,"totem power delay");
        AttackClock fast=new AttackClock();
        require(!fast.ready(0,10,0,0),"fast respects the selected full-charge threshold too");
        require(fast.ready(0,10,0,1),"fast permits a charged weapon");fast.attempted(0);
        require(!fast.ready(99_999_999,10,0,1) && fast.ready(100_000_000,10,0,1),"10 CPS maximum");
        require(!fast.ready(200_000_000,10,0,.49f,.5f)&&fast.ready(200_000_000,10,0,.5f,.5f),"explicit half-charge setting is respected");
        AttackClock normal=new AttackClock();
        require(!normal.ready(0,10,1,.8f) && normal.ready(0,10,1,1),"normal full cooldown");
        AttackClock slow=new AttackClock();
        require(!slow.ready(0,10,2,1),"slow begins wait");
        require(!slow.ready(299_999_999,10,2,1) && slow.ready(300_000_000,10,2,1),"slow waits 300 ms");
        slow.attempted(300_000_000);
        require(!slow.ready(500_000_000,10,2,.9f),"slow cooldown reset");
        require(!slow.ready(600_000_000,10,2,1) && slow.ready(900_000_000,10,2,1),"slow fresh wait");
        System.out.println("PASS: "+checks+" combat logic checks");
    }
}
