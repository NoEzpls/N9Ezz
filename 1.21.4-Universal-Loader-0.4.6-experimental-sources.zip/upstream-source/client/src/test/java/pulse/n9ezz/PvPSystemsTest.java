package pulse.n9ezz;

/** Numerical and ownership regressions that exercise public behavior, without a game world. */
public final class PvPSystemsTest {
    private static int checks;
    private static void ok(boolean condition,String name){checks++;if(!condition)throw new AssertionError(name);}
    public static void main(String[] args) {
        Object weapon=new Object(),heal=new Object();
        for(int original=0;original<9;original++)for(int wanted=0;wanted<9;wanted++){
            SlotOwnership s=new SlotOwnership();
            ok(s.request(weapon,50,wanted,original,10),"weapon acquires slot");
            ok(!s.request(heal,40,8,wanted,11),"lower priority cannot preempt");
            ok(s.request(heal,90,8,wanted,11),"healing preempts");
            ok(s.release(weapon,8,true)==-1&&s.owns(heal),"stale release leaves healing owner");
            ok(s.release(heal,8,true)==original,"restore original slot through preemption");
            ok(!s.active(),"release clears ownership");
            s.request(weapon,50,wanted,original,10);
            int manual=(wanted+1)%9;
            ok(s.release(weapon,manual,true)==-1,"manual selection is retained");
            s.request(weapon,50,wanted,original,10);
            ok(!s.request(weapon,50,wanted,manual,11)&&!s.active(),"manual change cancels refresh");
            s.request(weapon,50,wanted,original,10);
            ok(!s.expired(12)&&s.expired(13),"lease expiry boundary");
        }
        for(double step:new double[]{.01,.15,.6144})for(int i=-300;i<=300;i++) {
            double error=i*.07,motion=i*.11,q=PvPMath.mouseStep(motion,step,error);
            ok(Math.abs(q)<=Math.abs(error)+1e-9,"quantization never overshoots target");
            ok(Math.abs(q/step-Math.rint(q/step))<1e-8,"movement lies on mouse sensitivity grid");
        }
        for(double speed:new double[]{.5,1,2,3})for(int x=1;x<=60;x++)for(int y=-5;y<=20;y++){
            double angle=PvPMath.ballisticPitch(x,y,speed,.05);
            if(Double.isFinite(angle)){
                double time=x/(speed*Math.cos(angle));double height=speed*Math.sin(angle)*time-.05*time*time/2;
                ok(Math.abs(height-y)<1e-6,"low ballistic trajectory intersects target height");
            }else ok(speed*speed*speed*speed-.05*(.05*x*x+2*y*speed*speed)<0,"only unreachable targets are rejected");
        }
        for(int armor=0;armor<=30;armor++)for(int damage=1;damage<=100;damage++){
            double applied=PvPMath.armorDamage(damage,armor,8);
            ok(applied>=0&&applied<=damage,"armor damage stays in physical bounds");
        }
        ok(CombatRules.reactionDelay(20,100)==200_000_000L,"confirmation and power delay use maximum");
        ok(CombatRules.reactionDelay(100,900)==500_000_000L,"confirmation clamps to its valid range");
        ok(CombatRules.critical(true,true,false,.3f,false,true,true,true)==CombatRules.CriticalDecision.WAIT,"critical auto-jump waits for weapon charge");
        ok(CombatRules.critical(true,false,false,1,false,true,false,false)==CombatRules.CriticalDecision.WAIT,"ascending player waits for falling phase");
        System.out.println("PASS: "+checks+" PvP ownership, mouse-grid, ballistics, armor and timing checks");
    }
}
