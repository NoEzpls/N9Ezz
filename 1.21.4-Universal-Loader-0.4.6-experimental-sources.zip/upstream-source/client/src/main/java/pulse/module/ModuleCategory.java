package pulse.module;

/** Original ordinals are preserved for compatibility with Pulse. */
public enum ModuleCategory {
    VISUALS("Visuals"), HUD("HUD"), UTILITIES("Utilities"), COSMETICS("Cosmetics"), CHEATS("Читы");
    private final String displayName;
    ModuleCategory(String displayName) { this.displayName = displayName; }
    public String displayName() { return displayName; }
    public String a() { return displayName(); }
}
