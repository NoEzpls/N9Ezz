package pulse.gui.core;

import java.awt.Color;
import org.joml.Matrix3x2fStack;
import pulse.render.Renderer2D;
import pulse.render.font.FontManager;
import pulse.render.font.FontRenderer;
import pulse.n9ezz.InterfaceMode;

/** N9Ezz branding rendered with the visual client's existing smooth font. */
public class PulseLogoOverlay implements ClickGuiOverlay {
    @Override public void a(Matrix3x2fStack matrix,Renderer2D renderer,float x,float y,int mouseX,int mouseY) {
        FontRenderer title=FontManager.b[Math.min(40,FontManager.b.length-1)];
        FontRenderer caption=FontManager.b[Math.min(15,FontManager.b.length-1)];
        String name=InterfaceMode.hidden() ? "Pulse" : "N9Ezz";
        if(title!=null) title.a(name,x+148,(double)y-35,new Color(236,235,246),matrix);
        if(caption!=null) caption.a("Pulse visuals · Fabric 1.21.11",x+150,(double)y-10,new Color(164,164,181),matrix);
    }
    @Override public void a(float x,float y,int mouseX,int mouseY) {}
}
