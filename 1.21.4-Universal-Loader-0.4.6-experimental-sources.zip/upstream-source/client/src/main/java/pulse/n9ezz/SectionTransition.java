package pulse.n9ezz;

/** A reversible, half-second transition measured in elapsed time, not frames. */
public final class SectionTransition {
    private static final long DURATION = 500_000_000L;
    private long started = Long.MIN_VALUE;
    private double from;
    private double value;
    private boolean target;

    public double update(boolean active, long now) {
        if (started != Long.MIN_VALUE) {
            double t = Math.max(0, Math.min(1, (now - started) / (double) DURATION));
            double eased = t * t * (3 - 2 * t);
            value = from + ((target ? 1 : 0) - from) * eased;
        }
        if (active != target) {
            from = value;
            target = active;
            started = now;
        }
        return value;
    }

    public double value() { return value; }

    public void reset() {
        started = Long.MIN_VALUE;
        from = value = 0;
        target = false;
    }
}
