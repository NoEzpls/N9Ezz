package pulse.n9ezz;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;

public final class Attacks {
    private Attacks() {}
    private record Pending(PlayerEntity target,AttackClock clock,MissSequence misses,Options options,long tick,int slot,net.minecraft.item.Item item) {}
    private static Pending pending;
    private static long sent,blocked,skipped;
    private static String reason="Нет попыток";
    public record Options(int cps,int speed,int misses,float cooldown,float range,boolean weaponsOnly,boolean releaseShield,boolean resetSprint,boolean expanded) {}
    public static boolean weapon(PlayerEntity p) {var s=p.getMainHandStack();return s.isIn(ItemTags.SWORDS)||s.isIn(ItemTags.AXES)||s.isOf(Items.TRIDENT)||s.isOf(Items.MACE);}
    public static void clearPending(){pending=null;}
    public static void cancel(){clearPending();if(N9Ezz.SHIELD!=null)N9Ezz.SHIELD.cancel();}
    public static String diagnostics(){return "Автоудары: "+sent+"; пропуски: "+skipped+"; остановленные попытки: "+blocked+". Последнее: "+reason;}
    private static void blocked(String why){blocked++;reason=why;}
    public static boolean waitingSprintReset(){return pending!=null&&pending.tick()==CombatDispatch.tick()&&pending.options().resetSprint()&&MinecraftClient.getInstance().player!=null&&MinecraftClient.getInstance().player.isSprinting();}
    private static boolean valid(PlayerEntity target,Options o) {
        var mc=MinecraftClient.getInstance();
        return Targeting.canAct(o.releaseShield())&&Targeting.combatTarget(target,true,true)
            &&Targeting.distance(target,o.expanded())<=Targeting.combatRange(o.range())&&Targeting.realDistance(target)<=Targeting.actualCombatRange()&&Targeting.visible(target,o.expanded())
            &&(N9Ezz.TOTEM==null||!N9Ezz.TOTEM.reservingMainHand())&&(!o.weaponsOnly()||weapon(mc.player));
    }
    public static void attempt(PlayerEntity target,AttackClock clock,MissSequence misses,Options o) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(!valid(target,o)){clock.reset();cancel();blocked("Цель, предмет или дальность");return;}
        if(!CombatDispatch.available()){blocked("Ручная атака или уже выполненный удар");return;}
        long now=System.nanoTime();
        if((N9Ezz.SHIELD==null||!N9Ezz.SHIELD.pending())&&!clock.ready(now,o.cps(),o.speed(),mc.player.getAttackCooldownProgress(0),o.cooldown()/100))return;
        if(N9Ezz.SHIELD!=null&&!N9Ezz.SHIELD.prepare(target,now))return;
        if(!clock.ready(now,o.cps(),o.speed(),mc.player.getAttackCooldownProgress(0),o.cooldown()/100))return;
        if(N9Ezz.CRITICALS!=null&&!N9Ezz.CRITICALS.ready(now,o.resetSprint()))return;
        pending=new Pending(target,clock,misses,o,CombatDispatch.tick(),mc.player.getInventory().getSelectedSlot(),mc.player.getMainHandStack().getItem());
    }
    public static void flush() {
        var request=pending;clearPending();if(request==null)return;
        var mc=MinecraftClient.getInstance();var o=request.options();var target=request.target();
        if(request.tick()!=CombatDispatch.tick()||!valid(target,o)){cancel();blocked("Цель изменилась за тик");return;}
        if(request.slot()!=mc.player.getInventory().getSelectedSlot()||request.item()!=mc.player.getMainHandStack().getItem()){cancel();blocked("Оружие или слот изменились за тик");return;}
        if(Targeting.underCrosshairEntity(Targeting.combatRange(o.range()),o.expanded())!=target){cancel();blocked("Луч не попал в выбранный хитбокс");return;}
        long now=System.nanoTime();
        if(!request.clock().ready(now,o.cps(),o.speed(),mc.player.getAttackCooldownProgress(0),o.cooldown()/100)){blocked("Оружие ещё не заряжено");return;}
        if(o.resetSprint()&&mc.player.isSprinting()){blocked("Спринт ещё не остановлен обычным вводом");return;}
        if(N9Ezz.CRITICALS!=null&&!N9Ezz.CRITICALS.ready(now,false)){blocked("Нет условий реального крита");return;}
        if(!CombatDispatch.claim()){blocked("Ручная атака или уже выполненный удар");return;}
        boolean helperShield=N9Ezz.AUTOSHIELD!=null&&N9Ezz.AUTOSHIELD.ownsShield();
        boolean released=mc.player.isUsingItem()&&mc.player.getActiveItem().isOf(Items.SHIELD)&&(o.releaseShield()||helperShield);
        Hand active=released?mc.player.getActiveHand():Hand.MAIN_HAND;if(released)mc.interactionManager.stopUsingItem(mc.player);
        request.clock().attempted(now);
        try {if(request.misses().next(o.misses())){mc.player.swingHand(Hand.MAIN_HAND);skipped++;reason="Выбранный мисс";return;}
            mc.interactionManager.attackEntity(mc.player,target);mc.player.swingHand(Hand.MAIN_HAND);sent++;reason=(o.expanded()?"Расширенный":"Обычный")+" хитбокс, движение отправлено";
        } finally {if(N9Ezz.SHIELD!=null)N9Ezz.SHIELD.afterAttempt();
            if(released&&!helperShield&&mc.player!=null&&mc.options.useKey.isPressed()&&mc.player.getStackInHand(active).isOf(Items.SHIELD))mc.interactionManager.interactItem(mc.player,active);}
    }
}
