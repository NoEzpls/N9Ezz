package pulse.n9ezz.mixin;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.n9ezz.N9Ezz;

@Mixin(GameRenderer.class)
public abstract class AimFrameMixin {
    @Inject(method="render",at=@At("HEAD"))
    private void n9ezzAimFrame(RenderTickCounter tickCounter,boolean tick,CallbackInfo ci) {
        if(N9Ezz.AURA!=null&&N9Ezz.AURA.controlsView())N9Ezz.AURA.frame(System.nanoTime(),tickCounter.getTickProgress(false));
        else if(N9Ezz.PROJECTILE!=null&&N9Ezz.PROJECTILE.controlsView())N9Ezz.PROJECTILE.frame(System.nanoTime(),tickCounter.getTickProgress(false));
        else if(N9Ezz.AIM!=null && N9Ezz.AIM.isEnabled()) N9Ezz.AIM.frame(System.nanoTime(),tickCounter.getTickProgress(false));
    }
}
