package pulse.n9ezz;

import pulse.module.ModuleRegistry;

public abstract class PvPModule extends CheatModule {
    public PvPModule(){power.set(100);}
    protected boolean usesPower(){return true;}
    @Override public void collectSettings(){super.collectSettings();if(!usesPower())settings().remove(power);}
    protected String[] conflicts(){return new String[0];}
    @Override public void onEnable() {
        for(var module:ModuleRegistry.all())for(String name:conflicts())
            if(module.getClass().getSimpleName().equals(name)&&module.isEnabled())module.setEnabled(false);
        super.onEnable();
    }
    @Override public void onDisable() {
        ConsumableUse.cancel(this);CombatInventory.release(this,true);super.onDisable();
    }
}
