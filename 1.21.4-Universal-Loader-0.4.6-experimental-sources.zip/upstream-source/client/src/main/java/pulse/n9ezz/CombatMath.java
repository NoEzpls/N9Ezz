package pulse.n9ezz;

public final class CombatMath {
    private CombatMath() {}
    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
    public static double halfAngle(double power) {
        power = clamp(power, 0, 100);
        if (power <= 20) return 12 + power * 33 / 20;
        if (power <= 50) return 45 + (power - 20) * 65 / 30;
        if (power < 90) return 110 + (power - 50) * 70 / 40;
        return 180;
    }
    public static double wrapDegrees(double angle) {
        angle %= 360;
        if (angle >= 180) angle -= 360;
        if (angle < -180) angle += 360;
        return angle;
    }
    public static float approachAngle(float current, float desired, double maxChange) {
        return (float)(current + clamp(wrapDegrees(desired-current), -maxChange, maxChange));
    }
    public static double scale(double selected, double power) {
        return Math.min(10,1 + (clamp(selected, 1, 5)-1) * clamp(power, 0, 1000) / 100);
    }
    public static int playerSlot(int inventoryIndex) {
        if (inventoryIndex < 0 || inventoryIndex > 35) throw new IllegalArgumentException("inventory index");
        return inventoryIndex < 9 ? 36+inventoryIndex : inventoryIndex;
    }
    public static long totemDelay(double power) {
        return Math.round(400_000_000L * (1 - clamp(power, 0, 100)/100));
    }
}
