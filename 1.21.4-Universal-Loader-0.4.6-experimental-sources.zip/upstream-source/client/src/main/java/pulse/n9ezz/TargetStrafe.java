package pulse.n9ezz;
import net.minecraft.util.math.Vec2f;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Target Strafe",b="Поворачивает обычный ввод движения по окружности вокруг боевой цели; не добавляет скорость.",c=ModuleCategory.CHEATS)
public final class TargetStrafe extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting radius=new SliderSetting("Радиус",2,1,5,.1f);
    public final ModeSetting direction=new ModeSetting("Направление",new String[]{"По часовой","Против часовой"},0);
    public Vec2f input(Vec2f input) {
        var p=client().player;var t=CombatTargets.current();double length=Math.hypot(input.x,input.y);
        if(!isEnabled()||!Targeting.canAct()||t==null||length<.01||p.isGliding()||p.hasVehicle()||p.horizontalCollision||Targeting.realDistance(t)>6)return input;
        var d=t.getEntityPos().subtract(p.getEntityPos());double distance=Math.hypot(d.x,d.z);if(distance<.1)return input;
        double nx=d.x/distance,nz=d.z/distance,side=direction.selectedValue().equals("По часовой")?1:-1;
        double radial=CombatMath.clamp((distance-radius.get())*.7*Math.max(.1,strength()),-1,1),wx=nx*radial+nz*side,wz=nz*radial-nx*side;
        double yaw=Math.toRadians(p.getYaw()),norm=Math.hypot(wx,wz);wx/=norm;wz/=norm;
        double x=PvPMath.blend(input.x,(wx*Math.cos(yaw)+wz*Math.sin(yaw))*length,effectivePower());
        double y=PvPMath.blend(input.y,(wz*Math.cos(yaw)-wx*Math.sin(yaw))*length,effectivePower());
        double n=Math.hypot(x,y);return n>.001?new Vec2f((float)(x/n*length),(float)(y/n*length)):input;
    }
}
