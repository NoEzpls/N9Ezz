package pulse.n9ezz;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import pulse.events.ClientTickEvent;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.ModeSetting;
import pulse.settings.SliderSetting;

@ModuleInfo(a="Auto Totem",b="Меняет предмет в выбранной руке на тотем при низком HP. 2 HP = одно сердце.",c=ModuleCategory.CHEATS)
public final class AutoTotem extends CheatModule {
    public final SliderSetting hp=new SliderSetting("Порог HP",2,1,20,0.5f);
    public final ModeSetting hand=new ModeSetting("Рука",new String[]{"Правая (основная)","Левая (вторая)"},0);
    public boolean reservingMainHand() {return isEnabled()&&powered()&&client().player!=null&&!hand.selectedValue().startsWith("Левая")&&client().player.getHealth()<=hp.get();}
    private long lowSince=Long.MIN_VALUE;
    private long lastSwap=Long.MIN_VALUE;
    public AutoTotem() { power.set(100); }
    @Override public void onDisable() { lowSince=lastSwap=Long.MIN_VALUE;super.onDisable(); }
    @EventHandler public void tick(ClientTickEvent event) {
        var mc=client();
        if(!powered()||mc.player==null || mc.interactionManager==null || mc.currentScreen!=null || mc.isPaused()
            || !mc.player.isAlive() || mc.player.isSpectator() || mc.player.currentScreenHandler!=mc.player.playerScreenHandler) { lowSince=Long.MIN_VALUE;return; }
        if(mc.player.getHealth()>hp.get()) { lowSince=Long.MIN_VALUE;return; }
        boolean offhand=hand.selectedValue().startsWith("Левая");
        if(!offhand){ConsumableUse.cancel();Attacks.cancel();CombatInventory.cancel();}
        var held=offhand ? mc.player.getOffHandStack() : mc.player.getMainHandStack();
        if(held.isOf(Items.TOTEM_OF_UNDYING)) { lowSince=Long.MIN_VALUE;return; }
        long now=System.nanoTime();
        if(lowSince==Long.MIN_VALUE) lowSince=now;
        if(now-lowSince<actionDelay(400*(1-Math.min(1,strength())),0) || lastSwap!=Long.MIN_VALUE && now-lastSwap<actionDelay(250,50)) return;
        int button=offhand ? 40 : mc.player.getInventory().getSelectedSlot();
        for(int i=0;i<36;i++) {
            if(!offhand && i==button) continue;
            if(!mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            ConsumableUse.cancel();Attacks.cancel();
            if(offhand&&mc.player.isUsingItem()&&mc.player.getActiveHand()==net.minecraft.util.Hand.OFF_HAND)mc.interactionManager.stopUsingItem(mc.player);
            if(CombatInventory.swap(i,button)){lastSwap=now;lowSince=Long.MIN_VALUE;}return;
        }
    }
}
