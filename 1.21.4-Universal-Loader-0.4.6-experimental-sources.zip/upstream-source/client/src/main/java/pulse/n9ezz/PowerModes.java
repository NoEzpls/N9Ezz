package pulse.n9ezz;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import net.fabricmc.loader.api.FabricLoader;

/** One persisted level for the whole added category, independent from presets. */
public final class PowerModes {
    private static PowerCurve.Level current=PowerCurve.Level.LEGIT;
    private PowerModes(){}
    private static Path path(){return FabricLoader.getInstance().getConfigDir().resolve("n9ezz/power-mode.json");}
    public static PowerCurve.Level current(){return current;}
    public static String label(){return current.label();}
    public static void initialize(){
        try{Path file=path();if(Files.isRegularFile(file)&&Files.size(file)<4096)
            current=PowerCurve.Level.parse(JsonParser.parseString(Files.readString(file)).getAsJsonObject().get("level").getAsString());
        }catch(Exception ignored){current=PowerCurve.Level.LEGIT;}
    }
    public static void set(PowerCurve.Level level){
        if(level==null)throw new IllegalArgumentException("Уровень не выбран");
        current=level;
        if(N9Ezz.AURA!=null)N9Ezz.AURA.reset();
        if(N9Ezz.TRIGGER!=null)N9Ezz.TRIGGER.reset();
        if(N9Ezz.AIM!=null)N9Ezz.AIM.reset();
        if(N9Ezz.PROJECTILE!=null)N9Ezz.PROJECTILE.reset();
        Attacks.cancel();
    }
    public static void select(PowerCurve.Level level){
        PowerCurve.Level before=current;
        try{ConfigSnapshots.changing(()->set(level));}
        catch(RuntimeException e){set(before);throw e;}
    }
    public static void save(){
        Path file=path(),temp=null;
        try{
            Files.createDirectories(file.getParent());temp=Files.createTempFile(file.getParent(),"power-",".tmp");
            JsonObject json=new JsonObject();json.addProperty("level",current.name().toLowerCase(java.util.Locale.ROOT));
            Files.writeString(temp,json.toString(),StandardCharsets.UTF_8);
            try{Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
        }catch(java.io.IOException e){throw new IllegalStateException("Не удалось сохранить уровень мощности",e);}
        finally{if(temp!=null)try{Files.deleteIfExists(temp);}catch(java.io.IOException ignored){}}
    }
    public static String diagnostics(){
        var t=N9Ezz.TRIGGER;
        return "Уровень: "+label()+" ×"+current.multiplier()+"; Triggerbot: "+t.power.roundedInt()+"%, базовая сила "+String.format(java.util.Locale.ROOT,"%.2f",t.strength())+
            ", лимит "+t.effectiveCps()+" ударов/с; заряд "+t.cooldown.roundedInt()+"%.";
    }
}
