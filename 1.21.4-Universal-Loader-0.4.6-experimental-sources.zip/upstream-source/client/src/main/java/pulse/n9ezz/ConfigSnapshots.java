package pulse.n9ezz;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import pulse.config.ConfigManager;
import pulse.config.ConfigState;
import pulse.config.LocalConfigManager;
import pulse.module.ModuleRegistry;
import pulse.settings.Setting;
import pulse.settings.SettingGroup;
import pulse.settings.SliderSetting;
import pulse.settings.ModeSetting;
import pulse.gui.modules.ModuleSettingsPanel;
import pulse.gui.settings.SliderSettingWidget;
import pulse.hud.core.HudElement;
import pulse.hud.core.HudElementManager;
import pulse.hud.notifications.Notification;
import pulse.hud.notifications.NotificationStore;
import pulse.markers.MarkerOptions;
import java.awt.Color;

/** Complete local snapshots using Pulse's original settings/HUD codec and extra state. */
public final class ConfigSnapshots {
    private static final Gson GSON=new GsonBuilder().serializeNulls().setPrettyPrinting().create();
    private static final int MAX_BYTES=2*1024*1024;
    private ConfigSnapshots() {}
    private static Path directory() { return FabricLoader.getInstance().getConfigDir().resolve("n9ezz/configs"); }
    public static String name(String input) {
        String n=input.strip();
        if(n.startsWith("\"") && n.endsWith("\"") && n.length()>1) n=n.substring(1,n.length()-1).strip();
        if(n.isEmpty() || n.length()>64 || !n.matches("[\\p{L}\\p{N} _.-]+") || n.startsWith(".") || n.endsWith(".") || n.endsWith(" "))
            throw new IllegalArgumentException("Имя: 1–64 буквы, цифры, пробелы, _ или -");
        String first=n.split("\\.",2)[0].toUpperCase(Locale.ROOT);
        if(first.matches("CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]")) throw new IllegalArgumentException("Недопустимое имя файла");
        return n;
    }
    public static List<String> names() {
        if(!Files.isDirectory(directory())) return List.of();
        try(var files=Files.list(directory())) {
            return files.filter(p->Files.isRegularFile(p) && p.getFileName().toString().endsWith(".json"))
                .map(p->p.getFileName().toString().replaceFirst("\\.json$",""))
                .sorted(String.CASE_INSENSITIVE_ORDER).toList();
        } catch(Exception e) { return List.of(); }
    }
    private static Object call(Object target,String method,Class<?>[] types,Object... args) {
        try {
            Method m=target.getClass().getDeclaredMethod(method,types);m.setAccessible(true);return m.invoke(target,args);
        } catch(ReflectiveOperationException e) {throw new IllegalStateException("Не удалось обратиться к настройкам Pulse",e);}
    }
    private static Object read(Object target,String method) { return call(target,method,new Class<?>[0]); }
    public static void changing(Runnable change) {
        LocalConfigManager local=LocalConfigManager.get();
        try {
            Field field=LocalConfigManager.class.getDeclaredField("applying");field.setAccessible(true);
            boolean old=field.getBoolean(local);field.setBoolean(local,true);
            try {change.run();} finally {field.setBoolean(local,old);}
            if(!old) local.flushSaveNow("n9ezz-config");
            if(!old) FriendSupport.save();
            if(!old) PowerModes.save();
        } catch(ReflectiveOperationException e) {throw new IllegalStateException("Не удалось применить настройки",e);}
    }
    public static JsonObject capture() {
        JsonObject root=new JsonObject();root.addProperty("schema",4);root.addProperty("powerLevel",PowerModes.current().name().toLowerCase(Locale.ROOT));root.addProperty("minecraft","1.21.11");
        root.addProperty("profile",PowerProfiles.selected());
        JsonObject pulse=JsonParser.parseString((String)read(LocalConfigManager.get(),"serializeState")).getAsJsonObject();
        // Keep any String/Text settings the native JSON codec does not support.
        JsonObject modules=pulse.getAsJsonObject("modules");
        for(var module:ModuleRegistry.all()) {
            JsonObject settings=modules.getAsJsonObject(module.name()).getAsJsonObject("settings");
            for(Setting<?> setting:module.settings()) if(!(setting instanceof SettingGroup) && !settings.has(setting.name()) && setting.value()!=null) {
                JsonObject raw=new JsonObject();raw.addProperty("type","n9ezz-raw");raw.add("value",GSON.toJsonTree(setting.value()));settings.add(setting.name(),raw);
            }
        }
        var hud=HudElementManager.a();JsonObject positions=pulse.getAsJsonObject("hud");
        captureScale(positions,"potions",hud.i());captureScale(positions,"hotkeys",hud.j());
        captureScale(positions,"cooldowns",hud.k());captureScale(positions,"target",hud.l());
        captureScale(positions,"saturation",hud.getSaturationHud());
        root.add("pulse",pulse);
        ConfigManager manager=ConfigManager.a();
        root.add("friends",GSON.toJsonTree(read(manager,"o")));
        JsonArray markers=new JsonArray();
        for(Notification marker:NotificationStore.a()) if(!marker.isTemporary()) {
            JsonObject item=new JsonObject();item.addProperty("title",marker.title());
            item.addProperty("x",marker.x());item.addProperty("y",marker.y());item.addProperty("z",marker.z());
            item.addProperty("color",marker.color().getRGB());item.addProperty("icon",marker.icon().name());
            item.addProperty("priority",marker.priority());item.addProperty("source",marker.source());
            item.addProperty("createdAt",marker.createdAt());item.addProperty("expiresAt",marker.expiresAt());
            item.addProperty("visible",marker.visible());markers.add(item);
        }
        root.add("markers",markers);
        root.add("markerOptions",GSON.toJsonTree(read(manager,"q")));
        root.add("categoriesPosition",GSON.toJsonTree(read(manager,"s")));
        root.add("notificationSettings",GSON.toJsonTree(read(manager,"t")));
        root.add("clientColor",GSON.toJsonTree(read(manager,"u")));
        return root;
    }
    public static String create(String input) throws java.io.IOException {
        String n=name(input);
        if(PowerProfiles.find(n)!=null) throw new IllegalArgumentException("Это имя встроенного профиля; выбери другое имя конфига");
        JsonObject state=capture();
        byte[] data=GSON.toJson(state).getBytes(StandardCharsets.UTF_8);
        if(data.length>MAX_BYTES) throw new java.io.IOException("Конфиг слишком большой");
        Files.createDirectories(directory());
        Path target=directory().resolve(n+".json"),temp=Files.createTempFile(directory(),"cfg-",".tmp");
        try {
            Files.write(temp,data);
            try {Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException e) {Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING);}
        } finally {Files.deleteIfExists(temp);}
        return n;
    }
    public static void load(String input) throws java.io.IOException {
        String n=name(input);Path file=directory().resolve(n+".json");
        if(!Files.isRegularFile(file)) throw new java.io.IOException("Конфиг «"+n+"» не найден");
        if(Files.size(file)>MAX_BYTES) throw new java.io.IOException("Конфиг слишком большой");
        JsonObject before=capture();boolean wasHidden=InterfaceMode.hidden();
        JsonObject state;
        try {state=LegacyConfigs.upgrade(JsonParser.parseString(Files.readString(file)).getAsJsonObject(),before);validate(state,before);}
        catch(Exception e) {throw new java.io.IOException("Повреждённый или несовместимый конфиг",e);}
        try {
            InterfaceMode.reveal();
            changing(()->restore(state));
        } catch(RuntimeException e) {
            boolean restored=false;
            try {changing(()->restore(before));if(wasHidden) InterfaceMode.hide();restored=true;}catch(RuntimeException rollback) {e.addSuppressed(rollback);}
            throw new java.io.IOException(restored?"Ошибка загрузки; прежние настройки восстановлены":"Ошибка загрузки и восстановления настроек",e);
        }
    }
    private static JsonPrimitive primitive(JsonElement value) {
        if(value==null || !value.isJsonPrimitive()) throw new IllegalArgumentException("Ожидалось значение");
        return value.getAsJsonPrimitive();
    }
    private static String text(JsonElement value) {
        if(!primitive(value).isString()) throw new IllegalArgumentException("Ожидалась строка");
        return value.getAsString();
    }
    private static void bool(JsonElement value) {
        if(!primitive(value).isBoolean()) throw new IllegalArgumentException("Ожидался логический флаг");
    }
    private static double number(JsonElement value) {
        if(!primitive(value).isNumber() || !Double.isFinite(value.getAsDouble()) || !Float.isFinite(value.getAsFloat()))
            throw new IllegalArgumentException("Ожидалось конечное число");
        return value.getAsDouble();
    }
    private static long integer(JsonElement value,boolean wide) {
        if(!primitive(value).isNumber()) throw new IllegalArgumentException("Ожидалось целое число");
        try {return wide ? value.getAsBigDecimal().longValueExact() : value.getAsBigDecimal().intValueExact();}
        catch(ArithmeticException e) {throw new IllegalArgumentException("Некорректное целое число",e);}
    }
    private static void unit(JsonElement value) {
        double n=number(value);if(n<0 || n>1) throw new IllegalArgumentException("Цвет вне диапазона");
    }
    /** Validate structure before Pulse's tolerant codec can swallow a restore error. */
    private static void shape(JsonElement actual,JsonElement expected) {
        if(actual==null || actual.isJsonNull()) {
            if(expected!=null && expected.isJsonNull()) return;
            throw new IllegalArgumentException("Отсутствует обязательное значение");
        }
        if(expected.isJsonObject()) {
            if(!actual.isJsonObject()) throw new IllegalArgumentException("Ожидался объект");
            for(var field:expected.getAsJsonObject().entrySet()) shape(actual.getAsJsonObject().get(field.getKey()),field.getValue());
        } else if(expected.isJsonArray()) {
            if(!actual.isJsonArray()) throw new IllegalArgumentException("Ожидался список");
        } else if(expected.isJsonPrimitive()) {
            var sample=expected.getAsJsonPrimitive();
            if(sample.isString()) text(actual);else if(sample.isBoolean()) bool(actual);else number(actual);
        }
    }
    private static void validate(JsonObject state,JsonObject reference) {
        if(integer(state.get("schema"),false)!=4 || !"1.21.11".equals(text(state.get("minecraft")))) throw new IllegalArgumentException("Формат");
        if(state.has("profile")) text(state.get("profile"));
        PowerCurve.Level.parse(text(state.get("powerLevel")));
        for(String key:List.of("pulse","friends","markers","markerOptions","categoriesPosition","notificationSettings","clientColor"))
            shape(state.get(key),reference.get(key));
        JsonObject pulse=state.getAsJsonObject("pulse");integer(pulse.get("version"),false);
        JsonObject modules=pulse.getAsJsonObject("modules");
        for(var entry:modules.entrySet()) {
            JsonObject m=entry.getValue().getAsJsonObject();bool(m.get("enabled"));integer(m.get("bindKey"),false);
            for(var pair:m.getAsJsonObject("settings").entrySet()) {
                JsonObject setting=pair.getValue().getAsJsonObject();String type=text(setting.get("type"));
                switch(type) {
                    case "slider" -> number(setting.get("value"));
                    case "boolean" -> bool(setting.get("value"));
                    case "key" -> integer(setting.get("value"),false);
                    case "mode" -> {
                        integer(setting.get("value"),false);
                        if(setting.has("selected")) for(JsonElement index:setting.getAsJsonArray("selected")) integer(index,false);
                    }
                    case "color" -> {for(String key:List.of("hue","sat","bri")) unit(setting.get(key));}
                    case "token" -> text(setting.get("value"));
                    case "n9ezz-raw" -> {if(!setting.has("value") || setting.get("value").isJsonNull()) throw new IllegalArgumentException("Значение");}
                    case "itemtoggle" -> {bool(setting.get("enabled"));if(setting.has("color")) integer(setting.get("color"),false);}
                    default -> throw new IllegalArgumentException("Тип настройки: "+type);
                }
            }
        }
        JsonObject expectedModules=reference.getAsJsonObject("pulse").getAsJsonObject("modules");
        for(var module:ModuleRegistry.all()) {
            JsonObject settings=modules.getAsJsonObject(module.name()).getAsJsonObject("settings");
            JsonObject expected=expectedModules.getAsJsonObject(module.name()).getAsJsonObject("settings");
            for(Setting<?> setting:module.settings()) {
                if(setting instanceof SettingGroup || !expected.has(setting.name())) continue;
                JsonObject raw=settings.getAsJsonObject(setting.name());
                if(!text(raw.get("type")).equals(text(expected.getAsJsonObject(setting.name()).get("type"))))
                    throw new IllegalArgumentException("Изменён тип настройки: "+setting.name());
                if(setting instanceof SliderSetting slider) {
                    double value=number(raw.get("value"));
                    if(value<slider.min()-0.00001 || value>slider.max()+0.00001) throw new IllegalArgumentException("Настройка вне диапазона: "+setting.name());
                } else if(setting instanceof ModeSetting mode) {
                    long value=integer(raw.get("value"),false);
                    if(value<0 || value>=mode.values().length) throw new IllegalArgumentException("Неизвестный режим");
                    if(raw.has("selected")) for(JsonElement index:raw.getAsJsonArray("selected")) {
                        long selected=integer(index,false);
                        if(selected<0 || selected>=mode.values().length) throw new IllegalArgumentException("Неизвестный режим");
                    }
                }
            }
        }
        for(var entry:pulse.getAsJsonObject("hud").entrySet()) {
            JsonObject h=entry.getValue().getAsJsonObject();
            for(String key:List.of("x","y","scale")) number(h.get(key));
            if(h.get("scale").getAsDouble()<=0) throw new IllegalArgumentException("Масштаб HUD");
        }
        for(JsonElement element:state.getAsJsonArray("friends")) {
            JsonObject friend=element.getAsJsonObject();text(friend.get("c"));
            if(!friend.has("d")) throw new IllegalArgumentException("Данные друга");
            if(!friend.get("d").isJsonNull()) text(friend.get("d"));
        }
        for(JsonElement element:state.getAsJsonArray("markers")) {
            JsonObject m=element.getAsJsonObject();text(m.get("title"));
            Notification.Icon.valueOf(text(m.get("icon")));
            for(String key:List.of("x","y","z","color","priority")) integer(m.get(key),false);
            integer(m.get("createdAt"),true);integer(m.get("expiresAt"),true);bool(m.get("visible"));
            if(!m.has("source")) throw new IllegalArgumentException("Источник маркера");
            if(!m.get("source").isJsonNull()) text(m.get("source"));
        }
        integer(state.getAsJsonObject("markerOptions").get("d"),false);
        for(String key:List.of("d","e","f","g","h","i","j","k","l")) unit(state.getAsJsonObject("clientColor").get(key));
    }
    @SuppressWarnings({"rawtypes","unchecked"}) private static void restore(JsonObject state) {
        for(var module:ModuleRegistry.all()) module.setEnabled(false);
        PowerModes.set(PowerCurve.Level.parse(state.get("powerLevel").getAsString()));
        JsonObject pulse=state.getAsJsonObject("pulse");
        call(LocalConfigManager.get(),"applyJson",new Class<?>[]{String.class},pulse.toString());
        JsonObject modules=pulse.getAsJsonObject("modules");
        for(var module:ModuleRegistry.all()) {
            if(!modules.has(module.name())) continue;
            JsonObject settings=modules.getAsJsonObject(module.name()).getAsJsonObject("settings");
            for(Setting setting:module.settings()) if(settings.has(setting.name())) {
                JsonObject raw=settings.getAsJsonObject(setting.name());
                if("n9ezz-raw".equals(raw.get("type").getAsString()) && setting.value()!=null)
                    setting.setValue(GSON.fromJson(raw.get("value"),setting.value().getClass()));
            }
        }
        ConfigManager manager=ConfigManager.a();
        List<ConfigState.FriendHistoryState> friends=GSON.fromJson(state.get("friends"),new TypeToken<List<ConfigState.FriendHistoryState>>(){}.getType());
        call(manager,"b",new Class<?>[]{List.class},friends);
        NotificationStore.g().forEach(NotificationStore::b);
        for(JsonElement element:state.getAsJsonArray("markers")) {
            JsonObject item=element.getAsJsonObject();
            Notification marker=new Notification(item.get("title").getAsString(),item.get("x").getAsInt(),item.get("y").getAsInt(),item.get("z").getAsInt(),new Color(item.get("color").getAsInt(),true),Notification.Icon.valueOf(item.get("icon").getAsString()));
            marker.setPriority(item.get("priority").getAsInt());marker.setSource(item.get("source").isJsonNull()?null:item.get("source").getAsString());
            marker.setExpiresAt(item.get("expiresAt").getAsLong());marker.setVisible(item.get("visible").getAsBoolean());
            try {Field field=Notification.class.getDeclaredField("createdAt");field.setAccessible(true);field.setLong(marker,item.get("createdAt").getAsLong());}
            catch(ReflectiveOperationException e) {throw new IllegalStateException("Не удалось восстановить маркер",e);}
            NotificationStore.a(marker);
        }
        var options=GSON.fromJson(state.get("markerOptions"),ConfigState.MarkerOptionsState.class);
        call(manager,"a",new Class<?>[]{ConfigState.MarkerOptionsState.class},options);
        MarkerOptions.d(options.e());
        call(manager,"b",new Class<?>[]{String.class},state.get("categoriesPosition").getAsString());
        call(manager,"a",new Class<?>[]{ConfigState.NotificationSettingsState.class},GSON.fromJson(state.get("notificationSettings"),ConfigState.NotificationSettingsState.class));
        call(manager,"a",new Class<?>[]{ConfigState.ClientColorState.class},GSON.fromJson(state.get("clientColor"),ConfigState.ClientColorState.class));
        var hud=HudElementManager.a();JsonObject positions=pulse.getAsJsonObject("hud");
        restoreScale(positions,"potions",hud.i());restoreScale(positions,"hotkeys",hud.j());
        restoreScale(positions,"cooldowns",hud.k());restoreScale(positions,"target",hud.l());
        restoreScale(positions,"saturation",hud.getSaturationHud());hud.d();
        N9Ezz.FRIENDS.open.set(false);
        if(N9Ezz.AURA.isEnabled() && N9Ezz.TRIGGER.isEnabled()) N9Ezz.TRIGGER.setEnabledStateQuiet(false);
        PowerProfiles.selected(state.has("profile")?state.get("profile").getAsString():"Свой");
    }
    private static void restoreScale(JsonObject positions,String name,HudElement element) {
        if(element!=null && positions.has(name)) element.f().a(positions.getAsJsonObject(name).get("scale").getAsFloat());
    }
    private static void captureScale(JsonObject positions,String name,HudElement element) {
        if(element==null || !positions.has(name)) return;
        try {
            Field field=ModuleSettingsPanel.class.getDeclaredField("u");field.setAccessible(true);
            Object widget=field.get(element.f());
            Field value=SliderSettingWidget.class.getDeclaredField("r");value.setAccessible(true);
            SliderSetting setting=(SliderSetting)value.get(widget);
            // The native g() getter returns the animated display scale, not the saved value.
            if(setting!=null) positions.getAsJsonObject(name).addProperty("scale",setting.get());
            else {Field raw=SliderSettingWidget.class.getDeclaredField("n");raw.setAccessible(true);positions.getAsJsonObject(name).addProperty("scale",raw.getFloat(widget));}
        } catch(ReflectiveOperationException e) {throw new IllegalStateException("Не удалось сохранить масштаб HUD",e);}
    }
}
