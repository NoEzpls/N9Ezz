package pulse.n9ezz;

import net.minecraft.entity.effect.StatusEffects;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.BooleanSetting;
import pulse.settings.ModeSetting;

@ModuleInfo(a="Criticals",b="Выбирает момент критического удара для Aura/Triggerbot.",c=ModuleCategory.CHEATS)
public final class Criticals extends CheatModule {
    public final ModeSetting mode=new ModeSetting("Режим критов",new String[]{"Умные","Только критические"},0);
    public final BooleanSetting autoJump=new BooleanSetting("Автопрыжок",false);
    private long lastJump=Long.MIN_VALUE;
    public Criticals() { power.set(100); }
    @Override public void onDisable() { lastJump=Long.MIN_VALUE;super.onDisable(); }
    public boolean ready(long now,boolean resetSprint) {
        var mc=client();var player=mc.player;
        if(!isEnabled() || !powered() || player==null || mc.world==null) return player!=null;
        boolean capable=!player.isClimbing()&&!player.isTouchingWater()&&!player.isInLava()&&!player.hasVehicle()
            &&!player.isGliding()&&!player.getAbilities().flying&&!player.hasStatusEffect(StatusEffects.BLINDNESS);
        boolean falling=player.fallDistance>=.01+Math.max(0,100-effectivePower())*.001&&player.getVelocity().y<0;
        boolean strict=mode.selectedValue().equals("Только критические");
        var decision=CombatRules.critical(capable,player.isOnGround(),falling,player.getAttackCooldownProgress(0),
            player.isSprinting(),resetSprint,strict,autoJump.get());
        if(decision==CombatRules.CriticalDecision.JUMP) {
            if(!mc.world.isSpaceEmpty(player,player.getBoundingBox().offset(0,.42,0))) return !strict;
            if(lastJump==Long.MIN_VALUE||now-lastJump>=actionDelay(500,50)) { player.jump();lastJump=now; }
        }
        return decision==CombatRules.CriticalDecision.ATTACK;
    }
}
