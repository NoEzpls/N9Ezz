package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import pulse.events.ClientTickEvent;
import pulse.module.*;
@ModuleInfo(a="Pearl Throw",b="Однократный бросок эндер-жемчуга из хотбара по бинду; возвращает выбранный слот.",c=ModuleCategory.CHEATS)
public final class PearlThrow extends PvPModule {
    private long enabledAt;
    @Override public void onEnable(){enabledAt=System.nanoTime();super.onEnable();}
    @EventHandler public void tick(ClientTickEvent e) {
        if(!powered()||System.nanoTime()-enabledAt<actionDelay(100,0)||!CombatInventory.available()||client().player.isUsingItem()||ConsumableUse.active())return;
        int slot=CombatInventory.findHotbar(s->s.isOf(Items.ENDER_PEARL));
        if(slot>=0&&CombatInventory.select(this,95,slot)){
            if(!client().player.getItemCooldownManager().isCoolingDown(client().player.getMainHandStack()))client().interactionManager.interactItem(client().player,Hand.MAIN_HAND);
            CombatInventory.release(this,true);
        }
        setEnabled(false);
    }
}
