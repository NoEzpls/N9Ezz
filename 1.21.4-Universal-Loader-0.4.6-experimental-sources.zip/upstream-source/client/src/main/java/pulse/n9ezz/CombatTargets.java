package pulse.n9ezz;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public final class CombatTargets {
    private static PlayerEntity last;
    private static int attackedAt;
    private CombatTargets() {}
    public static void attacked(Entity entity) {
        var p=MinecraftClient.getInstance().player;
        if(p!=null&&entity instanceof PlayerEntity target&&Targeting.combatTarget(target,true,true)){
            last=target;attackedAt=p.age;
            if(N9Ezz.WTAP!=null&&N9Ezz.WTAP.isEnabled())N9Ezz.WTAP.attacked();
        }
    }
    public static PlayerEntity tracked() {
        var m=MinecraftClient.getInstance();if(m.player==null||m.world==null)return null;
        if(N9Ezz.AURA!=null&&N9Ezz.AURA.isEnabled()&&Targeting.combatTarget(N9Ezz.AURA.target(),true,true))return N9Ezz.AURA.target();
        if(N9Ezz.TRIGGER!=null&&N9Ezz.TRIGGER.isEnabled()&&Targeting.combatTarget(N9Ezz.TRIGGER.target(),true,true))return N9Ezz.TRIGGER.target();
        if(last!=null&&m.player.age-attackedAt<30&&m.world.getPlayers().contains(last)&&Targeting.combatTarget(last,true,true))return last;
        return null;
    }
    public static PlayerEntity current(){var t=tracked();var p=MinecraftClient.getInstance().player;return t!=null?t:p==null?null:Targeting.underCrosshair(p.getEntityInteractionRange());}
    public static void clear(){last=null;attackedAt=0;}
}
