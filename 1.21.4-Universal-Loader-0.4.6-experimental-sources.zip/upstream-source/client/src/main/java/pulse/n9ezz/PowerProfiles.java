package pulse.n9ezz;

import java.util.List;
import java.util.Locale;
import pulse.module.ClientModule;

/** Ready-to-use combinations; labels express strength, not anti-cheat guarantees. */
public final class PowerProfiles {
    public record Profile(String name,int power,int cps,int speed,int misses,float horizontal,float vertical,
                          float range,float hp,float bonus,boolean aura,boolean aim,boolean hitboxes,boolean damage) {}
    public static final List<Profile> ALL=List.of(
        new Profile("low",10,2,2,35,1.2f,1f,3,2,.2f,false,false,false,false),
        new Profile("legit",20,3,1,25,1.5f,1.1f,3,3,.2f,false,true,false,false),
        new Profile("legit medium",35,4,1,15,1.8f,1.2f,3,4,.3f,false,true,true,false),
        new Profile("medium",50,5,1,10,2f,1.3f,3,4,.4f,true,false,true,false),
        new Profile("hard medium",65,6,1,6,2.3f,1.4f,3,5,.5f,true,true,true,true),
        new Profile("hight",80,8,0,3,2.8f,1.6f,3.5f,6,.7f,true,true,true,true),
        new Profile("extra hight",90,9,0,1,3.5f,2f,4,8,.9f,true,true,true,true),
        new Profile("ultra",100,10,0,0,5f,5f,10,10,1f,true,true,true,true));
    private static String selected="Свой";
    private PowerProfiles() {}
    public static String selected() { return selected; }
    public static void selected(String value) { selected=value==null || value.isBlank() ? "Свой" : value; }
    public static Profile find(String name) {
        String normalized=name.strip().toLowerCase(Locale.ROOT);
        return ALL.stream().filter(p->p.name().equals(normalized)).findFirst().orElse(null);
    }
    public static void apply(Profile profile) {
        if(profile==null) throw new IllegalArgumentException("Профиль не найден");
        InterfaceMode.reveal();
        ConfigSnapshots.changing(()->{
            for(ClientModule module:N9Ezz.modules()) {
                module.setEnabled(false);
                if(module instanceof CheatModule cheat) cheat.power.set(profile.power());
            }
            N9Ezz.localBonus=0;
            N9Ezz.FRIENDS.open.set(false);
            N9Ezz.AURA.cps.set(profile.cps());N9Ezz.TRIGGER.cps.set(profile.cps());
            N9Ezz.AURA.speed.select(profile.speed());N9Ezz.TRIGGER.speed.select(profile.speed());
            N9Ezz.AIM.smoothing.set(95-profile.power()*.2f);
            N9Ezz.AURA.miss.set(profile.misses());N9Ezz.TRIGGER.miss.set(profile.misses());
            N9Ezz.AURA.range.set(Math.min(6,profile.range()));N9Ezz.TRIGGER.range.set(profile.range());
            N9Ezz.AURA.priority.select(profile.power()>=50?1:3);N9Ezz.AURA.lockTarget.set(true);
            N9Ezz.AURA.rotation.select(0);N9Ezz.AURA.smoothing.set(95-profile.power()*.2f);N9Ezz.AURA.fov.set(profile.power()>=80?180:90);
            N9Ezz.AURA.confirmation.set(Math.max(50,150-profile.power()));N9Ezz.AURA.manualOverride.set(200);N9Ezz.AURA.exactHit.set(!profile.hitboxes());N9Ezz.TRIGGER.exactHit.set(!profile.hitboxes());
            N9Ezz.AIM.fov.set(90);N9Ezz.AIM.manualOverride.set(200);N9Ezz.AIM.onlyAttack.set(false);N9Ezz.AIM.weaponsOnly.set(false);N9Ezz.AIM.point.select(0);
            N9Ezz.AURA.invisible.set(true);N9Ezz.AURA.unarmored.set(true);N9Ezz.AURA.weaponsOnly.set(true);N9Ezz.TRIGGER.invisible.set(true);N9Ezz.TRIGGER.unarmored.set(true);N9Ezz.TRIGGER.weaponsOnly.set(true);
            N9Ezz.AURA.cooldown.set(100);N9Ezz.TRIGGER.cooldown.set(100);N9Ezz.AURA.releaseShield.set(profile.power()>=35);N9Ezz.TRIGGER.releaseShield.set(profile.power()>=35);N9Ezz.AURA.resetSprint.set(true);N9Ezz.TRIGGER.resetSprint.set(true);
            N9Ezz.TRIGGER.confirmation.set(Math.max(0,100-profile.power()));
            N9Ezz.TRIGGER.range.set(profile.range());
            N9Ezz.HITBOXES.x.set(profile.horizontal());N9Ezz.HITBOXES.z.set(profile.horizontal());
            N9Ezz.HITBOXES.y.set(profile.vertical());N9Ezz.HITBOXES.outline.set(true);
            N9Ezz.HITBOXES.range.set(6);N9Ezz.HITBOXES.onlyTarget.set(false);
            N9Ezz.TOTEM.hp.set(profile.hp());N9Ezz.DAMAGE.extra.set(profile.bonus());
            N9Ezz.AIM.setEnabledStateQuiet(profile.aim());N9Ezz.HITBOXES.setEnabledStateQuiet(profile.hitboxes());
            N9Ezz.TOTEM.setEnabledStateQuiet(true);N9Ezz.DAMAGE.setEnabledStateQuiet(profile.damage());
            N9Ezz.FRIENDS.setEnabledStateQuiet(true);
            N9Ezz.CRITICALS.mode.select(0);N9Ezz.CRITICALS.autoJump.set(false);N9Ezz.CRITICALS.setEnabledStateQuiet(profile.power()>=35);
            N9Ezz.SHIELD.restoreWeapon.set(true);N9Ezz.SHIELD.switchDelay.set(50);N9Ezz.SHIELD.setEnabledStateQuiet(profile.power()>=50);
            N9Ezz.AURA.setEnabledStateQuiet(profile.aura());N9Ezz.TRIGGER.setEnabledStateQuiet(!profile.aura());
            selected=profile.name();
        });
    }
}
