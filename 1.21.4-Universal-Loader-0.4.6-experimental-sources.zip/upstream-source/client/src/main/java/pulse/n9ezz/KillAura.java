package pulse.n9ezz;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import pulse.events.ClientTickEvent;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.ModeSetting;
import pulse.settings.SliderSetting;
import pulse.settings.BooleanSetting;

@ModuleInfo(a="Kill Aura",b="Автоудары с приоритетом, удержанием цели, зарядом и поддержкой Criticals/Shield Breaker.",c=ModuleCategory.CHEATS)
public final class KillAura extends CheatModule {
    public final SliderSetting cps=new SliderSetting("Удары/сек","Базовый лимит при силе 1. Уровень и мощность меняют его до 20; заряд оружия сохраняется",5,1,10,1);
    public final ModeSetting speed=new ModeSetting("Скорость",new String[]{"Быстрая","Обычная","Медленная"},1);
    public final SliderSetting miss=new SliderSetting("Миссы / 100",0,0,50,1);
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",3,.5f,6,.1f);
    public final ModeSetting priority=new ModeSetting("Приоритет цели",new String[]{"Расстояние","Меньше HP","Меньше брони","Ближе к прицелу"},0);
    public final BooleanSetting lockTarget=new BooleanSetting("Удерживать цель",true);
    public final BooleanSetting invisible=new BooleanSetting("Невидимые игроки",true);
    public final BooleanSetting unarmored=new BooleanSetting("Игроки без брони",true);
    public final BooleanSetting weaponsOnly=new BooleanSetting("Только с оружием",false);
    public final SliderSetting cooldown=new SliderSetting("Заряд удара (%)",100,50,100,1);
    public final BooleanSetting releaseShield=new BooleanSetting("Отпускать свой щит",false);
    public final BooleanSetting resetSprint=new BooleanSetting("Сбрасывать спринт",true);
    public final ModeSetting rotation=new ModeSetting("Поворот камеры",new String[]{"Плавный","Без поворота"},0);
    public final SliderSetting smoothing=new SliderSetting("Плавность (%)",85,1,100,1);
    public final SliderSetting fov=new SliderSetting("Угол поиска (°)",90,10,360,5);
    public final SliderSetting confirmation=new SliderSetting("Подтверждение цели (мс)",100,0,500,10);
    public final SliderSetting manualOverride=new SliderSetting("Пауза после мыши (мс)",200,0,1000,50);
    public final BooleanSetting exactHit=new BooleanSetting("Обычное попадание",false);
    private final ViewMotion motion=new ViewMotion();
    private long acquiredAt;
    private final AttackClock clock=new AttackClock();
    private final MissSequence misses=new MissSequence();
    private PlayerEntity target;
    @Override public void onEnable() {
        if(N9Ezz.TRIGGER!=null) N9Ezz.TRIGGER.setEnabled(false);
        target=null;motion.reset();clock.reset();misses.reset();Attacks.cancel();super.onEnable();
    }
    @Override public void onDisable() { reset();super.onDisable(); }
    public PlayerEntity target(){return target;}
    public void reset(){target=null;motion.reset();clock.reset();Attacks.cancel();}
    public boolean controlsView(){return isEnabled()&&powered()&&rotation.selectedValue().equals("Плавный")&&target!=null;}
    public void frame(long now,float progress){if(!controlsView()||!Targeting.canAct(releaseShield.get())||!Targeting.combatTarget(target,invisible.get(),unarmored.get())){motion.reset();return;}motion.frame(Targeting.aimPoint(target,progress,0,!exactHit.get()),now,progress,effectivePower(),smoothing.get(),manualOverride.roundedInt());}
    @EventHandler public void tick(ClientTickEvent event) {
        if(!powered()||!Targeting.canAct(releaseShield.get())) { reset();return; }
        boolean expanded=!exactHit.get();
        double attackRange=Targeting.combatRange(range.get());
        var next=Targeting.acquire(target,attackRange,effectivePower(),java.util.Arrays.asList(priority.values()).indexOf(priority.selectedValue()),lockTarget.get(),expanded,p->Targeting.combatTarget(p,invisible.get(),unarmored.get())&&Targeting.yawDelta(p,expanded)<=fov.get()/2);
        if(next!=target){clock.reset();motion.reset();Attacks.cancel();acquiredAt=System.nanoTime();}target=next;
        if(target==null) { clock.reset();return; }
        if(System.nanoTime()-acquiredAt<CombatRules.reactionDelay(effectivePower(),confirmation.get())||Targeting.underCrosshair(attackRange,expanded)!=target)return;
        Attacks.attempt(target,clock,misses,new Attacks.Options(PowerCurve.cps(cps.roundedInt(),strength()),java.util.Arrays.asList(speed.values()).indexOf(speed.selectedValue()),miss.roundedInt(),cooldown.get(),range.get(),weaponsOnly.get(),releaseShield.get(),resetSprint.get(),expanded));
    }
}
