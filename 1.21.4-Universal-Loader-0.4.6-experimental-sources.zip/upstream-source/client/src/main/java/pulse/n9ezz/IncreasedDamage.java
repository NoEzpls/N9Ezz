package pulse.n9ezz;

import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.SliderSetting;

@ModuleInfo(a="Increased Damage",b="Дополнительные 0.2–1 единицы урона только в одиночном мире. На удалённом сервере урон задаёт сервер.",c=ModuleCategory.CHEATS)
public final class IncreasedDamage extends CheatModule {
    public final SliderSetting extra=new SliderSetting("Доп. урон (одиночный мир)",0.2f,0.2f,1,0.1f);
    public IncreasedDamage() { power.set(100); }
}
