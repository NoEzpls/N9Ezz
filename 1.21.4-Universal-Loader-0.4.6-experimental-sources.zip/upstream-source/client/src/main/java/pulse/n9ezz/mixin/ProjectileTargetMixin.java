package pulse.n9ezz.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pulse.n9ezz.Targeting;
import net.minecraft.world.World;
import java.util.List;
import java.util.function.Predicate;

@Mixin(ProjectileUtil.class)
public abstract class ProjectileTargetMixin {
    @Redirect(method="raycast",at=@At(value="INVOKE",target="Lnet/minecraft/world/World;getOtherEntities(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;)Ljava/util/List;"))
    private static List<Entity> n9ezz$candidates(World world,Entity source,Box search,Predicate<? super Entity> predicate) {
        return Targeting.candidates(world,source,search,predicate);
    }
    @Redirect(method="raycast",at=@At(value="INVOKE",target="Lnet/minecraft/entity/Entity;getBoundingBox()Lnet/minecraft/util/math/Box;"))
    private static Box n9ezz$targetBox(Entity entity) {
        // Never enlarge physics/collision boxes or server-side projectile hits.
        return MinecraftClient.getInstance().isOnThread() ? Targeting.box(entity) : entity.getBoundingBox();
    }
}
