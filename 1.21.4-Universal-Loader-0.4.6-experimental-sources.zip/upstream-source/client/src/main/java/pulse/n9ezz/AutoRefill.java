package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.*;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Refill",b="Пополняет запомненные расходники хотбара из инвентаря после опустошения слота.",c=ModuleCategory.CHEATS)
public final class AutoRefill extends PvPModule {
    public final SliderSetting delay=new SliderSetting("Пауза пополнения (мс)",300,100,1500,50);
    private final Item[] remembered=new Item[9];
    private long next;
    @Override public void onEnable(){java.util.Arrays.fill(remembered,null);next=0;super.onEnable();}
    @Override public void onDisable(){java.util.Arrays.fill(remembered,null);super.onDisable();}
    private boolean consumable(ItemStack s){return CombatItems.gapple(s)||s.isOf(Items.ENDER_PEARL)||s.isOf(Items.TOTEM_OF_UNDYING)||s.isOf(Items.COBWEB)||s.isOf(Items.END_CRYSTAL)||s.isOf(Items.POTION)||s.isOf(Items.SPLASH_POTION);}
    @EventHandler public void tick(ClientTickEvent e) {
        if(!powered()||!CombatInventory.available())return;var inv=client().player.getInventory();long now=System.nanoTime();
        for(int h=0;h<9;h++){
            var held=inv.getStack(h);if(!held.isEmpty()){remembered[h]=consumable(held)?held.getItem():null;continue;}
            if(remembered[h]==null||CombatInventory.busy()||client().player.isUsingItem()||now<next)continue;
            Item item=remembered[h];int best=-1,count=0;for(int i=9;i<36;i++){var s=inv.getStack(i);if(s.isOf(item)&&s.getCount()>count){best=i;count=s.getCount();}}
            if(best>=0&&CombatInventory.swap(best,h)){next=now+actionDelay(delay.get(),50);return;}
        }
    }
}
