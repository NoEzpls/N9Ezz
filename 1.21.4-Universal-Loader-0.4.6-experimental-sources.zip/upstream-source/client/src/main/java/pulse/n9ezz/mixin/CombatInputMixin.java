package pulse.n9ezz.mixin;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.*;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.n9ezz.N9Ezz;
import pulse.n9ezz.CombatDispatch;
@Mixin(KeyboardInput.class)
public abstract class CombatInputMixin extends Input {
    @Inject(method="tick",at=@At("TAIL"))
    private void n9ezzInput(CallbackInfo ci) {
        var m=MinecraftClient.getInstance();if(m.player==null||m.player.input!=(Object)this||m.currentScreen!=null||m.isPaused())return;
        var original=movementVector;
        if(N9Ezz.STRAFE!=null&&N9Ezz.STRAFE.isEnabled())movementVector=N9Ezz.STRAFE.input(movementVector);
        if(N9Ezz.WTAP!=null&&N9Ezz.WTAP.isEnabled())movementVector=N9Ezz.WTAP.input(movementVector);
        movementVector=CombatDispatch.input(movementVector);
        if(!movementVector.equals(original))playerInput=new PlayerInput(movementVector.y>.05,movementVector.y<-.05,movementVector.x>.05,movementVector.x<-.05,playerInput.jump(),playerInput.sneak(),playerInput.sprint());
    }
}
