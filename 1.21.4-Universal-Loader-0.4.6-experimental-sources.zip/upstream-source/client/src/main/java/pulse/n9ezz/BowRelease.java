package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.*;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Bow Release",b="Отпускает натянутый лук или трезубец после выбранного заряда при наведении на игрока.",c=ModuleCategory.CHEATS)
public final class BowRelease extends PvPModule {
    public final SliderSetting charge=new SliderSetting("Заряд (%)",100,50,100,5);
    public final SliderSetting range=new SliderSetting("Дальность цели",32,3,64,1);
    private long readySince;
    @Override public void onDisable(){readySince=0;super.onDisable();}
    public final BooleanSetting requireTarget=new BooleanSetting("Только при цели",true);
    @EventHandler public void tick(ClientTickEvent e) {
        var p=client().player;if(!powered()||!CombatInventory.available()||p==null||!p.isUsingItem()||ConsumableUse.active()){readySince=0;return;}
        var s=p.getActiveItem();if(!s.isOf(Items.BOW)&&!s.isOf(Items.TRIDENT)){readySince=0;return;}
        if(s.isOf(Items.TRIDENT)?p.getItemUseTime()<10:p.getItemUseTime()<20*charge.get()/100){readySince=0;return;}
        if(requireTarget.get()&&Targeting.underCrosshair(range.get(),false)==null)return;
        long now=System.nanoTime();if(readySince==0)readySince=now;
        if(now-readySince<actionDelay(100,0))return;
        client().interactionManager.stopUsingItem(p);readySince=0;
    }
}
