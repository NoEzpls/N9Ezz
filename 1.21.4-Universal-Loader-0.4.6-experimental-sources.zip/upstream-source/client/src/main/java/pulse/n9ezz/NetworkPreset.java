package pulse.n9ezz;

/** A reproducible conservative setup; never selects or claims a server-specific bypass. */
public final class NetworkPreset {
    private NetworkPreset() {}
    public static void apply() {
        boolean trigger=N9Ezz.TRIGGER.isEnabled()&&!N9Ezz.AURA.isEnabled();
        InterfaceMode.reveal();
        ConfigSnapshots.changing(()->{
            N9Ezz.disableAll();PowerModes.set(PowerCurve.Level.LEGIT);
            N9Ezz.AURA.power.set(40);N9Ezz.AURA.range.set(2.8f);N9Ezz.AURA.cps.set(3);
            N9Ezz.AURA.speed.select(1);N9Ezz.AURA.cooldown.set(100);N9Ezz.AURA.miss.set(0);
            N9Ezz.AURA.priority.select(3);N9Ezz.AURA.lockTarget.set(true);N9Ezz.AURA.weaponsOnly.set(true);
            N9Ezz.AURA.rotation.select(0);N9Ezz.AURA.smoothing.set(94);N9Ezz.AURA.fov.set(60);
            N9Ezz.AURA.confirmation.set(150);N9Ezz.AURA.manualOverride.set(300);
            N9Ezz.AURA.exactHit.set(true);N9Ezz.AURA.resetSprint.set(false);N9Ezz.AURA.releaseShield.set(false);
            N9Ezz.TRIGGER.power.set(40);N9Ezz.TRIGGER.range.set(2.8f);N9Ezz.TRIGGER.cps.set(3);
            N9Ezz.TRIGGER.speed.select(1);N9Ezz.TRIGGER.cooldown.set(100);N9Ezz.TRIGGER.miss.set(0);
            N9Ezz.TRIGGER.confirmation.set(150);N9Ezz.TRIGGER.weaponsOnly.set(true);
            N9Ezz.TRIGGER.exactHit.set(true);N9Ezz.TRIGGER.resetSprint.set(false);N9Ezz.TRIGGER.releaseShield.set(false);
            N9Ezz.AIM.power.set(40);N9Ezz.AIM.range.set(2.8f);N9Ezz.AIM.fov.set(60);
            N9Ezz.AIM.smoothing.set(94);N9Ezz.AIM.manualOverride.set(300);N9Ezz.AIM.weaponsOnly.set(true);
            N9Ezz.TOTEM.hp.set(4);N9Ezz.TOTEM.hand.select(1);N9Ezz.TOTEM.power.set(60);
            N9Ezz.TOTEM.setEnabledStateQuiet(true);N9Ezz.FRIENDS.setEnabledStateQuiet(true);
            N9Ezz.AURA.setEnabledStateQuiet(!trigger);N9Ezz.TRIGGER.setEnabledStateQuiet(trigger);N9Ezz.AIM.setEnabledStateQuiet(trigger);
            PowerProfiles.selected("Сетевая");
        });
    }
    public static String conflicts() {
        var names=new java.util.ArrayList<String>();
        for(var module:new pulse.module.ClientModule[]{N9Ezz.HITBOXES,N9Ezz.REACH,N9Ezz.VELOCITY,N9Ezz.NOSLOW,N9Ezz.ANTIWEB,N9Ezz.NOPUSH,N9Ezz.STRAFE})
            if(module.isEnabled())names.add(module.name());
        return names.isEmpty()?"Расширение попаданий и изменение физики выключены.":"Активны изменения попаданий/физики: "+String.join(", ",names);
    }
}
