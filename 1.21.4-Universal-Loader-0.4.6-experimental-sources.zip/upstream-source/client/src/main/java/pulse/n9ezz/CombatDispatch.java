package pulse.n9ezz;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec2f;
import net.minecraft.world.World;

/** Delivers automatic attacks after this tick's normal movement and rotation packets. */
public final class CombatDispatch {
    private static long tick;
    private static PlayerEntity player;
    private static World world;
    private static boolean consumed, movementSent;
    private CombatDispatch() {}
    public static void install() { ClientTickEvents.START_CLIENT_TICK.register(CombatDispatch::begin); }
    public static void begin(MinecraftClient mc) {
        tick++; player=mc.player; world=mc.world; consumed=false; movementSent=false;
        Attacks.clearPending();
    }
    public static long tick() { return tick; }
    public static boolean available() {
        var mc=MinecraftClient.getInstance();
        return player!=null && player==mc.player && world==mc.world && !consumed;
    }
    public static boolean claim() {
        if(!movementSent || !available()) return false;
        consumed=true; return true;
    }
    /** Observe manual attacks too, without cancelling or delaying the user's input. */
    public static void attacked(PlayerEntity source) { if(source==player) consumed=true; }
    public static void afterMovement() {
        var mc=MinecraftClient.getInstance();
        if(player!=mc.player || world!=mc.world || mc.player==null || mc.getCameraEntity()!=mc.player || mc.player.hasVehicle()) { Attacks.clearPending(); return; }
        movementSent=true;
        Attacks.flush();
        if(N9Ezz.CRYSTAL!=null) N9Ezz.CRYSTAL.flush();
        movementSent=false;
    }
    public static Vec2f input(Vec2f original) {
        return available() && Attacks.waitingSprintReset()
            ? new Vec2f(original.x,Math.min(0,original.y)) : original;
    }
}
