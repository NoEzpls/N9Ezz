package pulse.n9ezz.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.n9ezz.CombatDispatch;

@Mixin(ClientPlayerEntity.class)
public abstract class CombatTickMixin {
    @Inject(method="sendMovementPackets",at=@At("TAIL"))
    private void n9ezzAfterMovement(CallbackInfo ci) { CombatDispatch.afterMovement(); }
}
