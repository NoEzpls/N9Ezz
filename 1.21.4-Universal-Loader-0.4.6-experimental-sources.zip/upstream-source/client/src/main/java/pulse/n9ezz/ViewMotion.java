package pulse.n9ezz;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/** Frame-time easing, mouse-step quantization and temporary manual override. */
public final class ViewMotion {
    private final AimSmoothing motion=new AimSmoothing();
    private long lastFrame,manualUntil;
    private double remainderYaw,remainderPitch;
    private float expectedYaw,expectedPitch;
    private boolean observed;
    public void reset(){motion.reset();lastFrame=manualUntil=0;remainderYaw=remainderPitch=0;observed=false;}
    public void frame(Vec3d point,long now,float tickProgress,double power,double smoothing,int manualMs) {
        var m=MinecraftClient.getInstance();if(m.player==null)return;
        float yaw=m.player.getYaw(),pitch=m.player.getPitch();
        if(observed&&(Math.abs(CombatMath.wrapDegrees(yaw-expectedYaw))>.0001||Math.abs(pitch-expectedPitch)>.0001)) {
            manualUntil=now+Math.max(0,manualMs)*1_000_000L;motion.reset();remainderYaw=remainderPitch=0;
        }
        // Observe every frame, including paused ones, so continued manual motion extends the pause.
        expectedYaw=yaw;expectedPitch=pitch;observed=true;
        if(lastFrame==0||now<=lastFrame||now-lastFrame>250_000_000L){lastFrame=now;motion.reset();return;}
        double seconds=(now-lastFrame)/1e9;lastFrame=now;
        if(now<manualUntil)return;
        var d=point.subtract(m.player.getCameraPosVec(tickProgress));
        double wantedYaw=Math.toDegrees(Math.atan2(d.z,d.x))-90;
        double wantedPitch=-Math.toDegrees(Math.atan2(d.y,Math.hypot(d.x,d.z)));
        double yawError=CombatMath.wrapDegrees(wantedYaw-yaw),pitchError=wantedPitch-pitch;
        var t=motion.advance(yawError,pitchError,seconds,power,smoothing);
        double sensitivity=m.options.getMouseSensitivity().getValue();double step=Math.pow(sensitivity*.6+.2,3)*8*.15;
        remainderYaw=t.yaw()==0?0:remainderYaw+t.yaw();remainderPitch=t.pitch()==0?0:remainderPitch+t.pitch();
        double dy=PvPMath.mouseStep(remainderYaw,step,yawError),dp=PvPMath.mouseStep(remainderPitch,step,pitchError);
        remainderYaw-=dy;remainderPitch-=dp;
        expectedYaw=yaw+(float)dy;expectedPitch=(float)CombatMath.clamp(pitch+dp,-90,90);
        m.player.setYaw(expectedYaw);m.player.setPitch(expectedPitch);
    }
}
