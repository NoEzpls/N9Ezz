package pulse.n9ezz;

import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.BooleanSetting;

@ModuleInfo(a="Friends",b="Добавляй ники во вкладке Friends. Все боевые модули всегда исключают друзей.",c=ModuleCategory.CHEATS)
public final class Friends extends ClientModule {
    public final BooleanSetting open=new BooleanSetting("Открыть список друзей",false);
}
