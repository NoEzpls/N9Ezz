package pulse.n9ezz.mixin;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.n9ezz.N9Ezz;
@Mixin(PlayerEntity.class)
public abstract class ReachMixin {
    @Inject(method="getEntityInteractionRange",at=@At("RETURN"),cancellable=true)
    private void n9ezzReach(CallbackInfoReturnable<Double> ci){if(MinecraftClient.getInstance().player==(Object)this&&N9Ezz.REACH!=null&&N9Ezz.REACH.isEnabled())ci.setReturnValue(N9Ezz.REACH.range(ci.getReturnValue()));}
}
