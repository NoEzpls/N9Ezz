package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Gapple",b="При низком HP ест золотое яблоко из хотбара обычным использованием предмета.",c=ModuleCategory.CHEATS)
public final class AutoGapple extends PvPModule {
    public final SliderSetting hp=new SliderSetting("Порог HP",10,1,20,.5f);
    public final BooleanSetting absorption=new BooleanSetting("Учитывать поглощение",true);
    private int retryAt;
    @Override protected String[] conflicts(){return new String[]{"AutoEat"};}
    @Override public void onDisable(){retryAt=0;super.onDisable();}
    @EventHandler public void tick(ClientTickEvent e) {
        var p=client().player;if(!powered()||p==null||p.age<retryAt||p.getHealth()+(absorption.get()?p.getAbsorptionAmount():0)>hp.get())return;
        ConsumableUse.request(this,CombatItems::gapple);if(CombatInventory.owns(this))retryAt=p.age+PowerCurve.ticks(45,strength(),32);
    }
}
