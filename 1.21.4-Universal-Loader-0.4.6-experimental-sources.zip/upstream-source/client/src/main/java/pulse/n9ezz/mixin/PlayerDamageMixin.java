package pulse.n9ezz.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.n9ezz.N9Ezz;

@Mixin(PlayerEntity.class)
public abstract class PlayerDamageMixin {
    private static final Identifier N9EZZ_DAMAGE=Identifier.of("n9ezz","damage");
    @Inject(method="attack",at=@At("HEAD"))
    private void n9ezz$beforeAttack(Entity target,CallbackInfo ci) {
        PlayerEntity self=(PlayerEntity)(Object)this;
        if(self.getEntityWorld().isClient() || N9Ezz.localPlayerId==null || !self.getUuid().equals(N9Ezz.localPlayerId) || N9Ezz.localBonus<=0 || N9Ezz.friendPlayerIds.contains(target.getUuid())) return;
        EntityAttributeInstance attribute=self.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);
        if(attribute!=null) {
            attribute.removeModifier(N9EZZ_DAMAGE);
            attribute.addTemporaryModifier(new EntityAttributeModifier(N9EZZ_DAMAGE,N9Ezz.localBonus,EntityAttributeModifier.Operation.ADD_VALUE));
        }
    }
    @Inject(method="attack",at=@At("RETURN"))
    private void n9ezz$afterAttack(Entity target,CallbackInfo ci) {
        PlayerEntity self=(PlayerEntity)(Object)this;
        if(self.getEntityWorld().isClient()) return;
        EntityAttributeInstance attribute=self.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);
        if(attribute!=null) attribute.removeModifier(N9EZZ_DAMAGE);
    }
}
