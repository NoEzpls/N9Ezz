package pulse.n9ezz;

import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

/** Holds normal item use until completion; never changes the user's use key. */
public final class ConsumableUse {
    private static CheatModule owner;
    private static Item item;
    private static int startedAt,count;
    private static boolean observedUse;
    private ConsumableUse() {}
    private static MinecraftClient mc(){return MinecraftClient.getInstance();}
    public static boolean active(){return owner!=null;}
    public static void request(CheatModule caller,Predicate<ItemStack> predicate) {
        if(owner!=null||!CombatInventory.available()||mc().player.isUsingItem()||mc().options.useKey.isPressed()
            ||N9Ezz.TOTEM!=null&&N9Ezz.TOTEM.reservingMainHand())return;
        int slot=CombatInventory.findHotbar(predicate);if(slot<0)return;
        if(!CombatInventory.select(caller,90,slot))return;
        var stack=mc().player.getMainHandStack();
        if(mc().player.getItemCooldownManager().isCoolingDown(stack)){CombatInventory.release(caller,true);return;}
        owner=caller;item=stack.getItem();count=stack.getCount();startedAt=mc().player.age;observedUse=false;
        Attacks.cancel();mc().interactionManager.interactItem(mc().player,Hand.MAIN_HAND);
    }
    public static void tick() {
        if(owner==null)return;
        var m=mc();
        if(!owner.isEnabled()||!CombatInventory.available()||!CombatInventory.owns(owner)
            ||N9Ezz.TOTEM!=null&&N9Ezz.TOTEM.reservingMainHand()){cancel();return;}
        var stack=m.player.getMainHandStack();
        boolean using=m.player.isUsingItem()&&m.player.getActiveItem().isOf(item);
        observedUse|=using;
        if(!stack.isOf(item)||stack.getCount()<count||observedUse&&!using||m.player.age-startedAt>80){cancel();return;}
        if(!CombatInventory.select(owner,90,m.player.getInventory().getSelectedSlot())){cancel();return;}
        if(!using&&m.player.age-startedAt>2)cancel();
    }
    public static void cancel(CheatModule caller){if(owner==caller)cancel();}
    public static void cancel() {
        if(owner==null)return;
        var old=owner;owner=null;var m=mc();
        if(m.player!=null&&m.interactionManager!=null&&m.player.isUsingItem()&&m.player.getActiveItem().isOf(item))m.interactionManager.stopUsingItem(m.player);
        CombatInventory.release(old,true);item=null;observedUse=false;
    }
}
