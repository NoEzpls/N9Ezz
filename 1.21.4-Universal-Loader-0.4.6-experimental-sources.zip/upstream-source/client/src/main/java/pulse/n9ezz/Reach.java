package pulse.n9ezz;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Reach",b="Настраивает клиентскую дальность выбора сущности. Не меняет серверный предел удара.",c=ModuleCategory.CHEATS)
public final class Reach extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",3.1f,3,6,.1f);
    public double range(double vanilla){return PowerCurve.blend(vanilla,Math.max(vanilla,range.get()),strength(),vanilla,12);}
}
