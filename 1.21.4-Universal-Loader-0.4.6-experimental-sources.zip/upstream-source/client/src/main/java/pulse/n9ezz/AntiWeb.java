package pulse.n9ezz;
import net.minecraft.util.math.Vec3d;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Anti Web",b="Уменьшает клиентское замедление только в паутине; не меняет другие блоки.",c=ModuleCategory.CHEATS)
public final class AntiWeb extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting speed=new SliderSetting("Движение (%)",80,5,100,5);
    public Vec3d multiplier(Vec3d vanilla){double selected=speed.get()/100;return new Vec3d(PowerCurve.blend(vanilla.x,Math.max(vanilla.x,selected),strength(),vanilla.x,1),PowerCurve.blend(vanilla.y,Math.max(vanilla.y,selected),strength(),vanilla.y,1),PowerCurve.blend(vanilla.z,Math.max(vanilla.z,selected),strength(),vanilla.z,1));}
}
