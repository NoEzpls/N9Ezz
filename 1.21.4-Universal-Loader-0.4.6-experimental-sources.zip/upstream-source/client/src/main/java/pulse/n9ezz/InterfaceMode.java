package pulse.n9ezz;

import java.util.Arrays;
import java.util.List;
import java.util.Queue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import pulse.gui.core.ClickGuiTabType;
import pulse.gui.core.PulseClickGuiScreen;
import pulse.gui.modules.ModulesTab;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.hud.notifications.HudNotification;
import pulse.hud.notifications.ToggleTextNotification;

/** A reversible UI mode. It does not unload or conceal the Fabric mod itself. */
public final class InterfaceMode {
    private static boolean hidden;
    private static boolean chordWasDown;
    private InterfaceMode() {}
    public static boolean hidden() { return hidden; }
    public static void poll(MinecraftClient mc) {
        var window=mc.getWindow();
        boolean down=(InputUtil.isKeyPressed(window,GLFW.GLFW_KEY_RIGHT_CONTROL)
            || InputUtil.isKeyPressed(window,GLFW.GLFW_KEY_LEFT_CONTROL))
            && InputUtil.isKeyPressed(window,GLFW.GLFW_KEY_DELETE);
        keyState(down);
    }
    public static void keyState(boolean down) {
        if(down && !chordWasDown) toggle();
        chordWasDown=down;
    }
    public static void toggle() { if(hidden) reveal();else hide(); }
    public static void hide() {
        hidden=true;
        N9Ezz.disableAll();
        var mc=MinecraftClient.getInstance();
        if(ru.pulse.Pulse.getInstance().getClickGui() instanceof PulseClickGuiScreen gui) {
            gui.a(ClickGuiTabType.MODULES);
            if(gui.a() instanceof ModulesTab tab) {tab.k();tab.a(ModuleCategory.VISUALS);}
        }
        Stars.menuClosed();
        if(mc.currentScreen instanceof PulseClickGuiScreen) mc.setScreen(null);
    }
    public static void reveal() {
        N9Ezz.disableAll();
        hidden=false;
    }
    public static boolean allowActivation(boolean enabled,ClientModule module) {
        return enabled && !(hidden && module.category()==ModuleCategory.CHEATS);
    }
    public static String[] visibleNames(String[] names) {
        return hidden ? Arrays.copyOf(names,3) : names;
    }
    public static List<?> visibleEntries(List<?> entries) {
        if(!hidden) return entries;
        return entries.stream().filter(e->!(e instanceof ModulesTab.ModuleEntry m) || m.i()!=ModuleCategory.CHEATS).toList();
    }
    private static boolean ownNotice(HudNotification notice) {
        if(!(notice instanceof ToggleTextNotification toggle)) return false;
        for(ClientModule module:N9Ezz.modules()) if(module.name().equals(toggle.m())) return true;
        return false;
    }
    public static HudNotification visibleNotices(Queue<HudNotification> queue,HudNotification current) {
        if(!hidden) return current;
        queue.removeIf(InterfaceMode::ownNotice);
        return ownNotice(current) ? null : current;
    }
}
