package pulse.n9ezz;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;

/** Constant-string obfuscation; the decoder stays in the JAR, so this is not secrecy. */
public final class StringCodec {
    private static final ConcurrentHashMap<String,String> cache=new ConcurrentHashMap<>();
    private StringCodec() {}
    public static String decode(String value) {
        if(value==null || value.isEmpty() || value.charAt(0)!=1) return value;
        return cache.computeIfAbsent(value,StringCodec::unpack);
    }
    private static String unpack(String value) {
        byte[] data=Base64.getDecoder().decode(value.substring(1));
        for(int i=0;i<data.length;i++) data[i]^=(byte)(0x59+i*31+(i>>>2)*17);
        return new String(data,StandardCharsets.UTF_8).intern();
    }
}
