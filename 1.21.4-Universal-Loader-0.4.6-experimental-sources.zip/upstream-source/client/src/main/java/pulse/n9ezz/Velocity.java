package pulse.n9ezz;
import net.minecraft.util.math.Vec3d;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Velocity",b="Масштабирует полученную клиентом отдачу от ударов. Сервер может исправлять движение.",c=ModuleCategory.CHEATS)
public final class Velocity extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting horizontal=new SliderSetting("Горизонталь (%)",70,0,100,5);
    public final SliderSetting vertical=new SliderSetting("Вертикаль (%)",100,0,100,5);
    public Vec3d scale(Vec3d before,Vec3d after) {
        double h=PowerCurve.blend(1,horizontal.get()/100,strength(),0,1),v=PowerCurve.blend(1,vertical.get()/100,strength(),0,1);
        return new Vec3d(before.x+(after.x-before.x)*h,before.y+(after.y-before.y)*v,before.z+(after.z-before.z)*h);
    }
}
