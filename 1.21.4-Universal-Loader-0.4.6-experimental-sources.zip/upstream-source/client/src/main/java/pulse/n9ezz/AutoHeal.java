package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Heal",b="Пьёт зелье лечения или регенерации из хотбара при низком HP; не бросает зелья вслепую.",c=ModuleCategory.CHEATS)
public final class AutoHeal extends PvPModule {
    public final SliderSetting hp=new SliderSetting("Порог HP",8,1,20,.5f);
    public final SliderSetting delay=new SliderSetting("Пауза между зельями (мс)",1500,500,5000,100);
    private long attempted;
    @Override protected String[] conflicts(){return new String[]{"AutoPotion","HealingHelper"};}
    @Override public void onDisable(){attempted=0;super.onDisable();}
    @EventHandler public void tick(ClientTickEvent e) {
        var p=client().player;long now=System.nanoTime();if(!powered()||p==null||p.getHealth()>hp.get()||now-attempted<actionDelay(delay.get(),50))return;
        ConsumableUse.request(this,CombatItems::healingPotion);if(CombatInventory.owns(this))attempted=now;
    }
}
