package pulse.n9ezz;

import java.util.Random;

/** Exactly N misses in a shuffled block of 100 eligible attempts. */
public final class MissSequence {
    private final Random random;
    private final boolean[] sequence = new boolean[100];
    private int index = 100;
    private int count = -1;
    public MissSequence() { this(new Random()); }
    public MissSequence(Random random) { this.random = random; }
    public void reset() { index=100; count=-1; }
    public boolean next(int requested) {
        requested = Math.max(0, Math.min(50, requested));
        if (count != requested || index == 100) {
            count = requested;
            for(int i=0;i<100;i++) sequence[i] = i < count;
            for(int i=99;i>0;i--) {
                int j=random.nextInt(i+1);
                boolean b=sequence[i]; sequence[i]=sequence[j]; sequence[j]=b;
            }
            index=0;
        }
        return sequence[index++];
    }
}
