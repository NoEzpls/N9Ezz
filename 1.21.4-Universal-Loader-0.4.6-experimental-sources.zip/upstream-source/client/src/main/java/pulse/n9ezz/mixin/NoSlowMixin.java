package pulse.n9ezz.mixin;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pulse.n9ezz.N9Ezz;
@Mixin(ClientPlayerEntity.class)
public abstract class NoSlowMixin {
    @Inject(method="getActiveItemSpeedMultiplier",at=@At("RETURN"),cancellable=true)
    private void n9ezzNoSlow(CallbackInfoReturnable<Float> ci){if(N9Ezz.NOSLOW!=null&&N9Ezz.NOSLOW.isEnabled())ci.setReturnValue(N9Ezz.NOSLOW.multiplier(ci.getReturnValue()));}
}
