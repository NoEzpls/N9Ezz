package pulse.n9ezz;

import java.util.Set;
import java.util.HashSet;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import pulse.events.ClientTickEvent;
import pulse.events.EventBusService;
import pulse.gui.core.ClickGuiTabType;
import pulse.gui.core.PulseClickGuiScreen;
import pulse.module.ClientModule;
import ru.pulse.Pulse;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public final class N9Ezz {
    public static KillAura AURA;
    public static Triggerbot TRIGGER;
    public static AimBot AIM;
    public static Hitboxes HITBOXES;
    public static AutoTotem TOTEM;
    public static IncreasedDamage DAMAGE;
    public static Friends FRIENDS;
    public static Criticals CRITICALS;
    public static ShieldBreaker SHIELD;
    public static AutoWeapon WEAPON;
    public static AutoShield AUTOSHIELD;
    public static AutoGapple GAPPLE;
    public static AutoHeal HEAL;
    public static AutoArmor ARMOR;
    public static AutoRefill REFILL;
    public static AutoMace MACE;
    public static BowRelease BOW;
    public static ProjectileAim PROJECTILE;
    public static PearlThrow PEARL;
    public static WTap WTAP;
    public static TargetStrafe STRAFE;
    public static Velocity VELOCITY;
    public static NoPush NOPUSH;
    public static NoSlow NOSLOW;
    public static AntiWeb ANTIWEB;
    public static AntiBot ANTIBOT;
    public static TeamCheck TEAMS;
    public static Reach REACH;
    public static CrystalAura CRYSTAL;
    public static WebTrap WEB;
    public static volatile UUID localPlayerId;
    public static volatile double localBonus;
    public static volatile Set<UUID> friendPlayerIds=Set.of();
    private static boolean initialized;
    private N9Ezz() {}
    public static synchronized ClientModule[] modules() {
        if(!initialized) {
            PowerModes.initialize();
            AURA=new KillAura();TRIGGER=new Triggerbot();AIM=new AimBot();HITBOXES=new Hitboxes();
            TOTEM=new AutoTotem();DAMAGE=new IncreasedDamage();FRIENDS=new Friends();CRITICALS=new Criticals();SHIELD=new ShieldBreaker();
            WEAPON=new AutoWeapon();AUTOSHIELD=new AutoShield();GAPPLE=new AutoGapple();HEAL=new AutoHeal();ARMOR=new AutoArmor();REFILL=new AutoRefill();MACE=new AutoMace();
            BOW=new BowRelease();PROJECTILE=new ProjectileAim();PEARL=new PearlThrow();WTAP=new WTap();STRAFE=new TargetStrafe();VELOCITY=new Velocity();NOPUSH=new NoPush();
            NOSLOW=new NoSlow();ANTIWEB=new AntiWeb();ANTIBOT=new AntiBot();TEAMS=new TeamCheck();REACH=new Reach();CRYSTAL=new CrystalAura();WEB=new WebTrap();
            for(ClientModule module:new ClientModule[]{AURA,TRIGGER,AIM,HITBOXES,WEAPON,AUTOSHIELD,GAPPLE,HEAL,ARMOR,REFILL,MACE,BOW,PROJECTILE,PEARL,WTAP,STRAFE,VELOCITY,NOPUSH,NOSLOW,ANTIWEB,ANTIBOT,TEAMS,REACH,CRYSTAL,WEB})LegacyConfigs.remember(module);
            EventBusService.EVENT_BUS.subscribe(new N9Ezz());
            CombatDispatch.install();
            ClientTickEvents.END_CLIENT_TICK.register(InterfaceMode::poll);
            HitboxVisuals.install();
            ConfigCommands.install();
            initialized=true;
        }
        return new ClientModule[]{AURA,DAMAGE,TRIGGER,HITBOXES,TOTEM,AIM,CRITICALS,SHIELD,FRIENDS,WEAPON,AUTOSHIELD,GAPPLE,HEAL,ARMOR,REFILL,MACE,BOW,PROJECTILE,PEARL,WTAP,STRAFE,VELOCITY,NOPUSH,NOSLOW,ANTIWEB,ANTIBOT,TEAMS,REACH,CRYSTAL,WEB};
    }
    /** Disable the whole added category through Pulse's normal persistence path. */
    public static int disableAll() {
        ClientModule[] added=modules();
        ConsumableUse.cancel();if(SHIELD!=null)SHIELD.cancel();CombatInventory.cancel();CombatTargets.clear();
        localBonus=0;
        FRIENDS.open.set(false);
        int count=0;
        for(ClientModule module:added) if(module.isEnabled()) {
            module.setEnabled(false);
            count++;
        }
        return count;
    }
    @EventHandler(priority=EventPriority.HIGHEST) public void tick(ClientTickEvent event) {
        var mc=net.minecraft.client.MinecraftClient.getInstance();
        if(!(mc.currentScreen instanceof PulseClickGuiScreen)) Stars.menuClosed();
        localPlayerId=mc.player==null ? null : mc.player.getUuid();
        localBonus=mc.player!=null && mc.getServer()!=null && DAMAGE!=null && DAMAGE.isEnabled() ? DAMAGE.extra.get()*DAMAGE.strength() : 0;
        Set<UUID> friends=new HashSet<>();
        if(mc.world!=null) for(var player:mc.world.getPlayers()) if(Targeting.friend(player)) friends.add(player.getUuid());
        friendPlayerIds=Set.copyOf(friends);
        CombatInventory.tick();ConsumableUse.tick();
        FriendSupport.poll();
        if(SHIELD!=null)SHIELD.guard();
        if(FRIENDS!=null && FRIENDS.open.get()) {
            FRIENDS.open.set(false);
            if(Pulse.getInstance().getClickGui() instanceof PulseClickGuiScreen gui) {
                gui.a(ClickGuiTabType.FRIENDS);mc.setScreen(gui);
            }
        }
        // Configuration restoration must preserve the mutual exclusion as well.
        if(AURA!=null && TRIGGER!=null && AURA.isEnabled() && TRIGGER.isEnabled()) TRIGGER.setEnabled(false);
    }
}
