package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Crystal Aura",b="Разбивает существующие кристаллы возле противника с ограничением оценки урона себе. Автоустановки нет.",c=ModuleCategory.CHEATS)
public final class CrystalAura extends PvPModule {
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",4,1,6,.1f);
    public final SliderSetting enemyRange=new SliderSetting("Радиус от цели",5,1,8,.5f);
    public final SliderSetting ownDamage=new SliderSetting("Макс. оценка урона себе",8,0,20,.5f);
    public final SliderSetting hpFloor=new SliderSetting("Остаток HP минимум",8,1,20,.5f);
    public final SliderSetting delay=new SliderSetting("Пауза атак (мс)",300,150,1500,50);
    private long next;
    private EndCrystalEntity pending;
    private long queuedTick;
    /** Conservative open-air estimate, intentionally omits protection and obstruction reductions. */
    public double selfDamage(Vec3d crystal) {
        var p=client().player;double impact=Math.max(0,1-p.getEntityPos().distanceTo(crystal)/12);
        double raw=Math.floor((impact*impact+impact)/2*84+1);
        if(client().world.getDifficulty()==net.minecraft.world.Difficulty.HARD)raw*=1.5;
        return PvPMath.armorDamage(raw,p.getArmor(),p.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS));
    }
    @EventHandler public void tick(ClientTickEvent e) {
        pending=null;
        long now=System.nanoTime();var t=CombatTargets.current();if(!powered()||!Targeting.canAct()||t==null||now<next||client().world.getDifficulty()==net.minecraft.world.Difficulty.PEACEFUL)return;
        EndCrystalEntity best=null;double score=Double.MAX_VALUE;
        for(var entity:client().world.getOtherEntities(client().player,client().player.getBoundingBox().expand(range.get()),x->x instanceof EndCrystalEntity)){
            var crystal=(EndCrystalEntity)entity;double distance=client().player.getEyePos().distanceTo(Targeting.nearestPoint(crystal.getBoundingBox(),client().player.getEyePos()));
            if(distance>Targeting.combatRange(range.get())||crystal.getEntityPos().distanceTo(t.getEntityPos())>enemyRange.get()||!Targeting.visible(crystal.getBoundingBox().getCenter()))continue;
            double damage=selfDamage(crystal.getEntityPos());if(damage>ownDamage.get()||client().player.getHealth()+client().player.getAbsorptionAmount()-damage<hpFloor.get())continue;
            if(client().world.getPlayers().stream().anyMatch(p->Targeting.friend(p)&&p.getEntityPos().distanceTo(crystal.getEntityPos())<8))continue;
            if(distance<score){score=distance;best=crystal;}
        }
        if(best!=null){pending=best;queuedTick=CombatDispatch.tick();}
    }
    public void flush() {
        var crystal=pending;pending=null;
        if(crystal==null||!isEnabled()||!powered()||queuedTick!=CombatDispatch.tick()||!Targeting.canAct()||crystal.isRemoved()
            ||client().world.getEntityById(crystal.getId())!=crystal||System.nanoTime()<next
            ||Targeting.underCrosshairEntity(Targeting.combatRange(range.get()),false)!=crystal)return;
        var target=CombatTargets.current();if(target==null||crystal.getEntityPos().distanceTo(target.getEntityPos())>enemyRange.get())return;
        double damage=selfDamage(crystal.getEntityPos());
        if(damage>ownDamage.get()||client().player.getHealth()+client().player.getAbsorptionAmount()-damage<hpFloor.get()
            ||client().world.getPlayers().stream().anyMatch(p->Targeting.friend(p)&&p.getEntityPos().distanceTo(crystal.getEntityPos())<8)
            ||!CombatDispatch.claim())return;
        client().interactionManager.attackEntity(client().player,crystal);client().player.swingHand(Hand.MAIN_HAND);next=System.nanoTime()+actionDelay(delay.get(),50);
    }
}
