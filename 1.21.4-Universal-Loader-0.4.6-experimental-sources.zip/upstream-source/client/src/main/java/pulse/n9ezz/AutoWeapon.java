package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Weapon",b="Выбирает меч или топор в хотбаре при наведении на противника; возвращает слот после боя.",c=ModuleCategory.CHEATS)
public final class AutoWeapon extends PvPModule {
    public final ModeSetting weapon=new ModeSetting("Оружие",new String[]{"Меч","Топор"},0);
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",3,.5f,6,.1f);
    public final BooleanSetting restore=new BooleanSetting("Вернуть слот",true);
    @EventHandler public void tick(ClientTickEvent e) {
        var target=CombatTargets.current();
        if(!powered()||!Targeting.canAct()||ConsumableUse.active()||target==null||Targeting.realDistance(target)>PowerCurve.blend(.5,range.get(),strength(),.5,6)) {CombatInventory.release(this,restore.get());return;}
        int best=-1;double score=-1;boolean axe=weapon.selectedValue().equals("Топор");
        for(int i=0;i<9;i++){double s=CombatItems.weaponScore(client().player.getInventory().getStack(i),axe);if(s>score){score=s;best=i;}}
        if(best>=0)CombatInventory.select(this,50,best);
    }
}
