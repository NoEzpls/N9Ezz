package pulse.n9ezz;

/** Shared client targeting geometry, independent of Minecraft state and physics. */
public final class TargetGeometry {
    private TargetGeometry() {}
    public record Point(double x,double y,double z) {
        public Point { if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z))throw new IllegalArgumentException("non-finite point"); }
        public double squaredDistance(Point other) {double dx=x-other.x,dy=y-other.y,dz=z-other.z;return dx*dx+dy*dy+dz*dz;}
    }
    public record Bounds(double minX,double minY,double minZ,double maxX,double maxY,double maxZ) {
        public Bounds {
            if(!Double.isFinite(minX)||!Double.isFinite(minY)||!Double.isFinite(minZ)||!Double.isFinite(maxX)||!Double.isFinite(maxY)||!Double.isFinite(maxZ)
                ||minX>maxX||minY>maxY||minZ>maxZ)throw new IllegalArgumentException("invalid bounds");
        }
    }
    public static Bounds scale(Bounds b,double x,double y,double z) {
        if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z)||x<1||y<1||z<1)throw new IllegalArgumentException("invalid expansion");
        double cx=(b.minX+b.maxX)/2,cy=(b.minY+b.maxY)/2,cz=(b.minZ+b.maxZ)/2;
        double hx=(b.maxX-b.minX)*x/2,hy=(b.maxY-b.minY)*y/2,hz=(b.maxZ-b.minZ)*z/2;
        return new Bounds(x==1?b.minX:cx-hx,y==1?b.minY:cy-hy,z==1?b.minZ:cz-hz,
            x==1?b.maxX:cx+hx,y==1?b.maxY:cy+hy,z==1?b.maxZ:cz+hz);
    }
    public static Point nearestPoint(Bounds b,Point eye) {
        return new Point(Math.clamp(eye.x,b.minX,b.maxX),Math.clamp(eye.y,b.minY,b.maxY),Math.clamp(eye.z,b.minZ,b.maxZ));
    }
    public static Bounds translate(Bounds b,Point offset) {return new Bounds(b.minX+offset.x,b.minY+offset.y,b.minZ+offset.z,b.maxX+offset.x,b.maxY+offset.y,b.maxZ+offset.z);}
    public static double distanceSquared(Bounds b,Point eye) {return eye.squaredDistance(nearestPoint(b,eye));}
    public static boolean withinRange(Bounds b,Point eye,double range) {
        return Double.isFinite(range)&&range>=0&&distanceSquared(b,eye)<=range*range;
    }
    /** Segment/AABB intersection: positive infinity means the segment misses. */
    public static double rayHitDistanceSquared(Bounds b,Point eye,Point end) {
        double[] from={eye.x,eye.y,eye.z},to={end.x,end.y,end.z};
        double[] min={b.minX,b.minY,b.minZ},max={b.maxX,b.maxY,b.maxZ};
        double enter=0,leave=1;
        for(int axis=0;axis<3;axis++) {
            double direction=to[axis]-from[axis];
            if(direction==0) {if(from[axis]<min[axis]||from[axis]>max[axis])return Double.POSITIVE_INFINITY;continue;}
            double first=(min[axis]-from[axis])/direction,last=(max[axis]-from[axis])/direction;
            if(first>last){double swap=first;first=last;last=swap;}
            enter=Math.max(enter,first);leave=Math.min(leave,last);
            if(enter>leave)return Double.POSITIVE_INFINITY;
        }
        return enter*enter*eye.squaredDistance(end);
    }
    /** A wall at the same point wins; an entity at the requested range endpoint is valid. */
    public static boolean pickable(double hitDistanceSquared,double range,double blockDistanceSquared) {
        return Double.isFinite(hitDistanceSquared)&&Double.isFinite(range)&&range>0&&hitDistanceSquared>=0
            &&hitDistanceSquared<=range*range&&hitDistanceSquared<blockDistanceSquared;
    }
    /** Block collision at the destination surface does not hide that surface. */
    public static boolean visible(double destinationDistanceSquared,double blockDistanceSquared) {
        return Double.isFinite(destinationDistanceSquared)&&destinationDistanceSquared>=0
            &&blockDistanceSquared+0.0001>=destinationDistanceSquared;
    }
}
