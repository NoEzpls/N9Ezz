package pulse.n9ezz;
import java.util.*;
import net.minecraft.entity.player.PlayerEntity;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Anti Bot",b="Фильтр целей: наличие в списке сервера и ожидание после появления. Не удаляет сущности.",c=ModuleCategory.CHEATS)
public final class AntiBot extends PvPModule {
    public final BooleanSetting tab=new BooleanSetting("Проверять список игроков",true);
    public final SliderSetting spawnDelay=new SliderSetting("Ожидание появления (мс)",500,0,3000,100);
    private final Map<UUID,Long> seen=new HashMap<>();
    private Object world;
    public boolean allowed(PlayerEntity player){
        if(!powered())return true;
        if(world!=client().world){seen.clear();world=client().world;}
        if(seen.size()>1024)seen.keySet().removeIf(id->client().world.getPlayers().stream().noneMatch(p->p.getUuid().equals(id)));
        long now=System.nanoTime(),first=seen.computeIfAbsent(player.getUuid(),id->now);
        return now-first>=actionDelay(spawnDelay.get(),0)&&(!tab.get()||client().getNetworkHandler()!=null&&client().getNetworkHandler().getPlayerListEntry(player.getUuid())!=null);
    }
    @Override public void onDisable(){seen.clear();world=null;super.onDisable();}
}
