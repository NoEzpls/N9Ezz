package pulse.n9ezz;

public final class AttackClock {
    private long lastAttempt = Long.MIN_VALUE;
    private long chargedSince = Long.MIN_VALUE;
    public void reset() { lastAttempt=chargedSince=Long.MIN_VALUE; }
    public boolean ready(long now, int cps, int mode, float cooldown) {
        return ready(now,cps,mode,cooldown,1);
    }
    public boolean ready(long now,int cps,int mode,float cooldown,float threshold) {
        cps=Math.max(1,Math.min(20,cps));
        if (cooldown < Math.max(.5f,Math.min(1,threshold))-.001f) { chargedSince=Long.MIN_VALUE; return false; }
        if (mode == 2) {
            if(chargedSince==Long.MIN_VALUE) chargedSince=now;
            if(now-chargedSince < 300_000_000L) return false;
        } else chargedSince=Long.MIN_VALUE;
        return lastAttempt==Long.MIN_VALUE || now-lastAttempt >= 1_000_000_000L/cps;
    }
    public void attempted(long now) { lastAttempt=now; chargedSince=Long.MIN_VALUE; }
}
