package pulse.n9ezz;

import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.entity.player.PlayerEntity;
import pulse.events.ClientTickEvent;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.SliderSetting;
import pulse.settings.BooleanSetting;
import pulse.settings.ModeSetting;

@ModuleInfo(a="Aim Bot",b="Плавно поворачивает камеру к игроку. Сам не атакует; сочетается с Triggerbot.",c=ModuleCategory.CHEATS)
public final class AimBot extends CheatModule {
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",3,3,10,0.1f);
    public final SliderSetting smoothing=new SliderSetting("Плавность (%)","Больше — мягче разгон и замедление",85,1,100,1);
    public final SliderSetting fov=new SliderSetting("Угол поиска (°)",90,10,360,5);
    public final SliderSetting manualOverride=new SliderSetting("Пауза после мыши (мс)",200,0,1000,50);
    public final BooleanSetting onlyAttack=new BooleanSetting("Только при атаке",false);
    public final BooleanSetting weaponsOnly=new BooleanSetting("Только с оружием",false);
    public final ModeSetting point=new ModeSetting("Точка наведения",new String[]{"Ближайшая точка","Грудь","Центр"},0);
    private final ViewMotion motion=new ViewMotion();
    private PlayerEntity target;
    public void reset() {target=null;motion.reset();}
    @Override public void onEnable(){reset();super.onEnable();}
    @Override public void onDisable() {reset();super.onDisable();}
    private boolean canAim(){return powered()&&Targeting.canAct()&&(!onlyAttack.get()||client().options.attackKey.isPressed())&&(!weaponsOnly.get()||Attacks.weapon(client().player));}
    @EventHandler(priority=EventPriority.HIGH) public void tick(ClientTickEvent event) {
        if(!canAim()||N9Ezz.AURA.controlsView()) {reset();return;}
        PlayerEntity next=Targeting.acquire(target,range.get(),effectivePower(),3,true,p->Targeting.combatTarget(p,true,true)&&Targeting.yawDelta(p)<=fov.get()/2);
        if(next!=target) motion.reset();
        target=next;
    }
    /** Runs before the camera is updated, once per rendered frame. */
    public void frame(long now,float tickProgress) {
        if(!isEnabled() || !canAim() || target==null || !Targeting.combatTarget(target,true,true)
            || !client().world.getPlayers().contains(target)) {reset();return;}
        motion.frame(Targeting.aimPoint(target,tickProgress,java.util.Arrays.asList(point.values()).indexOf(point.selectedValue())),now,tickProgress,effectivePower(),smoothing.get(),manualOverride.roundedInt());
    }
}
