package pulse.n9ezz;

import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import pulse.n9ezz.mixin.SlotSyncAccessor;
import net.minecraft.screen.slot.SlotActionType;

/** Shared slot lease and one inventory click per tick for all N9Ezz helpers. */
public final class CombatInventory {
    private static final SlotOwnership slots=new SlotOwnership();
    private static PlayerEntity player;
    private static int clickedAt=Integer.MIN_VALUE;
    private CombatInventory() {}
    private static MinecraftClient mc(){return MinecraftClient.getInstance();}
    public static boolean available() {
        var m=mc();return m.player!=null&&m.world!=null&&m.interactionManager!=null&&m.currentScreen==null
            &&m.player.isAlive()&&!m.player.isSpectator()&&!m.isPaused()&&m.player.currentScreenHandler==m.player.playerScreenHandler;
    }
    public static void tick() {
        var p=mc().player;
        if(player!=p) {slots.clear();player=p;clickedAt=Integer.MIN_VALUE;}
        if(p==null)return;
        if(!available()||slots.expired(p.age))cancel();
    }
    public static boolean select(Object owner,int priority,int slot) {
        if(!available()||N9Ezz.TOTEM!=null&&N9Ezz.TOTEM.reservingMainHand())return false;
        tick();var p=mc().player;
        if(!slots.request(owner,priority,slot,p.getInventory().getSelectedSlot(),p.age))return false;
        setSlot(slot);return true;
    }
    public static boolean owns(Object owner){return slots.owns(owner);}
    public static boolean busy(){return slots.active()||ConsumableUse.active();}
    public static void release(Object owner,boolean restore) {
        var p=mc().player;if(p==null||p!=player){slots.clear();return;}
        int slot=slots.release(owner,p.getInventory().getSelectedSlot(),restore);if(slot>=0)setSlot(slot);
    }
    public static void cancel() {
        var p=mc().player;if(p!=null&&p==player){int slot=slots.cancel(p.getInventory().getSelectedSlot());if(slot>=0)setSlot(slot);}else slots.clear();
    }
    private static void setSlot(int slot) {
        var m=mc();if(m.player==null||m.player.getInventory().getSelectedSlot()==slot)return;
        m.player.getInventory().setSelectedSlot(slot);
        // Keep Minecraft's last-selected-slot cache in sync; native player tick updates weapon charge.
        ((SlotSyncAccessor)m.interactionManager).n9ezzSyncSelectedSlot();
    }
    public static int findHotbar(Predicate<ItemStack> predicate) {
        var p=mc().player;if(p==null)return -1;for(int i=0;i<9;i++)if(predicate.test(p.getInventory().getStack(i)))return i;return -1;
    }
    public static int findInventory(Predicate<ItemStack> predicate) {
        var p=mc().player;if(p==null)return -1;for(int i=0;i<36;i++)if(predicate.test(p.getInventory().getStack(i)))return i;return -1;
    }
    public static boolean swap(int inventorySlot,int hotbarButton) {
        if(!available()||inventorySlot<0||inventorySlot>35||hotbarButton<0||hotbarButton>40||hotbarButton>8&&hotbarButton!=40)return false;
        return click(CombatMath.playerSlot(inventorySlot),hotbarButton,SlotActionType.SWAP);
    }
    public static boolean click(int screenSlot,int button,SlotActionType action) {
        if(!available()||clickedAt==mc().player.age)return false;
        if(ConsumableUse.active())return false;
        clickedAt=mc().player.age;
        mc().interactionManager.clickSlot(mc().player.playerScreenHandler.syncId,screenSlot,button,action,mc().player);return true;
    }
}
