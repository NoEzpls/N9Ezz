package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Projectile Aim",b="Плавно наводит лук/трезубец с оценкой движения цели и низкой баллистической траекторией.",c=ModuleCategory.CHEATS)
public final class ProjectileAim extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting range=new SliderSetting("Дальность цели",32,3,64,1);
    public final SliderSetting fov=new SliderSetting("Угол поиска (°)",90,10,180,5);
    public final SliderSetting smoothing=new SliderSetting("Плавность (%)",80,1,100,1);
    public final BooleanSetting prediction=new BooleanSetting("Упреждение",true);
    private final ViewMotion motion=new ViewMotion();
    private PlayerEntity target;
    public boolean controlsView(){return isEnabled()&&powered()&&CombatInventory.available()&&client().player.isUsingItem()&&(client().player.getActiveItem().isOf(Items.BOW)||client().player.getActiveItem().isOf(Items.TRIDENT));}
    public void reset(){target=null;motion.reset();}
    @Override public void onDisable(){reset();super.onDisable();}
    @EventHandler public void tick(ClientTickEvent e) {
        if(!controlsView()){target=null;motion.reset();return;}
        var next=Targeting.acquire(target,range.get(),effectivePower(),3,true,p->Targeting.yawDelta(p)<=fov.get()/2);
        if(next!=target)motion.reset();target=next;
    }
    public void frame(long now,float progress) {
        if(!controlsView()||target==null||!Targeting.combatTarget(target,true,true))return;
        var p=client().player;double speed=p.getActiveItem().isOf(Items.TRIDENT)?2.5:3*BowItem.getPullProgress(p.getItemUseTime());if(speed<.3)return;
        var eye=p.getCameraPosVec(progress);var point=Targeting.aimPoint(target,progress,1);
        if(prediction.get())point=point.add(target.getVelocity().multiply(Math.min(30,eye.distanceTo(point)/speed)));
        var d=point.subtract(eye);double pitch=PvPMath.ballisticPitch(Math.hypot(d.x,d.z),d.y,speed,.05);if(!Double.isFinite(pitch))return;
        motion.frame(eye.add(d.x,Math.hypot(d.x,d.z)*Math.tan(pitch),d.z),now,progress,effectivePower(),smoothing.get(),200);
    }
}
