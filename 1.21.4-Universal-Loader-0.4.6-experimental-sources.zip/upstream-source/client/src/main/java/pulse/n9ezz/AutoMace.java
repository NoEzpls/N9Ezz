package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Mace",b="Выбирает булаву в хотбаре перед ударом в падении; возвращает обычное оружие на земле.",c=ModuleCategory.CHEATS)
public final class AutoMace extends PvPModule {
    public final SliderSetting fall=new SliderSetting("Минимум падения",1.5f,1.5f,8,.1f);
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",3,.5f,6,.1f);
    @Override protected String[] conflicts(){return new String[]{"MaceHelper"};}
    @EventHandler public void tick(ClientTickEvent e){
        var p=client().player;var t=CombatTargets.current();
        if(!powered()||!Targeting.canAct()||p==null||p.isOnGround()||p.isGliding()||p.getVelocity().y>=0||p.fallDistance<PowerCurve.blend(8,fall.get(),strength(),1.5,8)||t==null||Targeting.realDistance(t)>PowerCurve.blend(.5,range.get(),strength(),.5,6)){CombatInventory.release(this,true);return;}
        int slot=CombatInventory.findHotbar(s->s.isOf(Items.MACE));if(slot>=0)CombatInventory.select(this,60,slot);
    }
}
