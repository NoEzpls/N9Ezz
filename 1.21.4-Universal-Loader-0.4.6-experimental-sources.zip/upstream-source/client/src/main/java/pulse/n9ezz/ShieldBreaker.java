package pulse.n9ezz;

import java.util.UUID;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.BooleanSetting;
import pulse.settings.SliderSetting;

@ModuleInfo(a="Shield Breaker",b="Переключает Aura/Triggerbot на топор против поднятого щита и возвращает слот.",c=ModuleCategory.CHEATS)
public final class ShieldBreaker extends CheatModule {
    public final BooleanSetting restoreWeapon=new BooleanSetting("Вернуть оружие",true);
    public final SliderSetting switchDelay=new SliderSetting("Задержка смены (мс)",50,0,300,10);
    private PlayerEntity owner;private UUID targetId;private int selected=-1,lastRequested;private long switchedAt;
    public ShieldBreaker() { power.set(100); }
    @Override public void onDisable() { cancel();super.onDisable(); }
    public boolean blocking(PlayerEntity target) {
        if(target==null||!target.isBlocking()||!target.getActiveItem().isOf(Items.SHIELD)||client().player==null)return false;
        var d=client().player.getEntityPos().subtract(target.getEntityPos());var f=target.getRotationVec(1);
        return d.x*f.x+d.z*f.z>0;
    }
    public boolean prepare(PlayerEntity target,long now) {
        if(!isEnabled()||!powered()||!blocking(target)){cancel();return true;}
        var mc=client();var player=mc.player;var inv=player==null?null:player.getInventory();
        if(player==null||mc.currentScreen!=null||player.currentScreenHandler!=player.playerScreenHandler){cancel();return false;}
        if(owner!=null&&(owner!=player||!target.getUuid().equals(targetId)))cancel();
        if(owner!=null&&(!CombatInventory.owns(this)||inv.getSelectedSlot()!=selected)){cancel();return false;}
        if(owner==null) {
            if(player.getMainHandStack().isIn(ItemTags.AXES))return true;
            int axe=-1;for(int i=0;i<9;i++)if(inv.getStack(i).isIn(ItemTags.AXES)){axe=i;break;}
            if(axe<0)return true;
            if(!CombatInventory.select(this,80,axe))return false;
            owner=player;targetId=target.getUuid();selected=axe;switchedAt=now;
        }
        if(!CombatInventory.select(this,80,selected)){cancel();return false;}
        lastRequested=player.age;if(!player.getMainHandStack().isIn(ItemTags.AXES)){cancel();return false;}
        long delay=actionDelay(Math.max(switchDelay.get(),150*(1-Math.min(1,strength()))),0);
        return now-switchedAt>=delay;
    }
    public void guard() {
        if(owner==null)return;var mc=client();
        if(mc.player!=owner||mc.world==null||!owner.isAlive()||owner.isSpectator()||mc.currentScreen!=null||mc.isPaused()||owner.age-lastRequested>2
            ||owner.currentScreenHandler!=owner.playerScreenHandler||(N9Ezz.TOTEM!=null&&N9Ezz.TOTEM.reservingMainHand())
            ||(!N9Ezz.AURA.isEnabled()&&!N9Ezz.TRIGGER.isEnabled())){cancel();return;}
        var target=mc.world.getPlayers().stream().filter(p->p.getUuid().equals(targetId)).findFirst().orElse(null);
        if(target==null||!Targeting.eligible(target)||!blocking(target))cancel();
        else if(owner.getInventory().getSelectedSlot()!=selected||!CombatInventory.owns(this))cancel();
    }
    public boolean pending(){return owner!=null;}
    public void afterAttempt(){CombatInventory.release(this,restoreWeapon.get());clear();}
    public void cancel(){CombatInventory.release(this,true);clear();}
    private void clear(){owner=null;targetId=null;selected=-1;switchedAt=0;}
}
