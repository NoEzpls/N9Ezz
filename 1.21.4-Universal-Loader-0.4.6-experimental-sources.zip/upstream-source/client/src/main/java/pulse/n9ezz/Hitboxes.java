package pulse.n9ezz;

import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.SliderSetting;
import pulse.settings.BooleanSetting;
import pulse.settings.ColorSetting;
import java.awt.Color;

@ModuleInfo(a="Hitboxes",b="Расширяет области наведения по X/Y/Z и показывает их рамками. Не изменяет серверные хитбоксы.",c=ModuleCategory.CHEATS)
public final class Hitboxes extends CheatModule {
    public final SliderSetting x=new SliderSetting("X (×)",1.2f,1,5,0.1f);
    public final SliderSetting y=new SliderSetting("Y (×)",1,1,5,0.1f);
    public final SliderSetting z=new SliderSetting("Z (×)",1.2f,1,5,0.1f);
    public final SliderSetting range=new SliderSetting("Дальность расширения",6,1,12,.5f);
    public final BooleanSetting onlyTarget=new BooleanSetting("Только текущая цель",false);
    public final BooleanSetting outline=new BooleanSetting("Показывать рамки",true);
    public final SliderSetting lineWidth=new SliderSetting("Толщина рамки",2f,1,4,0.25f);
    public final ColorSetting color=new ColorSetting("Цвет рамки",new Color(130,180,255));
}
