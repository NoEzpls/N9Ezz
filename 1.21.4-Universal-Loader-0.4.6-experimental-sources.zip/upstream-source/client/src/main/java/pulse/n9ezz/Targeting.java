package pulse.n9ezz;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import pulse.gui.friends.FriendLookup;
import net.minecraft.world.World;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public final class Targeting {
    private Targeting() {}
    public static boolean friend(PlayerEntity player) {
        return FriendLookup.isFriendName(player.getName().getString());
    }
    public static boolean eligible(PlayerEntity player) {
        MinecraftClient mc=MinecraftClient.getInstance();
        return mc.player!=null && mc.world!=null && player!=null && player!=mc.player
            && mc.world.getPlayers().contains(player) && player.isAlive() && !player.isSpectator() && !friend(player);
    }
    public static boolean canAct() { return canAct(false); }
    public static boolean canAct(boolean releaseShield) {
        MinecraftClient mc=MinecraftClient.getInstance();
        releaseShield|=N9Ezz.AUTOSHIELD!=null&&N9Ezz.AUTOSHIELD.ownsShield();
        return mc.player!=null && mc.world!=null && mc.interactionManager!=null && mc.currentScreen==null
            && mc.player.isAlive() && !mc.player.isSpectator() && !mc.isPaused() && !ConsumableUse.active()
            && (!mc.player.isUsingItem() || releaseShield && mc.player.getActiveItem().isOf(net.minecraft.item.Items.SHIELD));
    }
    public static Box box(Entity entity) {
        Box original=entity.getBoundingBox();
        Hitboxes hitboxes=N9Ezz.HITBOXES;
        if (!(entity instanceof PlayerEntity player) || !eligible(player) || hitboxes==null || !hitboxes.isEnabled() || InterfaceMode.hidden()) return original;
        if(MinecraftClient.getInstance().player.getEyePos().distanceTo(nearestPoint(original,MinecraftClient.getInstance().player.getEyePos()))>hitboxes.range.get()
            ||hitboxes.onlyTarget.get()&&CombatTargets.tracked()!=player) return original;
        var scaled=TargetGeometry.scale(bounds(original),CombatMath.scale(hitboxes.x.get(),hitboxes.effectivePower()),
            CombatMath.scale(hitboxes.y.get(),hitboxes.effectivePower()),CombatMath.scale(hitboxes.z.get(),hitboxes.effectivePower()));
        return new Box(scaled.minX(),scaled.minY(),scaled.minZ(),scaled.maxX(),scaled.maxY(),scaled.maxZ());
    }
    public static Box box(Entity entity,boolean expanded) {return expanded?box(entity):entity.getBoundingBox();}
    private static TargetGeometry.Bounds bounds(Box b){return new TargetGeometry.Bounds(b.minX,b.minY,b.minZ,b.maxX,b.maxY,b.maxZ);}
    private static TargetGeometry.Point point(Vec3d p){return new TargetGeometry.Point(p.x,p.y,p.z);}
    /** Include enlarged player boxes that the vanilla broad-phase search misses. */
    public static List<Entity> candidates(World world,Entity source,Box search,Predicate<? super Entity> predicate) {
        List<Entity> vanilla=world.getOtherEntities(source,search,predicate);
        MinecraftClient mc=MinecraftClient.getInstance();
        Hitboxes module=N9Ezz.HITBOXES;
        if(!mc.isOnThread() || world!=mc.world || module==null || !module.isEnabled() || InterfaceMode.hidden()) return vanilla;
        List<Entity> result=vanilla;
        for(PlayerEntity player:world.getPlayers()) {
            if(player==source || !eligible(player) || vanilla.contains(player)
                || !predicate.test(player) || !box(player).intersects(search)) continue;
            if(result==vanilla) result=new ArrayList<>(vanilla);
            result.add(player);
        }
        return result;
    }
    public static Vec3d nearestPoint(Box box,Vec3d eye) {
        var p=TargetGeometry.nearestPoint(bounds(box),point(eye));return new Vec3d(p.x(),p.y(),p.z());
    }
    public static double distance(PlayerEntity player) {
        return distance(player,true);
    }
    public static double distance(PlayerEntity player,boolean expanded) {return Math.sqrt(TargetGeometry.distanceSquared(bounds(box(player,expanded)),point(MinecraftClient.getInstance().player.getEyePos())));}
    public static double yawDelta(PlayerEntity player) {
        return yawDelta(player,false);
    }
    public static double yawDelta(PlayerEntity player,boolean expanded) {
        MinecraftClient mc=MinecraftClient.getInstance();
        Vec3d delta=(expanded?nearestPoint(box(player),mc.player.getEyePos()):player.getEyePos()).subtract(mc.player.getEyePos());
        if(delta.horizontalLengthSquared()<1.0e-12)return 0;
        return Math.abs(CombatMath.wrapDegrees(Math.toDegrees(Math.atan2(delta.z,delta.x))-90-mc.player.getYaw()));
    }
    public static double realDistance(PlayerEntity player) {
        var eye=MinecraftClient.getInstance().player.getEyePos();return nearestPoint(player.getBoundingBox(),eye).distanceTo(eye);
    }
    /** Reach changes picking only; automated attacks use the unmodified entity attribute. */
    public static double combatRange(double requested) {
        return Math.max(0,Math.min(requested,actualCombatRange()));
    }
    public static double actualCombatRange() {var p=MinecraftClient.getInstance().player;return p==null?0:Math.max(0,p.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.ENTITY_INTERACTION_RANGE));}
    public static Vec3d aimPoint(PlayerEntity target,float tickProgress,int mode) {
        return aimPoint(target,tickProgress,mode,false);
    }
    public static Vec3d aimPoint(PlayerEntity target,float tickProgress,int mode,boolean expanded) {
        var mc=MinecraftClient.getInstance();Box b=box(target,expanded).offset(target.getLerpedPos(tickProgress).subtract(target.getEntityPos()));
        Vec3d point=mode==0?nearestPoint(b.contract(Math.min(.02,b.getLengthX()/4)),mc.player.getCameraPosVec(tickProgress))
            :mode==1?new Vec3d((b.minX+b.maxX)/2,b.minY+b.getLengthY()*.65,(b.minZ+b.maxZ)/2):b.getCenter();
        return point;
    }
    public static boolean visible(Vec3d point) {
        MinecraftClient mc=MinecraftClient.getInstance();
        Vec3d eye=mc.player.getEyePos();
        HitResult hit=mc.world.raycast(new RaycastContext(eye,point,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,mc.player));
        return TargetGeometry.visible(eye.squaredDistanceTo(point),hit.getType()==HitResult.Type.MISS?Double.POSITIVE_INFINITY:eye.squaredDistanceTo(hit.getPos()));
    }
    /** Expanded boxes can protrude in front of a wall; the physical player must still be visible. */
    public static boolean visible(PlayerEntity player,boolean expanded) {
        Vec3d eye=MinecraftClient.getInstance().player.getEyePos();
        return visible(nearestPoint(box(player,expanded),eye))&&(!expanded||visible(nearestPoint(player.getBoundingBox(),eye)));
    }
    public static boolean combatTarget(PlayerEntity p,boolean invisible,boolean unarmored){return p!=null&&eligible(p)&&!p.getAbilities().invulnerable&&(invisible||!p.isInvisible())&&(unarmored||p.getArmor()>0)
        &&(N9Ezz.ANTIBOT==null||!N9Ezz.ANTIBOT.isEnabled()||N9Ezz.ANTIBOT.allowed(p))
        &&(N9Ezz.TEAMS==null||!N9Ezz.TEAMS.isEnabled()||N9Ezz.TEAMS.allowed(p));}
    public static PlayerEntity acquire(PlayerEntity previous,double range,double power) {return acquire(previous,range,power,0,true,p->true);}
    public static PlayerEntity acquire(PlayerEntity previous,double range,double power,int priority,boolean lock,Predicate<PlayerEntity> filter) {
        return acquire(previous,range,power,priority,lock,false,filter);
    }
    public static PlayerEntity acquire(PlayerEntity previous,double range,double power,int priority,boolean lock,boolean expanded,Predicate<PlayerEntity> filter) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null)return null;
        if(lock&&previous!=null&&filter.test(previous)&&valid(previous,range,power,expanded)) return previous;
        PlayerEntity best=null;
        double bestDistance=Double.MAX_VALUE;
        for(PlayerEntity player:mc.world.getPlayers()) {
            if(!filter.test(player)||!valid(player,range,power,expanded)) continue;
            double d=CombatRules.targetScore(priority,distance(player,expanded),player.getHealth()+player.getAbsorptionAmount(),player.getArmor(),yawDelta(player,expanded));
            if(d<bestDistance) { best=player;bestDistance=d; }
        }
        return best;
    }
    private static boolean valid(PlayerEntity player,double range,double power,boolean expanded) {
        MinecraftClient mc=MinecraftClient.getInstance();
        return player!=null && mc.world.getPlayers().contains(player) && combatTarget(player,true,true) && distance(player,expanded)<=range&&(!expanded||realDistance(player)<=actualCombatRange())
            && yawDelta(player,expanded)<=CombatMath.halfAngle(power) && visible(player,expanded);
    }
    public static PlayerEntity underCrosshair(double range) {return underCrosshair(range,true);}
    public static PlayerEntity underCrosshair(double range,boolean expanded) {
        var hit=underCrosshairEntity(range,expanded);
        return hit instanceof PlayerEntity player&&combatTarget(player,true,true)?player:null;
    }
    public static Entity underCrosshairEntity(double range,boolean expanded) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null||range<=0)return null;
        Vec3d eye=mc.player.getEyePos();
        Vec3d end=eye.add(mc.player.getRotationVec(1.0f).multiply(range));
        HitResult block=mc.world.raycast(new RaycastContext(eye,end,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,mc.player));
        double blockDistance=block.getType()==HitResult.Type.MISS?Double.POSITIVE_INFINITY:eye.squaredDistanceTo(block.getPos());
        double closest=Double.POSITIVE_INFINITY;
        Entity best=null;
        List<Entity> entities=expanded?candidates(mc.world,mc.player,new Box(eye,end).expand(1),e->e.canHit()&&!e.isSpectator())
            :mc.world.getOtherEntities(mc.player,new Box(eye,end).expand(1),e->e.canHit()&&!e.isSpectator());
        for(Entity entity:entities) {
            Box box=box(entity,expanded);
            double distance=TargetGeometry.rayHitDistanceSquared(bounds(box),point(eye),point(end));
            if(TargetGeometry.pickable(distance,range,blockDistance)&&distance<closest
                &&(!expanded||!(entity instanceof PlayerEntity player)||visible(player,true))) { best=entity;closest=distance; }
        }
        return best;
    }
}
