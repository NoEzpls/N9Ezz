package pulse.n9ezz;
import net.minecraft.util.math.Vec2f;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="W Tap",b="Коротко убирает движение вперёд после удара, сохраняя физические состояния клавиш.",c=ModuleCategory.CHEATS)
public final class WTap extends PvPModule {
    public final SliderSetting pause=new SliderSetting("Пауза (мс)",100,30,250,10);
    public final BooleanSetting groundOnly=new BooleanSetting("Только на земле",true);
    private long until;
    public void attacked(){if(powered()&&client().player!=null&&(!groundOnly.get()||client().player.isOnGround()))until=System.nanoTime()+actionDelay(pause.get(),60);}
    public Vec2f input(Vec2f input){return isEnabled()&&powered()&&System.nanoTime()<until&&client().currentScreen==null?new Vec2f(input.x,Math.min(0,input.y)):input;}
    @Override public void onDisable(){until=0;super.onDisable();}
}
