package pulse.n9ezz;

import net.minecraft.client.MinecraftClient;
import pulse.module.ClientModule;
import pulse.settings.SliderSetting;

public abstract class CheatModule extends ClientModule {
    public final SliderSetting power = new SliderSetting("Мощность (%)", "Доля базовой силы выбранного уровня: Legit ×1, Hight ×2.5, Extra ×10", 50, 0, 100, 1);
    protected static MinecraftClient client() { return MinecraftClient.getInstance(); }
    public final double strength(){return PowerCurve.strength(power.get(),PowerModes.current());}
    public final float effectivePower(){return (float)(strength()*100);}
    protected final long actionDelay(double milliseconds,double minimumMs){return PowerCurve.delay(milliseconds,strength(),minimumMs);}
    protected final boolean powered(){return power.get()>0;}
    @Override public void collectSettings() {
        super.collectSettings();
        settings().addFirst(power);
    }
}
