package pulse.n9ezz;

import com.google.gson.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import pulse.config.LocalConfigManager;
import pulse.gui.core.PulseClickGuiScreen;
import pulse.gui.friends.*;
import ru.pulse.Pulse;

/** Repairs the supplied panel's empty mutators and persists the same list used by FriendLookup. */
public final class FriendSupport {
    private static boolean loaded,loading;
    private FriendSupport() {}
    private static FriendsPanel panel(){return Pulse.getInstance()!=null&&Pulse.getInstance().getClickGui() instanceof PulseClickGuiScreen gui?gui.h().e():null;}
    private static Path file(){return FabricLoader.getInstance().getConfigDir().resolve("n9ezz/friends.json");}
    @SuppressWarnings("unchecked") private static List<FriendCard> cards(FriendsPanel panel) {
        try{var field=FriendsPanel.class.getDeclaredField("s");field.setAccessible(true);return (List<FriendCard>)field.get(panel);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    private static void refresh(FriendsPanel panel) {
        try{var method=FriendsPanel.class.getDeclaredMethod("e");method.setAccessible(true);method.invoke(panel);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        if(!loading&&!LocalConfigManager.get().isApplying())save();
    }
    public static void add(FriendsPanel panel,HistoryEntry entry) {
        if(entry==null||entry.name()==null)return;String name=entry.name().strip();
        if(name.isBlank()||name.length()>64||panel.a().stream().anyMatch(e->e.name().equalsIgnoreCase(name)))return;
        entry.setName(name);if(entry.date()==null)entry.setDate(LocalDate.now());
        panel.a().add(entry);var card=new FriendCard(entry);card.a(e->remove(panel,e));cards(panel).add(card);refresh(panel);
    }
    public static void remove(FriendsPanel panel,HistoryEntry entry) {
        if(entry==null)return;
        panel.a().removeIf(e->e.name().equalsIgnoreCase(entry.name()));cards(panel).removeIf(c->c.a().name().equalsIgnoreCase(entry.name()));refresh(panel);
    }
    public static void clear(FriendsPanel panel){panel.a().clear();cards(panel).clear();refresh(panel);}
    public static void poll() {
        if(loaded)return;var panel=panel();if(panel==null)return;
        loaded=true;Path path=file();if(!Files.isRegularFile(path))return;
        try {
            if(Files.size(path)>65536)return;
            JsonArray entries=JsonParser.parseString(Files.readString(path)).getAsJsonArray();List<HistoryEntry> valid=new ArrayList<>();
            for(JsonElement raw:entries){var item=raw.getAsJsonObject();String name=item.get("name").getAsString();if(name.isBlank()||name.length()>64)throw new IllegalArgumentException("friend name");valid.add(new HistoryEntry(name,LocalDate.parse(item.get("date").getAsString())));}
            loading=true;try{for(var entry:valid)add(panel,entry);}finally{loading=false;}
        }catch(Exception ignored){loading=false;}
    }
    public static void save() {
        if(!loaded||loading)return;var panel=panel();if(panel==null)return;
        try {
            JsonArray list=new JsonArray();for(var entry:panel.a()){JsonObject item=new JsonObject();item.addProperty("name",entry.name());item.addProperty("date",entry.date().toString());list.add(item);}
            Path path=file();Files.createDirectories(path.getParent());Path temp=Files.createTempFile(path.getParent(),"friends-",".tmp");
            try{Files.writeString(temp,list.toString());try{Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING);}}finally{Files.deleteIfExists(temp);}
        }catch(java.io.IOException ignored){}
    }
}
