package pulse.n9ezz;

/** Pure combat policy used by Aura, Triggerbot and the optional critical-hit helper. */
public final class CombatRules {
    public enum CriticalDecision { ATTACK, WAIT, JUMP }
    private CombatRules() {}

    public static double targetScore(int priority,double distance,double health,double armor,double angle) {
        return switch(Math.max(0,Math.min(3,priority))) {
            case 1 -> health + distance * 0.0001;
            case 2 -> armor + distance * 0.0001;
            case 3 -> angle + distance * 0.0001;
            default -> distance;
        };
    }
    public static long reactionDelay(double power,double confirmationMs) {
        double s=CombatMath.clamp(power,0,1000)/100;
        double confirmation=CombatMath.clamp(confirmationMs,0,500);
        double ms=s<=1?Math.max(confirmation,250*(1-s)):Math.max(0,confirmation/s-50*(s-1));
        return Math.round(ms*1_000_000L);
    }
    public static CriticalDecision critical(boolean capable,boolean grounded,boolean falling,float cooldown,
                                            boolean sprinting,boolean resetSprint,boolean strict,boolean autoJump) {
        if(!capable || sprinting && !resetSprint) return strict ? CriticalDecision.WAIT : CriticalDecision.ATTACK;
        if(cooldown < .9f) return CriticalDecision.WAIT;
        if(grounded) return autoJump ? CriticalDecision.JUMP : (strict ? CriticalDecision.WAIT : CriticalDecision.ATTACK);
        return falling ? CriticalDecision.ATTACK : CriticalDecision.WAIT;
    }
}
