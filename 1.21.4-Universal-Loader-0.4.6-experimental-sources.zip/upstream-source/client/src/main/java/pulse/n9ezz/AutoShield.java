package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Shield",b="Поднимает щит во второй руке против видимого близкого противника и отпускает после угрозы.",c=ModuleCategory.CHEATS)
public final class AutoShield extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting range=new SliderSetting("Дальность угрозы",3,.5f,6,.1f);
    public final SliderSetting attackWindow=new SliderSetting("Окно атаки (мс)",300,100,800,50);
    private boolean raised;
    private long attackedAt;
    public boolean ownsShield(){return isEnabled()&&raised;}
    public void attacked(){attackedAt=System.nanoTime();release();}
    private void release(){if(raised&&client().player!=null&&client().interactionManager!=null&&client().player.isUsingItem()&&client().player.getActiveHand()==Hand.OFF_HAND&&client().player.getActiveItem().isOf(Items.SHIELD)&&!client().options.useKey.isPressed())client().interactionManager.stopUsingItem(client().player);raised=false;}
    @Override public void onDisable(){release();super.onDisable();}
    @EventHandler public void tick(ClientTickEvent e) {
        var m=client();if(!powered()||!CombatInventory.available()||ConsumableUse.active()||m.options.useKey.isPressed()||m.options.attackKey.isPressed()||System.nanoTime()-attackedAt<actionDelay(attackWindow.get(),50)){release();return;}
        var t=CombatTargets.current();
        if(t==null)t=Targeting.acquire(null,range.get(),effectivePower());
        if(t==null||Targeting.realDistance(t)>range.get()||Targeting.yawDelta(t)>70||!m.player.getOffHandStack().isOf(Items.SHIELD)||m.player.getItemCooldownManager().isCoolingDown(m.player.getOffHandStack())){release();return;}
        if(m.player.isUsingItem())return;
        m.interactionManager.interactItem(m.player,Hand.OFF_HAND);raised=m.player.isUsingItem();
    }
}
