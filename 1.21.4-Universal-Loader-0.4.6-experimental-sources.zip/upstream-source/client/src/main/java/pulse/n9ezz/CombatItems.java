package pulse.n9ezz;

import net.minecraft.item.*;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.effect.StatusEffects;

public final class CombatItems {
    private CombatItems() {}
    public static boolean gapple(ItemStack s){return s.isOf(Items.GOLDEN_APPLE)||s.isOf(Items.ENCHANTED_GOLDEN_APPLE);}
    public static boolean healingPotion(ItemStack s) {
        if(!s.isOf(Items.POTION))return false;
        var contents=s.get(DataComponentTypes.POTION_CONTENTS);
        if(contents!=null)for(var effect:contents.getEffects())
            if(effect.getEffectType().equals(StatusEffects.INSTANT_HEALTH)||effect.getEffectType().equals(StatusEffects.REGENERATION))return true;
        return false;
    }
    public static double weaponScore(ItemStack s,boolean axe) {
        if(!s.isIn(axe?ItemTags.AXES:ItemTags.SWORDS))return -1;
        String id=net.minecraft.registry.Registries.ITEM.getId(s.getItem()).getPath();
        double tier=id.startsWith("netherite_")?6:id.startsWith("diamond_")?5:id.startsWith("iron_")?4:id.startsWith("stone_")?3:id.startsWith("copper_")?2:1;
        return tier+(s.isDamageable()?1-(double)s.getDamage()/s.getMaxDamage():1)*.1;
    }
    public static int armorSlot(ItemStack s) {
        var equippable=s.get(DataComponentTypes.EQUIPPABLE);if(equippable==null)return -1;
        return switch(equippable.slot()) {case HEAD->5;case CHEST->6;case LEGS->7;case FEET->8;default->-1;};
    }
    public static double armorScore(ItemStack s) {
        if(s.isEmpty()||armorSlot(s)<0||s.isOf(Items.ELYTRA))return 0;
        String id=net.minecraft.registry.Registries.ITEM.getId(s.getItem()).getPath();
        double tier=id.startsWith("netherite_")?7:id.startsWith("diamond_")?6:id.startsWith("iron_")?5:id.startsWith("chainmail_")?4:id.startsWith("copper_")?3:id.startsWith("golden_")?2:id.startsWith("leather_")?1:id.startsWith("turtle_")?5:0;
        return tier+(s.isDamageable()?1-(double)s.getDamage()/s.getMaxDamage():1)*.1;
    }
}
