package pulse.n9ezz;

import meteordevelopment.orbit.EventHandler;
import pulse.events.ClientTickEvent;
import pulse.module.ModuleCategory;
import pulse.module.ModuleInfo;
import pulse.settings.ModeSetting;
import pulse.settings.SliderSetting;
import pulse.settings.BooleanSetting;

@ModuleInfo(a="Triggerbot",b="Удары под прицелом. Уровень и мощность меняют реакцию и базовый лимит ударов; заряд оружия сохраняется.",c=ModuleCategory.CHEATS)
public final class Triggerbot extends CheatModule {
    public final SliderSetting cps=new SliderSetting("Удары/сек","Базовый лимит при силе 1. Уровень и мощность меняют его до 20; заряд оружия сохраняется",5,1,10,1);
    public final ModeSetting speed=new ModeSetting("Скорость",new String[]{"Быстрая","Обычная","Медленная"},1);
    public final SliderSetting miss=new SliderSetting("Миссы / 100",0,0,50,1);
    public final SliderSetting range=new SliderSetting("Дальность (блоки)","Не отменяет серверную проверку дальности",3,.5f,10,0.1f);
    public final SliderSetting confirmation=new SliderSetting("Подтверждение цели (мс)",50,0,500,10);
    public final BooleanSetting invisible=new BooleanSetting("Невидимые игроки",true);
    public final BooleanSetting unarmored=new BooleanSetting("Игроки без брони",true);
    public final BooleanSetting weaponsOnly=new BooleanSetting("Только с оружием",false);
    public final SliderSetting cooldown=new SliderSetting("Заряд удара (%)",100,50,100,1);
    public final BooleanSetting releaseShield=new BooleanSetting("Отпускать свой щит",false);
    public final BooleanSetting resetSprint=new BooleanSetting("Сбрасывать спринт",true);
    public final BooleanSetting exactHit=new BooleanSetting("Обычное попадание",false);
    private final AttackClock clock=new AttackClock();
    private final MissSequence misses=new MissSequence();
    private java.util.UUID lookedAt;
    private long acquiredAt;
    private net.minecraft.entity.player.PlayerEntity current;
    @Override public void onEnable() {
        if(N9Ezz.AURA!=null) N9Ezz.AURA.setEnabled(false);
        clock.reset();misses.reset();lookedAt=null;super.onEnable();
    }
    @Override public void onDisable() { reset();super.onDisable(); }
    public void reset(){clock.reset();lookedAt=null;current=null;Attacks.cancel();}
    public net.minecraft.entity.player.PlayerEntity target(){return current;}
    public int effectiveCps(){return PowerCurve.cps(cps.roundedInt(),strength());}
    @EventHandler public void tick(ClientTickEvent event) {
        if(!powered()||!Targeting.canAct(releaseShield.get())) { reset();return; }
        boolean expanded=!exactHit.get();
        var target=Targeting.underCrosshair(Targeting.combatRange(range.get()),expanded);
        if(target==null||!Targeting.combatTarget(target,invisible.get(),unarmored.get())) { reset();return; }
        current=target;
        long now=System.nanoTime();
        if(!target.getUuid().equals(lookedAt)) { clock.reset();Attacks.cancel();lookedAt=target.getUuid();acquiredAt=now; }
        if(now-acquiredAt<CombatRules.reactionDelay(effectivePower(),confirmation.get())) return;
        Attacks.attempt(target,clock,misses,new Attacks.Options(effectiveCps(),java.util.Arrays.asList(speed.values()).indexOf(speed.selectedValue()),miss.roundedInt(),cooldown.get(),range.get(),weaponsOnly.get(),releaseShield.get(),resetSprint.get(),expanded));
    }
}
