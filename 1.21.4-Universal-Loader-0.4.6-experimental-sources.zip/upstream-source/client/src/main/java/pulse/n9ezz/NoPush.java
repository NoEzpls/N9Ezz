package pulse.n9ezz;
import pulse.module.*;
@ModuleInfo(a="No Push",b="Отменяет клиентское расталкивание локального игрока другими сущностями.",c=ModuleCategory.CHEATS)
public final class NoPush extends PvPModule {}
