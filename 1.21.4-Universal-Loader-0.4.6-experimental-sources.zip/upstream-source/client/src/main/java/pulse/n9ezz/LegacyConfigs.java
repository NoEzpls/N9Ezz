package pulse.n9ezz;

import com.google.gson.JsonObject;
import java.math.BigDecimal;
import java.util.*;
import pulse.module.ClientModule;
import pulse.settings.*;

/** Migrates the strict schema-1 snapshot format without changing old values. */
public final class LegacyConfigs {
    private static final Map<String,JsonObject> defaults=new LinkedHashMap<>();
    public static final List<String> ADDED=List.of("Auto Weapon","Auto Shield","Auto Gapple","Auto Heal","Auto Armor","Auto Refill","Auto Mace","Bow Release","Projectile Aim","Pearl Throw","W Tap","Target Strafe","Velocity","No Push","No Slow","Anti Web","Anti Bot","Team Check","Reach","Crystal Aura","Web Trap");
    private LegacyConfigs() {}
    /** Called while modules are fresh, before Pulse restores saved settings. */
    public static void remember(ClientModule module) {
        JsonObject settings=new JsonObject();
        try {for(var field:module.getClass().getFields()) {
            Object value=field.get(module);
            if(module instanceof PvPModule p&&!p.usesPower()&&value==p.power)continue;
            if(value instanceof SliderSetting s)slider(settings,s.name(),s.get());
            else if(value instanceof BooleanSetting s)flag(settings,s.name(),s.get());
            else if(value instanceof ModeSetting s)mode(settings,s.name(),Arrays.asList(s.values()).indexOf(s.selectedValue()));
        }}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        defaults.put(module.name(),settings);
    }
    public static JsonObject upgrade(JsonObject original,JsonObject reference) {
        JsonObject older=upgradeOld(original,reference);
        if(!older.has("schema")||!older.get("schema").isJsonPrimitive()||!older.getAsJsonPrimitive("schema").isNumber()
            ||older.get("schema").getAsBigDecimal().compareTo(BigDecimal.valueOf(3))!=0)return older;
        JsonObject root=older.deepCopy();root.addProperty("schema",4);root.addProperty("powerLevel","legit");
        var modules=root.getAsJsonObject("pulse").getAsJsonObject("modules");
        for(String name:ADDED){
            if(!modules.has(name)||!defaults.containsKey(name)||!defaults.get(name).has("Мощность (%)"))continue;
            var settings=modules.getAsJsonObject(name).getAsJsonObject("settings");
            if(!settings.has("Мощность (%)"))settings.add("Мощность (%)",defaults.get(name).get("Мощность (%)").deepCopy());
        }
        return root;
    }
    private static JsonObject upgradeOld(JsonObject original,JsonObject reference) {
        if(!original.has("schema")||!original.get("schema").isJsonPrimitive()||!original.getAsJsonPrimitive("schema").isNumber())return original;
        BigDecimal version=original.get("schema").getAsBigDecimal();
        if(version.compareTo(BigDecimal.ONE)!=0&&version.compareTo(BigDecimal.valueOf(2))!=0)return original;
        JsonObject root=upgrade(original).deepCopy();JsonObject modules=root.getAsJsonObject("pulse").getAsJsonObject("modules");
        JsonObject samples=reference.getAsJsonObject("pulse").getAsJsonObject("modules");
        for(String name:ADDED)if(!modules.has(name)){
            JsonObject m=module();m.add("settings",defaults.containsKey(name)?defaults.get(name).deepCopy():samples.getAsJsonObject(name).getAsJsonObject("settings").deepCopy());modules.add(name,m);
        }
        Map<String,List<String>> additions=Map.of(
            "Kill Aura",List.of("Поворот камеры","Плавность (%)","Угол поиска (°)","Подтверждение цели (мс)","Пауза после мыши (мс)","Обычное попадание"),
            "Triggerbot",List.of("Обычное попадание"),
            "Aim Bot",List.of("Угол поиска (°)","Пауза после мыши (мс)","Только при атаке","Только с оружием","Точка наведения"),
            "Hitboxes",List.of("Дальность расширения","Только текущая цель"));
        additions.forEach((name,keys)->{
            JsonObject settings=modules.getAsJsonObject(name).getAsJsonObject("settings");
            JsonObject source=defaults.getOrDefault(name,samples.getAsJsonObject(name).getAsJsonObject("settings"));
            for(String key:keys)if(!settings.has(key))settings.add(key,source.get(key).deepCopy());
        });
        root.addProperty("schema",3);return root;
    }
    public static JsonObject upgrade(JsonObject original) {
        if(!original.has("schema")||!original.get("schema").isJsonPrimitive()||!original.getAsJsonPrimitive("schema").isNumber()
            ||original.get("schema").getAsBigDecimal().compareTo(BigDecimal.ONE)!=0)return original;
        JsonObject root=original.deepCopy();JsonObject modules=root.getAsJsonObject("pulse").getAsJsonObject("modules");
        JsonObject aura=modules.getAsJsonObject("Kill Aura").getAsJsonObject("settings");JsonObject trigger=modules.getAsJsonObject("Triggerbot").getAsJsonObject("settings");
        slider(aura,"Дальность (блоки)",3);mode(aura,"Приоритет цели",0);flag(aura,"Удерживать цель",true);slider(trigger,"Подтверждение цели (мс)",50);
        for(JsonObject s:new JsonObject[]{aura,trigger}){flag(s,"Невидимые игроки",true);flag(s,"Игроки без брони",true);flag(s,"Только с оружием",false);slider(s,"Заряд удара (%)",100);flag(s,"Отпускать свой щит",false);flag(s,"Сбрасывать спринт",true);}
        JsonObject critical=module();mode(critical.getAsJsonObject("settings"),"Режим критов",0);flag(critical.getAsJsonObject("settings"),"Автопрыжок",false);
        JsonObject shield=module();flag(shield.getAsJsonObject("settings"),"Вернуть оружие",true);slider(shield.getAsJsonObject("settings"),"Задержка смены (мс)",50);
        if(!modules.has("Criticals"))modules.add("Criticals",critical);if(!modules.has("Shield Breaker"))modules.add("Shield Breaker",shield);root.addProperty("schema",2);return root;
    }
    private static JsonObject module(){JsonObject m=new JsonObject();m.addProperty("enabled",false);m.addProperty("bindKey",0);JsonObject s=new JsonObject();slider(s,"Мощность (%)",100);m.add("settings",s);return m;}
    private static void slider(JsonObject s,String n,Number v){number(s,n,"slider",v);}private static void mode(JsonObject s,String n,Number v){number(s,n,"mode",v);}
    private static void number(JsonObject s,String n,String t,Number v){if(s.has(n))return;JsonObject o=new JsonObject();o.addProperty("type",t);o.addProperty("value",v);s.add(n,o);}
    private static void flag(JsonObject s,String n,boolean v){if(s.has(n))return;JsonObject o=new JsonObject();o.addProperty("type","boolean");o.addProperty("value",v);s.add(n,o);}
}
