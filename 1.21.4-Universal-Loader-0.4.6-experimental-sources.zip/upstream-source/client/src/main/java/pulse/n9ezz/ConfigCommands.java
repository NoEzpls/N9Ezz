package pulse.n9ezz;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import java.util.stream.Stream;

public final class ConfigCommands {
    private ConfigCommands() {}
    public static void install() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher,registries)->dispatcher.register(
            ClientCommandManager.literal("cfg")
                .executes(c->{c.getSource().sendFeedback(Text.literal("/cfg mode legit|hight|extra — базовая мощность; /cfg create <название> — сохранить; /cfg load <название> — загрузить; /cfg list — список; /cfg pvp — сетевая настройка; /cfg combat — диагностика"));return 1;})
                .then(ClientCommandManager.literal("mode")
                    .executes(c->{c.getSource().sendFeedback(Text.literal(PowerModes.diagnostics()));return 1;})
                    .then(ClientCommandManager.argument("level",StringArgumentType.word())
                        .suggests((c,b)->CommandSource.suggestMatching(new String[]{"legit","hight","extra"},b))
                        .executes(c->mode(c.getSource(),StringArgumentType.getString(c,"level")))))
                .then(ClientCommandManager.literal("pvp").executes(c->{
                    NetworkPreset.apply();c.getSource().sendFeedback(Text.literal("Сетевая настройка применена. Обычные попадания и полный заряд; изменения физики выключены. Проверенного обхода конкретного античита нет."));return 1;
                }))
                .then(ClientCommandManager.literal("combat").executes(c->{
                    c.getSource().sendFeedback(Text.literal(PowerModes.diagnostics()));
                    c.getSource().sendFeedback(Text.literal(Attacks.diagnostics()));
                    c.getSource().sendFeedback(Text.literal(NetworkPreset.conflicts()));return 1;
                }))
                .then(ClientCommandManager.literal("create").then(ClientCommandManager.argument("name",StringArgumentType.greedyString())
                    .executes(c->create(c.getSource(),StringArgumentType.getString(c,"name")))))
                .then(ClientCommandManager.literal("load").then(ClientCommandManager.argument("name",StringArgumentType.greedyString())
                    .suggests((c,b)->CommandSource.suggestMatching(Stream.concat(PowerProfiles.ALL.stream().map(PowerProfiles.Profile::name),ConfigSnapshots.names().stream()),b))
                    .executes(c->load(c.getSource(),StringArgumentType.getString(c,"name")))))
                .then(ClientCommandManager.literal("list").executes(c->{
                    c.getSource().sendFeedback(Text.literal("Профили: "+String.join(", ",PowerProfiles.ALL.stream().map(PowerProfiles.Profile::name).toList())));
                    c.getSource().sendFeedback(Text.literal("Конфиги: "+(ConfigSnapshots.names().isEmpty()?"нет":String.join(", ",ConfigSnapshots.names()))));return 1;
                }))));
    }
    private static int mode(FabricClientCommandSource source,String value){
        try{PowerModes.select(PowerCurve.Level.parse(value));source.sendFeedback(Text.literal(PowerModes.diagnostics()));return 1;}
        catch(Exception e){source.sendError(Text.literal("Не удалось сменить уровень: "+e.getMessage()));return 0;}
    }
    private static int create(FabricClientCommandSource source,String name) {
        try { String saved=ConfigSnapshots.create(name);source.sendFeedback(Text.literal("Конфиг «"+saved+"» сохранён."));return 1; }
        catch(Exception e) {source.sendError(Text.literal("Не удалось сохранить: "+e.getMessage()));return 0;}
    }
    private static int load(FabricClientCommandSource source,String name) {
        try {
            String normalized=ConfigSnapshots.name(name);
            var profile=PowerProfiles.find(normalized);
            if(profile!=null) PowerProfiles.apply(profile);else ConfigSnapshots.load(normalized);
            source.sendFeedback(Text.literal((profile==null?"Конфиг «":"Профиль «")+normalized+"» загружен."));return 1;
        } catch(Exception e) {source.sendError(Text.literal("Не удалось загрузить: "+e.getMessage()));return 0;}
    }
}
