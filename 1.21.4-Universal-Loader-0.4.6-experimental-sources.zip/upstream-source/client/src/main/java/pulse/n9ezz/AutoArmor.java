package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Auto Armor",b="Надевает более прочный комплект из инвентаря, по одному предмету за операцию.",c=ModuleCategory.CHEATS)
public final class AutoArmor extends PvPModule {
    public final SliderSetting delay=new SliderSetting("Пауза операций (мс)",250,100,1000,50);
    public final BooleanSetting preserveElytra=new BooleanSetting("Сохранять элитру",true);
    private long next;
    private int source=-1,buffer=-1,destination=-1,stage;
    private ItemStack originalBuffer=ItemStack.EMPTY,better=ItemStack.EMPTY,oldArmor=ItemStack.EMPTY;
    private void clear(){source=buffer=destination=-1;stage=0;originalBuffer=better=oldArmor=ItemStack.EMPTY;}
    @Override public void onDisable(){clear();next=0;super.onDisable();}
    @EventHandler public void tick(ClientTickEvent e) {
        long now=System.nanoTime();if(!powered()||!CombatInventory.available()||CombatInventory.busy()||client().player.isUsingItem()||now<next)return;
        var handler=client().player.playerScreenHandler;
        if(source>=0){
            var inv=client().player.getInventory();
            if(!ItemStack.areEqual(inv.getStack(source),originalBuffer)||!ItemStack.areEqual(inv.getStack(buffer),stage==0?better:oldArmor)){clear();return;}
            if(stage==0){
                if(!ItemStack.areEqual(handler.getSlot(destination).getStack(),oldArmor)){if(CombatInventory.swap(source,buffer))clear();return;}
                if(CombatInventory.click(destination,buffer,SlotActionType.SWAP)){stage=1;next=now+actionDelay(delay.get(),50);}return;
            }
            if(CombatInventory.swap(source,buffer)){clear();next=now+actionDelay(delay.get(),50);}return;
        }
        for(int armor=5;armor<=8;armor++){
            ItemStack held=handler.getSlot(armor).getStack();
            if(preserveElytra.get()&&held.isOf(net.minecraft.item.Items.ELYTRA))continue;
            int best=-1;double score=CombatItems.armorScore(held);
            for(int i=0;i<36;i++){var s=client().player.getInventory().getStack(i);double rank=CombatItems.armorScore(s);if(CombatItems.armorSlot(s)==armor&&rank>score+.0001){score=rank;best=i;}}
            if(best<0)continue;
            if(best<9){if(CombatInventory.click(armor,best,SlotActionType.SWAP))next=now+actionDelay(delay.get(),50);return;}
            // Buffer then equip then restore. SWAP works with a full inventory and never holds a cursor stack.
            int empty=CombatInventory.findHotbar(ItemStack::isEmpty);
            int hotbar=empty>=0?empty:(client().player.getInventory().getSelectedSlot()+1)%9;
            var inv=client().player.getInventory();var original=inv.getStack(hotbar).copy();var candidate=inv.getStack(best).copy();
            if(CombatInventory.swap(best,hotbar)){source=best;buffer=hotbar;destination=armor;originalBuffer=original;better=candidate;oldArmor=held.copy();stage=0;next=now+actionDelay(delay.get(),50);}
            return;
        }
    }
}
