package pulse.n9ezz;

import java.util.Locale;

/** Shared base strength. Percentages are never rewritten when the level changes. */
public final class PowerCurve {
    public enum Level {
        LEGIT("Legit",1), HIGHT("Hight",2.5), EXTRA("Extra",10);
        private final String label;
        private final double multiplier;
        Level(String label,double multiplier){this.label=label;this.multiplier=multiplier;}
        public String label(){return label;}
        public double multiplier(){return multiplier;}
        public static Level parse(String name){
            if(name==null)throw new IllegalArgumentException("Уровень: legit, hight или extra");
            return switch(name.strip().toLowerCase(Locale.ROOT)){
                case "legit" -> LEGIT;
                case "hight", "high" -> HIGHT;
                case "extra" -> EXTRA;
                default -> throw new IllegalArgumentException("Уровень: legit, hight или extra");
            };
        }
    }
    private PowerCurve(){}
    public static double strength(double percent,Level level){return CombatMath.clamp(percent,0,100)/100*level.multiplier();}
    public static int cps(int selected,double strength){return (int)Math.round(CombatMath.clamp(selected*strength,1,20));}
    public static long delay(double milliseconds,double strength,double minimumMs){
        if(strength<=0)return Long.MAX_VALUE;
        return Math.round(Math.max(minimumMs,Math.max(0,milliseconds)/strength)*1_000_000L);
    }
    public static int ticks(int selected,double strength,int minimum){
        return strength<=0?Integer.MAX_VALUE:(int)Math.max(minimum,Math.ceil(selected/strength));
    }
    public static double blend(double original,double selected,double strength,double min,double max){
        return CombatMath.clamp(original+(selected-original)*Math.max(0,strength),min,max);
    }
}
