package pulse.n9ezz;

/** Time-based angular motion with velocity easing and bounded turn rate. */
public final class AimSmoothing {
    public record Turn(double yaw,double pitch) {}
    private double yawVelocity,pitchVelocity;
    public void reset() {yawVelocity=0;pitchVelocity=0;}
    public Turn advance(double yawError,double pitchError,double seconds,double power,double smoothing) {
        double dt=CombatMath.clamp(seconds,0,.1);
        double strength=CombatMath.clamp(power,0,1000)/100;
        double tau=(.1+.5*CombatMath.clamp(smoothing,1,100)/100)/Math.sqrt(Math.max(1,strength));
        double maximum=Math.min(1080,25+110*strength);
        double[] yaw=axis(yawError,yawVelocity,dt,maximum,tau);
        double[] pitch=axis(pitchError,pitchVelocity,dt,maximum*.7,tau);
        yawVelocity=yaw[1];pitchVelocity=pitch[1];
        return new Turn(yaw[0],pitch[0]);
    }
    private static double[] axis(double error,double velocity,double dt,double maximum,double tau) {
        if(Math.abs(error)<.08 || dt==0) return new double[]{0,dt==0?velocity:0};
        double wanted=CombatMath.clamp(error*2/tau,-maximum,maximum);
        double response=3/tau;
        double decay=Math.exp(-response*dt);
        double change=wanted*dt+(velocity-wanted)*(1-decay)/response;
        double next=wanted+(velocity-wanted)*decay;
        if(Math.signum(change)==Math.signum(error) && Math.abs(change)>Math.abs(error)) return new double[]{error,0};
        return new double[]{change,next};
    }
}
