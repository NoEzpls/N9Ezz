package pulse.n9ezz;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import pulse.events.ClientTickEvent;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="Web Trap",b="Ставит паутину в ноги боевой цели из хотбара, проверяя опору, видимость и дальность.",c=ModuleCategory.CHEATS)
public final class WebTrap extends PvPModule {
    public final SliderSetting range=new SliderSetting("Дальность (блоки)",3,1,4.5f,.1f);
    public final SliderSetting delay=new SliderSetting("Пауза установки (мс)",400,150,1500,50);
    private long next;
    @EventHandler public void tick(ClientTickEvent e) {
        long now=System.nanoTime();var t=CombatTargets.current();
        if(!powered()||!Targeting.canAct()||t==null||ConsumableUse.active()||now<next||!CombatInventory.available()||Targeting.realDistance(t)>range.get())return;
        BlockPos pos=t.getBlockPos();if(!client().world.getBlockState(pos).isReplaceable())return;
        int slot=CombatInventory.findHotbar(s->s.isOf(Items.COBWEB));if(slot<0)return;
        for(Direction direction:Direction.values()) {
            var support=pos.offset(direction);var state=client().world.getBlockState(support);if(state.isReplaceable()||state.getCollisionShape(client().world,support).isEmpty())continue;
            var face=direction.getOpposite();Vec3d point=Vec3d.ofCenter(support).add(Vec3d.of(face.getVector()).multiply(.5));
            if(client().player.getEyePos().distanceTo(point)>Math.min(range.get(),client().player.getBlockInteractionRange())||!Targeting.visible(point))continue;
            if(!CombatInventory.select(this,70,slot))return;
            try{var result=client().interactionManager.interactBlock(client().player,Hand.MAIN_HAND,new BlockHitResult(point,face,support,false));if(result.isAccepted())client().player.swingHand(Hand.MAIN_HAND);next=now+actionDelay(delay.get(),50);}
            finally{CombatInventory.release(this,true);}return;
        }
    }
}
