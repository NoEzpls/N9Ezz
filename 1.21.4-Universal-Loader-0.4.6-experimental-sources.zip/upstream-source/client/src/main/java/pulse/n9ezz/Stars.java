package pulse.n9ezz;

import java.awt.Color;
import pulse.module.ClientModule;
import pulse.module.ModuleCategory;
import pulse.render.Renderer2D;
import pulse.gui.core.GuiEntry;
import pulse.gui.modules.ModulesTab;
import pulse.gui.core.PulseClickGuiScreen;
import pulse.render.font.FontManager;
import pulse.render.font.FontRenderer;
import net.minecraft.client.MinecraftClient;

public final class Stars {
    private static final SectionTransition transition=new SectionTransition();
    private static ModulesTab buttonTab;
    private static float buttonX,buttonY;
    private static long confirmationUntil;
    private static boolean profileOpen,modeOpen;
    private static float profileX,hideX,modeX,modeY;
    private static final float BUTTON_WIDTH=142,BUTTON_HEIGHT=24;
    private Stars() {}
    private static boolean selected(ModulesTab tab) {
        return tab.g()==ModuleCategory.CHEATS && MinecraftClient.getInstance().currentScreen instanceof PulseClickGuiScreen gui && gui.a()==tab;
    }
    public static void beginFrame() {
        var screen=MinecraftClient.getInstance().currentScreen;
        boolean active=screen instanceof PulseClickGuiScreen gui && gui.a() instanceof ModulesTab tab && tab.g()==ModuleCategory.CHEATS;
        transition.update(active,System.nanoTime());
        buttonTab=null;
        if(!active){profileOpen=false;modeOpen=false;}
    }
    public static void menuClosed() {
        transition.reset();
        buttonTab=null;
        confirmationUntil=0;
        profileOpen=false;
        modeOpen=false;
    }
    public static Color sectionColor(Color original) {
        double p=transition.value();
        return new Color((int)Math.round(original.getRed()+(40-original.getRed())*p),
            (int)Math.round(original.getGreen()+(41-original.getGreen())*p),
            (int)Math.round(original.getBlue()+(46-original.getBlue())*p),original.getAlpha());
    }
    public static void section(Object matrix,Renderer2D renderer,float x,float y,float width,float height) {
        stars(matrix,renderer,x+8,y+8,width-16,height-16,(float)transition.value(),48);
    }
    public static void drawButton(ModulesTab tab,Object matrix,Renderer2D renderer,float x,float y,int mouseX,int mouseY) {
        if(!selected(tab) || tab.r()) {profileOpen=false;modeOpen=false;return;}
        buttonTab=tab;
        positions(x,y);
        boolean hover=inside(mouseX,mouseY);
        renderer.a(buttonX,buttonY,BUTTON_WIDTH,BUTTON_HEIGHT,6,hover ? new Color(86,80,112) : new Color(62,60,75),matrix);
        FontRenderer font=FontManager.b[Math.min(14,FontManager.b.length-1)];
        String text=System.nanoTime()<confirmationUntil ? "Читы отключены" : "Отключить все читы";
        if(font!=null) font.a(text,buttonX+(BUTTON_WIDTH-font.a(text))/2,buttonY+5,new Color(232,230,242),matrix);
        toolbarButton(matrix,renderer,font,profileX,128,"Профиль: "+PowerProfiles.selected(),mouseX,mouseY);
        toolbarButton(matrix,renderer,font,hideX,90,"Скрыть всё",mouseX,mouseY);
        boolean modeHover=mouseX>=modeX&&mouseX<modeX+106&&mouseY>=modeY&&mouseY<modeY+18;
        renderer.a(modeX,modeY,106,18,5,modeHover?new Color(86,80,112):new Color(62,60,75),matrix);
        if(font!=null)font.a("Уровень: "+PowerModes.label(),modeX+5,modeY+2,new Color(232,230,242),matrix);
        if(modeOpen){
            float top=modeY+22;
            renderer.a(modeX-3,top-3,112,60,6,new Color(38,39,45),matrix);
            for(var level:PowerCurve.Level.values()){
                float row=top+level.ordinal()*18;
                if(mouseX>=modeX&&mouseX<modeX+106&&mouseY>=row&&mouseY<row+18)
                    renderer.a(modeX,row,106,18,3,new Color(80,76,103),matrix);
                if(font!=null)font.a(level.label()+" ×"+level.multiplier(),modeX+6,row+3,
                    level==PowerModes.current()?new Color(180,165,255):new Color(232,230,242),matrix);
            }
        }
        if(profileOpen) {
            float top=buttonY-PowerProfiles.ALL.size()*18-4;
            renderer.a(profileX-3,top-3,158,PowerProfiles.ALL.size()*18+6,6,new Color(38,39,45),matrix);
            for(int i=0;i<PowerProfiles.ALL.size();i++) {
                String name=PowerProfiles.ALL.get(i).name();float row=top+i*18;
                if(mouseX>=profileX && mouseX<profileX+152 && mouseY>=row && mouseY<row+18)
                    renderer.a(profileX,row,152,18,3,new Color(80,76,103),matrix);
                if(font!=null) font.a(name,profileX+6,row+3,name.equals(PowerProfiles.selected())?new Color(180,165,255):new Color(232,230,242),matrix);
            }
        }
    }
    private static void positions(float x,float y) {
        buttonX=x+PulseClickGuiScreen.d()-19-BUTTON_WIDTH;
        buttonY=y+PulseClickGuiScreen.e()-19-BUTTON_HEIGHT;
        profileX=x+18;hideX=x+152;
        modeX=x+145;modeY=y+14;
    }
    private static void toolbarButton(Object matrix,Renderer2D renderer,FontRenderer font,float x,float width,String text,int mx,int my) {
        boolean hover=mx>=x && mx<x+width && my>=buttonY && my<buttonY+BUTTON_HEIGHT;
        renderer.a(x,buttonY,width,BUTTON_HEIGHT,6,hover?new Color(86,80,112):new Color(62,60,75),matrix);
        if(font!=null) {
            while(text.length()>1 && font.a(text)>width-10) text=text.substring(0,text.length()-2)+"…";
            font.a(text,x+(width-font.a(text))/2,buttonY+5,new Color(232,230,242),matrix);
        }
    }
    private static boolean inside(int x,int y) {
        return x>=buttonX && x<buttonX+BUTTON_WIDTH && y>=buttonY && y<buttonY+BUTTON_HEIGHT;
    }
    public static boolean clickButton(ModulesTab tab,float x,float y,int mouseX,int mouseY) {
        if(!selected(tab) || tab.r()) return false;
        positions(x,y);
        PulseClickGuiScreen gui=(PulseClickGuiScreen)MinecraftClient.getInstance().currentScreen;
        if(modeOpen){
            float top=modeY+22;
            if(mouseX>=modeX&&mouseX<modeX+106&&mouseY>=top&&mouseY<top+54){
                if(gui.clickBtn==0){PowerModes.select(PowerCurve.Level.values()[(int)((mouseY-top)/18)]);modeOpen=false;}
                return true;
            }
        }
        if(mouseX>=modeX&&mouseX<modeX+106&&mouseY>=modeY&&mouseY<modeY+18){
            if(gui.clickBtn==0){modeOpen=!modeOpen;profileOpen=false;}return true;
        }
        if(modeOpen){modeOpen=false;return true;}
        if(profileOpen) {
            float top=buttonY-PowerProfiles.ALL.size()*18-4;
            if(mouseX>=profileX && mouseX<profileX+152 && mouseY>=top && mouseY<top+PowerProfiles.ALL.size()*18) {
                if(gui.clickBtn==0) {PowerProfiles.apply(PowerProfiles.ALL.get((int)((mouseY-top)/18)));tab.k();profileOpen=false;}
                return true;
            }
        }
        if(mouseY>=buttonY && mouseY<buttonY+BUTTON_HEIGHT) {
            if(mouseX>=profileX && mouseX<profileX+128) {if(gui.clickBtn==0){profileOpen=!profileOpen;modeOpen=false;}return true;}
            if(mouseX>=hideX && mouseX<hideX+90) {if(gui.clickBtn==0) InterfaceMode.hide();return true;}
            if(inside(mouseX,mouseY)) {
                if(gui.clickBtn==0) {N9Ezz.disableAll();tab.k();profileOpen=false;confirmationUntil=System.nanoTime()+1_500_000_000L;}
                return true;
            }
        }
        if(profileOpen) {profileOpen=false;return true;}
        return false;
    }
    public static Color label(Color original,GuiEntry entry) {
        return entry instanceof ModulesTab.ModuleEntry module && module.i()==ModuleCategory.CHEATS ? new Color(164,163,181) : original;
    }
    public static float positionX(float x,ClientModule module) {
        return module!=null && module.category()==ModuleCategory.CHEATS ? Math.max(6,x) : x;
    }
    public static void paint(ClientModule module,Object matrix,Renderer2D renderer,float x,float y,float width,float height,float alpha) {
        if(module==null || module.category()!=ModuleCategory.CHEATS || alpha<0.03f) return;
        float scale=Math.max(0,Math.min(1,alpha));
        float left=x+width*(1-scale)/2,top=y+height*(1-scale)/2,w=width*scale,h=height*scale;
        float progress=(float)transition.value();
        Color gray=new Color(40,41,46,Math.min(255,(int)(244*scale*progress)));
        renderer.a(left,top,w,h,9*scale,gray,matrix);
        stars(matrix,renderer,left+7*scale,top+7*scale,w-14*scale,h-14*scale,scale*progress,24);
    }
    private static void stars(Object matrix,Renderer2D renderer,float x,float y,float width,float height,float alpha,int count) {
        if(alpha<0.005f || width<=0 || height<=0) return;
        double time=System.nanoTime()/1_000_000_000.0;
        for(int i=0;i<count;i++) {
            float sx=x+((i*0.61803398875f)%1)*width;
            float sy=y+((i*0.41421356237f+0.2f)%1)*height+(1-alpha)*5;
            float size=(i%5==0 ? 1.9f : 1.1f);
            int a=(int)((40+45*(0.5+0.5*Math.sin(time*.9+i)))*alpha);
            Color star=new Color(216,221,235,a);
            renderer.a(sx-size/2,sy-size/2,size,size,star,matrix);
            if(i%5==0) {
                renderer.a(sx-size*1.1f,sy-.2f,size*2.2f,.4f,star,matrix);
                renderer.a(sx-.2f,sy-size*1.1f,.4f,size*2.2f,star,matrix);
            }
        }
    }
}
