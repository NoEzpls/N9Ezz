package pulse.n9ezz;

/** One hotbar owner, with priority, expiry and respect for manual selection. */
public final class SlotOwnership {
    private Object owner;
    private int priority, original=-1, selected=-1, refreshed;
    public boolean request(Object caller,int rank,int slot,int current,int tick) {
        if(slot<0||slot>8||caller==null) return false;
        if(owner!=null&&current!=selected) {clear();return false;}
        if(owner!=null&&owner!=caller&&rank<=priority) return false;
        if(owner==null) original=current;
        owner=caller;priority=rank;selected=slot;refreshed=tick;return true;
    }
    public boolean owns(Object caller) {return owner==caller;}
    public boolean active() {return owner!=null;}
    public boolean expired(int tick) {return owner!=null&&tick-refreshed>2;}
    public int release(Object caller,int current,boolean restore) {
        if(owner!=caller) return -1;
        int slot=restore&&current==selected?original:-1;clear();return slot;
    }
    public int cancel(int current) {return release(owner,current,true);}
    public void clear() {owner=null;priority=0;original=selected=-1;refreshed=0;}
}
