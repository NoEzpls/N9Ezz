package pulse.n9ezz.mixin;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pulse.n9ezz.*;
@Mixin(ClientPlayerInteractionManager.class)
public abstract class AttackCallbackMixin {
    @Inject(method="attackEntity",at=@At("HEAD"))
    private void n9ezzUnshield(PlayerEntity player,Entity target,CallbackInfo ci){CombatDispatch.attacked(player);if(N9Ezz.AUTOSHIELD!=null&&N9Ezz.AUTOSHIELD.isEnabled())N9Ezz.AUTOSHIELD.attacked();}
    @Inject(method="attackEntity",at=@At("TAIL"))
    private void n9ezzAttack(PlayerEntity player,Entity target,CallbackInfo ci){CombatTargets.attacked(target);}
}
