package pulse.n9ezz;
import net.minecraft.entity.player.PlayerEntity;
import pulse.module.*;
@ModuleInfo(a="Team Check",b="Исключает из автоматических атак игроков своей команды scoreboard.",c=ModuleCategory.CHEATS)
public final class TeamCheck extends PvPModule {
    @Override protected boolean usesPower(){return false;}
    public boolean allowed(PlayerEntity player){return client().player==null||!client().player.isTeammate(player);}
}
