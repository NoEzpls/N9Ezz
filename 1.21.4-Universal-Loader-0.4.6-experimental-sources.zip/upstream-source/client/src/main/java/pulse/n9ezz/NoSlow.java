package pulse.n9ezz;
import pulse.module.*;
import pulse.settings.*;
@ModuleInfo(a="No Slow",b="Уменьшает замедление обычного ввода во время использования предмета.",c=ModuleCategory.CHEATS)
public final class NoSlow extends PvPModule {
    @Override protected boolean usesPower(){return true;}
    public final SliderSetting speed=new SliderSetting("Движение (%)",80,20,100,5);
    public float multiplier(float vanilla){return (float)PowerCurve.blend(vanilla,Math.max(vanilla,speed.get()/100),strength(),vanilla,1);}
}
