package pulse.n9ezz;

/** Numerical combat helpers, kept independent of Minecraft for verification. */
public final class PvPMath {
    private PvPMath() {}
    public static double mouseStep(double motion,double step,double error) {
        if(!Double.isFinite(motion)||!Double.isFinite(step)||step<=0)return 0;
        double q=Math.copySign(Math.floor(Math.abs(motion)/step)*step,motion);
        if(Math.signum(q)==Math.signum(error)&&Math.abs(q)>Math.abs(error))q=Math.copySign(Math.floor(Math.abs(error)/step)*step,error);
        return q;
    }
    public static double ballisticPitch(double horizontal,double height,double speed,double gravity) {
        if(horizontal<1e-6||speed<=0||gravity<=0)return Double.NaN;
        double v2=speed*speed,discriminant=v2*v2-gravity*(gravity*horizontal*horizontal+2*height*v2);
        return discriminant<0?Double.NaN:Math.atan((v2-Math.sqrt(discriminant))/(gravity*horizontal));
    }
    public static double blend(double original,double selected,double power) {return original+(selected-original)*CombatMath.clamp(power,0,100)/100;}
    public static double armorDamage(double damage,double armor,double toughness) {
        double reduced=CombatMath.clamp(armor-damage/(2+toughness/4),armor*.2,20);return damage*(1-reduced/25);
    }
}
