package pulse.n9ezz.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ClientPlayerInteractionManager.class)
public interface SlotSyncAccessor {
    @Invoker("syncSelectedSlot") void n9ezzSyncSelectedSlot();
}
