package pulse.n9ezz;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.util.math.Box;
import net.minecraft.world.debug.gizmo.GizmoDrawing;

/** Vanilla gizmos keep drawing and target acquisition on the same expanded box. */
public final class HitboxVisuals {
    private HitboxVisuals() {}
    public static void install() { WorldRenderEvents.END_EXTRACTION.register(HitboxVisuals::extract); }
    public static void extract(WorldExtractionContext context) {
        Hitboxes module=N9Ezz.HITBOXES;
        if(module==null || !module.isEnabled() || !module.outline.get() || InterfaceMode.hidden() || context.world()==null) return;
        float delta=context.tickCounter().getTickProgress(false);
        DrawStyle style=DrawStyle.stroked(module.color.rgb()|0xFF000000,module.lineWidth.get());
        try(var scope=context.worldRenderer().startDrawingGizmos()) {
            for(var player:context.world().getPlayers()) {
                if(!Targeting.eligible(player)) continue;
                Box box=Targeting.box(player).offset(player.getLerpedPos(delta).subtract(player.getEntityPos()));
                if(context.frustum().isVisible(box)) GizmoDrawing.box(box,style);
            }
        }
    }
}
