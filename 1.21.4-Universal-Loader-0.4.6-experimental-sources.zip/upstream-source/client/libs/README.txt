Place your original Pulse visuals JAR here as Pulse-visuals-1.21.11-BETA.jar.
The original JAR is not part of this source archive.
