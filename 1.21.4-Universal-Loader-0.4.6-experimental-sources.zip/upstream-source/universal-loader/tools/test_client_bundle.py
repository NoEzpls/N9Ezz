#!/usr/bin/env python3
"""Black-box checks for the pinned Java updater; never executes mod classes."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import tempfile
import zipfile

HOST_SHA = "2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb"
OVERLAY_SHA = "80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206"
OUTPUT_SHA = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--java", required=True)
    ap.add_argument("--classpath", required=True)
    ap.add_argument("--host", type=Path, required=True)
    ap.add_argument("--overlay", type=Path, required=True)
    ap.add_argument("--merged", type=Path, required=True)
    args = ap.parse_args()
    assert sha(args.host) == HOST_SHA and sha(args.overlay) == OVERLAY_SHA
    assert sha(args.merged) == OUTPUT_SHA
    tests = 1
    with zipfile.ZipFile(args.host) as host, zipfile.ZipFile(args.merged) as merged:
        names = merged.namelist()
        assert len(names) == len(set(names))
        assert set(host.namelist()) <= set(names)
        added = set(names) - set(host.namelist())
        assert added == {"pulse/n9ezz/TargetGeometry.class", "pulse/n9ezz/TargetGeometry$Point.class", "pulse/n9ezz/TargetGeometry$Bounds.class"}
        tests += 1
        for name in host.namelist():
            if not name.startswith("pulse/n9ezz/"):
                assert host.read(name) == merged.read(name), name
        tests += 1
        assert merged.read("fabric.mod.json").count(b'"n9ezz.mixins.json"') == 1
        assert merged.read("n9ezz.mixins.json") == host.read("n9ezz.mixins.json")
        tests += 1
    prefix = [args.java, "-cp", args.classpath, "MergeBundledClient"]
    with tempfile.TemporaryDirectory(prefix="n9ezz-client-updater-") as directory:
        temp = Path(directory)
        second = temp / "second.jar"
        result = subprocess.run(prefix + [str(args.host), str(args.overlay), str(second)], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        assert sha(second) == OUTPUT_SHA
        tests += 1
        rejected = subprocess.run(prefix + [str(args.host), str(args.overlay), str(second)], capture_output=True, text=True)
        assert rejected.returncode != 0 and "new paths" in rejected.stderr
        assert sha(second) == OUTPUT_SHA
        tests += 1
        wrong_overlay = temp / "wrong-overlay.jar"
        wrong_overlay.write_bytes(args.overlay.read_bytes() + b"mutation")
        rejected_output = temp / "rejected.jar"
        rejected = subprocess.run(prefix + [str(args.host), str(wrong_overlay), str(rejected_output)], capture_output=True, text=True)
        assert rejected.returncode != 0 and "SHA256 mismatch" in rejected.stderr
        assert not rejected_output.exists()
        tests += 1
    assert sha(args.host) == HOST_SHA and sha(args.overlay) == OVERLAY_SHA
    tests += 1
    print(f"PASS: {tests} bundled-client updater checks; no mod code executed")


if __name__ == "__main__":
    main()
