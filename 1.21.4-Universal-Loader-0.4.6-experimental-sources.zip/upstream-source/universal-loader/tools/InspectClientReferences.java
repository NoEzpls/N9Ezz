import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Read-only review aid. Does not load or execute user classes. */
public final class InspectClientReferences {
    public static void main(String[] args) throws Exception {
        try (ZipFile zip = new ZipFile(args[0])) {
            var entries=zip.entries();
            while(entries.hasMoreElements()) {
                var e=entries.nextElement();
                if(!e.getName().endsWith(".class") || e.getName().startsWith("pulse/n9ezz/")) continue;
                ClassNode n=new ClassNode();new ClassReader(zip.getInputStream(e).readAllBytes()).accept(n,0);
                for(MethodNode m:n.methods) for(AbstractInsnNode i:m.instructions) {
                    if(i instanceof MethodInsnNode c && c.owner.startsWith("pulse/n9ezz/")) System.out.println(n.name+"."+m.name+m.desc+" CALL "+c.owner+"."+c.name+c.desc);
                    if(i instanceof FieldInsnNode c && c.owner.startsWith("pulse/n9ezz/")) System.out.println(n.name+"."+m.name+m.desc+" FIELD "+c.owner+"."+c.name+":"+c.desc);
                    if(i instanceof LdcInsnNode c && c.cst instanceof String s && (s.contains("n9ezz") || s.startsWith("m"))) System.out.println(n.name+"."+m.name+m.desc+" STRING "+s);
                }
            }
        }
    }
}
