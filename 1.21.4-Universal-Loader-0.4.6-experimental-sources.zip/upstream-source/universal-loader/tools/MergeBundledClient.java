import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.commons.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.CheckClassAdapter;

/**
 * Updates only the existing N9Ezz class subsystem of the pinned 1.5.3 bundle.
 * Does not run MergeClient, insert host hooks, execute mod code or change metadata.
 * Compile with Java 21 and the pinned ASM dependencies documented alongside this file.
 */
public final class MergeBundledClient implements Opcodes {
    private static final String PREFIX="pulse/n9ezz/";
    private static final String HOST_SHA="2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb";
    private static final String OVERLAY_SHA="80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206";
    private static final List<String> HELPERS=List.of("CombatMath","MissSequence","AttackClock","Targeting","Attacks","SectionTransition");
    private static final List<String> MODULES=List.of("KillAura","Triggerbot","AimBot","Hitboxes","AutoTotem","IncreasedDamage","Friends","Criticals","ShieldBreaker","AutoWeapon","AutoShield","AutoGapple","AutoHeal","AutoArmor","AutoRefill","AutoMace","BowRelease","ProjectileAim","PearlThrow","WTap","TargetStrafe","Velocity","NoPush","NoSlow","AntiWeb","AntiBot","TeamCheck","Reach","CrystalAura","WebTrap");
    private static final Set<String> NEW_CLASSES=Set.of(PREFIX+"TargetGeometry.class",PREFIX+"TargetGeometry$Bounds.class",PREFIX+"TargetGeometry$Point.class");
    private record Maps(Map<String,String> classes,Map<String,String> fields,Map<String,String> methods) {}

    public static void main(String[] args) throws Exception {
        if(args.length!=3) throw new IllegalArgumentException("host.jar overlay.jar output.jar");
        Path host=Path.of(args[0]).toAbsolutePath().normalize(),overlay=Path.of(args[1]).toAbsolutePath().normalize(),output=Path.of(args[2]).toAbsolutePath().normalize();
        if(output.equals(host)||output.equals(overlay)||Files.exists(output)||Files.exists(Path.of(output+".report.txt"))) throw new IllegalArgumentException("Output and report must be new paths; neither input is modified");
        requireHash(host,HOST_SHA);requireHash(overlay,OVERLAY_SHA);
        TreeMap<String,byte[]> original=readZip(host),addon=readZip(overlay);
        require(Arrays.equals(required(original,"n9ezz.mixins.json"),required(addon,"n9ezz.mixins.json")),"Mixin configuration changed");
        require(new String(required(original,"META-INF/MANIFEST.MF"),StandardCharsets.UTF_8).contains("Fabric-Mapping-Namespace: intermediary"),"Host namespace must be intermediary");
        require(new String(required(addon,"META-INF/MANIFEST.MF"),StandardCharsets.UTF_8).contains("Fabric-Mapping-Namespace: intermediary"),"Overlay namespace must be intermediary");
        require(original.keySet().stream().noneMatch(n->n.matches("(?i)META-INF/[^/]+\\.(SF|RSA|DSA|EC)")),"Signed host unsupported; signatures are never removed");

        TreeMap<String,byte[]> classes=new TreeMap<>();
        for(var e:addon.entrySet()) if(e.getKey().startsWith(PREFIX)&&e.getKey().endsWith(".class")) classes.put(e.getKey(),e.getValue());
        require(classes.size()==82,"Expected exactly 82 overlay subsystem classes");
        Maps maps=createMaps(classes);
        Remapper mapper=new Remapper(ASM9) {
            @Override public String map(String name) {return maps.classes().getOrDefault(name,name);}
            @Override public String mapFieldName(String owner,String name,String desc) {return maps.fields().getOrDefault(owner+"."+name+":"+desc,name);}
            @Override public String mapMethodName(String owner,String name,String desc) {return maps.methods().getOrDefault(owner+"."+name+desc,name);}
        };
        TreeMap<String,byte[]> replacements=new TreeMap<>();
        for(var e:classes.entrySet()) {
            ClassReader reader=new ClassReader(e.getValue());
            ClassWriter writer=new ClassWriter(0);reader.accept(new ClassRemapper(writer,mapper),0);
            String name=mapper.map(reader.getClassName())+".class";
            require(replacements.put(name,writer.toByteArray())==null,"Duplicate remapped class: "+name);
        }
        Set<String> hostClasses=new TreeSet<>();
        original.keySet().stream().filter(n->n.startsWith(PREFIX)&&n.endsWith(".class")).forEach(hostClasses::add);
        require(hostClasses.size()==79,"Expected exactly 79 host subsystem classes");
        require(replacements.keySet().containsAll(hostClasses),"Overlay would leave an obsolete subsystem class");
        Set<String> added=new TreeSet<>(replacements.keySet());added.removeAll(hostClasses);
        require(added.equals(NEW_CLASSES),"Only the three TargetGeometry classes may be added");
        TreeMap<String,byte[]> merged=new TreeMap<>(original);merged.putAll(replacements);
        Map<String,ClassNode> before=nodes(original),after=nodes(merged);
        int injections=checkInjectionContracts(before,after);
        int exportedAbi=checkHostAbi(before,after);
        Set<String> preservedGameMembers=new TreeSet<>();
        int hostReferences=checkReferences(after,before,true,preservedGameMembers),allReferences=checkReferences(after,before,false,preservedGameMembers);
        for(var e:replacements.entrySet()) verify(e.getKey(),e.getValue());
        for(var e:original.entrySet()) if(!e.getKey().startsWith(PREFIX)) require(Arrays.equals(e.getValue(),merged.get(e.getKey())),"Host entry changed: "+e.getKey());
        Files.createDirectories(output.getParent());
        Path temporary=Files.createTempFile(output.getParent(),".n9ezz-merge-",".jar");
        try {
            try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(temporary))) {
                zip.setLevel(9);
                for(var e:merged.entrySet()) {
                    ZipEntry entry=new ZipEntry(e.getKey());entry.setTimeLocal(LocalDateTime.of(1980,1,1,0,0));
                    zip.putNextEntry(entry);zip.write(e.getValue());zip.closeEntry();
                }
            }
            TreeMap<String,byte[]> written=readZip(temporary);
            require(written.keySet().equals(merged.keySet()),"Output entry set differs");
            for(var e:merged.entrySet()) require(Arrays.equals(e.getValue(),written.get(e.getKey())),"Output bytes differ: "+e.getKey());
            Files.move(temporary,output,StandardCopyOption.ATOMIC_MOVE);
        } finally {Files.deleteIfExists(temporary);}
        StringBuilder report=new StringBuilder();
        report.append("hostSha256=").append(HOST_SHA).append('\n').append("overlaySha256=").append(OVERLAY_SHA).append('\n');
        report.append("outputSha256=").append(hash(output)).append('\n').append("outputSize=").append(Files.size(output)).append('\n');
        report.append("subsystemReplacements=79\nsubsystemAdditions=3\nverifiedClasses=82\n");
        report.append("hostMemberReferences=").append(hostReferences).append("\nallSubsystemMemberReferences=").append(allReferences).append("\nunchangedMixinContracts=").append(injections).append('\n');
        report.append("unchangedHostAbiReferences=").append(exportedAbi).append('\n');
        report.append("baselineInheritedGameMembers=").append(preservedGameMembers.size()).append('\n');
        report.append("metadataAndHostHooks=byte-identical\nmodCodeExecuted=false\nrealMinecraftGameplay=not-tested-by-updater\nuniversalCoreCompatibility=not-tested-by-updater-see-game-report\n");
        report.append("\nClass replacements and additions:\n");replacements.keySet().forEach(n->report.append(n).append('\n'));
        report.append("\nUnchanged inherited Minecraft symbols (resolved when game classes are on tool classpath):\n");preservedGameMembers.forEach(n->report.append(n).append('\n'));
        report.append("\nClass remapping:\n");maps.classes().forEach((a,b)->report.append(a).append(" -> ").append(b).append('\n'));
        report.append("\nInternal member remapping (all callers replaced together):\n");
        maps.fields().forEach((a,b)->report.append(a).append(" -> ").append(b).append('\n'));
        maps.methods().forEach((a,b)->report.append(a).append(" -> ").append(b).append('\n'));
        Files.writeString(Path.of(output+".report.txt"),report,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
        System.out.print(report.substring(0,report.indexOf("\nClass replacements")));
    }

    private static Maps createMaps(Map<String,byte[]> files) {
        Map<String,String> classes=new TreeMap<>(),fields=new TreeMap<>(),methods=new TreeMap<>();
        for(int i=0;i<HELPERS.size();i++) classes.put(PREFIX+HELPERS.get(i),PREFIX+(char)('a'+i));
        for(int i=0;i<MODULES.size();i++) classes.put(PREFIX+MODULES.get(i),PREFIX+"u"+i);
        for(var e:files.entrySet()) {
            ClassNode n=node(e.getValue());if(n.name.startsWith(PREFIX+"mixin/")) continue;
            int f=0,m=0;
            for(FieldNode field:n.fields) if((field.access&ACC_PRIVATE)!=0) fields.put(n.name+"."+field.name+":"+field.desc,"f"+f++);
            for(MethodNode method:n.methods) if(!method.name.startsWith("<")&&((method.access&ACC_PRIVATE)!=0||HELPERS.contains(n.name.substring(PREFIX.length())))) methods.put(n.name+"."+method.name+method.desc,"m"+m++);
        }
        return new Maps(classes,fields,methods);
    }
    private static TreeMap<String,byte[]> readZip(Path file) throws IOException {
        TreeMap<String,byte[]> result=new TreeMap<>();
        try(ZipFile zip=new ZipFile(file.toFile())) {
            var entries=zip.entries();while(entries.hasMoreElements()) {
                ZipEntry e=entries.nextElement();String n=e.getName();
                require(!n.startsWith("/")&&!n.contains("\\")&&!Arrays.asList(n.split("/")).contains(".."),"Unsafe ZIP path: "+n);
                if(e.isDirectory())continue;
                try(InputStream in=zip.getInputStream(e)) {require(result.put(n,in.readAllBytes())==null,"Duplicate ZIP entry: "+n);}
            }
        }return result;
    }
    private static ClassNode node(byte[] bytes) {ClassNode n=new ClassNode();new ClassReader(bytes).accept(n,0);return n;}
    private static Map<String,ClassNode> nodes(Map<String,byte[]> files) {
        Map<String,ClassNode> result=new TreeMap<>();
        for(var e:files.entrySet()) if(e.getKey().endsWith(".class")) {
            ClassNode n=node(e.getValue());require(e.getKey().equals(n.name+".class"),"Class path mismatch: "+e.getKey());
            require(result.put(n.name,n)==null,"Duplicate class identity: "+n.name);
        }return result;
    }
    private static void verify(String name,byte[] bytes) throws AnalyzerException {
        ClassNode n=node(bytes);require(n.version<=V21,"Class requires newer Java: "+name);
        new ClassReader(bytes).accept(new CheckClassAdapter(new ClassWriter(0),false),0);
        for(MethodNode m:n.methods) if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0) new Analyzer<>(new BasicVerifier()).analyze(n.name,m);
    }
    private static int checkReferences(Map<String,ClassNode> classes,Map<String,ClassNode> baseline,boolean hostOnly,Set<String> gameMembers) {
        int count=0;
        for(ClassNode n:classes.values()) {
            if(hostOnly&&n.name.startsWith(PREFIX))continue;
            for(MethodNode m:n.methods) for(AbstractInsnNode i:m.instructions) {
                if(i instanceof MethodInsnNode c&&c.owner.startsWith(PREFIX)) {checkReference(classes,baseline,n.name,c.owner,c.name,c.desc,true,gameMembers);count++;}
                if(i instanceof FieldInsnNode c&&c.owner.startsWith(PREFIX)) {checkReference(classes,baseline,n.name,c.owner,c.name,c.desc,false,gameMembers);count++;}
                if(i instanceof InvokeDynamicInsnNode c) {checkValue(classes,c.bsm);for(Object v:c.bsmArgs)checkValue(classes,v);}
                if(i instanceof LdcInsnNode c)checkValue(classes,c.cst);
            }
        }return count;
    }
    private static int checkHostAbi(Map<String,ClassNode> before,Map<String,ClassNode> after) {
        int count=0,mask=ACC_PUBLIC|ACC_PRIVATE|ACC_PROTECTED|ACC_STATIC;
        for(ClassNode n:before.values())if(!n.name.startsWith(PREFIX))for(MethodNode m:n.methods)for(AbstractInsnNode i:m.instructions) {
            if(i instanceof MethodInsnNode c&&c.owner.startsWith(PREFIX)) {
                ClassNode a=before.get(c.owner),b=after.get(c.owner);require(a!=null&&b!=null,"Host API class absent: "+c.owner);
                MethodNode old=a.methods.stream().filter(v->v.name.equals(c.name)&&v.desc.equals(c.desc)).findFirst().orElseThrow();
                MethodNode updated=b.methods.stream().filter(v->v.name.equals(c.name)&&v.desc.equals(c.desc)).findFirst().orElseThrow();
                require((old.access&mask)==(updated.access&mask),"Host API method access changed: "+c.owner+"."+c.name+c.desc);
                require((updated.access&ACC_PUBLIC)!=0,"Host API method must stay public: "+c.owner+"."+c.name);
                require(((updated.access&ACC_STATIC)!=0)==(c.getOpcode()==INVOKESTATIC),"Host API method static contract changed");count++;
            }
            if(i instanceof FieldInsnNode c&&c.owner.startsWith(PREFIX)) {
                ClassNode a=before.get(c.owner),b=after.get(c.owner);require(a!=null&&b!=null,"Host API class absent: "+c.owner);
                FieldNode old=a.fields.stream().filter(v->v.name.equals(c.name)&&v.desc.equals(c.desc)).findFirst().orElseThrow();
                FieldNode updated=b.fields.stream().filter(v->v.name.equals(c.name)&&v.desc.equals(c.desc)).findFirst().orElseThrow();
                require((old.access&mask)==(updated.access&mask),"Host API field access changed: "+c.owner+"."+c.name+c.desc);count++;
            }
        }return count;
    }
    private static void checkReference(Map<String,ClassNode> classes,Map<String,ClassNode> baseline,String caller,String owner,String name,String desc,boolean method,Set<String> gameMembers) {
        if(hasMember(classes,owner,name,desc,method,new HashSet<>()))return;
        ClassNode previous=baseline.get(owner),current=classes.get(owner);
        if(caller.equals(owner)&&owner.startsWith(PREFIX+"mixin/")&&previous!=null&&current!=null
            &&Objects.equals(previous.superName,current.superName)&&current.superName.startsWith("net/minecraft/")) {
            for(MethodNode m:previous.methods)for(AbstractInsnNode i:m.instructions) {
                if(method&&i instanceof MethodInsnNode c&&c.owner.equals(owner)&&c.name.equals(name)&&c.desc.equals(desc)) {gameMembers.add(owner+"."+name+desc);return;}
                if(!method&&i instanceof FieldInsnNode c&&c.owner.equals(owner)&&c.name.equals(name)&&c.desc.equals(desc)) {gameMembers.add(owner+"."+name+":"+desc);return;}
            }
        }
        throw new IllegalStateException("Unresolved new subsystem "+(method?"method ":"field ")+owner+"."+name+desc);
    }
    private static void checkValue(Map<String,ClassNode> classes,Object value) {
        if(value instanceof Handle h&&h.getOwner().startsWith(PREFIX)) checkMember(classes,h.getOwner(),h.getName(),h.getDesc(),h.getTag()>=H_INVOKEVIRTUAL,new HashSet<>());
        if(value instanceof ConstantDynamic c) {checkValue(classes,c.getBootstrapMethod());for(int i=0;i<c.getBootstrapMethodArgumentCount();i++)checkValue(classes,c.getBootstrapMethodArgument(i));}
    }
    private static boolean hasMember(Map<String,ClassNode> classes,String owner,String name,String desc,boolean method,Set<String> seen) {
        if(owner==null||!seen.add(owner))return false;ClassNode n=classes.get(owner);
        if(n==null) {
            try(InputStream in=MergeBundledClient.class.getClassLoader().getResourceAsStream(owner+".class")) {
                if(in!=null)n=node(in.readAllBytes());
            } catch(IOException e) {throw new UncheckedIOException(e);}
        }
        if(n==null)return false;
        if(method) {for(MethodNode m:n.methods)if(m.name.equals(name)&&m.desc.equals(desc))return true;}
        else {for(FieldNode f:n.fields)if(f.name.equals(name)&&f.desc.equals(desc))return true;}
        if(hasMember(classes,n.superName,name,desc,method,seen))return true;
        for(String iface:n.interfaces)if(hasMember(classes,iface,name,desc,method,seen))return true;
        return false;
    }
    private static void checkMember(Map<String,ClassNode> classes,String owner,String name,String desc,boolean method,Set<String> seen) {
        require(hasMember(classes,owner,name,desc,method,seen),"Unresolved subsystem "+(method?"method ":"field ")+owner+"."+name+desc);
    }
    private static int checkInjectionContracts(Map<String,ClassNode> before,Map<String,ClassNode> after) {
        int count=0;
        for(var e:before.entrySet()) if(e.getKey().startsWith(PREFIX+"mixin/")) {
            require(injectionContracts(e.getValue()).equals(injectionContracts(after.get(e.getKey()))),"Mixin target/injection contract changed: "+e.getKey());count++;
        }require(count==10,"Expected ten existing mixin classes");return count;
    }
    private static List<String> injectionContracts(ClassNode n) {
        List<String> out=new ArrayList<>();addAnnotations(out,"class",n.visibleAnnotations);addAnnotations(out,"class",n.invisibleAnnotations);
        for(MethodNode m:n.methods) {addAnnotations(out,m.name+m.desc,m.visibleAnnotations);addAnnotations(out,m.name+m.desc,m.invisibleAnnotations);}
        Collections.sort(out);return out;
    }
    private static void addAnnotations(List<String> result,String owner,List<AnnotationNode> nodes) {
        if(nodes==null)return;for(AnnotationNode a:nodes)if(a.desc.startsWith("Lorg/spongepowered/asm/mixin/"))result.add(owner+":"+annotation(a));
    }
    private static String annotation(Object v) {
        if(v instanceof AnnotationNode n)return n.desc+annotation(n.values);
        if(v instanceof List<?> l)return l.stream().map(MergeBundledClient::annotation).toList().toString();
        if(v instanceof String[] a)return Arrays.toString(a);return String.valueOf(v);
    }
    private static byte[] required(Map<String,byte[]> entries,String name) {byte[] bytes=entries.get(name);require(bytes!=null,"Missing "+name);return bytes;}
    private static void requireHash(Path file,String expected) throws Exception {require(hash(file).equals(expected),"Input SHA256 mismatch: "+file.getFileName());}
    private static String hash(Path file) throws Exception {MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=Files.newInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))>=0)digest.update(b,0,n);}return HexFormat.of().formatHex(digest.digest());}
    private static void require(boolean condition,String message) {if(!condition)throw new IllegalStateException(message);}
}
