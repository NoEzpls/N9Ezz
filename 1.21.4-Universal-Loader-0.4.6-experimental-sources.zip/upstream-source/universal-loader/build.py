#!/usr/bin/env python3
"""Java 21 reproducible build, without an unpinned Gradle/Maven bootstrap."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
DIST = ROOT / "dist"
CACHE = ROOT / ".cache" / "deps"
VERSION = "0.4.1-experimental"
STAMP = (1980, 1, 1, 0, 0, 0)
CLIENT_INPUTS = ROOT / "inputs"
CLIENT_RESOURCE = "embedded/n9ezz-client-1.5.3.jar"
CLIENT_SHA256 = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424"
CLIENT_VERSION = "1.5.3-n9ezz"
FABRIC_API_RESOURCE = "embedded/fabric-api-0.141.3+1.21.11.jar"
FABRIC_API_FILE = "fabric-api-0.141.3+1.21.11.jar"
FABRIC_API_SHA256 = "86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5"
COMPILED_INPUTS = {}


def run(args):
    subprocess.run(args, cwd=ROOT, check=True)


def dependencies(offline):
    CACHE.mkdir(parents=True, exist_ok=True)
    lock = json.loads((ROOT / "deps-lock.json").read_text())
    paths = []
    for dep in lock:
        path = CACHE / dep["file"]
        valid = path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == dep["sha256"]
        if not valid:
            if offline:
                raise RuntimeError("Offline cache missing or corrupt: " + dep["file"])
            # urllib retains TLS verification and the managed HTTPS proxy.
            with urllib.request.urlopen(dep["url"], timeout=60) as response:
                data = response.read(16 * 1024 * 1024)
            if hashlib.sha256(data).hexdigest() != dep["sha256"]:
                raise RuntimeError("Dependency SHA-256 mismatch: " + dep["file"])
            temporary = path.with_suffix(".download")
            temporary.write_bytes(data)
            temporary.replace(path)
        paths.append(path)
    return paths


def compile_sources(directory, target, classpath):
    files = sorted(directory.rglob("*.java")) if directory.is_dir() else []
    if not files:
        raise RuntimeError("No Java sources in " + str(directory))
    target.mkdir(parents=True, exist_ok=True)
    for file in files:
        COMPILED_INPUTS[file] = hashlib.sha256(file.read_bytes()).hexdigest()
    # Some cloud images provide JDK modules but omit javac's executable shim.
    run(["java", "com.sun.tools.javac.Main", "--release", "21", "-proc:none", "-encoding", "UTF-8",
         "-Xlint:all", "-cp", os.pathsep.join(map(str, classpath)), "-d", str(target), *map(str, files)])


def copy_resources(directory, target):
    """Keep service descriptors, mapping data and fixtures on their actual runtime classpath."""
    if not directory.is_dir():
        return
    for source in sorted(directory.rglob("*")):
        if not source.is_file():
            continue
        COMPILED_INPUTS[source] = hashlib.sha256(source.read_bytes()).hexdigest()
        destination = target / source.relative_to(directory)
        if destination.exists():
            raise RuntimeError("Compiled class/resource collision: " + str(destination))
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)


def validate_compiled_inputs():
    for file, digest in COMPILED_INPUTS.items():
        if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise RuntimeError("Source changed during the build; rerun with stable inputs: " + str(file))


def write_zip(path, entries):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content in sorted(entries.items()):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content, compresslevel=9)


def embedded_client(deps):
    """Apply the Java updater to pinned inputs, retaining original host hooks once."""
    lock = json.loads((CLIENT_INPUTS / "client-bundle-inputs.json").read_text())
    for role in ("base", "overlay"):
        source = CLIENT_INPUTS / lock[role]["file"]
        if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != lock[role]["sha256"]:
            raise RuntimeError("Missing or corrupt pinned client input: " + str(source))
    tools = BUILD / "client-tools"
    compile_sources(ROOT / "tools", tools, deps)
    output = BUILD / "N9Ezz-1.5.3-hitbox-updated.jar"
    command = ["java", "-cp", os.pathsep.join(map(str, [tools, *deps])), "MergeBundledClient",
               str(CLIENT_INPUTS / lock["base"]["file"]), str(CLIENT_INPUTS / lock["overlay"]["file"]), str(output)]
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (DIST / "client-bundle-report.txt").write_text(result.stdout)
    print(result.stdout, end="")
    if result.returncode:
        raise subprocess.CalledProcessError(result.returncode, command)
    data = output.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != CLIENT_SHA256 or digest != lock["output"]["sha256"] or len(data) != lock["output"]["size"]:
        raise RuntimeError("Embedded N9Ezz client SHA-256 mismatch: expected "
                           + CLIENT_SHA256 + ", got " + digest)
    shutil.copyfile(Path(str(output) + ".report.txt"), DIST / "client-bundle-symbols-report.txt")
    return data


def embedded_fabric_api():
    source = CLIENT_INPUTS / FABRIC_API_FILE
    if not source.is_file():
        raise RuntimeError("Missing pinned official Fabric API input: " + str(source))
    data = source.read_bytes()
    if hashlib.sha256(data).hexdigest() != FABRIC_API_SHA256:
        raise RuntimeError("Pinned official Fabric API input SHA-256 mismatch: " + str(source))
    return data


def pack_jar(classes, deps, demo, client, fabric_api):
    validate_compiled_inputs()
    entries = {}
    services = {}
    package_attributes = {}
    for dep in deps:
        # Also retain each complete original archive with its licenses/notices.
        entries["META-INF/n9ezz/dependencies/" + dep.name] = dep.read_bytes()
        with zipfile.ZipFile(dep) as source:
            attributes = {}
            if "META-INF/MANIFEST.MF" in source.namelist():
                raw_manifest = source.read("META-INF/MANIFEST.MF").decode("utf-8").replace("\r\n", "\n")
                logical = []
                for line in raw_manifest.split("\n\n", 1)[0].splitlines():
                    if line.startswith(" ") and logical:
                        logical[-1] += line[1:]
                    else:
                        logical.append(line)
                attributes = dict(line.split(": ", 1) for line in logical if ": " in line)
                attributes = {key: value for key, value in attributes.items()
                              if key in ("Implementation-Title", "Implementation-Version", "Implementation-Vendor")}
            for info in source.infolist():
                name = info.filename
                if info.is_dir() or name == "module-info.class" or name.startswith("META-INF/versions/"):
                    continue
                if name.startswith("META-INF/"):
                    if name.startswith("META-INF/services/"):
                        services.setdefault(name, set()).update(source.read(info).decode().splitlines())
                    continue
                if name in entries:
                    raise RuntimeError("Shaded dependency collision: " + name)
                entries[name] = source.read(info)
                if name.endswith(".class") and "/" in name and attributes:
                    package = name.rsplit("/", 1)[0] + "/"
                    prior = package_attributes.setdefault(package, attributes)
                    if prior != attributes:
                        raise RuntimeError("Shaded package metadata collision: " + package)
    for file in sorted(classes.rglob("*")):
        if file.is_file():
            name = file.relative_to(classes).as_posix()
            if name.startswith("META-INF/services/"):
                services.setdefault(name, set()).update(file.read_text().splitlines())
                continue
            if name in entries:
                raise RuntimeError("Own/dependency class collision: " + name)
            entries[name] = file.read_bytes()
    for name, lines in services.items():
        providers = {line.split("#", 1)[0].strip() for line in lines}
        providers.discard("")
        # GlobalProperties uses the first available provider; the own host must
        # precede optional upstream LaunchWrapper/ModLauncher service entries.
        ordered = sorted(providers, key=lambda provider: (not provider.startswith("dev.n9ezz."), provider))
        entries[name] = ("\n".join(ordered) + "\n").encode()
    manifest = (
        "Manifest-Version: 1.0\r\nMain-Class: dev.n9ezz.loader.launch.Main\r\n"
        "Implementation-Title: N9Ezz Universal Loader experimental core\r\n"
        f"Implementation-Version: {VERSION}\r\n\r\n")
    # Mixin reads ASM's package implementation version to enable JAVA_21.
    # Retain dependency package provenance when shading, separate from our version.
    for package, attributes in sorted(package_attributes.items()):
        manifest += "Name: " + package + "\r\n"
        for key, value in sorted(attributes.items()):
            line = (key + ": " + value).encode("utf-8")
            while len(line) > 70:
                cut = 70
                while (line[cut] & 0xc0) == 0x80:
                    cut -= 1
                manifest += line[:cut].decode("utf-8") + "\r\n"
                line = b" " + line[cut:]
            manifest += line.decode("utf-8") + "\r\n"
        manifest += "\r\n"
    entries["META-INF/MANIFEST.MF"] = manifest.encode()
    entries["META-INF/n9ezz/deps-lock.json"] = (ROOT / "deps-lock.json").read_bytes()
    entries["META-INF/n9ezz/LICENSE"] = (ROOT / "LICENSE").read_bytes()
    entries["META-INF/n9ezz/THIRD-PARTY-NOTICES.md"] = (ROOT / "THIRD-PARTY-NOTICES.md").read_bytes()
    for file in sorted((ROOT / "licenses").glob("*")):
        if file.is_file():
            entries["META-INF/n9ezz/licenses/" + file.name] = file.read_bytes()
    for file in sorted((ROOT / "third-party-sources").glob("*")):
        if file.is_file():
            entries["META-INF/n9ezz/sources/" + file.name] = file.read_bytes()
    entries["examples/native-smoke-mod.jar"] = demo.read_bytes()
    entries["examples/native-smoke-mod.json"] = json.dumps({
        "resource": "examples/native-smoke-mod.jar", "id": "n9ezz_smoke", "version": "1.0.0",
        "sha256": hashlib.sha256(demo.read_bytes()).hexdigest(), "size": demo.stat().st_size,
        "java": 21, "minecraft": "1.21.11"
    }, sort_keys=True, separators=(",", ":")).encode()
    entries[CLIENT_RESOURCE] = client
    entries[FABRIC_API_RESOURCE] = fabric_api
    entries["META-INF/n9ezz/embedded-fabric-api.json"] = json.dumps({
        "resource": FABRIC_API_RESOURCE, "id": "fabric-api", "version": "0.141.3+1.21.11",
        "minecraft": "1.21.11", "sha256": FABRIC_API_SHA256, "size": len(fabric_api),
        "source": "Pinned official Fabric API archive; runtime selects six unchanged modules",
        "execution": "Selected components use the common classloader and shared Mixin service"
    }, sort_keys=True, separators=(",", ":")).encode()
    entries["META-INF/n9ezz/embedded-client.json"] = json.dumps({
        "resource": CLIENT_RESOURCE,
        "id": "pulse",
        "version": CLIENT_VERSION,
        "minecraft": "1.21.11",
        "java": 21,
        "sha256": CLIENT_SHA256,
        "size": len(client),
        "source": "Pinned base client and compiled Java overlay; inputs/client-bundle-inputs.json",
        "baseSha256": "2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb",
        "overlaySha256": "80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206",
        "execution": "pinned builtin common-runtime module; shared mappings, Mixin and six selected Fabric API modules"
    }, sort_keys=True, separators=(",", ":")).encode()
    path = DIST / f"N9Ezz-Universal-Loader-{VERSION}.jar"
    write_zip(path, entries)
    return path


def source_archive():
    validate_compiled_inputs()
    entries = {}
    for file in sorted(ROOT.rglob("*")):
        relative = file.relative_to(ROOT)
        if file.is_file() and not any(p in (".cache", "build", "dist", "__pycache__") for p in relative.parts):
            entries["universal-loader/" + relative.as_posix()] = file.read_bytes()
    for file in sorted((ROOT.parent / "docs").glob("*")):
        if file.is_file() and file.suffix in (".md", ".json", ".log", ".txt"):
            entries["docs/" + file.name] = file.read_bytes()
    # Include the actual addon changes and unchanged original installer sources.
    # Omit legacy build caches, screenshots and prepared engine blobs. The pinned
    # client update inputs above are retained so the release can be reproduced.
    for folder in ("client", "loader", "baseline"):
        base = ROOT.parent / folder
        for file in sorted(base.rglob("*")):
            relative = file.relative_to(base)
            if not file.is_file() or any(part in ("build", "dist", ".gradle", "__pycache__") for part in relative.parts):
                continue
            if file.suffix.lower() in (".png", ".jpg", ".zip", ".jar") and relative.as_posix() != "gradle/wrapper/gradle-wrapper.jar":
                continue
            entries[folder + "/" + relative.as_posix()] = file.read_bytes()
    readme = ROOT.parent / "README.md"
    if readme.is_file():
        entries["README.md"] = readme.read_bytes()
    entries[".gitignore"] = (ROOT.parent / ".gitignore").read_bytes()
    path = DIST / f"N9Ezz-Universal-Loader-{VERSION}-sources.zip"
    write_zip(path, entries)
    validate_compiled_inputs()
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--skip-tests", action="store_true", help="Build only; does not certify readiness")
    args = parser.parse_args()
    version = subprocess.run(["java", "-version"], capture_output=True, text=True, check=True).stderr
    if not ('version "21.' in version or 'version "21"' in version):
        raise RuntimeError("This build pins a complete host JDK 21 (--release 21). Found: " + version.splitlines()[0])
    dep_paths = dependencies(args.offline)
    if BUILD.exists():
        shutil.rmtree(BUILD)
    classes = BUILD / "classes"
    compile_sources(ROOT / "src/main/java", classes, dep_paths)
    copy_resources(ROOT / "src/main/resources", classes)
    demo_classes = BUILD / "demo-classes"
    compile_sources(ROOT / "src/demo/java", demo_classes, [classes, *dep_paths])
    demo_entries = {p.relative_to(demo_classes).as_posix(): p.read_bytes()
                    for p in demo_classes.rglob("*") if p.is_file()}
    demo_entries["n9ezz.mod.json"] = json.dumps({
        "schemaVersion": 1, "id": "n9ezz_smoke", "version": "1.0.0", "namespace": "none",
        "entrypoints": {"common": ["dev.n9ezz.examples.SmokeMod"]},
        "depends": {"java": ">=21", "n9ezz": ">=0.2.0"}}, sort_keys=True).encode()
    demo = BUILD / "native-smoke-mod.jar"
    write_zip(demo, demo_entries)
    DIST.mkdir(parents=True, exist_ok=True)
    client = embedded_client(dep_paths)
    fabric_api = embedded_fabric_api()
    jar = pack_jar(classes, dep_paths, demo, client, fabric_api)
    if not args.skip_tests:
        test_classes = BUILD / "test-classes"
        compile_sources(ROOT / "src/test/java", test_classes, [classes, *dep_paths])
        copy_resources(ROOT / "src/test/resources", test_classes)
        with (DIST / "test-report.txt").open("w") as report:
            command = ["java", "-cp", os.pathsep.join(map(str, [test_classes, classes, *dep_paths])),
                       "dev.n9ezz.loader.tests.RuntimeTests"]
            result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            report.write(result.stdout)
            print(result.stdout, end="")
            if result.returncode:
                raise subprocess.CalledProcessError(result.returncode, command)
        test_classpath = os.pathsep.join(map(str, [test_classes, classes, *dep_paths]))
        for name, test_main, extra in (
                ("mapping-test-report.txt", "dev.n9ezz.loader.mapping.MappingTests", []),
                ("access-widener-test-report.txt", "dev.n9ezz.loader.mapping.AccessWidenerTests", []),
                ("nested-discovery-test-report.txt", "dev.n9ezz.loader.tests.NestedDiscoveryTests", []),
                ("mixin-test-report.txt", "dev.n9ezz.loader.tests.MixinIntegrationTests", []),
                ("fabric-compatibility-test-report.txt", "dev.n9ezz.loader.tests.FabricCompatibilityTests",
                    [str(CLIENT_INPUTS / FABRIC_API_FILE)]),
                ("fabric-entrypoint-test-report.txt", "dev.n9ezz.loader.compat.FabricEntrypointTests",
                    [str(CLIENT_INPUTS / FABRIC_API_FILE)]),
                ("fabric-dependency-test-report.txt", "dev.n9ezz.loader.tests.FabricDependencyTests",
                    [str(BUILD / "N9Ezz-1.5.3-hitbox-updated.jar"), str(CLIENT_INPUTS / FABRIC_API_FILE)]),
                ("game-integration-test-report.txt", "dev.n9ezz.loader.core.GameIntegrationTests", []),
                ("external-mod-policy-test-report.txt", "dev.n9ezz.loader.core.ExternalModPolicyTests", []),
                ("universal-game-policy-test-report.txt", "dev.n9ezz.loader.core.UniversalGamePolicyTests", []),
                ("quilt-game-test-report.txt", "dev.n9ezz.loader.quilt.QuiltCompatibilityTests", []),
                ("fml-game-test-report.txt", "dev.n9ezz.loader.fml.FmlCompatibilityTests", []),
                ("local-diagnostics-test-report.txt", "dev.n9ezz.loader.tests.LocalDiagnosticsTests", []),
                ("client-contract-test-report.txt", "dev.n9ezz.loader.core.BundledClientContractTests",
                    [str(BUILD / "N9Ezz-1.5.3-hitbox-updated.jar"), str(CLIENT_INPUTS / "base-client-1.5.3.jar")]),
                ("resource-pack-test-report.txt", "dev.n9ezz.loader.resources.ResourcePackTests",
                    [str(BUILD / "N9Ezz-1.5.3-hitbox-updated.jar")])):
            # Exercise the real shaded Mixin/ASM/service packaging, whose
            # manifest differs from loose development dependency JARs.
            suite_classpath = (os.pathsep.join(map(str, [test_classes, jar]))
                               if test_main == "dev.n9ezz.loader.tests.MixinIntegrationTests" else test_classpath)
            command = ["java", "-cp", suite_classpath, test_main, *extra]
            result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            (DIST / name).write_text(result.stdout)
            print(result.stdout, end="")
            if result.returncode:
                raise subprocess.CalledProcessError(result.returncode, command)
        for name, command in (
                ("client-bundle-tests.txt", [sys.executable, "tools/test_client_bundle.py", "--java", "java",
                    "--classpath", os.pathsep.join(map(str, [BUILD / "client-tools", *dep_paths])),
                    "--host", str(CLIENT_INPUTS / "base-client-1.5.3.jar"),
                    "--overlay", str(CLIENT_INPUTS / "hitbox-overlay-1.5.3.jar"),
                    "--merged", str(BUILD / "N9Ezz-1.5.3-hitbox-updated.jar")]),
                ("embedded-hitbox-test-report.txt", [sys.executable, "scripts/embedded_hitbox_qa.py",
                    "--loader", str(jar), "--java", shutil.which("java"), "--output", str(BUILD / "embedded-hitbox-qa")]),
                ("packaged-smoke-report.txt", ["java", "-jar", str(jar), "--self-test"]),
                ("gameplay-acceptance-test-report.txt", [sys.executable, "scripts/test_gameplay_acceptance.py"]),
                ("cross-platform-acceptance-test-report.txt", [sys.executable, "scripts/test_cross_platform_acceptance.py"]),
                ("installer-report.txt", [sys.executable, "scripts/installer_smoke.py", str(jar)])):
            result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            (DIST / name).write_text(result.stdout)
            print(result.stdout, end="")
            if result.returncode:
                raise subprocess.CalledProcessError(result.returncode, command)
    source = source_archive()
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (jar, source)}
    (DIST / "SHA256SUMS").write_text("".join(f"{digest}  {name}\n" for name, digest in hashes.items()))
    print("ARTIFACT", jar)
    print("SOURCES", source)
    print(json.dumps(hashes, indent=2))


if __name__ == "__main__":
    main()
