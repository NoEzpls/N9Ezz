# N9Ezz Universal Loader 0.4.1 experimental

Java 21 shared runtime for the pinned Minecraft 1.21.11 client. The installer
embeds N9Ezz and a selected Fabric API set, with one launcher profile and no
platform selection. It does not launch upstream loader engines.

**External mods now require the own `n9ezz.mod.json` format.** Ordinary Fabric,
Quilt, Forge and NeoForge descriptors are rejected before external code runs,
including archives combining an own and a foreign descriptor. External nested
JARs are unsupported. The pinned built-in N9Ezz/API archives retain their
verified internal path. Descriptor admission is not an authorship signature or
a security sandbox. See the [native mod contract and Java example](../docs/native-mod-policy.md).

```bash
python3 build.py          # resolves SHA-256-pinned dependencies
python3 build.py --offline
java -jar dist/N9Ezz-Universal-Loader-0.4.1-experimental.jar --self-test
java -jar dist/N9Ezz-Universal-Loader-0.4.1-experimental.jar --install --game-dir /path/to/.minecraft
```

Installation/gameplay require Java 21 runtime; building requires a complete
JDK 21. In the prepared cloud environment activate it with
`source /workspace/toolchains/activate-temurin21.sh`. Python 3 orchestrates the
build; runtime, installer and updater implementations are Java.

The shared game path retains own dependency resolution, official-to-intermediary
mapping, access widening, a real Mixin host and common/client initialization
from the Minecraft constructor. The six pinned Fabric API modules retain their
original game hooks. Quilt/FML adapters remain implemented and tested at lower
levels, but 0.4.1 deliberately stops admitting their external descriptor paths.
The API-only CLI enforces the same external native-only rule.

The [0.4.1 report](../docs/release-test-report-0.4.1.md) records this version's
build, game and reproduction status. The preserved [0.4.0 report](../docs/release-test-report-0.4.md)
belongs to an earlier binary: its four external platform fixture launch is
intentionally disallowed by the new policy. It must not be reported as a
successful 0.4.1 launch. The client, module logic and packets are unchanged.

Read the [main README](../README.md), [current runtime status](../docs/latest-runtime-status.md),
[native admission policy](../docs/native-mod-policy.md), [compatibility boundary](../docs/compatibility.md),
[Fabric contracts](../docs/fabric-runtime-contract.md) and
[Mixin contracts](../docs/shared-mixin.md). Full Forge/NeoForge game patches,
stock QSL, dedicated-server bootstrap and arbitrary platform mods are unsupported.

`deps-lock.json` pins dependencies; `inputs/` pins client updater inputs and
Fabric API. `licenses/` and `third-party-sources/` retain licensing materials
and corresponding TinyRemapper sources. See [THIRD-PARTY-NOTICES](THIRD-PARTY-NOTICES.md).
