/* Copyright 2022 The Quilt Project. Public API shape adapted under Apache-2.0. */
package org.quiltmc.qsl.base.api.entrypoint.client;

import org.quiltmc.loader.api.ModContainer;

/** QSL callback ABI at the shared Minecraft constructor boundary, before GameOptions. */
@FunctionalInterface
public interface ClientModInitializer {
    String ENTRYPOINT_KEY = "client_init";
    void onInitializeClient(ModContainer mod);
}
