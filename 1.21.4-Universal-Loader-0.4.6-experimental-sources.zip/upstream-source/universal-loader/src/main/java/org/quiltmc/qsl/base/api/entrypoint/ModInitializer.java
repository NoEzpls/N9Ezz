/* Copyright 2022 The Quilt Project. Public API shape adapted under Apache-2.0. */
package org.quiltmc.qsl.base.api.entrypoint;

import org.quiltmc.loader.api.ModContainer;

/**
 * QSL initializer ABI only. The explicit N9Ezz quilt-lifecycle-v1 contract invokes registry-independent
 * common callbacks at the shared Minecraft constructor boundary, after the stock QSL registry phase.
 * This interface does not provide QSL modules or its original registry-freeze hook.
 */
@FunctionalInterface
public interface ModInitializer {
    String ENTRYPOINT_KEY = "init";
    void onInitialize(ModContainer mod);
}
