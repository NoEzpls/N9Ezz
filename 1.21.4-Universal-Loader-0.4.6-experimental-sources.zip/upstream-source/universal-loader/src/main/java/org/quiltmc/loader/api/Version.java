package org.quiltmc.loader.api;

/** Raw version access only. Semantic comparison, parsing, and other Quilt methods are unsupported. */
public interface Version {
    String raw();
}
