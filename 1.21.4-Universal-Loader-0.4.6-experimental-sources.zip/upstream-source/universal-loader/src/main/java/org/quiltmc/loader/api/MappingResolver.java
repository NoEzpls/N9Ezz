/* Copyright 2016 FabricMC; 2022-2023 QuiltMC. Public API shape adapted under Apache-2.0. */
package org.quiltmc.loader.api;

import java.util.Collection;

/** Quilt 0.30.1 resolver ABI backed by the same own official/intermediary index as Fabric. */
public interface MappingResolver {
    Collection<String> getNamespaces();
    String getCurrentRuntimeNamespace();
    String mapClassName(String fromNamespace, String className);
    String unmapClassName(String targetNamespace, String className);
    String mapFieldName(String fromNamespace, String owner, String name, String descriptor);
    String mapMethodName(String fromNamespace, String owner, String name, String descriptor);
}
