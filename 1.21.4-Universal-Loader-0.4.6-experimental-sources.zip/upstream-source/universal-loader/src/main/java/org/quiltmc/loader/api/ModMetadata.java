/* Copyright 2016 FabricMC; 2022-2023 QuiltMC. Public API shape adapted under Apache-2.0. */
package org.quiltmc.loader.api;

/** Read-only metadata subset; dependency, contributor and custom-value APIs remain unsupported. */
public interface ModMetadata {
    String id();
    Version version();
    default String group() { throw new UnsupportedOperationException("No prepared Quilt metadata group"); }
    default String name() { return id(); }
    default String description() { return ""; }
}
