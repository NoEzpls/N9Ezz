/* Copyright 2016 FabricMC; 2022-2023 QuiltMC. Public API shape adapted under Apache-2.0. */
package org.quiltmc.loader.api;

import java.nio.file.Path;
import java.util.List;

/** Read-only subset of the Quilt Loader 0.30.1 public container ABI. */
public interface ModContainer {
    ModMetadata metadata();
    default Path rootPath() { throw new UnsupportedOperationException("No prepared Quilt archive view"); }
    default Path getPath(String file) { throw new UnsupportedOperationException("No prepared Quilt archive view"); }
    default List<List<Path>> getSourcePaths() { throw new UnsupportedOperationException("No prepared Quilt archive view"); }
    default BasicSourceType getSourceType() { throw new UnsupportedOperationException("No prepared Quilt archive view"); }
    default ClassLoader getClassLoader() { throw new UnsupportedOperationException("No prepared Quilt archive view"); }

    enum BasicSourceType { NORMAL_QUILT, NORMAL_FABRIC, BUILTIN, OTHER }
}
