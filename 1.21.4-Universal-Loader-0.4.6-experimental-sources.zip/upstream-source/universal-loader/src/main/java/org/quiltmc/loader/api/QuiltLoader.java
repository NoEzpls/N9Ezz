/* Copyright 2016 FabricMC; 2022-2023 QuiltMC. Public API shape adapted under Apache-2.0. */
package org.quiltmc.loader.api;

import dev.n9ezz.loader.quilt.QuiltRuntime;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Optional;

/** Exact documented read-only ABI subset, implemented by the single N9Ezz runtime. */
public final class QuiltLoader {
    private QuiltLoader() {}
    public static Optional<ModContainer> getModContainer(String id) { return QuiltRuntime.service().getModContainer(id); }
    public static Optional<ModContainer> getModContainer(Class<?> type) { return QuiltRuntime.service().getModContainer(type); }
    public static Collection<ModContainer> getAllMods() { return QuiltRuntime.service().getAllMods(); }
    public static boolean isModLoaded(String id) { return QuiltRuntime.service().isModLoaded(id); }
    public static Path getGameDir() { return QuiltRuntime.service().getGameDir(); }
    public static Path getConfigDir() { return QuiltRuntime.service().getConfigDir(); }
    public static Path getCacheDir() { return QuiltRuntime.service().getCacheDir(); }
    public static String getRawGameVersion() { return QuiltRuntime.service().getRawGameVersion(); }
    public static String getNormalizedGameVersion() { return QuiltRuntime.service().getRawGameVersion(); }
    public static boolean isDevelopmentEnvironment() { return QuiltRuntime.service().isDevelopmentEnvironment(); }
    public static Object getGameInstance() { return QuiltRuntime.service().getGameInstance(); }
    public static MappingResolver getMappingResolver() { return QuiltRuntime.service().getMappingResolver(); }
}
