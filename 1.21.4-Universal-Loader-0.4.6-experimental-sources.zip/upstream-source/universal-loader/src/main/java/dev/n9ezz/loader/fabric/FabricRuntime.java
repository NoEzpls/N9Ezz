package dev.n9ezz.loader.fabric;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.n9ezz.loader.core.VersionConstraint;
import dev.n9ezz.loader.metadata.ModMetadata;
import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.jar.JarFile;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.MappingResolver;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.Version;

/** Read-only Fabric services and the single game initialization boundary in the own runtime. */
public final class FabricRuntime {
    public static final String VERIFIED_LOADER_ABI_VERSION = "0.19.2";
    private static volatile Access active;
    private FabricRuntime() {}

    /** Installs services before any API class/mod initializer. Closing releases archive filesystems. */
    public static synchronized Registration install(Path gameDir, List<ModMetadata> mods,
                                                    MappingResolver mappings, Consumer<Object> gameInitializer) throws IOException {
        if (active != null) throw new IllegalStateException("A Fabric compatibility runtime is already active");
        Access access = new Access(gameDir.toRealPath(), mods, mappings, gameInitializer);
        active = access;
        return new Registration(access);
    }
    public static FabricLoader loader() {
        Access access = active;
        if (access == null) throw new IllegalStateException("Fabric compatibility services were accessed before the universal runtime was prepared");
        return access;
    }
    /** Called only by the validated Minecraft constructor transform, before GameOptions construction. */
    public static void bootstrapGame(Object game) {
        Access access = active;
        if (access == null) throw new IllegalStateException("The game initialization hook has no prepared universal runtime");
        synchronized (access) {
            if (access.initializationAttempted) throw new IllegalStateException("The game initialization hook ran more than once");
            access.initializationAttempted = true;
            access.game = Objects.requireNonNull(game, "game");
            access.gameInitializer.accept(game);
            access.initializationCompleted = true;
        }
    }
    public static boolean initializationCompleted() { Access access = active; return access != null && access.initializationCompleted; }

    public static final class Registration implements AutoCloseable {
        private final Access access;
        private Registration(Access access) { this.access = access; }
        @Override public void close() throws IOException {
            synchronized (FabricRuntime.class) {
                if (active != access) return;
                active = null;
            }
            IOException failure = null;
            for (FileSystem fs : access.filesystems) try { fs.close(); }
            catch (IOException error) { if (failure == null) failure = error; else failure.addSuppressed(error); }
            if (failure != null) throw failure;
        }
    }
    private static final class Access implements FabricLoader {
        private final Path gameDir, configDir;
        private final MappingResolver mappings;
        private final Consumer<Object> gameInitializer;
        private final Map<String, ModContainer> byId;
        private final List<ModContainer> mods;
        private final List<FileSystem> filesystems = new ArrayList<>();
        private volatile Object game;
        private boolean initializationAttempted;
        private volatile boolean initializationCompleted;
        private Access(Path gameDir, List<ModMetadata> discovered, MappingResolver mappings, Consumer<Object> initializer) throws IOException {
            this.gameDir = gameDir; this.configDir = gameDir.resolve("config");
            this.mappings = Objects.requireNonNull(mappings); this.gameInitializer = Objects.requireNonNull(initializer);
            Files.createDirectories(configDir);
            LinkedHashMap<String, ModContainer> identities = new LinkedHashMap<>();
            List<ModContainer> actual = new ArrayList<>();
            try {
                for (ModMetadata mod : discovered) {
                    ReadOnlyContainer container = container(mod);
                    if (identities.putIfAbsent(mod.id(), container) != null) throw new IOException("Duplicate mod identity " + mod.id());
                    actual.add(container);
                    for (String alias : mod.provides()) if (identities.putIfAbsent(alias, container) != null) throw new IOException("Duplicate mod alias " + alias);
                }
                addBuiltin(identities, actual, "fabricloader", VERIFIED_LOADER_ABI_VERSION, "N9Ezz Fabric Loader ABI compatibility");
                addBuiltin(identities, actual, "minecraft", "1.21.11", "Minecraft");
                addBuiltin(identities, actual, "java", Integer.toString(Runtime.version().feature()), "Java");
            } catch (Throwable error) {
                for (FileSystem fs : filesystems) try { fs.close(); } catch (IOException closeError) { error.addSuppressed(closeError); }
                throw error;
            }
            this.byId = Map.copyOf(identities); this.mods = List.copyOf(actual);
        }
        private ReadOnlyContainer container(ModMetadata mod) throws IOException {
            String name = mod.id(), description = "", type = mod.platform().name().toLowerCase(java.util.Locale.ROOT);
            List<String> licenses = List.of();
            try (JarFile jar = new JarFile(mod.jar().toFile())) {
                var entry = jar.getJarEntry("fabric.mod.json");
                if (entry != null) try (var stream = jar.getInputStream(entry); var reader = new java.io.InputStreamReader(stream, java.nio.charset.StandardCharsets.UTF_8)) {
                    JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                    if (json.has("name")) name = json.get("name").getAsString();
                    if (json.has("description")) description = json.get("description").getAsString();
                    if (json.has("license")) {
                        var license = json.get("license");
                        if (license.isJsonArray()) licenses = license.getAsJsonArray().asList().stream().map(x -> x.getAsString()).toList();
                        else licenses = List.of(license.getAsString());
                    }
                }
            }
            FileSystem fs = FileSystems.newFileSystem(mod.jar(), Map.of());
            filesystems.add(fs);
            return new ReadOnlyContainer(new Identity(type, mod.id(), mod.provides(), new Value(mod.version()), name, description, licenses), List.of(fs.getPath("/")));
        }
        private static void addBuiltin(Map<String, ModContainer> byId, List<ModContainer> mods, String id, String version, String name) throws IOException {
            if (byId.containsKey(id)) throw new IOException("Mod impersonates builtin identity " + id);
            var container = new ReadOnlyContainer(new Identity("builtin", id, List.of(), new Value(version), name, "Universal runtime service provider", List.of()), List.of());
            byId.put(id, container); mods.add(container);
        }
        @Override public Path getConfigDir() { return configDir; }
        @Override public Path getGameDir() { return gameDir; }
        @Override public boolean isDevelopmentEnvironment() { return false; }
        @Override public EnvType getEnvironmentType() { return EnvType.CLIENT; }
        @Override public String getRawGameVersion() { return "1.21.11"; }
        @Override public Object getGameInstance() { return game; }
        @Override public boolean isModLoaded(String id) { return byId.containsKey(id); }
        @Override public Optional<ModContainer> getModContainer(String id) { return Optional.ofNullable(byId.get(id)); }
        @Override public Collection<ModContainer> getAllMods() { return mods; }
        @Override public MappingResolver getMappingResolver() { return mappings; }
    }
    private record ReadOnlyContainer(net.fabricmc.loader.api.metadata.ModMetadata metadata, List<Path> roots) implements ModContainer {
        @Override public net.fabricmc.loader.api.metadata.ModMetadata getMetadata() { return metadata; }
        @Override public List<Path> getRootPaths() { return roots; }
    }
    private record Identity(String type, String id, Collection<String> provides, Version version, String name, String description, Collection<String> licenses)
            implements net.fabricmc.loader.api.metadata.ModMetadata {
        private Identity { provides = List.copyOf(provides); licenses = List.copyOf(licenses); }
        @Override public String getType() { return type; }
        @Override public String getId() { return id; }
        @Override public Collection<String> getProvides() { return provides; }
        @Override public Version getVersion() { return version; }
        @Override public String getName() { return name; }
        @Override public String getDescription() { return description; }
        @Override public Collection<String> getLicense() { return licenses; }
    }
    private record Value(String value) implements Version {
        private Value { VersionConstraint.parse("=" + value).matches(value); }
        @Override public String getFriendlyString() { return value; }
        @Override public int compareTo(Version other) {
            if (VersionConstraint.parse("=" + other.getFriendlyString()).matches(value)) return 0;
            return VersionConstraint.parse(">" + other.getFriendlyString()).matches(value) ? 1 : -1;
        }
    }
}
