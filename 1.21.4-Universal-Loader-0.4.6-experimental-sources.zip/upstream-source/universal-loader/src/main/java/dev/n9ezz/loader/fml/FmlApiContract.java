package dev.n9ezz.loader.fml;

import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.jar.JarFile;
import org.objectweb.asm.*;
import org.objectweb.asm.signature.SignatureReader;
import org.objectweb.asm.signature.SignatureVisitor;

/** Scans every class before construction; presence of an annotation never grants arbitrary FML APIs. */
final class FmlApiContract {
    private FmlApiContract() {}
    record Candidate(String name, String constructor, int dependencyCount, int sideCount) {}
    private static final Set<String> TYPES = Set.of(
        "net/minecraftforge/fml/common/Mod", "net/minecraftforge/fml/ModContainer", "net/minecraftforge/fml/ModLoadingContext", "net/minecraftforge/fml/ModLoadingStage",
        "net/minecraftforge/fml/javafmlmod/FMLModContainer", "net/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext",
        "net/minecraftforge/fml/event/IModBusEvent", "net/minecraftforge/fml/event/lifecycle/ModLifecycleEvent", "net/minecraftforge/fml/event/lifecycle/ParallelDispatchEvent",
        "net/minecraftforge/fml/event/lifecycle/FMLCommonSetupEvent", "net/minecraftforge/fml/event/lifecycle/FMLClientSetupEvent", "net/minecraftforge/fml/event/lifecycle/FMLLoadCompleteEvent",
        "net/minecraftforge/eventbus/internal/Event", "net/minecraftforge/eventbus/internal/EventCharacteristic", "net/minecraftforge/eventbus/api/event/characteristic/SelfDestructing", "net/minecraftforge/eventbus/api/event/InheritableEvent", "net/minecraftforge/eventbus/api/event/MutableEvent",
        "net/minecraftforge/eventbus/api/bus/BusGroup", "net/minecraftforge/eventbus/api/bus/EventBus", "net/minecraftforge/eventbus/api/listener/EventListener", "net/minecraftforge/eventbus/api/listener/Priority",
        "net/neoforged/fml/common/Mod", "net/neoforged/api/distmarker/Dist", "net/neoforged/bus/api/Event", "net/neoforged/bus/api/EventPriority", "net/neoforged/bus/api/IEventBus",
        "net/neoforged/fml/ModContainer", "net/neoforged/fml/ModLoadingContext", "net/neoforged/fml/javafmlmod/FMLModContainer", "net/neoforged/fml/DeferredWorkQueue", "net/neoforged/fml/event/IModBusEvent",
        "net/neoforged/fml/event/lifecycle/ModLifecycleEvent", "net/neoforged/fml/event/lifecycle/ParallelDispatchEvent",
        "net/neoforged/fml/event/lifecycle/FMLCommonSetupEvent", "net/neoforged/fml/event/lifecycle/FMLClientSetupEvent", "net/neoforged/fml/event/lifecycle/FMLLoadCompleteEvent");
    private static final Set<String> CONSTRUCTOR_TYPES = Set.of(
        "net/minecraftforge/fml/event/lifecycle/ModLifecycleEvent", "net/minecraftforge/fml/event/lifecycle/ParallelDispatchEvent",
        "net/minecraftforge/fml/event/lifecycle/FMLCommonSetupEvent", "net/minecraftforge/fml/event/lifecycle/FMLClientSetupEvent", "net/minecraftforge/fml/event/lifecycle/FMLLoadCompleteEvent",
        "net/minecraftforge/eventbus/api/event/MutableEvent", "net/neoforged/bus/api/Event",
        "net/neoforged/fml/event/lifecycle/ModLifecycleEvent", "net/neoforged/fml/event/lifecycle/ParallelDispatchEvent",
        "net/neoforged/fml/event/lifecycle/FMLCommonSetupEvent", "net/neoforged/fml/event/lifecycle/FMLClientSetupEvent", "net/neoforged/fml/event/lifecycle/FMLLoadCompleteEvent");
    private record Member(String owner, String name, String descriptor, boolean method, int opcode) {}
    private static final class ClassData {
        String name, parent;
        String[] interfaces;
        int access;
        final Map<String, Integer> methods = new HashMap<>();
        final Set<String> fields = new HashSet<>();
        final List<Member> references = new ArrayList<>();
        String annotationId;
        final Set<String> annotationKeys = new TreeSet<>();
        final List<String> dependencies = new ArrayList<>();
        final List<String> sides = new ArrayList<>(List.of("CLIENT", "DEDICATED_SERVER"));
    }
    static List<Candidate> validate(ModMetadata mod, Set<String> installed) throws IOException {
        if (mod.platform() != Platform.FORGE && mod.platform() != Platform.NEOFORGE) throw error(mod, "FML_PLATFORM_MISMATCH", "Expected Forge or NeoForge metadata");
        Map<String, ClassData> classes = new HashMap<>();
        TreeSet<String> unsupported = new TreeSet<>();
        String annotation = mod.platform() == Platform.FORGE ? "Lnet/minecraftforge/fml/common/Mod;" : "Lnet/neoforged/fml/common/Mod;";
        try (JarFile jar = new JarFile(mod.jar().toFile())) {
            for (var entry : jar.stream().filter(e -> !e.isDirectory() && e.getName().endsWith(".class")).sorted(Comparator.comparing(java.util.jar.JarEntry::getName)).toList()) {
                if (entry.getName().startsWith("META-INF/versions/")) throw error(mod, "UNSUPPORTED_MULTI_RELEASE_MOD", "FML lifecycle profile does not accept multi-release mod classes");
                if (entry.getName().equals("module-info.class")) throw error(mod, "UNSUPPORTED_FML_MODULE", "JPMS mod module descriptors are outside fml-lifecycle-v1");
                byte[] bytes;
                try (var stream = jar.getInputStream(entry)) { bytes = stream.readNBytes(16 * 1024 * 1024 + 1); }
                if (bytes.length > 16 * 1024 * 1024) throw error(mod, "FML_CLASS_SIZE_LIMIT", "Class exceeds 16 MiB: " + entry.getName());
                ClassData data;
                try { data = scan(bytes, annotation, unsupported); }
                catch (RuntimeException invalid) { throw new LoaderException(new Diagnostic("INVALID_FML_BYTECODE", "Cannot inspect class " + entry.getName() + ": " + invalid, mod.id(), "fml-preflight", mod.jar()), invalid); }
                if (!entry.getName().equals(data.name + ".class")) throw error(mod, "FML_CLASS_PATH_MISMATCH", "Declared class name disagrees with JAR path: " + entry.getName());
                if (classes.putIfAbsent(data.name, data) != null) throw error(mod, "DUPLICATE_FML_CLASS", "Repeated class " + data.name);
            }
        }
        for (ClassData data : classes.values()) {
            for (Member member : data.references) checkMember(member, classes, unsupported, new HashSet<>());
        }
        if (!unsupported.isEmpty()) throw error(mod, "UNSUPPORTED_PLATFORM_API", "fml-lifecycle-v1 does not implement: " + String.join(", ", unsupported));
        List<ClassData> annotated = classes.values().stream().filter(data -> mod.id().equals(data.annotationId)).sorted(Comparator.comparing(data -> data.name)).toList();
        if (annotated.isEmpty()) throw error(mod, "MISSING_MOD_ANNOTATION", "No @Mod(\"" + mod.id() + "\") class exists in its declared JAR");
        if (mod.platform() == Platform.FORGE && annotated.size() != 1) throw error(mod, "AMBIGUOUS_FORGE_ENTRYPOINT", "Forge lifecycle profile requires exactly one matching @Mod class");
        List<Candidate> result = new ArrayList<>();
        for (ClassData data : annotated) {
            Set<String> allowed = mod.platform() == Platform.FORGE ? Set.of("value") : Set.of("value", "dist", "depends");
            if (!allowed.containsAll(data.annotationKeys)) throw error(mod, "UNSUPPORTED_MOD_ANNOTATION", "Unsupported @Mod attributes on " + data.name + ": " + data.annotationKeys);
            if (!Set.of("CLIENT", "DEDICATED_SERVER").containsAll(data.sides)) throw error(mod, "INVALID_MOD_SIDE", "Unknown @Mod dist on " + data.name);
            // Neo optional entrypoints with missing depends, and server-only entrypoints, do not initialize on a client.
            if (mod.platform() == Platform.NEOFORGE && (!data.sides.contains("CLIENT") || !installed.containsAll(data.dependencies))) continue;
            if ((data.access & Opcodes.ACC_PUBLIC) == 0 || (data.access & (Opcodes.ACC_INTERFACE | Opcodes.ACC_ABSTRACT)) != 0)
                throw error(mod, "UNSUPPORTED_MOD_CONSTRUCTOR", "@Mod class must be public and concrete: " + data.name);
            String constructor;
            if (mod.platform() == Platform.FORGE) {
                String injected = "(Lnet/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext;)V";
                constructor = data.methods.containsKey("<init>" + injected) ? injected : "()V";
                Integer access = data.methods.get("<init>" + constructor);
                if (access == null || (access & Opcodes.ACC_PUBLIC) == 0) throw error(mod, "UNSUPPORTED_MOD_CONSTRUCTOR", "Forge requires a public context or no-argument constructor: " + data.name);
            } else {
                List<String> constructors = data.methods.entrySet().stream().filter(e -> e.getKey().startsWith("<init>") && (e.getValue() & Opcodes.ACC_PUBLIC) != 0).map(e -> e.getKey().substring(6)).toList();
                if (constructors.size() != 1) throw error(mod, "UNSUPPORTED_MOD_CONSTRUCTOR", "NeoForge requires exactly one public constructor: " + data.name);
                constructor = constructors.getFirst();
                Set<String> parameters = new HashSet<>();
                for (Type type : Type.getArgumentTypes(constructor)) {
                    if (!Set.of("Lnet/neoforged/bus/api/IEventBus;", "Lnet/neoforged/fml/ModContainer;", "Lnet/neoforged/fml/javafmlmod/FMLModContainer;", "Lnet/neoforged/api/distmarker/Dist;").contains(type.getDescriptor()) || !parameters.add(type.getDescriptor()))
                        throw error(mod, "UNSUPPORTED_MOD_CONSTRUCTOR", "Unsupported or duplicate NeoForge constructor argument " + type + " on " + data.name);
                }
            }
            result.add(new Candidate(data.name.replace('/', '.'), constructor, data.dependencies.size(), data.sides.size()));
        }
        result.sort(Comparator.comparingInt(Candidate::dependencyCount).thenComparingInt(candidate -> -candidate.sideCount()).thenComparing(Candidate::name));
        return List.copyOf(result);
    }
    private static ClassData scan(byte[] bytes, String annotation, Set<String> unsupported) {
        ClassData data = new ClassData();
        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public void visit(int version, int access, String name, String signature, String parent, String[] interfaces) {
                data.name = name; data.parent = parent; data.interfaces = interfaces; data.access = access;
                name(parent, unsupported); if (interfaces != null) for (String iface : interfaces) name(iface, unsupported); signature(signature, unsupported);
            }
            @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                descriptor(descriptor, unsupported);
                if (!annotation.equals(descriptor)) return annotationValues(unsupported, data);
                return new AnnotationVisitor(Opcodes.ASM9) {
                    @Override public void visit(String key, Object value) { data.annotationKeys.add(key); if (key.equals("value") && value instanceof String id) data.annotationId = id; }
                    @Override public AnnotationVisitor visitArray(String key) {
                        data.annotationKeys.add(key);
                        if (key.equals("dist")) data.sides.clear();
                        return new AnnotationVisitor(Opcodes.ASM9) {
                            @Override public void visit(String ignored, Object value) { if (key.equals("depends") && value instanceof String dependency) data.dependencies.add(dependency); }
                            @Override public void visitEnum(String ignored, String desc, String value) { descriptor(desc, unsupported); if (key.equals("dist")) data.sides.add(value); }
                        };
                    }
                };
            }
            @Override public AnnotationVisitor visitTypeAnnotation(int ref, TypePath path, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
            @Override public void visitNestHost(String host) { name(host, unsupported); }
            @Override public void visitNestMember(String member) { name(member, unsupported); }
            @Override public void visitOuterClass(String owner, String method, String desc) { name(owner, unsupported); descriptor(desc, unsupported); }
            @Override public void visitInnerClass(String inner, String outer, String simple, int access) { name(inner, unsupported); name(outer, unsupported); }
            @Override public RecordComponentVisitor visitRecordComponent(String component, String desc, String sig) {
                descriptor(desc, unsupported); signature(sig, unsupported);
                return new RecordComponentVisitor(Opcodes.ASM9) {
                    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitTypeAnnotation(int ref, TypePath path, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                };
            }
            @Override public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                data.fields.add(name + desc); descriptor(desc, unsupported); signature(signature, unsupported); constant(value, data, unsupported);
                return new FieldVisitor(Opcodes.ASM9) {
                    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitTypeAnnotation(int ref, TypePath path, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                };
            }
            @Override public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                data.methods.put(name + desc, access); descriptor(desc, unsupported); signature(signature, unsupported);
                if (exceptions != null) for (String exception : exceptions) name(exception, unsupported);
                return new MethodVisitor(Opcodes.ASM9) {
                    @Override public AnnotationVisitor visitAnnotationDefault() { return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitAnnotation(String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitTypeAnnotation(int ref, TypePath path, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitInsnAnnotation(int ref, TypePath path, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitTryCatchAnnotation(int ref, TypePath path, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitLocalVariableAnnotation(int ref, TypePath path, Label[] start, Label[] end, int[] index, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
                    @Override public void visitTypeInsn(int opcode, String type) { name(type, unsupported); }
                    @Override public void visitFieldInsn(int opcode, String owner, String field, String desc) { name(owner, unsupported); descriptor(desc, unsupported); data.references.add(new Member(owner, field, desc, false, opcode)); }
                    @Override public void visitMethodInsn(int opcode, String owner, String method, String desc, boolean iface) { name(owner, unsupported); descriptor(desc, unsupported); data.references.add(new Member(owner, method, desc, true, opcode)); }
                    @Override public void visitLdcInsn(Object value) { constant(value, data, unsupported); }
                    @Override public void visitInvokeDynamicInsn(String name, String desc, Handle handle, Object... arguments) { descriptor(desc, unsupported); constant(handle, data, unsupported); for (Object argument : arguments) constant(argument, data, unsupported); }
                    @Override public void visitMultiANewArrayInsn(String desc, int dimensions) { descriptor(desc, unsupported); }
                    @Override public void visitTryCatchBlock(Label start, Label end, Label handler, String type) { name(type, unsupported); }
                };
            }
        }, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return data;
    }
    private static AnnotationVisitor annotationValues(Set<String> unsupported, ClassData data) {
        return new AnnotationVisitor(Opcodes.ASM9) {
            @Override public void visit(String name, Object value) { constant(value, data, unsupported); }
            @Override public void visitEnum(String name, String desc, String value) { descriptor(desc, unsupported); data.references.add(new Member(Type.getType(desc).getInternalName(), value, desc, false, Opcodes.GETSTATIC)); }
            @Override public AnnotationVisitor visitAnnotation(String name, String desc) { descriptor(desc, unsupported); return annotationValues(unsupported, data); }
            @Override public AnnotationVisitor visitArray(String name) { return annotationValues(unsupported, data); }
        };
    }
    private static void constant(Object value, ClassData data, Set<String> unsupported) {
        if (value instanceof Type type) type(type, unsupported);
        if (value instanceof Handle handle) {
            name(handle.getOwner(), unsupported); descriptor(handle.getDesc(), unsupported);
            boolean method = handle.getTag() > Opcodes.H_PUTSTATIC;
            int opcode = switch (handle.getTag()) {
                case Opcodes.H_GETFIELD -> Opcodes.GETFIELD; case Opcodes.H_GETSTATIC -> Opcodes.GETSTATIC;
                case Opcodes.H_PUTFIELD -> Opcodes.PUTFIELD; case Opcodes.H_PUTSTATIC -> Opcodes.PUTSTATIC;
                case Opcodes.H_INVOKESTATIC -> Opcodes.INVOKESTATIC; default -> Opcodes.INVOKEVIRTUAL;
            };
            data.references.add(new Member(handle.getOwner(), handle.getName(), handle.getDesc(), method, opcode));
        }
        if (value instanceof ConstantDynamic dynamic) {
            descriptor(dynamic.getDescriptor(), unsupported); constant(dynamic.getBootstrapMethod(), data, unsupported);
            for (int i = 0; i < dynamic.getBootstrapMethodArgumentCount(); i++) constant(dynamic.getBootstrapMethodArgument(i), data, unsupported);
        }
    }
    private static void signature(String value, Set<String> unsupported) {
        if (value == null) return;
        new SignatureReader(value).accept(new SignatureVisitor(Opcodes.ASM9) { @Override public void visitClassType(String value) { name(value, unsupported); } });
    }
    private static void descriptor(String value, Set<String> unsupported) { if (value != null) type(value.startsWith("(") ? Type.getMethodType(value) : Type.getType(value), unsupported); }
    private static void type(Type type, Set<String> unsupported) {
        switch (type.getSort()) {
            case Type.ARRAY -> type(type.getElementType(), unsupported);
            case Type.OBJECT -> name(type.getInternalName(), unsupported);
            case Type.METHOD -> { type(type.getReturnType(), unsupported); for (Type argument : type.getArgumentTypes()) type(argument, unsupported); }
            default -> { }
        }
    }
    private static boolean platform(String name) { return name.startsWith("net/minecraftforge/") || name.startsWith("net/neoforged/") || name.startsWith("cpw/mods/"); }
    private static void name(String value, Set<String> unsupported) {
        if (value == null) return;
        if (value.startsWith("[")) { descriptor(value, unsupported); return; }
        if (platform(value) && !TYPES.contains(value)) unsupported.add(value.replace('/', '.'));
        if (value.startsWith("net/minecraft/")) unsupported.add("unmapped/patched Minecraft reference " + value.replace('/', '.'));
        if (value.startsWith("dev/n9ezz/loader/")) unsupported.add("private runtime API " + value.replace('/', '.'));
    }
    private static void checkMember(Member member, Map<String, ClassData> classes, Set<String> unsupported, Set<String> visited) {
        if (!visited.add(member.owner)) return;
        if (platform(member.owner)) {
            if (!TYPES.contains(member.owner)) return; // The type diagnostic already identifies this unsupported owner.
            if (member.name.startsWith("n9ezz")) { unsupported.add(member.owner.replace('/', '.') + "." + member.name + member.descriptor); return; }
            Class<?> api;
            try { api = Class.forName(member.owner.replace('/', '.'), false, FmlApiContract.class.getClassLoader()); }
            catch (ClassNotFoundException missing) { unsupported.add(member.owner.replace('/', '.')); return; }
            boolean found = false;
            if (member.method && member.name.equals("<init>")) {
                if (CONSTRUCTOR_TYPES.contains(member.owner)) for (var constructor : api.getDeclaredConstructors())
                    if ((Modifier.isPublic(constructor.getModifiers()) || Modifier.isProtected(constructor.getModifiers())) && Type.getConstructorDescriptor(constructor).equals(member.descriptor)) found = true;
            } else if (member.method) {
                for (var method : api.getMethods()) if (method.getName().equals(member.name) && Type.getMethodDescriptor(method).equals(member.descriptor)
                        && Modifier.isStatic(method.getModifiers()) == (member.opcode == Opcodes.INVOKESTATIC)) found = true;
            } else {
                for (var field : api.getFields()) if (field.getName().equals(member.name) && Type.getDescriptor(field.getType()).equals(member.descriptor)
                        && Modifier.isStatic(field.getModifiers()) == (member.opcode == Opcodes.GETSTATIC || member.opcode == Opcodes.PUTSTATIC)
                        && (!Modifier.isFinal(field.getModifiers()) || member.opcode == Opcodes.GETSTATIC || member.opcode == Opcodes.GETFIELD)) found = true;
            }
            if (!found) unsupported.add(member.owner.replace('/', '.') + "." + member.name + member.descriptor);
            return;
        }
        ClassData own = classes.get(member.owner);
        if (own == null || (member.method ? own.methods.containsKey(member.name + member.descriptor) : own.fields.contains(member.name + member.descriptor))) return;
        if (own.parent != null) checkMember(new Member(own.parent, member.name, member.descriptor, member.method, member.opcode), classes, unsupported, visited);
        if (own.interfaces != null) for (String iface : own.interfaces) checkMember(new Member(iface, member.name, member.descriptor, member.method, member.opcode), classes, unsupported, visited);
    }
    private static LoaderException error(ModMetadata mod, String code, String message) { return new LoaderException(new Diagnostic(code, message, mod.id(), "fml-preflight", mod.jar())); }
}
