package dev.n9ezz.loader.core;

public enum LifecycleEvent {
    DISCOVERED, RESOLVED, TRANSFORMERS_READY, COMMON_SETUP, CLIENT_SETUP, READY, FAILED
}
