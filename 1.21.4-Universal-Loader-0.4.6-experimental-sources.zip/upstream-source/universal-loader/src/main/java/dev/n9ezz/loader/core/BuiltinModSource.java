package dev.n9ezz.loader.core;

import com.google.gson.JsonObject;
import com.google.gson.Strictness;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import dev.n9ezz.loader.metadata.MetadataReader;
import dev.n9ezz.loader.metadata.MetadataException;
import dev.n9ezz.loader.metadata.ModMetadata;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;
import java.util.Objects;
import java.util.HashSet;

/** A packaged mod is a source for the shared runtime, never a second platform engine. */
public final class BuiltinModSource {
    public static final String CLIENT_MANIFEST = "META-INF/n9ezz/embedded-client.json";
    private static final int MAX_MANIFEST_SIZE = 16_384;
    private static final int MAX_BUNDLE_SIZE = 256 * 1024 * 1024;
    private final ClassLoader resources;
    private final String manifestResource;

    public record BundleInfo(String resource, String id, String version, String sha256, int size) { }

    private BuiltinModSource(ClassLoader resources, String manifestResource) {
        this.resources = Objects.requireNonNull(resources, "resources");
        this.manifestResource = checkedResource(manifestResource);
    }

    public static BuiltinModSource embeddedClient() {
        return resource(BuiltinModSource.class.getClassLoader(), CLIENT_MANIFEST);
    }

    /** Useful for other fixed bundles and for independent native-fixture verification. */
    public static BuiltinModSource resource(ClassLoader resources, String manifestResource) {
        return new BuiltinModSource(resources, manifestResource);
    }

    public List<ModMetadata> discover(Path gameDir) throws IOException {
        BundleInfo descriptor = describe();
        Path jar = materialize(gameDir, descriptor);
        List<ModMetadata> metadata;
        try {
            metadata = MetadataReader.read(jar);
        } catch (MetadataException unsupported) {
            throw new LoaderException(new Diagnostic(unsupported.code(), "Packaged mod '" + descriptor.id()
                    + "' " + descriptor.version() + ": " + unsupported.getMessage(), descriptor.id(), "builtin-discovery", jar), unsupported);
        }
        if (metadata.size() != 1 || !descriptor.id().equals(metadata.getFirst().id())
                || !descriptor.version().equals(metadata.getFirst().version())) {
            throw failure("BUILTIN_METADATA_MISMATCH", "Bundle manifest identity/version do not match its mod descriptor", descriptor.id(), jar);
        }
        return metadata;
    }

    public BundleInfo describe() throws IOException {
        try (InputStream input = resources.getResourceAsStream(manifestResource)) {
            if (input == null) throw failure("BUILTIN_MANIFEST_MISSING", "Missing packaged manifest: " + manifestResource, null, null);
            byte[] bytes = input.readNBytes(MAX_MANIFEST_SIZE + 1);
            if (bytes.length > MAX_MANIFEST_SIZE) throw new IllegalArgumentException("manifest exceeds 16 KiB");
            JsonObject root = readManifest(bytes);
            String resource = checkedResource(string(root, "resource"));
            String id = string(root, "id");
            String version = string(root, "version");
            String sha256 = string(root, "sha256");
            long size = integer(root, "size");
            if (!id.matches("[a-z][a-z0-9_-]{0,63}") || version.isBlank() || version.length() > 128
                    || !sha256.matches("[a-f0-9]{64}") || size < 1 || size > MAX_BUNDLE_SIZE) {
                throw new IllegalArgumentException("invalid bundle identity, SHA-256 or size");
            }
            if (root.has("java") && integer(root, "java") != 21) throw new IllegalArgumentException("bundle requires unsupported Java version");
            if (root.has("minecraft") && !string(root, "minecraft").equals("1.21.11")) throw new IllegalArgumentException("bundle requires unsupported Minecraft version");
            return new BundleInfo(resource, id, version, sha256, (int) size);
        } catch (LoaderException failure) {
            throw failure;
        } catch (RuntimeException | IOException invalid) {
            throw new LoaderException(new Diagnostic("BUILTIN_MANIFEST_INVALID", "Invalid packaged manifest " + manifestResource + ": " + invalid.getMessage(), null, "builtin-discovery", null), invalid);
        }
    }

    public byte[] verifiedBytes() throws IOException { return verifiedBytes(describe()); }

    public Path materialize(Path gameDir) throws IOException { return materialize(gameDir, describe()); }

    private byte[] verifiedBytes(BundleInfo descriptor) throws IOException {
        byte[] bytes;
        try (InputStream input = resources.getResourceAsStream(descriptor.resource())) {
            if (input == null) throw failure("BUILTIN_RESOURCE_MISSING", "Missing packaged mod: " + descriptor.resource(), descriptor.id(), null);
            bytes = input.readNBytes(descriptor.size() + 1);
        }
        if (bytes.length != descriptor.size() || !descriptor.sha256().equals(hash(bytes))) {
            throw failure("BUILTIN_RESOURCE_MISMATCH", "Packaged mod failed the manifest size/SHA-256 verification", descriptor.id(), null);
        }
        return bytes;
    }

    private Path materialize(Path gameDir, BundleInfo descriptor) throws IOException {
        byte[] bytes = verifiedBytes(descriptor);
        Path base = gameDir.toAbsolutePath().normalize();
        Path directory = base.resolve(".n9ezz/builtin");
        ensureNoSymlinks(directory);
        Files.createDirectories(directory);
        Path target = directory.resolve(descriptor.sha256() + ".jar");
        ensureNoSymlinks(target);
        Path lockPath = directory.resolve(descriptor.sha256() + ".lock");
        ensureNoSymlinks(lockPath);
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE, LinkOption.NOFOLLOW_LINKS);
                var lock = channel.tryLock()) {
            if (lock == null) throw failure("BUILTIN_CACHE_BUSY", "Another runtime is preparing this packaged mod cache", descriptor.id(), target);
            if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) {
                verifyCache(target, descriptor);
                return target.toRealPath();
            }
            Path temporary = Files.createTempFile(directory, ".builtin-", ".tmp");
            try {
                Files.write(temporary, bytes);
                try {
                    Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE);
                } catch (FileAlreadyExistsException concurrent) {
                    verifyCache(target, descriptor);
                } catch (AtomicMoveNotSupportedException unsupported) {
                    throw failure("BUILTIN_CACHE_ATOMIC_MOVE_UNSUPPORTED", "Cannot atomically prepare packaged mod cache", descriptor.id(), target);
                }
            } finally {
                Files.deleteIfExists(temporary);
            }
            verifyCache(target, descriptor);
            return target.toRealPath();
        } catch (OverlappingFileLockException concurrent) {
            throw failure("BUILTIN_CACHE_BUSY", "Another runtime in this JVM is preparing the packaged mod cache", descriptor.id(), target);
        }
    }

    private static void verifyCache(Path target, BundleInfo descriptor) throws IOException {
        if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) || Files.size(target) != descriptor.size()
                || !descriptor.sha256().equals(hash(Files.readAllBytes(target)))) {
            throw failure("BUILTIN_CACHE_MISMATCH", "Existing packaged mod cache is altered; preserving the file", descriptor.id(), target);
        }
    }

    private static JsonObject readManifest(byte[] bytes) throws IOException {
        String text = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        try (JsonReader reader = new JsonReader(new StringReader(text))) {
            reader.setStrictness(Strictness.STRICT);
            JsonObject root = new JsonObject();
            var names = new HashSet<String>();
            reader.beginObject();
            while (reader.hasNext()) {
                String name = reader.nextName();
                if (!names.add(name)) throw new IllegalArgumentException("duplicate manifest key: " + name);
                switch (reader.peek()) {
                    case STRING -> root.addProperty(name, reader.nextString());
                    case NUMBER -> root.addProperty(name, new java.math.BigDecimal(reader.nextString()));
                    case BOOLEAN -> root.addProperty(name, reader.nextBoolean());
                    case NULL -> { reader.nextNull(); root.add(name, com.google.gson.JsonNull.INSTANCE); }
                    default -> throw new IllegalArgumentException("bundle manifest fields must be primitive values");
                }
            }
            reader.endObject();
            if (reader.peek() != JsonToken.END_DOCUMENT) throw new IllegalArgumentException("trailing manifest content");
            return root;
        }
    }

    private static String string(JsonObject root, String name) {
        if (!root.has(name) || !root.get(name).isJsonPrimitive() || !root.getAsJsonPrimitive(name).isString())
            throw new IllegalArgumentException("manifest field must be a string: " + name);
        return root.get(name).getAsString();
    }

    private static long integer(JsonObject root, String name) {
        if (!root.has(name) || !root.get(name).isJsonPrimitive() || !root.getAsJsonPrimitive(name).isNumber()
                || !root.get(name).getAsString().matches("[0-9]+")) throw new IllegalArgumentException("manifest field must be an integer: " + name);
        return Long.parseLong(root.get(name).getAsString());
    }

    private static void ensureNoSymlinks(Path target) {
        Path current = target.getRoot();
        for (Path part : target) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current)) throw failure("BUILTIN_CACHE_SYMLINK", "Packaged mod cache path contains a symbolic link", null, current);
        }
    }

    private static String checkedResource(String resource) {
        Objects.requireNonNull(resource, "resource");
        if (resource.isBlank() || resource.startsWith("/") || resource.contains("\\")
                || resource.contains(":") || java.util.Arrays.stream(resource.split("/", -1)).anyMatch(part -> part.isEmpty() || part.equals(".") || part.equals(".."))) {
            throw new IllegalArgumentException("Unsafe resource name: " + resource);
        }
        return resource;
    }

    private static String hash(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }

    private static LoaderException failure(String code, String message, String id, Path source) {
        return new LoaderException(new Diagnostic(code, message, id, "builtin-discovery", source));
    }
}
