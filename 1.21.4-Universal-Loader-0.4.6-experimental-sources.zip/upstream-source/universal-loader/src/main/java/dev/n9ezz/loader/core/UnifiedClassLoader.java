package dev.n9ezz.loader.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.net.URL;
import java.nio.file.Path;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.security.SecureClassLoader;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/** One child-first loader for all mod formats; JVM, runtime, and supported shim APIs remain parent-owned. */
public final class UnifiedClassLoader extends SecureClassLoader implements AutoCloseable {
    static { registerAsParallelCapable(); }
    private static final int MAX_CLASS_BYTES = 16 * 1024 * 1024;
    private static final List<String> PARENT_PREFIXES = List.of("java.", "javax.", "jdk.", "sun.", "com.sun.",
        "dev.n9ezz.loader.", "org.objectweb.asm.", "com.google.gson.", "org.tomlj.", "org.antlr.",
        "net.fabricmc.", "org.quiltmc.", "net.minecraftforge.", "net.neoforged.", "cpw.mods.", "org.spongepowered.asm.", "com.llamalad7.mixinextras.");
    @FunctionalInterface public interface GeneratedClassProvider { byte[] generate(String binaryName); }
    /** Explicit game integration leaves loader APIs parent-owned and vets every Fabric API source. */
    public record GameIntegration(Set<Path> fabricApiJars, Path bundledClientJar) {
        public GameIntegration(Set<Path> fabricApiJars) { this(fabricApiJars, null); }
        public GameIntegration { fabricApiJars = Set.copyOf(fabricApiJars); }
    }
    private record Definition(Path source, byte[] bytes, ProtectionDomain domain) {}
    private final Map<String, Definition> definitions = new TreeMap<>();
    private final Map<String, List<URL>> resources = new LinkedHashMap<>();
    private final TransformationPipeline pipeline;
    private final Path gameJar;
    private final GameIntegration integration;
    private final Set<String> invalidClasses = ConcurrentHashMap.newKeySet();
    private final List<URL> classPath = new ArrayList<>();
    private volatile GeneratedClassProvider generatedClasses;
    private final Object mixinLoadLock = new Object();
    private volatile boolean closed;

    public UnifiedClassLoader(List<Path> jars, ClassLoader parent, TransformationPipeline pipeline) throws IOException {
        this(jars, null, parent, pipeline);
    }

    /** The game role is explicit and unique; it never weakens mod/library class restrictions. */
    public UnifiedClassLoader(List<Path> jars, Path gameJar, ClassLoader parent, TransformationPipeline pipeline) throws IOException {
        this(jars, gameJar, parent, pipeline, null);
    }
    public UnifiedClassLoader(List<Path> jars, Path gameJar, ClassLoader parent, TransformationPipeline pipeline, GameIntegration integration) throws IOException {
        super(parent);
        this.pipeline = Objects.requireNonNull(pipeline, "pipeline");
        this.gameJar = gameJar == null ? null : gameJar.toRealPath();
        if (integration == null) this.integration = null;
        else {
            Set<Path> vetted = new TreeSet<>();
            for (Path path : integration.fabricApiJars()) {
                Path real = path.toRealPath();
                if (!dev.n9ezz.loader.fabric.SelectedFabricApi.isVerifiedModule(real)) throw new IOException("Fabric API class role requires exact verified module bytes: " + real);
                vetted.add(real);
            }
            Path client = integration.bundledClientJar() == null ? null : integration.bundledClientJar().toRealPath();
            if (client != null && !BundledClientContract.isVerifiedArchive(client)) throw new IOException("Builtin client class role requires the pinned complete client: " + client);
            this.integration = new GameIntegration(vetted, client);
        }
        if (!pipeline.isFrozen()) throw new IllegalStateException("Transformation pipeline must be frozen before classpath indexing");
        List<Diagnostic> diagnostics = new ArrayList<>();
        TreeSet<Path> paths = new TreeSet<>();
        for (Path jar : jars) {
            Path source = jar.toRealPath();
            if (source.equals(this.gameJar)) throw new LoaderException(new Diagnostic("GAME_ROLE_COLLISION", "The game Jar cannot also be declared as a mod or library", null, "class-index", source));
            paths.add(source);
        }
        if (this.gameJar != null) {
            try (JarFile game = new JarFile(this.gameJar.toFile(), true)) {
                JarEntry main = game.getJarEntry("net/minecraft/client/main/Main.class");
                if (main == null || main.isDirectory()) throw new LoaderException(new Diagnostic("INVALID_GAME_JAR", "Explicit game Jar does not contain net/minecraft/client/main/Main.class", null, "class-index", this.gameJar));
            }
            paths.add(this.gameJar);
        }
        for (Path path : paths) index(path, path.equals(this.gameJar), diagnostics);
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
    }

    private void index(Path path, boolean gameRole, List<Diagnostic> diagnostics) throws IOException {
        URL source = path.toUri().toURL();
        classPath.add(source);
        ProtectionDomain domain = new ProtectionDomain(new CodeSource(source, (Certificate[]) null), null, this, null);
        try (JarFile jar = new JarFile(path.toFile(), true)) {
            Map<String, JarEntry> selected = new TreeMap<>();
            boolean multiRelease = jar.getManifest() != null && "true".equalsIgnoreCase(jar.getManifest().getMainAttributes().getValue("Multi-Release"));
            for (JarEntry candidate : jar.stream().filter(entry -> !entry.isDirectory()).sorted(java.util.Comparator.comparing(JarEntry::getName)).toList()) {
                String logical = candidate.getName();
                if (logical.startsWith("META-INF/versions/") && integration != null) {
                    String[] parts = logical.split("/", 4);
                    if (parts.length != 4) throw new IOException("Malformed multi-release entry: " + logical);
                    int version;
                    try { version = Integer.parseInt(parts[2]); } catch (NumberFormatException invalid) { throw new IOException("Malformed multi-release version: " + logical); }
                    if (!multiRelease || version < 9 || version > 21) continue;
                    logical = parts[3];
                    JarEntry existing = selected.get(logical);
                    if (existing != null && existing.getName().startsWith("META-INF/versions/")) {
                        int previous = Integer.parseInt(existing.getName().split("/", 4)[2]);
                        if (previous > version) continue;
                    }
                } else if (integration != null && selected.containsKey(logical)) continue;
                selected.put(logical, candidate);
            }
            for (Map.Entry<String, JarEntry> selectedEntry : selected.entrySet()) {
                JarEntry entry = selectedEntry.getValue();
                String logicalName = selectedEntry.getKey();
                URL resource = new URL("jar:" + source.toExternalForm() + "!/" + entry.getName());
                resources.computeIfAbsent(logicalName, ignored -> new ArrayList<>()).add(resource);
                if (!logicalName.endsWith(".class")) continue;
                if (logicalName.startsWith("META-INF/versions/")) {
                    diagnostics.add(new Diagnostic("UNSUPPORTED_MULTIRELEASE", "Multi-release mod class entries are not supported: " + entry.getName(), null, "class-index", path));
                    continue;
                }
                if (logicalName.equals("module-info.class")) continue;
                String name = logicalName.substring(0, logicalName.length() - 6).replace('/', '.');
                boolean fabricClass = name.startsWith("net.fabricmc.fabric.");
                if (parentOwned(name) || (fabricClass && (integration == null || !integration.fabricApiJars().contains(path)))) {
                    diagnostics.add(new Diagnostic("RESERVED_CLASS", "Mod/library Jar defines parent-owned or game class '" + name + "'", null, "class-index", path));
                    continue;
                }
                if (entry.getSize() > MAX_CLASS_BYTES) throw new IOException("Class exceeds " + MAX_CLASS_BYTES + " bytes: " + entry.getName());
                byte[] bytes;
                try (InputStream stream = jar.getInputStream(entry)) {
                    bytes = stream.readNBytes(MAX_CLASS_BYTES + 1);
                }
                if (bytes.length > MAX_CLASS_BYTES) throw new IOException("Class exceeds " + MAX_CLASS_BYTES + " bytes: " + entry.getName());
                if (!gameRole && name.startsWith("net.minecraft.")
                        && (integration == null || !path.equals(integration.bundledClientJar()) || !BundledClientContract.isVerifiedClass(path, name, bytes))) {
                    diagnostics.add(new Diagnostic("RESERVED_CLASS", "Mod/library Jar defines reserved game class '" + name + "'", null, "class-index", path));
                    continue;
                }
                Definition previous = definitions.putIfAbsent(name, new Definition(path, bytes, domain));
                if (previous != null) {
                    diagnostics.add(new Diagnostic("DUPLICATE_CLASS", "Class '" + name + "' is declared by both " + previous.source() + " and " + path, null, "class-index", path));
                    continue;
                }
                try {
                    BytecodeValidator.validate(name, bytes);
                    List<String> references = gameRole ? List.of() : BytecodeValidator.unsupportedReferences(bytes);
                    if (integration != null) references = references.stream().filter(value -> !value.startsWith("Minecraft:")).toList();
                    if (!references.isEmpty()) diagnostics.add(new Diagnostic("UNSUPPORTED_GAME_OR_ENGINE_REFERENCE", "Class '" + name + "' needs game mappings or an unavailable engine integration: " + String.join(", ", references), null, "class-index", path));
                } catch (LoaderException error) {
                    for (Diagnostic diagnostic : error.diagnostics()) diagnostics.add(new Diagnostic(diagnostic.code(), diagnostic.message(), null, "class-index", path));
                }
            }
        }
    }

    private boolean parentOwned(String name) {
        if (integration != null && name.startsWith("net.fabricmc.fabric.")) return false;
        return PARENT_PREFIXES.stream().anyMatch(name::startsWith);
    }
    public Path sourceOf(String name) { Definition definition = definitions.get(name); return definition == null ? null : definition.source(); }
    public List<String> classNames() { return List.copyOf(definitions.keySet()); }
    public Path gameJar() { return gameJar; }
    public URL[] classPath() { return classPath.toArray(URL[]::new); }
    public boolean isClassLoaded(String name) { return findLoadedClass(name) != null; }
    public void registerInvalidClass(String name) { invalidClasses.add(name); }
    public void setGeneratedClassProvider(GeneratedClassProvider provider) {
        synchronized (mixinLoadLock) {
            if (closed) throw new IllegalStateException("Runtime session is closed");
            if (generatedClasses != null) throw new IllegalStateException("Generated class provider is already installed");
            generatedClasses = Objects.requireNonNull(provider);
        }
    }
    public byte[] classBytes(String name, boolean preMixinTransformers) throws IOException, ClassNotFoundException {
        Definition definition = definitions.get(name);
        byte[] bytes;
        if (definition != null) bytes = definition.bytes();
        else {
            if (gameJar != null && name.startsWith("net.minecraft.")) throw new ClassNotFoundException(name);
            try (InputStream input = getParent().getResourceAsStream(name.replace('.', '/') + ".class")) {
                if (input == null) throw new ClassNotFoundException(name);
                bytes = input.readNBytes(MAX_CLASS_BYTES + 1);
                if (bytes.length > MAX_CLASS_BYTES) throw new IOException("Class resource exceeds maximum size: " + name);
            }
        }
        return preMixinTransformers ? pipeline.applyBefore(name, bytes, TransformationPipeline.Stage.MIXIN) : bytes.clone();
    }

    @Override protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        // Mixin may inspect/load a second class while defining the first. A single
        // reentrant lock avoids inversions between Mixin's lock and parallel per-class locks.
        synchronized (mixinLoadLock) {
            if (invalidClasses.contains(name)) throw new ClassNotFoundException("Mixin implementation classes cannot be loaded directly: " + name);
            Class<?> found = findLoadedClass(name);
            if (found == null) {
                if (parentOwned(name)) found = getParent().loadClass(name);
                else if (definitions.containsKey(name)) found = findClass(name);
                else {
                    if (closed && generatedClasses != null) throw new ClassNotFoundException("Runtime session is closed: " + name);
                    byte[] generated = generatedClasses == null ? null : generatedClasses.generate(name);
                    if (generated != null) found = defineGenerated(name, generated);
                    else if (gameJar != null && name.startsWith("net.minecraft.")) throw new ClassNotFoundException("Class is absent from the explicit game Jar: " + name);
                    else found = getParent().loadClass(name);
                }
            }
            if (resolve) resolveClass(found);
            return found;
        }
    }
    private Class<?> defineGenerated(String name, byte[] bytes) {
        if (closed) throw new IllegalStateException("Runtime session is closed: " + name);
        BytecodeValidator.validate(name, bytes);
        return defineClass(name, bytes, 0, bytes.length, UnifiedClassLoader.class.getProtectionDomain());
    }
    @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
        if (closed) throw new ClassNotFoundException("Runtime session is closed: " + name);
        Definition definition = definitions.get(name);
        if (definition == null) throw new ClassNotFoundException(name);
        byte[] bytes = pipeline.apply(name, definition.bytes());
        synchronized (mixinLoadLock) {
            if (closed) throw new ClassNotFoundException("Runtime session is closed: " + name);
            return defineClass(name, bytes, 0, bytes.length, definition.domain());
        }
    }
    @Override public URL getResource(String name) {
        List<URL> urls = resources.get(name);
        if (!closed && urls != null && !urls.isEmpty()) return urls.getFirst();
        return getParent().getResource(name);
    }
    @Override public InputStream getResourceAsStream(String name) {
        URL resource = getResource(name);
        if (resource == null) return null;
        try {
            // AWT Font.createFont copies some font streams one byte at a time.
            // Buffer compressed JAR resources so this does not inflate per byte.
            return new BufferedInputStream(resource.openStream(), 64 * 1024);
        } catch (IOException error) { return null; }
    }
    @Override public Enumeration<URL> getResources(String name) throws IOException {
        List<URL> urls = new ArrayList<>();
        if (!closed) urls.addAll(resources.getOrDefault(name, List.of()));
        getParent().getResources(name).asIterator().forEachRemaining(urls::add);
        return Collections.enumeration(urls.stream().distinct().toList());
    }
    @Override public void close() { synchronized (mixinLoadLock) { closed = true; } }
}
