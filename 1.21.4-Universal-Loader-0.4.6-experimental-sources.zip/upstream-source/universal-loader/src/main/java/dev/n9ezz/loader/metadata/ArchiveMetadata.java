package dev.n9ezz.loader.metadata;

import java.util.List;
import java.util.Objects;

/** Parsing does not activate declared transformers, libraries, or entrypoints. */
public record ArchiveMetadata(List<ModMetadata> mods, ArchiveFeatures features) {
    public ArchiveMetadata {
        mods = List.copyOf(mods);
        Objects.requireNonNull(features, "features");
    }
}
