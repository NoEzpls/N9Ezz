package dev.n9ezz.loader.metadata;

import java.util.List;

/** Declarations retained for an explicitly enabled shared Fabric runtime. */
public record ArchiveFeatures(List<String> nestedJars, List<String> accessWideners) {
    public static final ArchiveFeatures NONE = new ArchiveFeatures(List.of(), List.of());
    public ArchiveFeatures {
        nestedJars = List.copyOf(nestedJars);
        accessWideners = List.copyOf(accessWideners);
    }
}
