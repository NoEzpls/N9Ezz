package dev.n9ezz.loader.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

/** Synchronous, deterministic bus. Higher priorities run first, ties follow registration order. */
public final class EventBus {
    private record Handler(long sequence, int priority, Consumer<LifecycleEvent> callback) {}
    private final EnumMap<LifecycleEvent, List<Handler>> handlers = new EnumMap<>(LifecycleEvent.class);
    private long sequence;

    public synchronized AutoCloseable on(LifecycleEvent event, int priority, Consumer<LifecycleEvent> handler) {
        Objects.requireNonNull(event, "event");
        Objects.requireNonNull(handler, "handler");
        Handler registration = new Handler(sequence++, priority, handler);
        handlers.computeIfAbsent(event, ignored -> new ArrayList<>()).add(registration);
        return () -> {
            synchronized (EventBus.this) {
                List<Handler> registered = handlers.get(event);
                if (registered != null) registered.remove(registration);
            }
        };
    }

    public void publish(LifecycleEvent event) {
        Objects.requireNonNull(event, "event");
        List<Handler> snapshot;
        synchronized (this) {
            snapshot = handlers.getOrDefault(event, List.of()).stream()
                .sorted(Comparator.comparingInt(Handler::priority).reversed().thenComparingLong(Handler::sequence))
                .toList();
        }
        // Changes made by a callback apply on the next publication, never midway through this one.
        for (Handler handler : snapshot) handler.callback().accept(event);
    }
}
