package dev.n9ezz.loader.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/** Shared transform ordering. Empty stages do not claim a mappings, access-widener or Mixin implementation. */
public final class TransformationPipeline {
    public enum Stage { MAPPING, ACCESS, CORE, MIXIN, POST }
    @FunctionalInterface public interface Transformer { byte[] transform(String binaryClassName, byte[] bytecode) throws Exception; }
    private record Registration(Stage stage, int priority, String id, Transformer transformer) {}
    private final List<Registration> registrations = new ArrayList<>();
    private final Set<String> ids = new HashSet<>();
    private volatile List<Registration> frozen;

    public synchronized void register(Stage stage, int priority, String id, Transformer transformer) {
        if (frozen != null) throw new IllegalStateException("Transformation pipeline is frozen");
        Objects.requireNonNull(stage, "stage"); Objects.requireNonNull(transformer, "transformer");
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Transformer id is required");
        if (!ids.add(id)) throw new IllegalArgumentException("Duplicate transformer id: " + id);
        registrations.add(new Registration(stage, priority, id, transformer));
    }
    public synchronized void freeze() {
        if (frozen == null) frozen = registrations.stream().sorted(Comparator.comparing(Registration::stage)
            .thenComparing(Comparator.comparingInt(Registration::priority).reversed()).thenComparing(Registration::id)).toList();
    }
    public boolean isFrozen() { return frozen != null; }
    public List<String> order() {
        List<Registration> snapshot = frozen;
        if (snapshot == null) throw new IllegalStateException("Transformation pipeline must be frozen");
        return snapshot.stream().map(registration -> registration.stage() + ":" + registration.id()).toList();
    }
    public byte[] apply(String name, byte[] input) {
        return applyBefore(name, input, null);
    }
    /** Raw class inspection by Mixin must never recursively invoke Mixin or POST. */
    public byte[] applyBefore(String name, byte[] input, Stage exclusiveStage) {
        List<Registration> snapshot = frozen;
        if (snapshot == null) throw new IllegalStateException("Transformation pipeline must be frozen before defining classes");
        BytecodeValidator.validate(name, input);
        byte[] result = input.clone();
        for (Registration registration : snapshot) {
            if (exclusiveStage != null && registration.stage().compareTo(exclusiveStage) >= 0) break;
            try {
                result = Objects.requireNonNull(registration.transformer().transform(name, result), "Transformer returned null");
                BytecodeValidator.validate(name, result);
            } catch (Exception | Error error) {
                throw new LoaderException(new Diagnostic("TRANSFORM_FAILED", "Transformer '" + registration.id() + "' in " + registration.stage() + " failed for '" + name + "'"), error);
            }
        }
        return result;
    }
}
