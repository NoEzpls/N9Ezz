package dev.n9ezz.loader.fml;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/** Private runtime ownership behind public API descriptors; accepted mod references exclude this bridge. */
public final class FmlBindings {
    private FmlBindings() {}
    private record Binding(DeferredTasks tasks, ClassLoader loader, Supplier<AutoCloseable> context) {}
    private static final Map<Object, Binding> BINDINGS = new IdentityHashMap<>();
    static synchronized void bind(Object mod, DeferredTasks tasks, ClassLoader loader, Supplier<AutoCloseable> context) {
        if (BINDINGS.putIfAbsent(mod, new Binding(tasks, loader, context)) != null) throw new IllegalStateException("Duplicate FML container binding");
    }
    static synchronized void unbind(Object mod) { BINDINGS.remove(mod); }
    private static synchronized Binding binding(Object mod) {
        Binding result = BINDINGS.get(mod);
        if (result == null) throw new IllegalStateException("FML container is outside its owning runtime");
        return result;
    }
    public static CompletableFuture<Void> enqueue(Object mod, Runnable work) {
        java.util.Objects.requireNonNull(work);
        return enqueue(mod, () -> { work.run(); return null; });
    }
    public static <T> CompletableFuture<T> enqueue(Object mod, Supplier<T> work) { return binding(mod).tasks.enqueue(mod, work); }
    static AutoCloseable enter(Object mod) {
        Binding binding = binding(mod);
        Thread thread = Thread.currentThread();
        ClassLoader previous = thread.getContextClassLoader();
        thread.setContextClassLoader(binding.loader);
        AutoCloseable active;
        try { active = binding.context.get(); }
        catch (Throwable failure) { thread.setContextClassLoader(previous); throw failure; }
        return () -> { try { active.close(); } finally { thread.setContextClassLoader(previous); } };
    }
}
