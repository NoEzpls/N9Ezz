package dev.n9ezz.loader.metadata;

import java.nio.file.Path;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public record ModMetadata(String id, String version, Platform platform, Path jar,
                          List<Dependency> dependencies, List<Entrypoint> entrypoints,
                          List<String> mixins, String namespace, Set<String> provides) {
    public ModMetadata {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(version, "version");
        Objects.requireNonNull(platform, "platform");
        Objects.requireNonNull(jar, "jar");
        Objects.requireNonNull(namespace, "namespace");
        dependencies = List.copyOf(dependencies);
        entrypoints = List.copyOf(entrypoints);
        mixins = List.copyOf(mixins);
        provides = Set.copyOf(provides);
    }
}
