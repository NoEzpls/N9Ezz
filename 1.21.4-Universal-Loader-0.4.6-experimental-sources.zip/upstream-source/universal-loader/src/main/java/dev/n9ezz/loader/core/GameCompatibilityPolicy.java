package dev.n9ezz.loader.core;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import dev.n9ezz.loader.fml.FmlCompatibilityRuntime;
import dev.n9ezz.loader.quilt.QuiltRuntime;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.jar.JarFile;
import org.tomlj.Toml;

/** Explicit per-mod contracts prevent a small ABI adapter impersonating a complete platform. */
public final class GameCompatibilityPolicy {
    public static final String QUILT_CONTRACT = "quilt-lifecycle-v1";
    public static final String FML_CONTRACT = "fml-lifecycle-v1";
    private GameCompatibilityPolicy() { }

    public static void validate(ModMetadata mod) {
        if (mod.platform() != Platform.N9EZZ && mod.platform() != Platform.FABRIC) {
            String required = mod.platform() == Platform.QUILT ? QUILT_CONTRACT : FML_CONTRACT;
            if (!required.equals(declaredContract(mod))) throw failure(mod, "UNSUPPORTED_GAME_PLATFORM",
                    "The game layer requires an explicit n9ezz.compatibility=" + required
                    + " declaration; this is a bounded API contract, not complete platform compatibility");
        }
        if (!mod.namespace().equals("none") && !mod.namespace().equals("intermediary")) {
            throw failure(mod, "UNSUPPORTED_NAMESPACE", "The common game runs intermediary; declared mod namespace is "
                    + mod.namespace() + ". Mojang-named/official and SRG mod remapping are not implemented");
        }
    }

    /** javafml is a language identity scoped to its declaring format; its versions conflict globally. */
    public static Map<String, String> additionalProviders(ModMetadata mod) {
        validate(mod);
        return switch (mod.platform()) {
            case QUILT -> Map.of("quilt_loader", QuiltRuntime.VERIFIED_LOADER_ABI_VERSION);
            case FORGE, NEOFORGE -> FmlCompatibilityRuntime.providerVersions(mod.platform());
            default -> Map.of();
        };
    }

    /** A callback cannot promise its FML prerequisite's setup before the global FML barrier. */
    public static void validateStageDependencies(List<ModMetadata> ordered) {
        Map<String, ModMetadata> providers = new HashMap<>();
        for (ModMetadata mod : ordered) {
            providers.put(mod.id(), mod);
            for (String alias : mod.provides()) providers.put(alias, mod);
        }
        List<Diagnostic> failures = new ArrayList<>();
        for (ModMetadata mod : ordered) {
            if (isFml(mod) || mod.entrypoints().isEmpty()) continue;
            for (var dependency : mod.dependencies()) {
                ModMetadata provider = providers.get(dependency.id());
                if (dependency.optional() || dependency.incompatible() || provider == null || !isFml(provider)) continue;
                failures.add(new Diagnostic("UNSUPPORTED_CROSS_PHASE_DEPENDENCY",
                        "Initializer dependency on FML mod '" + provider.id() + "' cannot guarantee its setup completion: "
                        + "FML common/client listeners run at global phase barriers after ordinary callbacks. "
                        + "This lifecycle-v1 combination is rejected before initialization",
                        mod.id(), "stage-dependencies", mod.jar()));
            }
        }
        if (!failures.isEmpty()) throw new LoaderException(failures);
    }

    private static boolean isFml(ModMetadata mod) {
        return mod.platform() == Platform.FORGE || mod.platform() == Platform.NEOFORGE;
    }

    private static String declaredContract(ModMetadata mod) {
        String descriptor = switch (mod.platform()) {
            case QUILT -> "quilt.mod.json";
            case FORGE -> "META-INF/mods.toml";
            case NEOFORGE -> "META-INF/neoforge.mods.toml";
            default -> throw new IllegalArgumentException("Not a selected platform adapter");
        };
        try (JarFile archive = new JarFile(mod.jar().toFile(), true)) {
            var entry = archive.getJarEntry(descriptor);
            if (entry == null || entry.isDirectory()) return null;
            byte[] bytes;
            try (var stream = archive.getInputStream(entry)) { bytes = stream.readNBytes(1_048_577); }
            if (bytes.length > 1_048_576) throw new IOException("Descriptor exceeds supported size");
            String text = new String(bytes, StandardCharsets.UTF_8);
            if (mod.platform() == Platform.QUILT) {
                JsonObject root = JsonParser.parseString(text).getAsJsonObject();
                if (!root.has("n9ezz")) return null;
                var extension = root.getAsJsonObject("n9ezz");
                var value = extension.get("compatibility");
                return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()
                        ? value.getAsString() : null;
            }
            var toml = Toml.parse(text);
            if (toml.hasErrors()) throw new IOException("Invalid TOML compatibility descriptor");
            return toml.getString("n9ezz.compatibility");
        } catch (IOException | RuntimeException error) {
            if (error instanceof LoaderException failure) throw failure;
            throw new LoaderException(new Diagnostic("GAME_CONTRACT_INVALID", "Cannot validate selected game contract: "
                    + error.getMessage(), mod.id(), "game-contract", mod.jar()), error);
        }
    }

    private static LoaderException failure(ModMetadata mod, String code, String message) {
        return new LoaderException(new Diagnostic(code, message, mod.id(), "game-contract", mod.jar()));
    }
}
