package dev.n9ezz.loader.core;

import dev.n9ezz.loader.metadata.MetadataReader;
import dev.n9ezz.loader.metadata.ModMetadata;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Flat, sorted discovery: no nested Jar extraction or silent platform installation. */
public final class ModDiscovery {
    private ModDiscovery() {}
    public static List<ModMetadata> discover(Path directory) throws IOException {
        if (!Files.isDirectory(directory)) throw new IOException("Mod directory is missing or not a directory: " + directory);
        List<Path> jars;
        try (var paths = Files.list(directory)) {
            jars = paths.filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar"))
                .sorted(Comparator.comparing(path -> path.getFileName().toString())).toList();
        }
        List<ModMetadata> mods = new ArrayList<>();
        for (Path jar : jars) {
            if (!Files.isRegularFile(jar, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Mod Jar must be a regular file (symbolic links are not supported): " + jar);
            ExternalModPolicy.validate(jar);
            List<ModMetadata> metadata = MetadataReader.read(jar.toRealPath());
            if (metadata.isEmpty()) throw new LoaderException(new Diagnostic("MISSING_METADATA", "Jar in the mod directory has no supported metadata descriptor; explicit libraries belong on extraClasspath", null, "discovery", jar));
            mods.addAll(metadata);
        }
        return List.copyOf(mods);
    }
}
