package dev.n9ezz.loader.metadata;

/** The metadata/API contract requested by a mod, never a choice of launch engine. */
public enum Platform { N9EZZ, FABRIC, QUILT, FORGE, NEOFORGE }
