package dev.n9ezz.loader.fabric;

import dev.n9ezz.loader.mapping.TinyMappingIndex;
import java.util.Collection;
import java.util.Objects;
import net.fabricmc.loader.api.MappingResolver;

/** Adapts binary-name reflection queries to the same mappings used by the game remapper. */
public final class FabricMappingResolver implements MappingResolver {
    private final TinyMappingIndex index;
    private final String runtime;
    public FabricMappingResolver(TinyMappingIndex index, String runtime) {
        this.index = Objects.requireNonNull(index);
        if (!index.namespaces().contains(runtime)) throw new IllegalArgumentException("Unknown runtime namespace " + runtime);
        this.runtime = runtime;
    }
    @Override public Collection<String> getNamespaces() { return index.namespaces(); }
    @Override public String getCurrentRuntimeNamespace() { return runtime; }
    @Override public String mapClassName(String namespace, String className) {
        return index.mapClass(namespace, runtime, internal(className)).replace('/', '.');
    }
    @Override public String unmapClassName(String namespace, String className) {
        return index.mapClass(runtime, namespace, internal(className)).replace('/', '.');
    }
    @Override public String mapFieldName(String namespace, String owner, String name, String descriptor) {
        return index.mapField(namespace, runtime, internal(owner), name, descriptor);
    }
    @Override public String mapMethodName(String namespace, String owner, String name, String descriptor) {
        return index.mapMethod(namespace, runtime, internal(owner), name, descriptor);
    }
    private static String internal(String binaryName) {
        Objects.requireNonNull(binaryName);
        if (binaryName.indexOf('/') >= 0) throw new IllegalArgumentException("Fabric MappingResolver expects binary names, not internal names");
        return binaryName.replace('.', '/');
    }
}
