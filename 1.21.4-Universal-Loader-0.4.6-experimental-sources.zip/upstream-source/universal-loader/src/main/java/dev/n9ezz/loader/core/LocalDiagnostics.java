package dev.n9ezz.loader.core;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Secret redaction for this loader's local error output. Does not intercept network traffic. */
public final class LocalDiagnostics {
    private static final String MARKER = "[REDACTED]";
    private static final String NAMES = "(?:access[_-]?token|refresh[_-]?token|client[_-]?token|id[_-]?token|client[_-]?secret|api[_-]?key|password|passwd|session[_-]?token|token)";
    private static final Pattern ASSIGNMENT = Pattern.compile("(?i)\\b" + NAMES + "\\b[\"']?[\\t ]*[:=][\\t ]*");
    private static final Pattern FLAG = Pattern.compile("(?i)(?<![\\w-])--" + NAMES + "(?:[\\t ]+|=)");
    private static final Pattern AUTHORIZATION = Pattern.compile("(?i)\\bAuthorization[\"']?[\\t ]*[:=][\\t ]*");
    private static final Pattern AUTH_SCHEME = Pattern.compile("(?i)(?:Bearer|Basic|ApiKey)[\\t ]+");
    private static final Pattern BEARER = Pattern.compile("(?i)\\bBearer[\\t ]+");
    private static final Set<String> SECRETS = ConcurrentHashMap.newKeySet();
    private static final Set<String> SECRET_OPTIONS = Set.of("accesstoken", "refreshtoken", "clienttoken", "idtoken", "clientsecret", "apikey", "password", "passwd", "sessiontoken", "token");

    private record Span(int start, int end) { }

    private LocalDiagnostics() { }

    public static void observeArguments(String[] arguments) {
        // Remember only credentials for error-output redaction. The original
        // argument array and all values forwarded to Minecraft remain intact.
        for (int index = 0; index < arguments.length; index++) {
            String argument = arguments[index];
            if (argument == null || !argument.startsWith("--")) continue;
            int equals = argument.indexOf('=');
            String key = equals < 0 ? argument.substring(2) : argument.substring(2, equals);
            key = key.replace("_", "").replace("-", "").toLowerCase(java.util.Locale.ROOT);
            if (!SECRET_OPTIONS.contains(key)) continue;
            String value = equals < 0 ? (index + 1 < arguments.length ? arguments[index + 1] : null) : argument.substring(equals + 1);
            // Short placeholders such as the offline demo token '0' must not
            // erase unrelated counters or IDs. Named fields are still masked.
            if (value != null && value.length() >= 8 && !value.startsWith("--") && value.length() <= 4096 && SECRETS.size() < 64) SECRETS.add(value);
        }
    }

    public static String redact(String text) {
        if (text == null) return null;
        List<Span> spans = new ArrayList<>();
        // Find all ranges in the original text. Rewriting a field's first word
        // must not prevent matching an observed multiword credential afterward.
        for (String secret : SECRETS.stream().sorted(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder())).toList()) {
            int from = 0;
            while ((from = text.indexOf(secret, from)) >= 0) {
                int end = from + secret.length();
                if (!partiallyOverlapsMarker(text, from, end)) addSpan(spans, text, from, end);
                from = end;
            }
        }
        collectValues(FLAG, text, spans, false);
        collectValues(ASSIGNMENT, text, spans, false);
        collectValues(AUTHORIZATION, text, spans, true);
        collectValues(BEARER, text, spans, false);
        if (spans.isEmpty()) return text;
        spans.sort(Comparator.comparingInt(Span::start).thenComparing(Comparator.comparingInt(Span::end).reversed()));
        StringBuilder safe = new StringBuilder(text.length());
        int cursor = 0;
        for (int index = 0; index < spans.size();) {
            Span first = spans.get(index++);
            int end = first.end();
            while (index < spans.size() && spans.get(index).start() <= end) end = Math.max(end, spans.get(index++).end());
            safe.append(text, cursor, first.start()).append(MARKER);
            cursor = end;
        }
        return safe.append(text, cursor, text.length()).toString();
    }

    private static void collectValues(Pattern prefix, String text, List<Span> spans, boolean authorization) {
        Matcher match = prefix.matcher(text);
        while (match.find()) {
            int value = match.end();
            if (value == text.length()) continue;
            boolean quoted = text.charAt(value) == '"' || text.charAt(value) == '\'';
            int content = quoted ? value + 1 : value;
            int end = quoted ? quotedEnd(text, content, text.charAt(value)) : tokenEnd(text, content);
            if (authorization) {
                Matcher scheme = AUTH_SCHEME.matcher(text).region(content, lineEnd(text, content));
                if (scheme.lookingAt()) {
                    content = scheme.end();
                    if (!quoted) {
                        if (content < text.length() && (text.charAt(content) == '"' || text.charAt(content) == '\'')) {
                            char credentialQuote = text.charAt(content++);
                            end = quotedEnd(text, content, credentialQuote);
                        } else end = tokenEnd(text, content);
                    }
                }
            }
            addSpan(spans, text, content, end);
        }
    }

    private static int quotedEnd(String text, int content, char quote) {
        boolean escaped = false;
        for (int index = content; index < text.length(); index++) {
            char character = text.charAt(index);
            // Malformed values cannot consume subsequent diagnostic/stack lines.
            if (character == '\r' || character == '\n') return index;
            if (escaped) { escaped = false; continue; }
            if (character == '\\') escaped = true;
            else if (character == quote) return index;
        }
        return text.length();
    }

    private static int tokenEnd(String text, int content) {
        if (text.startsWith(MARKER, content)) return content + MARKER.length();
        int end = content;
        while (end < text.length()) {
            char character = text.charAt(end);
            if (Character.isWhitespace(character) || "&,;]}\"')".indexOf(character) >= 0) break;
            end++;
        }
        return end;
    }

    private static int lineEnd(String text, int content) {
        int end = content;
        while (end < text.length() && text.charAt(end) != '\r' && text.charAt(end) != '\n') end++;
        return end;
    }

    private static void addSpan(List<Span> spans, String text, int start, int end) {
        if (end > start && !(end - start == MARKER.length() && text.startsWith(MARKER, start))) spans.add(new Span(start, end));
    }

    private static boolean partiallyOverlapsMarker(String text, int start, int end) {
        int marker = text.indexOf(MARKER, Math.max(0, start - MARKER.length() + 1));
        while (marker >= 0 && marker < end) {
            if (marker + MARKER.length() > start && (start > marker || end < marker + MARKER.length())) return true;
            marker = text.indexOf(MARKER, marker + MARKER.length());
        }
        return false;
    }

    public static String throwableText(Throwable error) {
        StringWriter buffer = new StringWriter();
        error.printStackTrace(new PrintWriter(buffer));
        // Keep types, frames, causes, suppressed failures and cycle markers.
        // Redacting the entire trace also protects nested exception messages.
        return redact(buffer.toString());
    }

    public static void printThrowable(Throwable error, PrintStream output) {
        output.print(throwableText(error));
    }
}
