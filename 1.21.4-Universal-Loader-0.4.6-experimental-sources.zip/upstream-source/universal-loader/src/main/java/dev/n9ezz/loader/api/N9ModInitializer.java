package dev.n9ezz.loader.api;

/** Entry point for an API-only N9Ezz mod in the shared runtime. */
@FunctionalInterface
public interface N9ModInitializer {
    void onInitialize(ModContext context) throws Exception;
}
