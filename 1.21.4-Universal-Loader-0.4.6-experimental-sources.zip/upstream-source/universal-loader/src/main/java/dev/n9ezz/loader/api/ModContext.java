package dev.n9ezz.loader.api;

import dev.n9ezz.loader.core.EventBus;
import java.nio.file.Path;
import java.util.Objects;

/** Per-mod initialization context. No Minecraft API is exposed by this prototype. */
public record ModContext(String modId, Path gameDirectory, EventBus events) {
    public ModContext {
        Objects.requireNonNull(modId, "modId");
        gameDirectory = Objects.requireNonNull(gameDirectory, "gameDirectory").toAbsolutePath().normalize();
        Objects.requireNonNull(events, "events");
    }
}
