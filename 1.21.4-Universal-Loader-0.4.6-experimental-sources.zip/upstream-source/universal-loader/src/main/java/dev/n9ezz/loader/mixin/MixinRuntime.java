package dev.n9ezz.loader.mixin;

import com.google.gson.JsonParser;
import com.llamalad7.mixinextras.MixinExtrasBootstrap;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.FabricUtil;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigSource;
import org.spongepowered.asm.mixin.transformer.IMixinTransformer;
import org.spongepowered.asm.service.MixinService;

/** One actual Mixin transformer in the common runtime, without any platform loader engine. */
public final class MixinRuntime implements AutoCloseable {
    public interface Host {
        /** Transformed requests apply MAPPING, ACCESS and CORE only, never MIXIN or POST. */
        byte[] classBytes(String binaryName, boolean runPreMixinTransformers) throws IOException, ClassNotFoundException;
        Class<?> findClass(String binaryName, boolean initialize) throws ClassNotFoundException;
        InputStream resource(String path);
        boolean isClassLoaded(String binaryName);
        void registerInvalidClass(String binaryName);
        default URL[] classPath() { return new URL[0]; }
    }
    public record Configuration(String modId, String resource) implements IMixinConfigSource {
        public Configuration { Objects.requireNonNull(modId); Objects.requireNonNull(resource); }
        @Override public String getId() { return modId; }
        @Override public String getDescription() { return "N9Ezz common runtime mod '" + modId + "'"; }
    }
    public enum Side { CLIENT, SERVER }
    private enum State { NEW, INITIALIZING, READY, FAILED, CLOSED }
    private static MixinRuntime active;
    private volatile State state = State.NEW;
    private volatile Host host;
    private volatile IMixinTransformer transformer;
    private Side side;
    private final List<String> audit = new ArrayList<>();
    private List<Configuration> configurations = List.of();

    public void register(TransformationPipeline pipeline) {
        pipeline.register(TransformationPipeline.Stage.MIXIN, 0, "n9ezz:shared-mixin", this::transform);
    }

    /** Initialization is a process boundary: upstream Mixin maintains singleton state for the JVM lifetime. */
    public void initialize(Host targetHost, List<Configuration> configs, Side targetSide) {
        Objects.requireNonNull(targetHost); Objects.requireNonNull(configs); Objects.requireNonNull(targetSide);
        synchronized (MixinRuntime.class) {
            if (state != State.NEW || active != null) throw failure("MIXIN_ALREADY_INITIALIZED", "A common Mixin runtime already exists in this JVM", null);
            validateConfigurations(targetHost, configs);
            host = targetHost; side = targetSide; configurations = List.copyOf(configs);
            state = State.INITIALIZING; active = this;
        }
        try {
            System.setProperty("mixin.bootstrapService", UniversalMixinServiceBootstrap.class.getName());
            System.setProperty("mixin.service", UniversalMixinService.class.getName());
            if (!(MixinService.getGlobalPropertyService() instanceof UniversalGlobalPropertyService))
                throw failure("MIXIN_SERVICE_CONFLICT", "Another loader selected Mixin's global property service", null);
            MixinBootstrap.init();
            if (!(MixinService.getService() instanceof UniversalMixinService))
                throw failure("MIXIN_SERVICE_CONFLICT", "Another loader selected Mixin's host service", null);
            MixinEnvironment.getCurrentEnvironment().setSide(environmentSide());
            MixinEnvironment.getDefaultEnvironment().setSide(environmentSide());
            MixinExtrasBootstrap.init();
            for (Configuration config : configs) Mixins.addConfiguration(config.resource(), config);
            for (var loaded : Mixins.getConfigs()) {
                Configuration owner = configs.stream().filter(config -> config.resource().equals(loaded.getName())).findFirst().orElse(null);
                if (owner != null) {
                    loaded.getConfig().decorate(FabricUtil.KEY_MOD_ID, owner.modId());
                    loaded.getConfig().decorate(FabricUtil.KEY_COMPATIBILITY, FabricUtil.COMPATIBILITY_LATEST);
                }
            }
            MixinBootstrap.getPlatform().inject();
            // Upstream deliberately exposes no public phase-advance method for non-agent hosts.
            // The host advances once, before it permits any game/mod class definitions.
            Method advance = MixinEnvironment.class.getDeclaredMethod("gotoPhase", MixinEnvironment.Phase.class);
            advance.setAccessible(true);
            advance.invoke(null, MixinEnvironment.Phase.INIT);
            advance.invoke(null, MixinEnvironment.Phase.DEFAULT);
            if (transformer == null) throw failure("MIXIN_TRANSFORMER_MISSING", "Mixin did not offer its transformer factory to the common service", null);
            state = State.READY;
        } catch (Throwable error) {
            state = State.FAILED;
            if (error instanceof LoaderException known) throw known;
            throw failure("MIXIN_BOOTSTRAP_FAILED", "Cannot initialize shared Mixin runtime: " + error.getMessage(), error);
        }
    }

    private static void validateConfigurations(Host host, List<Configuration> configs) {
        LinkedHashMap<String, String> owners = new LinkedHashMap<>();
        for (Configuration config : configs) {
            String path = config.resource();
            if (path.isBlank() || path.startsWith("/") || path.contains("\\") || List.of(path.split("/")).contains(".."))
                throw failure("INVALID_MIXIN_CONFIG", "Unsafe Mixin resource path for '" + config.modId() + "': " + path, null);
            String previous = owners.putIfAbsent(path, config.modId());
            if (previous != null) throw failure("DUPLICATE_MIXIN_CONFIG", "Mixin config '" + path + "' is declared by both '" + previous + "' and '" + config.modId() + "'", null);
            try (InputStream input = host.resource(path)) {
                if (input == null) throw failure("MISSING_MIXIN_CONFIG", "Missing config '" + path + "' for mod '" + config.modId() + "'", null);
                byte[] json = input.readNBytes(1024 * 1024 + 1);
                if (json.length > 1024 * 1024 || !JsonParser.parseString(new String(json, StandardCharsets.UTF_8)).isJsonObject())
                    throw new IllegalArgumentException("Mixin config must be a JSON object no larger than 1 MiB");
            } catch (IOException | RuntimeException error) {
                if (error instanceof LoaderException known) throw known;
                throw failure("INVALID_MIXIN_CONFIG", "Invalid config '" + path + "' for mod '" + config.modId() + "': " + error.getMessage(), error);
            }
        }
    }

    public synchronized byte[] transform(String binaryName, byte[] input) {
        // Config plugins are ordinary mod classes and upstream may request them while reading configs.
        // Targets accidentally loaded by a plugin are rejected by Mixin's real loaded-class tracker.
        if (state != State.READY && !(state == State.INITIALIZING && transformer != null)) requireReady();
        try { return transformer.transformClass(MixinEnvironment.getCurrentEnvironment(), binaryName, input); }
        catch (Throwable error) { throw failure("MIXIN_APPLY_FAILED", "Mixin failed for '" + binaryName + "' with configs " + configurations, error); }
    }

    /** Synthetic helpers are defined by the same common classloader as their targets. */
    public synchronized byte[] generate(String binaryName) {
        // The loader queries generation before parent fallback, including during config-plugin loading.
        if (state == State.NEW || state == State.INITIALIZING && transformer == null) return null;
        if (state != State.INITIALIZING) requireReady();
        try { return transformer.generateClass(MixinEnvironment.getCurrentEnvironment(), binaryName); }
        catch (Throwable error) { throw failure("MIXIN_GENERATE_FAILED", "Cannot generate Mixin helper '" + binaryName + "'", error); }
    }
    public synchronized List<String> auditTrail() { return List.copyOf(audit); }
    public List<Configuration> configurations() { return configurations; }
    public boolean isReady() { return state == State.READY; }
    public String serviceName() { return isReady() ? MixinService.getService().getName() : "uninitialized"; }
    void record(String action) { synchronized (this) { audit.add(action); } }
    void offerTransformer(IMixinTransformer offered) {
        if (transformer != null) throw failure("MIXIN_TRANSFORMER_CONFLICT", "More than one Mixin transformer was offered", null);
        transformer = Objects.requireNonNull(offered);
    }
    Host host() { if (host == null) throw failure("MIXIN_HOST_MISSING", "Mixin host is not attached", null); return host; }
    String sideName() { return side.name(); }
    private MixinEnvironment.Side environmentSide() { return side == Side.CLIENT ? MixinEnvironment.Side.CLIENT : MixinEnvironment.Side.SERVER; }
    static synchronized MixinRuntime active() { if (active == null) throw failure("MIXIN_HOST_MISSING", "Shared Mixin runtime has not been initialized", null); return active; }
    static synchronized boolean hasHost() { return active != null && active.host != null; }
    private void requireReady() { if (state != State.READY) throw failure("MIXIN_NOT_READY", "Mixin transformer is " + state + "; initialize it before defining classes", null); }
    private static LoaderException failure(String code, String message, Throwable cause) {
        return new LoaderException(new Diagnostic(code, message, null, "mixin", null), cause);
    }
    @Override public void close() { state = State.CLOSED; }
}
