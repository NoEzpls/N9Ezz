package dev.n9ezz.loader.fabric;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.jar.JarFile;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Unmodified official modules, pinned by hashes, loaded inside the common N9Ezz runtime. */
public final class SelectedFabricApi {
    public static final String RESOURCE = "/embedded/fabric-api-0.141.3+1.21.11.jar";
    public static final String VERSION = "0.141.3+1.21.11";
    public static final String SOURCE_SHA256 = "86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5";
    private static final int MAX_UMBRELLA = 8 * 1024 * 1024;
    private static final List<Module> MODULES = List.of(
        new Module("fabric-api-base", "1.0.5+4ebb5c083e", "bce4ae302479d627bd614b97edf69a6bc13a9f2c50509c9c92a65a6febc7db68", 27859),
        new Module("fabric-command-api-v2", "2.4.7+6b42a6003e", "1478069c47f0fd536794e7278a058276263048b7492b4425ec5d62c88a7de282", 33366),
        new Module("fabric-key-binding-api-v1", "1.1.7+4fc5413f3e", "758c2777045e3e357981ebf99cdecbcafeca21580f4736d00e95b0bf6327f45a", 16615),
        new Module("fabric-lifecycle-events-v1", "2.6.15+4ebb5c083e", "2ce334ea2c050f532443a19addf97ac3e9edcb7b1e3a4a2075dbea0207fe51b0", 90181),
        new Module("fabric-networking-api-v1", "5.1.5+ae1e07683e", "0cb3c3dd650c6fe970181dbd8fbd3281e3a43fc8ad2305856276313b31600aba", 208725),
        new Module("fabric-rendering-v1", "16.2.10+0290ad933e", "d2a97821550e1dca3e0522fc99fa25eea0bf390fea04d1358ff5f1f7cd407518", 161268)
    );
    public record Module(String id, String version, String sha256, int size) {
        public String archiveEntry() { return "META-INF/jars/" + id + "-" + version + ".jar"; }
    }
    public record Selection(Path umbrella, String sha256, List<Module> modules) {
        public Selection { modules = List.copyOf(modules); }
    }
    private SelectedFabricApi() {}
    public static List<Module> modules() { return MODULES; }

    /** The reduced jars declaration prevents accidentally claiming all 43 Fabric API modules. */
    public static Selection resolve(Path cache) throws IOException {
        byte[] official;
        try (var stream = SelectedFabricApi.class.getResourceAsStream(RESOURCE)) {
            if (stream == null) throw new IOException("Missing embedded official Fabric API resource " + RESOURCE);
            official = stream.readNBytes(MAX_UMBRELLA + 1);
        }
        return select(official, cache);
    }
    /** Public for reproducible source tooling and black-box archive verification. */
    public static Selection select(byte[] official, Path cache) throws IOException {
        if (official.length > MAX_UMBRELLA || !hash(official).equals(SOURCE_SHA256)) throw new IOException("Fabric API source integrity mismatch");
        Map<String, byte[]> original = entries(official);
        JsonObject metadata = JsonParser.parseString(new String(required(original, "fabric.mod.json"), StandardCharsets.UTF_8)).getAsJsonObject();
        if (!metadata.get("id").getAsString().equals("fabric-api") || !metadata.get("version").getAsString().equals(VERSION)) throw new IOException("Unexpected Fabric API source identity");
        JsonArray nested = new JsonArray();
        TreeMap<String, byte[]> selected = new TreeMap<>();
        for (var entry : original.entrySet()) {
            String name = entry.getKey();
            if (!name.startsWith("META-INF/jars/") && !isOuterSignature(name)) selected.put(name, entry.getValue());
        }
        // The changed outer metadata invalidates its signature. Nested module bytes and signatures stay untouched.
        byte[] outerManifest = selected.get("META-INF/MANIFEST.MF");
        if (outerManifest != null) {
            var manifestFile = new java.util.jar.Manifest(new ByteArrayInputStream(outerManifest));
            manifestFile.getEntries().clear();
            ByteArrayOutputStream manifestBytes = new ByteArrayOutputStream(); manifestFile.write(manifestBytes);
            selected.put("META-INF/MANIFEST.MF", manifestBytes.toByteArray());
        }
        JsonArray manifest = new JsonArray();
        for (Module module : MODULES) {
            byte[] bytes = required(original, module.archiveEntry());
            if (bytes.length != module.size() || !hash(bytes).equals(module.sha256())) throw new IOException("Fabric API nested module integrity mismatch: " + module.id());
            JsonObject identity = moduleMetadata(bytes);
            if (!identity.get("id").getAsString().equals(module.id()) || !identity.get("version").getAsString().equals(module.version())) throw new IOException("Fabric API module identity mismatch: " + module.id());
            selected.put(module.archiveEntry(), bytes);
            JsonObject declaration = new JsonObject(); declaration.addProperty("file", module.archiveEntry()); nested.add(declaration);
            JsonObject provenance = new JsonObject(); provenance.addProperty("id", module.id()); provenance.addProperty("version", module.version());
            provenance.addProperty("file", module.archiveEntry()); provenance.addProperty("sha256", module.sha256()); provenance.addProperty("size", module.size()); manifest.add(provenance);
        }
        metadata.add("jars", nested);
        selected.put("fabric.mod.json", metadata.toString().getBytes(StandardCharsets.UTF_8));
        JsonObject provenance = new JsonObject();
        provenance.addProperty("source", "https://github.com/FabricMC/fabric/tree/1.21.11");
        provenance.addProperty("sourceVersion", VERSION); provenance.addProperty("sourceSha256", SOURCE_SHA256);
        provenance.addProperty("modification", "Umbrella jars declaration reduced to six pinned modules. Invalidated outer signature files and manifest digest sections removed. Module bytes, signatures, mixins, access wideners, licenses and metadata retained unchanged.");
        provenance.addProperty("limitations", "Only the selected module API contracts are supported; the fabric alias does not establish arbitrary Fabric mod compatibility.");
        provenance.add("modules", manifest);
        selected.put("META-INF/n9ezz/fabric-api-selection.json", provenance.toString().getBytes(StandardCharsets.UTF_8));
        byte[] curated = archive(selected);
        String digest = hash(curated);
        Files.createDirectories(cache);
        if (Files.isSymbolicLink(cache)) throw new IOException("Fabric API cache must not be a symlink");
        Path target = cache.resolve("fabric-api-" + VERSION + "-selected-" + digest + ".jar");
        if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) {
            if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) || !hash(Files.readAllBytes(target)).equals(digest)) throw new IOException("Existing curated Fabric API cache file was modified: " + target);
        } else {
            Path temporary = Files.createTempFile(cache, "fabric-api-selection-", ".tmp");
            try { Files.write(temporary, curated); Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE); }
            finally { Files.deleteIfExists(temporary); }
        }
        return new Selection(target.toRealPath(), digest, MODULES);
    }
    /** A role is granted only to exact known official bytes, never by package name or declared mod id. */
    public static boolean isVerifiedModule(Path jar) throws IOException {
        if (!Files.isRegularFile(jar, LinkOption.NOFOLLOW_LINKS) || Files.size(jar) > 1024 * 1024) return false;
        byte[] bytes = Files.readAllBytes(jar); String digest = hash(bytes);
        return MODULES.stream().anyMatch(module -> module.size() == bytes.length && module.sha256().equals(digest));
    }
    private static JsonObject moduleMetadata(byte[] archive) throws IOException {
        Map<String, byte[]> files = entries(archive);
        return JsonParser.parseString(new String(required(files, "fabric.mod.json"), StandardCharsets.UTF_8)).getAsJsonObject();
    }
    private static Map<String, byte[]> entries(byte[] archive) throws IOException {
        Map<String, byte[]> files = new LinkedHashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(archive))) {
            for (ZipEntry entry; (entry = zip.getNextEntry()) != null;) {
                if (entry.isDirectory()) continue;
                byte[] bytes = zip.readNBytes(MAX_UMBRELLA + 1);
                if (bytes.length > MAX_UMBRELLA || files.putIfAbsent(entry.getName(), bytes) != null) throw new IOException("Oversized or duplicate Fabric API archive entry " + entry.getName());
            }
        }
        return files;
    }
    private static byte[] required(Map<String, byte[]> files, String name) throws IOException {
        byte[] bytes = files.get(name); if (bytes == null) throw new IOException("Fabric API entry is missing: " + name); return bytes;
    }
    private static boolean isOuterSignature(String name) {
        String upper = name.toUpperCase(java.util.Locale.ROOT);
        return upper.startsWith("META-INF/") && upper.indexOf('/', "META-INF/".length()) < 0
            && (upper.endsWith(".SF") || upper.endsWith(".RSA") || upper.endsWith(".DSA") || upper.endsWith(".EC") || upper.startsWith("META-INF/SIG-"));
    }
    private static byte[] archive(Map<String, byte[]> files) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(output, StandardCharsets.UTF_8)) {
            for (var file : files.entrySet()) {
                ZipEntry entry = new ZipEntry(file.getKey()); entry.setTime(315532800000L); entry.setMethod(ZipEntry.STORED);
                CRC32 crc = new CRC32(); crc.update(file.getValue()); entry.setSize(file.getValue().length); entry.setCrc(crc.getValue());
                zip.putNextEntry(entry); zip.write(file.getValue()); zip.closeEntry();
            }
        }
        return output.toByteArray();
    }
    private static String hash(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
}
