package dev.n9ezz.loader.core;

import java.util.List;

public final class LoaderException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private final List<Diagnostic> diagnostics;
    private final List<String> lifecycleTrace;

    public LoaderException(Diagnostic diagnostic) { this(List.of(diagnostic), null, List.of()); }
    public LoaderException(Diagnostic diagnostic, Throwable cause) { this(List.of(diagnostic), cause, List.of()); }
    public LoaderException(List<Diagnostic> diagnostics) { this(diagnostics, null, List.of()); }
    public LoaderException(List<Diagnostic> diagnostics, Throwable cause, List<String> lifecycleTrace) {
        super(diagnostics.stream().map(Diagnostic::toString).reduce((a, b) -> a + "\n" + b).orElse("Loader failed"), cause);
        this.diagnostics = List.copyOf(diagnostics);
        this.lifecycleTrace = List.copyOf(lifecycleTrace);
    }
    public List<Diagnostic> diagnostics() { return diagnostics; }
    public List<String> lifecycleTrace() { return lifecycleTrace; }
    public LoaderException withTrace(List<String> trace) {
        return new LoaderException(diagnostics, this, trace);
    }
}
