package dev.n9ezz.loader.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.jar.JarFile;

/** Admission policy for user supplied files, separate from the internal platform adapters. */
public final class ExternalModPolicy {
    private static final String NATIVE = "n9ezz.mod.json";
    private static final List<String> FOREIGN = List.of("fabric.mod.json", "quilt.mod.json",
            "META-INF/mods.toml", "META-INF/neoforge.mods.toml");

    private ExternalModPolicy() { }

    /**
     * Require an explicit native mod contract before discovery can load any classes.
     * A filename, mod ID, alias or old platform opt-in is never an admission token.
     * MetadataReader still validates the complete descriptor and archive afterwards.
     * This is a format restriction, not a signature or a Java security sandbox.
     */
    public static void validate(Path path) throws IOException {
        requireFile(path);
        try (JarFile jar = new JarFile(path.toFile(), true)) {
            var nativeEntry = jar.getJarEntry(NATIVE);
            if (nativeEntry == null || nativeEntry.isDirectory()) {
                throw failure("EXTERNAL_MOD_NOT_N9EZZ",
                        "External mods must be written for N9Ezz and contain n9ezz.mod.json. "
                        + "Ordinary Fabric, Quilt, Forge and NeoForge mods are not accepted", path);
            }
            for (String descriptor : FOREIGN) if (jar.getJarEntry(descriptor) != null) {
                throw failure("EXTERNAL_MOD_AMBIGUOUS",
                        "External N9Ezz mods must publish only n9ezz.mod.json; remove the foreign contract "
                        + descriptor + " and port the entrypoints to the N9Ezz API", path);
            }
            rejectNested(jar, path, "EXTERNAL_NESTED_MOD_UNSUPPORTED");
        }
    }

    /** Libraries cannot smuggle a second mod descriptor past the mods-directory policy. */
    public static void validateLibrary(Path path) throws IOException {
        requireFile(path);
        try (JarFile jar = new JarFile(path.toFile(), true)) {
            if (jar.getJarEntry(NATIVE) != null) throw libraryFailure(path);
            for (String descriptor : FOREIGN) if (jar.getJarEntry(descriptor) != null) throw libraryFailure(path);
            rejectNested(jar, path, "EXTERNAL_CLASSPATH_MOD");
        }
    }

    private static void rejectNested(JarFile jar, Path path, String code) {
        var entries = jar.entries();
        while (entries.hasMoreElements()) {
            var entry = entries.nextElement();
            if (entry.getName().toLowerCase(Locale.ROOT).endsWith(".jar")) {
                // Only the hash-pinned built-in dependency closure supports nested JARs.
                // Native external packages must shade ordinary libraries instead.
                throw failure(code, "Nested JARs are not supported in external mods/libraries: "
                        + entry.getName(), path);
            }
        }
    }

    private static LoaderException libraryFailure(Path path) {
        return failure("EXTERNAL_CLASSPATH_MOD",
                "A mod descriptor is not allowed on the library classpath. "
                + "Install a native N9Ezz mod in the mods directory instead", path);
    }

    private static void requireFile(Path path) throws IOException {
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("External mod/library must be a regular JAR, not a symbolic link: " + path);
        }
    }

    private static LoaderException failure(String code, String message, Path path) {
        return new LoaderException(new Diagnostic(code, message, null, "external-mod-policy", path));
    }
}
