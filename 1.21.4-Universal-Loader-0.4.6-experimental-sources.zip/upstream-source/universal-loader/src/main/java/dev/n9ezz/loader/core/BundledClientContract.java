package dev.n9ezz.loader.core;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Map;

/**
 * The two pre-existing Pulse render bridges are absent from Minecraft 1.21.11.
 * They may be indexed only from the explicit built-in client role, with their
 * original bytes and the complete corrected client archive independently pinned.
 * This contract does not grant an external mod a Minecraft namespace exception.
 */
public final class BundledClientContract {
    public static final String CLIENT_SHA256 = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424";
    public static final long CLIENT_SIZE = 41_062_124L;
    private static final Map<String, String> RENDER_BRIDGES = Map.of(
            "net.minecraft.client.gl.ShaderProgramKeys", "0620bce88d16df2ee6cda788ccd3b59a257deeed8d649daf35bc49a32cbe32a3",
            "net.minecraft.client.render.BufferRenderer", "6a446f06f3ba3f43523e657dfcae3df09e85f12eba21789ba7fd64f18fbf7a3e");

    private BundledClientContract() { }

    /** Describes candidates; it must never be used as permission to load them. */
    public static Map<String, String> renderBridges() { return RENDER_BRIDGES; }

    /**
     * Called only after the class index establishes the explicit built-in role.
     * Does not cache path-based trust: a changed archive must fail the next check.
     */
    public static boolean isVerifiedClass(Path jar, String binaryName, byte[] bytes) throws IOException {
        String classHash = RENDER_BRIDGES.get(binaryName);
        if (jar == null || bytes == null || classHash == null || !classHash.equals(hash(bytes))) return false;
        return isVerifiedArchive(jar);
    }

    public static boolean isVerifiedArchive(Path jar) throws IOException {
        if (jar == null) return false;
        Path source = jar.toAbsolutePath().normalize();
        if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS) || Files.size(source) != CLIENT_SIZE) return false;
        MessageDigest digest = digest();
        long count = 0;
        byte[] buffer = new byte[64 * 1024];
        try (InputStream input = Files.newInputStream(source)) {
            for (int read; (read = input.read(buffer)) != -1; ) {
                count += read;
                if (count > CLIENT_SIZE) return false;
                digest.update(buffer, 0, read);
            }
        }
        return count == CLIENT_SIZE && CLIENT_SHA256.equals(HexFormat.of().formatHex(digest.digest()));
    }

    private static String hash(byte[] bytes) { return HexFormat.of().formatHex(digest().digest(bytes)); }

    private static MessageDigest digest() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
}
