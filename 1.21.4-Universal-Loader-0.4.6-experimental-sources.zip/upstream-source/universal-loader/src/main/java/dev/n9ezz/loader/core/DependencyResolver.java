package dev.n9ezz.loader.core;

import dev.n9ezz.loader.metadata.Dependency;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Objects;
import java.util.function.Consumer;

/** One graph for all metadata formats; platform identities are explicit runtime contracts. */
public final class DependencyResolver {
    public static final Map<String, String> BUILTINS = Map.of("java", "21", "minecraft", "1.21.11", "n9ezz", "0.4.1");
    /** The opt-in compatibility facade implements the selected 0.19.2 API surface, not an engine. */
    public static final Map<String, String> FABRIC_RUNTIME_BUILTINS = Map.of("java", "21", "minecraft", "1.21.11", "n9ezz", "0.4.1", "fabricloader", "0.19.2");
    private static final Set<String> ENGINES = Set.of("fabricloader", "fabric-loader", "quilt_loader", "quilt-loader", "forge", "neoforge", "javafml", "lowcodefml");
    private DependencyResolver() {}

    public static List<ModMetadata> resolve(List<ModMetadata> input) {
        return resolve(input, false, diagnostic -> { });
    }

    public static List<ModMetadata> resolveFabricRuntime(List<ModMetadata> input) {
        return resolveFabricRuntime(input, diagnostic -> { });
    }

    /** Advisory Fabric dependencies are reported without preventing an otherwise valid graph. */
    public static List<ModMetadata> resolveFabricRuntime(List<ModMetadata> input, Consumer<Diagnostic> warnings) {
        return resolve(input, true, false, Objects.requireNonNull(warnings, "warnings"));
    }

    /** One graph, with explicitly selected and preflighted API contracts for each metadata format. */
    public static List<ModMetadata> resolveUniversalGame(List<ModMetadata> input, Consumer<Diagnostic> warnings) {
        input.forEach(GameCompatibilityPolicy::validate);
        List<ModMetadata> ordered = resolve(input, true, true, Objects.requireNonNull(warnings, "warnings"));
        GameCompatibilityPolicy.validateStageDependencies(ordered);
        return ordered;
    }

    private record SoftEdge(ModMetadata dependent, ModMetadata provider) { }

    private static List<ModMetadata> resolve(List<ModMetadata> input, boolean fabricRuntime, Consumer<Diagnostic> warnings) {
        return resolve(input, fabricRuntime, false, warnings);
    }

    private static List<ModMetadata> resolve(List<ModMetadata> input, boolean fabricRuntime, boolean universalGame, Consumer<Diagnostic> warnings) {
        Map<String, String> runtimeVersions = fabricRuntime ? FABRIC_RUNTIME_BUILTINS : BUILTINS;
        Map<String, ModMetadata> mods = new TreeMap<>();
        Map<String, ModMetadata> providers = new TreeMap<>();
        List<Diagnostic> diagnostics = new ArrayList<>();
        for (ModMetadata mod : input.stream().sorted(java.util.Comparator.comparing(ModMetadata::id).thenComparing(m -> m.jar().toString())).toList()) {
            if (mods.putIfAbsent(mod.id(), mod) != null) {
                diagnostics.add(new Diagnostic("DUPLICATE_MOD", "More than one mod declares id '" + mod.id() + "'", mod.id(), "resolve", mod.jar()));
            }
            TreeSet<String> identities = new TreeSet<>(mod.provides());
            identities.add(mod.id());
            for (String identity : identities) {
                if (BUILTINS.containsKey(identity) || ENGINES.contains(identity)) {
                    diagnostics.add(new Diagnostic("RESERVED_MOD_ID", "Mod cannot provide reserved runtime identity '" + identity + "'", mod.id(), "resolve", mod.jar()));
                    continue;
                }
                ModMetadata previous = providers.putIfAbsent(identity, mod);
                if (previous != null && previous != mod) diagnostics.add(new Diagnostic("DUPLICATE_PROVIDER", "Identity '" + identity + "' is provided by both '" + previous.id() + "' and '" + mod.id() + "'", mod.id(), "resolve", mod.jar()));
            }
        }
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
        Map<String, Set<String>> prerequisites = new TreeMap<>();
        Map<String, Set<String>> dependents = new TreeMap<>();
        List<SoftEdge> softEdges = new ArrayList<>();
        mods.keySet().forEach(id -> { prerequisites.put(id, new TreeSet<>()); dependents.put(id, new TreeSet<>()); });
        for (ModMetadata mod : mods.values()) {
            Map<String, String> selectedProviders = universalGame ? GameCompatibilityPolicy.additionalProviders(mod) : Map.of();
            for (Dependency dependency : mod.dependencies()) {
                boolean advisory = fabricRuntime && mod.platform() == Platform.FABRIC && dependency.optional();
                VersionConstraint constraint;
                try { constraint = fabricRuntime && mod.platform() == Platform.FABRIC
                        ? VersionConstraint.parseFabric(dependency.constraint()) : VersionConstraint.parse(dependency.constraint()); }
                catch (IllegalArgumentException error) {
                    diagnostics.add(new Diagnostic("INVALID_VERSION_CONSTRAINT", error.getMessage(), mod.id(), "resolve", mod.jar()));
                    continue;
                }
                ModMetadata provider = providers.get(dependency.id());
                String version = runtimeVersions.get(dependency.id());
                if (selectedProviders.containsKey(dependency.id())) version = selectedProviders.get(dependency.id());
                if (provider != null) version = provider.version();
                if (version == null) {
                    if (!dependency.optional() && !dependency.incompatible()) {
                        String code = ENGINES.contains(dependency.id()) ? "UNSUPPORTED_PLATFORM_DEPENDENCY" : "MISSING_DEPENDENCY";
                        String detail = ENGINES.contains(dependency.id())
                            ? "The shared " + (fabricRuntime ? "selected Fabric compatibility" : "API-only") + " runtime does not implement the '" + dependency.id() + "' engine/ABI; its version cannot be advertised"
                            : "Required dependency '" + dependency.id() + "' " + dependency.constraint() + " is missing";
                        diagnostics.add(new Diagnostic(code, detail, mod.id(), "resolve", mod.jar()));
                    }
                    continue;
                }
                boolean matches;
                try { matches = constraint.matches(version); }
                catch (IllegalArgumentException error) {
                    Diagnostic diagnostic = new Diagnostic("UNSUPPORTED_DEPENDENCY_VERSION", "Cannot evaluate '" + dependency.id() + "' version '" + version + "': " + error.getMessage(), mod.id(), "resolve", mod.jar());
                    if (advisory) warnings.accept(diagnostic); else diagnostics.add(diagnostic);
                    continue;
                }
                if (dependency.incompatible()) {
                    if (matches) {
                        Diagnostic diagnostic = new Diagnostic(advisory ? "OPTIONAL_MOD_CONFLICT" : "INCOMPATIBLE_MOD", "Incompatible dependency '" + dependency.id() + "' " + version + " matches " + dependency.constraint(), mod.id(), "resolve", mod.jar());
                        if (advisory) warnings.accept(diagnostic); else diagnostics.add(diagnostic);
                    }
                } else if (!matches) {
                    Diagnostic diagnostic = new Diagnostic(advisory ? "OPTIONAL_DEPENDENCY_VERSION" : "DEPENDENCY_VERSION", "Dependency '" + dependency.id() + "' is " + version + ", requires " + dependency.constraint(), mod.id(), "resolve", mod.jar());
                    if (advisory) warnings.accept(diagnostic); else diagnostics.add(diagnostic);
                } else if (provider != null && advisory) {
                    softEdges.add(new SoftEdge(mod, provider));
                } else if (provider != null && !provider.id().equals(mod.id())) {
                    prerequisites.get(mod.id()).add(provider.id());
                    dependents.get(provider.id()).add(mod.id());
                } else if (provider != null) {
                    // A self dependency is a cycle, including one declared via an alias.
                    prerequisites.get(mod.id()).add(mod.id());
                    dependents.get(mod.id()).add(mod.id());
                }
            }
        }
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
        // Honour a matching recommendation's ordering when it does not impose a cycle.
        // Recommendations and suggestions never turn a valid required graph into a failure.
        for (SoftEdge edge : softEdges) {
            String dependent = edge.dependent().id(), provider = edge.provider().id();
            if (reaches(prerequisites, provider, dependent, new java.util.HashSet<>())) {
                warnings.accept(new Diagnostic("OPTIONAL_DEPENDENCY_CYCLE", "Advisory ordering from '" + dependent + "' to '" + provider + "' was ignored because it would create a cycle", dependent, "resolve", edge.dependent().jar()));
            } else {
                prerequisites.get(dependent).add(provider);
                dependents.get(provider).add(dependent);
            }
        }
        Map<String, Integer> degrees = new HashMap<>();
        PriorityQueue<String> available = new PriorityQueue<>();
        prerequisites.forEach((id, dependencies) -> { degrees.put(id, dependencies.size()); if (dependencies.isEmpty()) available.add(id); });
        List<ModMetadata> ordered = new ArrayList<>();
        while (!available.isEmpty()) {
            String id = available.remove();
            ordered.add(mods.get(id));
            for (String dependent : dependents.get(id)) if (degrees.compute(dependent, (key, degree) -> degree - 1) == 0) available.add(dependent);
        }
        if (ordered.size() != mods.size()) {
            String blocked = degrees.entrySet().stream().filter(entry -> entry.getValue() > 0).map(Map.Entry::getKey).sorted().reduce((a, b) -> a + ", " + b).orElse("");
            throw new LoaderException(new Diagnostic("DEPENDENCY_CYCLE", "Dependency cycle prevents initialization; affected mods: " + blocked));
        }
        return List.copyOf(ordered);
    }

    private static boolean reaches(Map<String, Set<String>> graph, String from, String target, Set<String> visited) {
        if (from.equals(target)) return true;
        if (!visited.add(from)) return false;
        for (String next : graph.get(from)) if (reaches(graph, next, target, visited)) return true;
        return false;
    }
}
