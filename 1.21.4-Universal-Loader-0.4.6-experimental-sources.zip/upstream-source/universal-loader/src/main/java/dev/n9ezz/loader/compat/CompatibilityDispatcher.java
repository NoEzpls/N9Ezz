package dev.n9ezz.loader.compat;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.fabric.SelectedFabricApi;
import dev.n9ezz.loader.fml.FmlCompatibilityRuntime;
import dev.n9ezz.loader.quilt.QuiltRuntime;
import dev.n9ezz.loader.metadata.Entrypoint;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.jar.JarFile;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

/**
 * Narrow platform callback bridges inside the single N9Ezz classloader.
 * This deliberately does not launch or emulate a platform's loader engine.
 */
public final class CompatibilityDispatcher {
    private final Map<String, LoaderException> attempted = new HashMap<>();
    private final Map<String, Object> instances = new HashMap<>();
    private final Set<Path> verifiedFabricApiJars;
    private FmlCompatibilityRuntime fmlRuntime;

    /** Strict fixture/native mode retains the original initializer and namespace restrictions. */
    public CompatibilityDispatcher() { verifiedFabricApiJars = Set.of(); }

    /** Game mode permits only the complete, hash-pinned official Fabric API modules. */
    public CompatibilityDispatcher(Set<Path> verifiedFabricApiJars) throws IOException {
        Set<Path> canonical = new HashSet<>();
        for (Path jar : Objects.requireNonNull(verifiedFabricApiJars)) {
            Path real = jar.toRealPath();
            if (!SelectedFabricApi.isVerifiedModule(real)) throw new IOException("Entrypoint role requires exact pinned Fabric API module bytes: " + jar);
            canonical.add(real);
        }
        this.verifiedFabricApiJars = Set.copyOf(canonical);
    }

    /** Selected game adapters use the same dispatcher, classloader and phase-attempt ledger. */
    public CompatibilityDispatcher(Set<Path> verifiedFabricApiJars, FmlCompatibilityRuntime fmlRuntime) throws IOException {
        this(verifiedFabricApiJars);
        this.fmlRuntime = Objects.requireNonNull(fmlRuntime, "fmlRuntime");
    }

    /** Every mod phase is attempted once, including failed attempts. Calls are serialized. */
    public synchronized void initialize(ModMetadata mod, String phase, ClassLoader loader, ModContext context)
            throws Exception {
        Objects.requireNonNull(mod, "mod");
        Objects.requireNonNull(loader, "loader");
        Objects.requireNonNull(context, "context");
        if (!"common".equals(phase) && !"client".equals(phase)) {
            throw error(mod, phase, "UNSUPPORTED_PHASE", "Only common and client initialization are supported", null);
        }
        if (!mod.id().equals(context.modId())) {
            throw error(mod, phase, "INVALID_MOD_CONTEXT", "Context mod id differs from metadata", null);
        }
        String phaseKey = mod.id() + ":" + phase;
        if (attempted.containsKey(phaseKey)) {
            LoaderException failure = attempted.get(phaseKey);
            if (failure != null) throw failure;
            return;
        }
        // Claim before invoking user code: a callback cannot recursively initialize its phase again.
        attempted.put(phaseKey, null);
        ClassLoader previousContextLoader = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(loader);
        try {
            Set<String> invoked = new HashSet<>();
            for (Entrypoint entrypoint : mod.entrypoints()) {
                if (!phase.equals(entrypoint.phase())) continue;
                if (!invoked.add(entrypoint.adapter() + ":" + entrypoint.className())) {
                    throw error(mod, phase, "DUPLICATE_ENTRYPOINT", "Repeated entrypoint " + entrypoint.className(), null);
                }
                if ((mod.platform() == Platform.FORGE || mod.platform() == Platform.NEOFORGE)
                        && entrypoint.adapter().equals("annotation")) {
                    initializeAnnotated(mod, phase, loader);
                } else {
                    initializeInterface(mod, entrypoint, phase, loader, context);
                }
            }
        } catch (LoaderException exception) {
            attempted.put(phaseKey, exception);
            throw exception;
        } catch (ReflectiveOperationException | LinkageError exception) {
            Throwable cause = exception instanceof InvocationTargetException invocation
                    ? invocation.getCause() : exception;
            String code = cause instanceof LinkageError ? "UNSUPPORTED_PLATFORM_API" : "ENTRYPOINT_CONSTRUCTION_FAILED";
            LoaderException failure = error(mod, phase, code,
                    "Entrypoint linkage or construction failed: " + detail(cause)
                            + "; only the documented compatibility API subset is available", cause);
            attempted.put(phaseKey, failure);
            throw failure;
        } catch (Exception exception) {
            LoaderException failure = error(mod, phase, "ENTRYPOINT_FAILED", detail(exception), exception);
            attempted.put(phaseKey, failure);
            throw failure;
        } catch (Error exception) {
            LoaderException failure = error(mod, phase, "ENTRYPOINT_FAILED", detail(exception), exception);
            attempted.put(phaseKey, failure);
            throw failure;
        } finally {
            Thread.currentThread().setContextClassLoader(previousContextLoader);
        }
    }

    private void initializeInterface(ModMetadata mod, Entrypoint entrypoint, String phase,
            ClassLoader loader, ModContext context) throws Exception {
        if (mod.platform() == Platform.FORGE || mod.platform() == Platform.NEOFORGE) {
            throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Forge and NeoForge only support value-only @Mod discovery", null);
        }
        if (!entrypoint.adapter().equals("default") && !entrypoint.adapter().equals("quilt-init")
                && !(fmlRuntime != null && entrypoint.adapter().equals("quilt-client-init"))) {
            throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Unsupported language adapter " + entrypoint.adapter(), null);
        }
        if (entrypoint.className().contains("::")) {
            initializeMethodReference(mod, entrypoint, phase, loader);
            return;
        }
        Class<?> type = ownedClass(mod, entrypoint.className(), phase, loader);
        Class<?> contract;
        if (mod.platform() == Platform.N9EZZ) {
            if (!entrypoint.adapter().equals("default")) {
                throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Native mods require the default initializer adapter", null);
            }
            contract = N9ModInitializer.class;
        } else if (entrypoint.adapter().equals("quilt-init") || entrypoint.adapter().equals("quilt-client-init")) {
            boolean client = entrypoint.adapter().equals("quilt-client-init");
            if (mod.platform() != Platform.QUILT || !phase.equals(client ? "client" : "common")) {
                throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Quilt entrypoint adapter does not match its phase", null);
            }
            contract = client ? org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer.class
                    : org.quiltmc.qsl.base.api.entrypoint.ModInitializer.class;
        } else {
            contract = phase.equals("client") ? net.fabricmc.api.ClientModInitializer.class
                    : net.fabricmc.api.ModInitializer.class;
        }
        if (!contract.isAssignableFrom(type)) {
            throw error(mod, phase, "ENTRYPOINT_INTERFACE_MISMATCH", type.getName() + " must implement " + contract.getName(), null);
        }
        Object instance = instance(mod, phase, type);
        if (mod.platform() == Platform.N9EZZ) {
            ((N9ModInitializer) instance).onInitialize(context);
        } else if (entrypoint.adapter().equals("quilt-init")) {
            ((org.quiltmc.qsl.base.api.entrypoint.ModInitializer) instance).onInitialize(
                    fmlRuntime == null ? quiltContainer(mod) : QuiltRuntime.container(mod));
        } else if (entrypoint.adapter().equals("quilt-client-init")) {
            ((org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer) instance).onInitializeClient(QuiltRuntime.container(mod));
        } else if (phase.equals("client")) {
            ((net.fabricmc.api.ClientModInitializer) instance).onInitializeClient();
        } else {
            ((net.fabricmc.api.ModInitializer) instance).onInitialize();
        }
    }

    private void initializeMethodReference(ModMetadata mod, Entrypoint entrypoint, String phase, ClassLoader loader) throws Exception {
        if (mod.platform() != Platform.FABRIC || !entrypoint.adapter().equals("default") || !verifiedFabricApi(mod)) {
            throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Method entrypoints are limited to selected verified Fabric API modules: " + entrypoint.className(), null);
        }
        String[] parts = entrypoint.className().split("::", -1);
        if (parts.length != 2 || !parts[1].matches("[A-Za-z_$][A-Za-z0-9_$]*")) {
            throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Expected a Class::method default-adapter definition: " + entrypoint.className(), null);
        }
        Class<?> type = ownedClass(mod, parts[0], phase, loader);
        Method method;
        try { method = type.getDeclaredMethod(parts[1]); }
        catch (NoSuchMethodException failure) { throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Static entrypoint must declare a no-argument method: " + entrypoint.className(), failure); }
        invokeStaticNoArg(mod, phase, method);
    }

    /** Separate shape validation allows exact adapter tests without pretending a fixture is an official module. */
    static void invokeStaticNoArg(ModMetadata mod, String phase, Method method) throws Exception {
        if (!Modifier.isPublic(method.getDeclaringClass().getModifiers()) || !Modifier.isPublic(method.getModifiers())
                || !Modifier.isStatic(method.getModifiers()) || method.getReturnType() != void.class || method.getParameterCount() != 0) {
            throw error(mod, phase, "UNSUPPORTED_ADAPTER", "Selected API method entrypoint must be public static void with no arguments: " + method, null);
        }
        method.invoke(null);
    }

    private boolean verifiedFabricApi(ModMetadata mod) throws IOException {
        Path real = mod.jar().toRealPath();
        return verifiedFabricApiJars.contains(real) && SelectedFabricApi.isVerifiedModule(real);
    }

    private void initializeAnnotated(ModMetadata mod, String phase, ClassLoader loader) throws Exception {
        if (!phase.equals("common")) {
            throw error(mod, phase, "UNSUPPORTED_PHASE", "@Mod construction is a common-phase operation", null);
        }
        if (fmlRuntime != null) {
            fmlRuntime.construct(mod, loader);
            return;
        }
        String annotation = mod.platform() == Platform.FORGE
                ? "Lnet/minecraftforge/fml/common/Mod;" : "Lnet/neoforged/fml/common/Mod;";
        List<AnnotatedClass> candidates = new ArrayList<>();
        try (JarFile jar = new JarFile(mod.jar().toFile())) {
            var entries = jar.stream().filter(entry -> !entry.isDirectory() && entry.getName().endsWith(".class"))
                    .sorted(java.util.Comparator.comparing(java.util.jar.JarEntry::getName)).toList();
            for (var entry : entries) {
                if (entry.getName().startsWith("META-INF/versions/")) {
                    throw error(mod, phase, "UNSUPPORTED_MULTI_RELEASE_MOD", "Multi-release annotation mods are unsupported", null);
                }
                try (var input = jar.getInputStream(entry)) {
                    AnnotatedClass scanned = scan(input.readAllBytes(), annotation, mod.id());
                    if (scanned.matches) candidates.add(scanned);
                }
            }
        }
        if (candidates.isEmpty()) {
            throw error(mod, phase, "MISSING_MOD_ANNOTATION", "No @Mod(\"" + mod.id() + "\") class exists in this jar", null);
        }
        for (AnnotatedClass candidate : candidates) {
            if (!candidate.unsupported.isEmpty()) {
                throw error(mod, phase, "UNSUPPORTED_PLATFORM_API", candidate.className
                        + " references unsupported API " + String.join(", ", candidate.unsupported), null);
            }
            if (!candidate.hasPublicNoArg || !candidate.publicConcrete) {
                throw error(mod, phase, "UNSUPPORTED_MOD_CONSTRUCTOR", candidate.className
                        + " requires a public concrete class with a public no-argument constructor; FML service injection is unsupported", null);
            }
            instance(mod, phase, ownedClass(mod, candidate.className, phase, loader));
        }
    }

    private Object instance(ModMetadata mod, String phase, Class<?> type) throws Exception {
        String instanceKey = mod.id() + ":" + type.getName();
        if (instances.containsKey(instanceKey)) return instances.get(instanceKey);
        if (!Modifier.isPublic(type.getModifiers()) || Modifier.isAbstract(type.getModifiers()) || type.isInterface()) {
            throw error(mod, phase, "UNSUPPORTED_MOD_CONSTRUCTOR", type.getName() + " must be a public concrete class", null);
        }
        Constructor<?> constructor;
        try {
            constructor = type.getConstructor();
        } catch (NoSuchMethodException exception) {
            throw error(mod, phase, "UNSUPPORTED_MOD_CONSTRUCTOR", type.getName()
                    + " requires a public no-argument constructor; injected constructors are unsupported", exception);
        }
        Object result = constructor.newInstance();
        instances.put(instanceKey, result);
        return result;
    }

    private Class<?> ownedClass(ModMetadata mod, String className, String phase, ClassLoader loader) throws Exception {
        boolean verifiedApiClass = className.startsWith("net.fabricmc.fabric.") && mod.platform() == Platform.FABRIC && verifiedFabricApi(mod);
        if (className.isBlank() || className.startsWith("java.") || className.startsWith("dev.n9ezz.loader.")
                || (className.startsWith("net.fabricmc.") && !verifiedApiClass) || className.startsWith("org.quiltmc.")
                || className.startsWith("net.minecraftforge.") || className.startsWith("net.neoforged.")) {
            throw error(mod, phase, "INVALID_ENTRYPOINT", "Reserved or empty entrypoint class " + className, null);
        }
        try (JarFile jar = new JarFile(mod.jar().toFile())) {
            if (jar.getJarEntry(className.replace('.', '/') + ".class") == null) {
                throw error(mod, phase, "ENTRYPOINT_SOURCE_MISMATCH", className + " is absent from the declared mod jar", null);
            }
        }
        Class<?> type = Class.forName(className, false, loader);
        CodeSource source = type.getProtectionDomain().getCodeSource();
        Path actual;
        try {
            actual = source == null || source.getLocation() == null ? null : Path.of(source.getLocation().toURI()).toRealPath();
        } catch (IOException | URISyntaxException | IllegalArgumentException exception) {
            throw error(mod, phase, "ENTRYPOINT_SOURCE_MISMATCH", "Cannot establish code source for " + className, exception);
        }
        if (type.getClassLoader() != loader || actual == null || !actual.equals(mod.jar().toRealPath())) {
            throw error(mod, phase, "ENTRYPOINT_SOURCE_MISMATCH", className + " resolved outside its declared mod jar", null);
        }
        return type;
    }

    private static org.quiltmc.loader.api.ModContainer quiltContainer(ModMetadata mod) {
        org.quiltmc.loader.api.Version version = () -> mod.version();
        org.quiltmc.loader.api.ModMetadata metadata = new org.quiltmc.loader.api.ModMetadata() {
            @Override public String id() { return mod.id(); }
            @Override public org.quiltmc.loader.api.Version version() { return version; }
        };
        return () -> metadata;
    }

    private static AnnotatedClass scan(byte[] bytes, String annotationDescriptor, String modId) {
        AnnotatedClass scanned = new AnnotatedClass();
        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
                scanned.className = name.replace('/', '.');
                scanned.publicConcrete = (access & Opcodes.ACC_PUBLIC) != 0 && (access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_INTERFACE)) == 0;
                checkName(superName, annotationDescriptor, scanned);
                if (interfaces != null) for (String iface : interfaces) checkName(iface, annotationDescriptor, scanned);
            }
            @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                checkType(Type.getType(descriptor), annotationDescriptor, scanned);
                if (!annotationDescriptor.equals(descriptor)) return null;
                return new AnnotationVisitor(Opcodes.ASM9) {
                    @Override public void visit(String name, Object value) {
                        if (name.equals("value")) scanned.matches = modId.equals(value);
                        else scanned.unsupported.add("@Mod attribute " + name);
                    }
                    @Override public AnnotationVisitor visitArray(String name) {
                        scanned.unsupported.add("@Mod attribute " + name);
                        return null;
                    }
                };
            }
            @Override public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
                checkType(Type.getType(descriptor), annotationDescriptor, scanned);
                return new FieldVisitor(Opcodes.ASM9) {
                    @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                        checkType(Type.getType(descriptor), annotationDescriptor, scanned);
                        return null;
                    }
                };
            }
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                if (name.equals("<init>") && descriptor.equals("()V") && (access & Opcodes.ACC_PUBLIC) != 0) scanned.hasPublicNoArg = true;
                checkType(Type.getMethodType(descriptor), annotationDescriptor, scanned);
                if (exceptions != null) for (String exception : exceptions) checkName(exception, annotationDescriptor, scanned);
                return new MethodVisitor(Opcodes.ASM9) {
                    @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                        checkType(Type.getType(descriptor), annotationDescriptor, scanned);
                        return null;
                    }
                    @Override public void visitTypeInsn(int opcode, String type) { checkName(type, annotationDescriptor, scanned); }
                    @Override public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
                        checkName(owner, annotationDescriptor, scanned);
                        checkType(Type.getType(descriptor), annotationDescriptor, scanned);
                    }
                    @Override public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
                        checkName(owner, annotationDescriptor, scanned);
                        checkType(Type.getMethodType(descriptor), annotationDescriptor, scanned);
                    }
                    @Override public void visitLdcInsn(Object value) {
                        if (value instanceof Type type) checkType(type, annotationDescriptor, scanned);
                        if (value instanceof Handle handle) checkName(handle.getOwner(), annotationDescriptor, scanned);
                    }
                    @Override public void visitInvokeDynamicInsn(String name, String descriptor, Handle handle, Object... arguments) {
                        checkType(Type.getMethodType(descriptor), annotationDescriptor, scanned);
                        checkName(handle.getOwner(), annotationDescriptor, scanned);
                        for (Object argument : arguments) {
                            if (argument instanceof Type type) checkType(type, annotationDescriptor, scanned);
                            if (argument instanceof Handle nested) checkName(nested.getOwner(), annotationDescriptor, scanned);
                        }
                    }
                };
            }
        }, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return scanned;
    }

    private static void checkType(Type type, String annotation, AnnotatedClass scanned) {
        switch (type.getSort()) {
            case Type.ARRAY -> checkType(type.getElementType(), annotation, scanned);
            case Type.OBJECT -> checkName(type.getInternalName(), annotation, scanned);
            case Type.METHOD -> {
                checkType(type.getReturnType(), annotation, scanned);
                for (Type argument : type.getArgumentTypes()) checkType(argument, annotation, scanned);
            }
            default -> { }
        }
    }

    private static void checkName(String name, String annotation, AnnotatedClass scanned) {
        if (name == null || annotation.equals("L" + name + ";")) return;
        if (name.startsWith("[")) {
            checkType(Type.getType(name), annotation, scanned);
            return;
        }
        if (name.startsWith("net/minecraftforge/") || name.startsWith("net/neoforged/")
                || name.startsWith("cpw/mods/")) scanned.unsupported.add(name.replace('/', '.'));
    }

    private static String detail(Throwable exception) {
        return exception.getClass().getSimpleName() + (exception.getMessage() == null ? "" : ": " + exception.getMessage());
    }

    private static LoaderException error(ModMetadata mod, String phase, String code, String message, Throwable cause) {
        return new LoaderException(new Diagnostic(code, message, mod.id(), phase, mod.jar()), cause);
    }

    private static final class AnnotatedClass {
        String className;
        boolean matches;
        boolean publicConcrete;
        boolean hasPublicNoArg;
        final Set<String> unsupported = new java.util.TreeSet<>();
    }
}
