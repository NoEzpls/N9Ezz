package dev.n9ezz.loader.mapping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.fabricmc.tinyremapper.IMappingProvider;
import org.objectweb.asm.Type;

/** Own strict reader/index for the pinned two-namespace Tiny v2 distribution. */
public final class TinyMappingIndex {
    private record Member(String owner, String name, String descriptor) {}
    private final String sourceNamespace;
    private final String targetNamespace;
    private final Map<String, String> classes = new LinkedHashMap<>();
    private final Map<String, String> reverseClasses = new LinkedHashMap<>();
    private final Map<Member, String> fields = new LinkedHashMap<>();
    private final Map<Member, String> methods = new LinkedHashMap<>();
    private final Map<Member, String> reverseFields = new LinkedHashMap<>();
    private final Map<Member, String> reverseMethods = new LinkedHashMap<>();

    private TinyMappingIndex(String sourceNamespace, String targetNamespace) {
        this.sourceNamespace = sourceNamespace;
        this.targetNamespace = targetNamespace;
    }

    public static TinyMappingIndex read(Reader input) throws IOException {
        BufferedReader reader = input instanceof BufferedReader buffered ? buffered : new BufferedReader(input);
        String header = reader.readLine();
        String[] columns = header == null ? new String[0] : header.split("\\t", -1);
        if (columns.length != 5 || !columns[0].equals("tiny") || !columns[1].equals("2") || !columns[2].equals("0")
                || columns[3].isBlank() || columns[4].isBlank() || columns[3].equals(columns[4])) {
            throw new IOException("Expected Tiny v2.0 with exactly two distinct namespaces");
        }
        TinyMappingIndex index = new TinyMappingIndex(columns[3], columns[4]);
        String owner = null;
        String line;
        int number = 1;
        while ((line = reader.readLine()) != null) {
            number++;
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\t", -1);
            try {
                if (parts.length == 3 && parts[0].equals("c")) {
                    internalName(parts[1]); internalName(parts[2]);
                    putUnique(index.classes, parts[1], parts[2]);
                    putUnique(index.reverseClasses, parts[2], parts[1]);
                    owner = parts[1];
                } else if (parts.length == 5 && parts[0].isEmpty() && (parts[1].equals("f") || parts[1].equals("m"))) {
                    if (owner == null || parts[3].isEmpty() || parts[4].isEmpty()) throw new IllegalArgumentException("Member without owner/names");
                    boolean method = parts[1].equals("m");
                    validateDescriptor(parts[2], method);
                    putUnique(method ? index.methods : index.fields, new Member(owner, parts[3], parts[2]), parts[4]);
                } else {
                    throw new IllegalArgumentException("Unsupported Tiny row; this reader supports class, field and method rows only");
                }
            } catch (RuntimeException error) {
                throw new IOException("Invalid Tiny mapping at line " + number + ": " + error.getMessage(), error);
            }
        }
        for (Map.Entry<Member, String> entry : index.fields.entrySet()) index.addReverse(index.reverseFields, entry);
        for (Map.Entry<Member, String> entry : index.methods.entrySet()) index.addReverse(index.reverseMethods, entry);
        return index;
    }

    private void addReverse(Map<Member, String> destination, Map.Entry<Member, String> entry) throws IOException {
        Member source = entry.getKey();
        Member reverse = new Member(classes.getOrDefault(source.owner(), source.owner()), entry.getValue(),
            mapDescriptor(sourceNamespace, targetNamespace, source.descriptor()));
        if (destination.putIfAbsent(reverse, source.name()) != null) throw new IOException("Duplicate target member: " + reverse);
    }
    private static <K> void putUnique(Map<K, String> map, K key, String value) {
        if (map.putIfAbsent(key, value) != null) throw new IllegalArgumentException("Duplicate mapping: " + key);
    }
    private static void internalName(String value) {
        if (value.isEmpty() || value.indexOf('.') >= 0 || value.startsWith("/") || value.contains("//") || value.indexOf(';') >= 0
                || value.indexOf('[') >= 0 || value.indexOf('\\') >= 0) throw new IllegalArgumentException("Invalid internal class name: " + value);
    }
    private static void validateDescriptor(String descriptor, boolean method) {
        int end;
        if (method) {
            if (!descriptor.startsWith("(")) throw new IllegalArgumentException("Invalid method descriptor: " + descriptor);
            int offset = 1;
            while (offset < descriptor.length() && descriptor.charAt(offset) != ')') offset = typeEnd(descriptor, offset, false);
            if (offset >= descriptor.length()) throw new IllegalArgumentException("Missing method return descriptor");
            end = typeEnd(descriptor, offset + 1, true);
        } else end = typeEnd(descriptor, 0, false);
        if (end != descriptor.length()) throw new IllegalArgumentException("Trailing descriptor data: " + descriptor);
    }
    private static int typeEnd(String descriptor, int offset, boolean allowVoid) {
        if (offset >= descriptor.length()) throw new IllegalArgumentException("Missing descriptor type");
        char kind = descriptor.charAt(offset);
        if ("BCDFIJSZ".indexOf(kind) >= 0 || (allowVoid && kind == 'V')) return offset + 1;
        if (kind == '[') return typeEnd(descriptor, offset + 1, false);
        if (kind == 'L') {
            int end = descriptor.indexOf(';', offset);
            if (end < 0) throw new IllegalArgumentException("Missing object descriptor terminator");
            internalName(descriptor.substring(offset + 1, end));
            return end + 1;
        }
        throw new IllegalArgumentException("Invalid descriptor type: " + kind);
    }
    public Set<String> namespaces() { return Set.of(sourceNamespace, targetNamespace); }
    public String sourceNamespace() { return sourceNamespace; }
    public String targetNamespace() { return targetNamespace; }
    public int classCount() { return classes.size(); }
    public int fieldCount() { return fields.size(); }
    public int methodCount() { return methods.size(); }
    public Map<String, String> classMappings() { return Collections.unmodifiableMap(classes); }

    private boolean reverse(String source, String target) {
        if (!namespaces().contains(source) || !namespaces().contains(target)) throw new IllegalArgumentException("Unsupported mapping namespace: " + source + " -> " + target);
        return source.equals(targetNamespace) && target.equals(sourceNamespace);
    }
    public String mapClass(String source, String target, String internalName) {
        boolean reverse = reverse(source, target);
        if (source.equals(target)) return internalName;
        return (reverse ? reverseClasses : classes).getOrDefault(internalName, internalName);
    }
    public String mapField(String source, String target, String owner, String name, String descriptor) {
        boolean reverse = reverse(source, target);
        if (source.equals(target)) return name;
        return (reverse ? reverseFields : fields).getOrDefault(new Member(owner, name, descriptor), name);
    }
    public String mapMethod(String source, String target, String owner, String name, String descriptor) {
        boolean reverse = reverse(source, target);
        if (source.equals(target)) return name;
        return (reverse ? reverseMethods : methods).getOrDefault(new Member(owner, name, descriptor), name);
    }
    public String mapDescriptor(String source, String target, String descriptor) {
        reverse(source, target);
        if (!descriptor.equals("V")) validateDescriptor(descriptor, descriptor.startsWith("("));
        Type type = Type.getType(descriptor);
        return mappedType(source, target, type).getDescriptor();
    }
    private Type mappedType(String source, String target, Type type) {
        if (type.getSort() == Type.OBJECT) return Type.getObjectType(mapClass(source, target, type.getInternalName()));
        if (type.getSort() == Type.ARRAY) return Type.getType("[".repeat(type.getDimensions()) + mappedType(source, target, type.getElementType()).getDescriptor());
        if (type.getSort() == Type.METHOD) {
            Type[] arguments = type.getArgumentTypes();
            for (int i = 0; i < arguments.length; i++) arguments[i] = mappedType(source, target, arguments[i]);
            return Type.getMethodType(mappedType(source, target, type.getReturnType()), arguments);
        }
        return type;
    }
    public IMappingProvider provider() {
        return acceptor -> {
            classes.forEach(acceptor::acceptClass);
            fields.forEach((member, name) -> acceptor.acceptField(new IMappingProvider.Member(member.owner(), member.name(), member.descriptor()), name));
            methods.forEach((member, name) -> acceptor.acceptMethod(new IMappingProvider.Member(member.owner(), member.name(), member.descriptor()), name));
        };
    }
}
