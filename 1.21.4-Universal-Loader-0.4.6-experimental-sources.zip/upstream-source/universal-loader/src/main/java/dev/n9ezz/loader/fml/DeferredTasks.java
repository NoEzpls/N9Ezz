package dev.n9ezz.loader.fml;

import java.util.ArrayDeque;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/** FIFO phase barrier on the game thread, rather than a second platform executor. */
final class DeferredTasks {
    private record Task(Object mod, Supplier<?> work, CompletableFuture<Object> future) {}
    static final class Failure extends RuntimeException {
        final Object mod;
        Failure(Object mod, Throwable cause) { super(cause); this.mod = mod; }
    }
    private final Thread owner = Thread.currentThread();
    private final ArrayDeque<Task> tasks = new ArrayDeque<>();
    private boolean active;
    private void thread() { if (Thread.currentThread() != owner) throw new IllegalStateException("Deferred FML work must be enqueued on the lifecycle thread"); }
    void begin() { thread(); if (active || !tasks.isEmpty()) throw new IllegalStateException("FML deferred queue already active"); active = true; }
    @SuppressWarnings("unchecked") <T> CompletableFuture<T> enqueue(Object mod, Supplier<T> work) {
        thread(); if (!active) throw new IllegalStateException("FML enqueueWork is valid only while a lifecycle phase is active");
        Objects.requireNonNull(work);
        CompletableFuture<Object> future = new CompletableFuture<>(); tasks.add(new Task(mod, work, future));
        return (CompletableFuture<T>) (CompletableFuture<?>) future;
    }
    void drain() throws Exception {
        thread(); if (!active) throw new IllegalStateException("FML deferred queue is not active");
        int count = 0;
        try {
            while (!tasks.isEmpty()) {
                if (++count > 10000) throw new IllegalStateException("FML deferred work exceeded the per-phase limit of 10000 tasks");
                Task task = tasks.remove();
                // CompletableFuture async work does not run a canceled or externally completed task.
                if (task.future.isDone()) continue;
                try (AutoCloseable ignored = FmlBindings.enter(task.mod)) {
                    task.future.complete(task.work.get());
                } catch (Throwable failure) {
                    task.future.completeExceptionally(failure);
                    throw new Failure(task.mod, failure);
                }
            }
        } finally { active = false; }
    }
    void abort(Throwable reason) {
        thread(); active = false;
        while (!tasks.isEmpty()) tasks.remove().future.completeExceptionally(reason);
    }
}
