package dev.n9ezz.loader.core;

import java.nio.file.Path;

/** Stable structured error data; Throwable details are kept separately by LoaderException. */
public record Diagnostic(String code, String message, String modId, String phase, Path source) {
    public Diagnostic { message = LocalDiagnostics.redact(message); }
    public Diagnostic(String code, String message) { this(code, message, null, null, null); }

    @Override public String toString() {
        return LocalDiagnostics.redact(code + (modId == null ? "" : " [mod=" + modId + "]")
            + (phase == null ? "" : " [phase=" + phase + "]") + ": " + message
            + (source == null ? "" : " (" + source + ")"));
    }
}
