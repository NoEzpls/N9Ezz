package dev.n9ezz.loader.fml;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.eventbus.api.bus.EventBus;
import net.minecraftforge.eventbus.api.listener.EventListener;
import net.minecraftforge.eventbus.internal.Event;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;

/** Original synchronous event adapters. Only startup lifecycle events have verified semantics. */
public final class FmlEventBuses {
    private FmlEventBuses() {}
    private static final Map<String, ForgeGroup> GROUPS = new HashMap<>();
    private static final Set<String> FORGE_EVENTS = Set.of(
            "net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent",
            "net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent",
            "net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent");
    private static final Set<String> NEO_EVENTS = Set.of(
            "net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent",
            "net.neoforged.fml.event.lifecycle.FMLClientSetupEvent",
            "net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent");

    public static synchronized BusGroup forgeGroup(String name, Class<?> baseType) {
        Objects.requireNonNull(name); Objects.requireNonNull(baseType);
        if (name.isBlank() || GROUPS.containsKey(name)) throw new IllegalArgumentException("Duplicate or empty FML bus group name: " + name);
        ForgeGroup group = new ForgeGroup(name, baseType);
        GROUPS.put(name, group);
        return group;
    }
    public static <T extends Event> EventBus<T> forgeBus(BusGroup group, Class<T> eventType) {
        if (!(group instanceof ForgeGroup own)) throw new IllegalArgumentException("Foreign BusGroup implementation is unsupported");
        return own.bus(eventType);
    }
    public static IEventBus neoBus() { return new NeoBus(); }
    static void disposeNeo(IEventBus bus) { ((NeoBus) bus).dispose(); }
    private static void owner(Thread expected) {
        if (Thread.currentThread() != expected) throw new IllegalStateException("FML lifecycle bus must be used on its owner thread");
    }
    private static final class ForgeGroup implements BusGroup {
        final String name;
        final Class<?> baseType;
        final Thread thread = Thread.currentThread();
        final Map<Class<?>, ForgeBus<?>> buses = new HashMap<>();
        boolean running = true, disposed;
        ForgeGroup(String name, Class<?> baseType) { this.name = name; this.baseType = baseType; }
        private void usable() { owner(thread); if (disposed) throw new IllegalStateException("Disposed FML bus group: " + name); }
        @SuppressWarnings("unchecked") <T extends Event> EventBus<T> bus(Class<T> eventType) {
            usable(); Objects.requireNonNull(eventType);
            if (!FORGE_EVENTS.contains(eventType.getName()) || !baseType.isAssignableFrom(eventType))
                throw new UnsupportedOperationException("Unsupported Forge event type in fml-lifecycle-v1: " + eventType.getName());
            return (EventBus<T>) buses.computeIfAbsent(eventType, key -> new ForgeBus<>(this, eventType));
        }
        public String name() { return name; }
        public void startup() { usable(); running = true; }
        public void shutdown() { usable(); running = false; }
        public void trim() { usable(); }
        public void dispose() {
            owner(thread); if (disposed) return;
            disposed = true; running = false;
            buses.values().forEach(bus -> bus.listeners.clear()); buses.clear();
            synchronized (FmlEventBuses.class) { GROUPS.remove(name, this); }
        }
    }
    private static final class ForgeListener<T extends Event> implements EventListener {
        final ForgeBus<T> bus;
        final byte priority;
        final long order;
        final Consumer<T> consumer;
        ForgeListener(ForgeBus<T> bus, byte priority, long order, Consumer<T> consumer) {
            this.bus = bus; this.priority = priority; this.order = order; this.consumer = consumer;
        }
        public Class<? extends Event> eventType() { return bus.type; }
        public byte priority() { return priority; }
    }
    private static final class ForgeBus<T extends Event> implements EventBus<T> {
        final ForgeGroup group;
        final Class<T> type;
        final List<ForgeListener<T>> listeners = new ArrayList<>();
        long sequence;
        boolean posted;
        ForgeBus(ForgeGroup group, Class<T> type) { this.group = group; this.type = type; }
        private void usable() {
            group.usable();
            if (posted) throw new IllegalStateException("Lifecycle event bus is single-use: " + type.getName());
        }
        public EventListener addListener(Consumer<T> listener) { return addListener((byte) 0, listener); }
        public EventListener addListener(byte priority, Consumer<T> listener) {
            usable(); ForgeListener<T> result = new ForgeListener<>(this, priority, sequence++, Objects.requireNonNull(listener));
            listeners.add(result); return result;
        }
        @SuppressWarnings("unchecked") public EventListener addListener(EventListener listener) {
            usable();
            if (!(listener instanceof ForgeListener<?> existing) || existing.bus != this)
                throw new IllegalArgumentException("Listener does not belong to this FML event bus");
            if (!listeners.contains(existing)) listeners.add((ForgeListener<T>) existing);
            return listener;
        }
        public void removeListener(EventListener listener) { usable(); listeners.remove(listener); }
        public boolean hasListeners() { group.usable(); return !listeners.isEmpty(); }
        public boolean post(T event) { fire(event); return false; }
        public T fire(T event) {
            usable(); if (!type.isInstance(Objects.requireNonNull(event))) throw new IllegalArgumentException("Wrong FML event type");
            if (!group.running) return event;
            // Upstream lifecycle events are single-use. Claim before invoking listeners, including recursive calls.
            posted = true;
            List<ForgeListener<T>> snapshot = new ArrayList<>(listeners);
            snapshot.sort(Comparator.<ForgeListener<T>>comparingInt(listener -> -listener.priority).thenComparingLong(listener -> listener.order));
            try { for (ForgeListener<T> listener : snapshot) listener.consumer.accept(event); }
            finally { listeners.clear(); }
            return event;
        }
    }
    private record NeoListener(Class<? extends net.neoforged.bus.api.Event> type, EventPriority priority,
                               long sequence, Object identity, Consumer<net.neoforged.bus.api.Event> consumer) {}
    private static final class NeoBus implements IEventBus {
        final Thread thread = Thread.currentThread();
        final List<NeoListener> listeners = new ArrayList<>();
        final Set<Class<?>> posted = java.util.Collections.newSetFromMap(new IdentityHashMap<>());
        long sequence;
        boolean running = true, disposed;
        private void usable() { owner(thread); if (disposed) throw new IllegalStateException("Disposed NeoForge lifecycle bus"); }
        public <T extends net.neoforged.bus.api.Event> void addListener(Consumer<T> consumer) { addListener(EventPriority.NORMAL, false, consumer); }
        public <T extends net.neoforged.bus.api.Event> void addListener(Class<T> type, Consumer<T> consumer) { addListener(EventPriority.NORMAL, false, type, consumer); }
        public <T extends net.neoforged.bus.api.Event> void addListener(EventPriority priority, Consumer<T> consumer) { addListener(priority, false, consumer); }
        public <T extends net.neoforged.bus.api.Event> void addListener(EventPriority priority, Class<T> type, Consumer<T> consumer) { addListener(priority, false, type, consumer); }
        public <T extends net.neoforged.bus.api.Event> void addListener(boolean canceled, Consumer<T> consumer) { addListener(EventPriority.NORMAL, canceled, consumer); }
        public <T extends net.neoforged.bus.api.Event> void addListener(boolean canceled, Class<T> type, Consumer<T> consumer) { addListener(EventPriority.NORMAL, canceled, type, consumer); }
        @SuppressWarnings("unchecked") public <T extends net.neoforged.bus.api.Event> void addListener(EventPriority priority, boolean canceled, Consumer<T> consumer) {
            addListener(priority, canceled, (Class<T>) inferType(consumer), consumer);
        }
        @SuppressWarnings("unchecked") public <T extends net.neoforged.bus.api.Event> void addListener(EventPriority priority, boolean canceled, Class<T> type, Consumer<T> consumer) {
            usable(); Objects.requireNonNull(type); Objects.requireNonNull(priority); Objects.requireNonNull(consumer);
            if (!NEO_EVENTS.contains(type.getName())) throw new UnsupportedOperationException("Unsupported NeoForge event type in fml-lifecycle-v1: " + type.getName());
            if (posted.contains(type)) throw new IllegalStateException("Lifecycle event has already completed: " + type.getName());
            // These three lifecycle events cannot be canceled, so receiveCanceled has no effect.
            listeners.add(new NeoListener(type, priority, sequence++, consumer, event -> consumer.accept((T) event)));
        }
        public void unregister(Object target) { usable(); listeners.removeIf(listener -> listener.identity == target); }
        public <T extends net.neoforged.bus.api.Event> T post(T event) { return dispatch(null, event); }
        public <T extends net.neoforged.bus.api.Event> T post(EventPriority phase, T event) { return dispatch(Objects.requireNonNull(phase), event); }
        private <T extends net.neoforged.bus.api.Event> T dispatch(EventPriority phase, T event) {
            usable(); Objects.requireNonNull(event);
            if (!NEO_EVENTS.contains(event.getClass().getName())) throw new UnsupportedOperationException("Unsupported NeoForge lifecycle event: " + event.getClass().getName());
            if (!running) return event;
            if (phase == null && !posted.add(event.getClass())) throw new IllegalStateException("Lifecycle event already posted: " + event.getClass().getName());
            List<NeoListener> snapshot = listeners.stream().filter(listener -> listener.type == event.getClass() && (phase == null || phase == listener.priority))
                    .sorted(Comparator.comparingInt((NeoListener listener) -> listener.priority.ordinal()).thenComparingLong(NeoListener::sequence)).toList();
            try { for (NeoListener listener : snapshot) listener.consumer.accept(event); }
            finally { if (phase == null) listeners.removeIf(listener -> listener.type == event.getClass()); }
            return event;
        }
        public void start() { usable(); running = true; }
        void dispose() { owner(thread); disposed = true; running = false; listeners.clear(); posted.clear(); }
    }
    private static Class<? extends net.neoforged.bus.api.Event> inferType(Object consumer) {
        Objects.requireNonNull(consumer);
        Class<? extends net.neoforged.bus.api.Event> found = null;
        for (Type type : consumer.getClass().getGenericInterfaces()) {
            if (type instanceof ParameterizedType parameter && parameter.getRawType() == Consumer.class
                    && parameter.getActualTypeArguments()[0] instanceof Class<?> candidate
                    && net.neoforged.bus.api.Event.class.isAssignableFrom(candidate)) found = candidate.asSubclass(net.neoforged.bus.api.Event.class);
        }
        for (Method method : consumer.getClass().getMethods()) {
            if (method.getName().equals("accept") && method.getParameterCount() == 1 && !method.isBridge()
                    && net.neoforged.bus.api.Event.class.isAssignableFrom(method.getParameterTypes()[0]))
                found = method.getParameterTypes()[0].asSubclass(net.neoforged.bus.api.Event.class);
        }
        if (found == null) throw new UnsupportedOperationException("Cannot infer lifecycle type from this Consumer; fml-lifecycle-v1 requires addListener(EventClass.class, consumer) for erased lambdas/method references");
        return found;
    }
}
