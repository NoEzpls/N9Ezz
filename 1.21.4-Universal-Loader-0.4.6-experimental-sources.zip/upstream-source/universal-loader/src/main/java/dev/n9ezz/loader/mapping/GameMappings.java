package dev.n9ezz.loader.mapping;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import net.fabricmc.tinyremapper.TinyRemapper;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;

/** Own pinned game preparation; TinyRemapper supplies inheritance-aware bytecode remapping only. */
public final class GameMappings {
    public static final String MINECRAFT_VERSION = "1.21.11";
    public static final String GAME_SHA256 = "1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd";
    public static final String MAPPINGS_SHA256 = "a355c24bd12edc6f49c6860bb9bf8ee33e55eab4d4e2e0179c3c3c2dc3b27ca4";
    public static final String REMAPPER_VERSION = "0.13.0";
    private static final String RESOURCE = "/mappings/intermediary-1.21.11.tiny";
    private static final String CACHE_SCHEMA = "n9ezz-game-remap-v2";
    private static final String REMAPPER_PACKAGE = "net/fabricmc/tinyremapper/";
    private static final Gson GSON = new Gson();
    private static volatile TinyMappingIndex mappingIndex;
    private GameMappings() {}

    public static TinyMappingIndex index() throws IOException {
        TinyMappingIndex result = mappingIndex;
        if (result != null) return result;
        synchronized (GameMappings.class) {
            if (mappingIndex == null) {
                byte[] bytes;
                try (InputStream input = GameMappings.class.getResourceAsStream(RESOURCE)) {
                    if (input == null) throw new IOException("Pinned mappings resource missing: " + RESOURCE);
                    bytes = input.readNBytes(8 * 1024 * 1024 + 1);
                }
                if (!sha256(bytes).equals(MAPPINGS_SHA256)) throw new IOException("Pinned mapping resource integrity mismatch");
                TinyMappingIndex loaded = TinyMappingIndex.read(new StringReader(new String(bytes, StandardCharsets.UTF_8)));
                if (!loaded.sourceNamespace().equals("official") || !loaded.targetNamespace().equals("intermediary")
                        || loaded.classCount() != 10242 || loaded.fieldCount() != 45245 || loaded.methodCount() != 49671) {
                    throw new IOException("Unexpected pinned mapping distribution structure");
                }
                mappingIndex = loaded;
            }
            return mappingIndex;
        }
    }

    public static Path prepare(Path originalGameJar, Path gameDir, List<Path> libraries) throws IOException {
        Path original = originalGameJar.toRealPath();
        String originalHash = sha256(original);
        if (!originalHash.equals(GAME_SHA256)) throw new LoaderException(new Diagnostic("GAME_HASH_MISMATCH",
            "Only the verified official Minecraft " + MINECRAFT_VERSION + " client is supported; SHA-256 was " + originalHash, null, "mapping", original));
        TinyMappingIndex mappings = index();
        List<Path> classpath = new ArrayList<>();
        TreeMap<String, Path> byHash = new TreeMap<>();
        for (Path library : libraries) {
            Path resolved = library.toRealPath();
            if (resolved.equals(original)) continue;
            if (!Files.isRegularFile(resolved)) throw new IOException("Not a remapping classpath Jar: " + resolved);
            byHash.putIfAbsent(sha256(resolved), resolved);
        }
        classpath.addAll(byHash.values());
        String classpathHashes = String.join("\n", byHash.keySet());
        String remapperHash = remapperFingerprint();
        String key = cacheKey(classpathHashes, remapperHash);
        Path directory = safeCacheDirectory(gameDir, key);
        Path output = directory.resolve("minecraft-1.21.11-intermediary.jar");
        Path receipt = directory.resolve("remap.json");
        Path lockPath = directory.resolve("remap.lock");
        rejectSymlink(lockPath); rejectSymlink(output); rejectSymlink(receipt);
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                FileLock lock = channel.lock()) {
            if (validCache(output, receipt, key, remapperHash)) return output;
            Path temporary = Files.createTempFile(directory, "remap-", ".jar");
            Path temporaryReceipt = Files.createTempFile(directory, "receipt-", ".json");
            try {
                remap(original, temporary, classpath, mappings);
                verifyGameSymbols(temporary);
                JsonObject metadata = new JsonObject();
                metadata.addProperty("schema", CACHE_SCHEMA);
                metadata.addProperty("cacheKey", key);
                metadata.addProperty("minecraft", MINECRAFT_VERSION);
                metadata.addProperty("namespace", "intermediary");
                metadata.addProperty("originalSha256", GAME_SHA256);
                metadata.addProperty("mappingsSha256", MAPPINGS_SHA256);
                metadata.addProperty("remapper", "TinyRemapper " + REMAPPER_VERSION);
                metadata.addProperty("remapperSha256", remapperHash);
                metadata.addProperty("classpathSha256", sha256(classpathHashes.getBytes(StandardCharsets.UTF_8)));
                metadata.addProperty("outputSha256", sha256(temporary));
                Files.writeString(temporaryReceipt, GSON.toJson(metadata), StandardCharsets.UTF_8);
                rejectSymlink(output); rejectSymlink(receipt);
                Files.move(temporary, output, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                Files.move(temporaryReceipt, receipt, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
                return output;
            } finally {
                Files.deleteIfExists(temporary); Files.deleteIfExists(temporaryReceipt);
            }
        }
    }

    private static Path safeCacheDirectory(Path gameDir, String key) throws IOException {
        Path root = gameDir.toAbsolutePath().normalize();
        Files.createDirectories(root);
        root = root.toRealPath();
        Path current = root;
        for (String component : List.of(".n9ezz", "cache", "game", key)) {
            current = current.resolve(component);
            rejectSymlink(current);
            Files.createDirectories(current);
            if (!current.toRealPath().startsWith(root)) throw new IOException("Game cache escapes game directory");
        }
        return current;
    }
    private static void rejectSymlink(Path path) throws IOException {
        if (Files.isSymbolicLink(path)) throw new IOException("Refusing symbolic link in game mapping cache: " + path);
    }
    static String cacheKey(String classpathHashes, String remapperHash) {
        return sha256((CACHE_SCHEMA + "\n" + GAME_SHA256 + "\n" + MAPPINGS_SHA256 + "\n" + REMAPPER_VERSION
            + "\nremapperSha256=" + remapperHash + "\nasm=9.9.1\n" + classpathHashes).getBytes(StandardCharsets.UTF_8));
    }

    static boolean validCache(Path output, Path receipt, String key, String remapperHash) throws IOException {
        if (!Files.isRegularFile(output, LinkOption.NOFOLLOW_LINKS) || !Files.isRegularFile(receipt, LinkOption.NOFOLLOW_LINKS)) return false;
        if (Files.size(receipt) > 16384) return false;
        try {
            JsonObject metadata = GSON.fromJson(Files.readString(receipt, StandardCharsets.UTF_8), JsonObject.class);
            if (!metadata.get("schema").getAsString().equals(CACHE_SCHEMA) || !metadata.get("cacheKey").getAsString().equals(key)
                    || !metadata.get("originalSha256").getAsString().equals(GAME_SHA256)
                    || !metadata.get("mappingsSha256").getAsString().equals(MAPPINGS_SHA256)
                    || !metadata.get("remapperSha256").getAsString().equals(remapperHash)
                    || !metadata.get("outputSha256").getAsString().equals(sha256(output))) return false;
            verifyGameSymbols(output);
            return true;
        } catch (RuntimeException | IOException error) { return false; }
    }

    /** Hash the library actually selected by the JVM, independent of its version label. */
    static String remapperFingerprint() throws IOException {
        var remapperSource = TinyRemapper.class.getProtectionDomain().getCodeSource();
        var loaderSource = GameMappings.class.getProtectionDomain().getCodeSource();
        if (remapperSource == null || loaderSource == null) throw new IOException("TinyRemapper binary provenance is unavailable");
        return remapperFingerprint(remapperSource.getLocation(), loaderSource.getLocation());
    }

    static String remapperFingerprint(URL remapperSource, URL loaderSource) throws IOException {
        Path binary = sourcePath(remapperSource);
        Path owner = sourcePath(loaderSource);
        if (Files.isDirectory(binary)) return packageFingerprint(binary);
        if (!Files.isRegularFile(binary)) throw new IOException("TinyRemapper CodeSource is not a library file: " + binary);
        // A replacement JAR earlier on the launcher classpath takes precedence over
        // shaded classes. Its real binary, rather than our embedded old copy, wins.
        if (!binary.equals(owner)) return sha256(binary);
        try (JarFile installer = new JarFile(binary.toFile(), false)) {
            var archives = installer.stream().filter(entry -> !entry.isDirectory()
                && entry.getName().startsWith("META-INF/n9ezz/dependencies/tiny-remapper-")
                && entry.getName().endsWith(".jar")
                && !entry.getName().substring("META-INF/n9ezz/dependencies/".length()).contains("/")).toList();
            if (archives.size() > 1) throw new IOException("Ambiguous preserved TinyRemapper archives");
            if (archives.size() == 1) {
                byte[] original;
                try (InputStream input = installer.getInputStream(archives.getFirst())) { original = boundedBytes(input, 16 * 1024 * 1024); }
                // Normally the preserved original is the precise binary expanded by
                // build.py. Detect manual edits to any shaded library class too.
                String actualClasses = packageFingerprint(installer);
                try (ZipInputStream input = new ZipInputStream(new java.io.ByteArrayInputStream(original))) {
                    TreeMap<String, byte[]> classes = new TreeMap<>();
                    ZipEntry entry;
                    while ((entry = input.getNextEntry()) != null) if (remapperClass(entry.getName())) {
                        if (classes.putIfAbsent(entry.getName(), boundedBytes(input, 16 * 1024 * 1024)) != null)
                            throw new IOException("Duplicate TinyRemapper class in preserved archive");
                    }
                    if (actualClasses.equals(packageFingerprint(classes))) return sha256(original);
                }
                return actualClasses;
            }
            return packageFingerprint(installer);
        }
    }

    private static Path sourcePath(URL source) throws IOException {
        if (!source.getProtocol().equals("file")) throw new IOException("Unsupported TinyRemapper CodeSource protocol: " + source.getProtocol());
        try { return Path.of(source.toURI()).toRealPath(); }
        catch (URISyntaxException | IllegalArgumentException error) { throw new IOException("Invalid TinyRemapper CodeSource", error); }
    }

    private static boolean remapperClass(String name) { return name.startsWith(REMAPPER_PACKAGE) && name.endsWith(".class"); }

    private static String packageFingerprint(Path directory) throws IOException {
        TreeMap<String, byte[]> classes = new TreeMap<>();
        Path packageRoot = directory.resolve(REMAPPER_PACKAGE);
        if (!Files.isDirectory(packageRoot)) throw new IOException("TinyRemapper classes are absent from CodeSource");
        try (var paths = Files.walk(packageRoot)) {
            for (Path path : paths.filter(item -> Files.isRegularFile(item) && item.toString().endsWith(".class")).toList()) {
                if (!path.toRealPath().startsWith(directory)) throw new IOException("TinyRemapper class escapes CodeSource directory");
                try (InputStream input = Files.newInputStream(path)) {
                    classes.put(directory.relativize(path).toString().replace(java.io.File.separatorChar, '/'), boundedBytes(input, 16 * 1024 * 1024));
                }
            }
        }
        return packageFingerprint(classes);
    }

    private static String packageFingerprint(JarFile jar) throws IOException {
        TreeMap<String, byte[]> classes = new TreeMap<>();
        for (var entry : jar.stream().filter(item -> !item.isDirectory() && remapperClass(item.getName())).toList()) {
            try (InputStream input = jar.getInputStream(entry)) {
                if (classes.putIfAbsent(entry.getName(), boundedBytes(input, 16 * 1024 * 1024)) != null)
                    throw new IOException("Duplicate TinyRemapper class in CodeSource");
            }
        }
        return packageFingerprint(classes);
    }

    private static String packageFingerprint(TreeMap<String, byte[]> classes) throws IOException {
        if (!classes.containsKey(REMAPPER_PACKAGE + "TinyRemapper.class")) throw new IOException("TinyRemapper class is absent from CodeSource");
        MessageDigest digest = digest();
        digest.update("n9ezz-tiny-remapper-classes-v1\n".getBytes(StandardCharsets.UTF_8));
        for (var entry : classes.entrySet()) {
            digest.update(entry.getKey().getBytes(StandardCharsets.UTF_8));
            digest.update((byte) 0);
            digest.update(sha256(entry.getValue()).getBytes(StandardCharsets.UTF_8));
            digest.update((byte) '\n');
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    private static byte[] boundedBytes(InputStream input, int maximum) throws IOException {
        byte[] bytes = input.readNBytes(maximum + 1);
        if (bytes.length > maximum) throw new IOException("Oversized TinyRemapper binary entry");
        return bytes;
    }

    static void remap(Path original, Path output, List<Path> libraries, TinyMappingIndex mappings) throws IOException {
        TreeMap<String, byte[]> entries = new TreeMap<>();
        TinyRemapper remapper = TinyRemapper.newRemapper().withMappings(mappings.provider()).threads(1)
            .renameInvalidLocals(true).rebuildSourceFilenames(true).build();
        try {
            remapper.readClassPath(libraries.toArray(Path[]::new));
            remapper.readInputs(original);
            remapper.apply((name, bytes) -> {
                if (entries.putIfAbsent(name + ".class", bytes) != null) throw new IllegalStateException("Duplicate remapped class: " + name);
            });
        } finally { remapper.finish(); }
        try (JarFile jar = new JarFile(original.toFile(), false)) {
            for (var entry : jar.stream().filter(item -> !item.isDirectory()).toList()) {
                String name = entry.getName();
                if (name.endsWith(".class") || signature(name)) continue;
                if (name.startsWith("/") || name.contains("../") || name.contains("\\")) throw new IOException("Invalid input Jar entry: " + name);
                try (InputStream input = jar.getInputStream(entry)) {
                    byte[] bytes = input.readAllBytes();
                    if (entries.putIfAbsent(name, bytes) != null) throw new IOException("Remapped resource collision: " + name);
                }
            }
        }
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(output))) {
            zip.setLevel(9);
            for (Map.Entry<String, byte[]> entry : entries.entrySet()) {
                ZipEntry item = new ZipEntry(entry.getKey());
                item.setTime(315532800000L);
                zip.putNextEntry(item); zip.write(entry.getValue()); zip.closeEntry();
            }
        }
    }
    private static boolean signature(String name) {
        String upper = name.toUpperCase(java.util.Locale.ROOT);
        return upper.startsWith("META-INF/") && (upper.endsWith(".SF") || upper.endsWith(".RSA") || upper.endsWith(".DSA") || upper.substring(9).startsWith("SIG-"));
    }
    public static void verifyGameSymbols(Path jarPath) throws IOException {
        try (JarFile jar = new JarFile(jarPath.toFile(), false)) {
            if (jar.getJarEntry("net/minecraft/client/main/Main.class") == null || jar.getJarEntry("gfj.class") != null) throw new IOException("Incorrect remapped Minecraft entrypoint/namespace");
            var entry = jar.getJarEntry("net/minecraft/class_310.class");
            if (entry == null) throw new IOException("Remapped MinecraftClient class missing");
            ClassNode node = new ClassNode();
            try (InputStream input = jar.getInputStream(entry)) { new ClassReader(input.readAllBytes()).accept(node, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES); }
            if (!node.name.equals("net/minecraft/class_310")
                    || node.fields.stream().noneMatch(field -> field.name.equals("field_1724") && field.desc.equals("Lnet/minecraft/class_746;"))
                    || node.methods.stream().noneMatch(method -> method.name.equals("method_1551") && method.desc.equals("()Lnet/minecraft/class_310;"))) {
                throw new IOException("Remapped MinecraftClient member descriptors failed verification");
            }
        }
    }
    public static String sha256(Path path) throws IOException {
        MessageDigest digest = digest();
        try (InputStream input = Files.newInputStream(path)) { byte[] buffer = new byte[131072]; int count; while ((count = input.read(buffer)) >= 0) digest.update(buffer, 0, count); }
        return HexFormat.of().formatHex(digest.digest());
    }
    private static String sha256(byte[] bytes) { return HexFormat.of().formatHex(digest().digest(bytes)); }
    private static MessageDigest digest() { try { return MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException error) { throw new AssertionError(error); } }
}
