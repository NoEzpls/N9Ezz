package dev.n9ezz.loader.discovery;

import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.metadata.ArchiveFeatures;
import dev.n9ezz.loader.metadata.ArchiveMetadata;
import dev.n9ezz.loader.metadata.MetadataReader;
import dev.n9ezz.loader.metadata.ModMetadata;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.channels.FileChannel;
import java.nio.channels.OverlappingFileLockException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * A bounded Fabric jar-in-jar closure for the one shared classloader. Discovery
 * executes no code, selects no platform loader, and verifies every extracted byte.
 */
public final class NestedJarResolver {
    public record Limits(int maxDepth, int maxArchives, long maxArchiveBytes,
                         long maxNestedBytes, long maxExpandedBytes, int maxEntries,
                         int maxCompressionRatio, boolean allowMetadataLessNestedLibraries) {
        public static final Limits DEFAULT = new Limits(8, 256, 128L << 20,
                64L << 20, 256L << 20, 200_000, 1000, true);
        public Limits {
            if (maxDepth < 0 || maxArchives < 1 || maxArchiveBytes < 1 || maxNestedBytes < 1
                    || maxExpandedBytes < 1 || maxEntries < 1 || maxCompressionRatio < 1) {
                throw new IllegalArgumentException("Discovery limits must be positive (depth may be zero)");
            }
        }
    }

    /** A null selection includes all declared children; a set selects exact child IDs. */
    public record Source(Path jar, String label, String expectedSha256, Set<String> selectedNestedIds) {
        public Source(Path jar, Set<String> selectedNestedIds) { this(jar, jar.toString(), null, selectedNestedIds); }
        public Source(Path jar) { this(jar, null); }
        public Source {
            Objects.requireNonNull(jar, "jar");
            Objects.requireNonNull(label, "label");
            if (expectedSha256 != null && !expectedSha256.matches("[a-f0-9]{64}")) throw new IllegalArgumentException("Invalid SHA-256");
            selectedNestedIds = selectedNestedIds == null ? null : Set.copyOf(selectedNestedIds);
        }
    }

    public record Origin(String source, String parentSha256, String entry, int depth) { }
    public record Archive(Path jar, String sha256, long size, List<String> modIds,
                          boolean library, List<Origin> origins) {
        public Archive { modIds = List.copyOf(modIds); origins = List.copyOf(origins); }
    }
    public record Omitted(String parentSha256, String entry, String sha256, List<String> modIds) {
        public Omitted { modIds = List.copyOf(modIds); }
    }
    public record Result(List<ModMetadata> mods, List<Path> libraries, List<Archive> archives,
                         Map<Path, ArchiveFeatures> features, List<Omitted> omitted) {
        public Result {
            mods = List.copyOf(mods); libraries = List.copyOf(libraries); archives = List.copyOf(archives);
            features = Map.copyOf(features); omitted = List.copyOf(omitted);
        }
        public List<Path> classpath() { return archives.stream().map(Archive::jar).toList(); }
    }

    private final Path cache;
    private final Limits limits;
    private final LinkedHashMap<String, Seen> seen = new LinkedHashMap<>();
    private record IdOwner(String hash, String modId) { }
    private final Map<String, IdOwner> idOwners = new HashMap<>();
    private final Map<String, Path> classOwners = new HashMap<>();
    private final List<ModMetadata> mods = new ArrayList<>();
    private final List<Path> libraries = new ArrayList<>();
    private final Map<Path, ArchiveFeatures> features = new LinkedHashMap<>();
    private final List<Omitted> omitted = new ArrayList<>();
    private long expanded;
    private int inspected;

    private static final class Seen {
        final Path path; final String hash; final long size; final ArchiveMetadata metadata;
        final List<Origin> origins = new ArrayList<>(); final Set<String> selection;
        Seen(Path path, String hash, long size, ArchiveMetadata metadata, Set<String> selection) {
            this.path = path; this.hash = hash; this.size = size; this.metadata = metadata; this.selection = selection;
        }
        Archive archive() { return new Archive(path, hash, size, metadata.mods().stream().map(ModMetadata::id).toList(), metadata.mods().isEmpty(), origins); }
    }

    private NestedJarResolver(Path gameDirectory, Limits limits) {
        cache = gameDirectory.toAbsolutePath().normalize().resolve(".n9ezz/nested");
        this.limits = Objects.requireNonNull(limits, "limits");
    }

    public static Result discover(Path gameDirectory, List<Source> sources) throws IOException {
        return discover(gameDirectory, sources, Limits.DEFAULT);
    }
    public static Result discover(Path gameDirectory, List<Source> sources, Limits limits) throws IOException {
        NestedJarResolver resolver = new NestedJarResolver(gameDirectory, limits);
        for (Source source : List.copyOf(sources)) {
            Path path = source.jar().toAbsolutePath().normalize();
            resolver.checkRegular(path);
            long size = Files.size(path);
            if (size > limits.maxArchiveBytes()) throw failure("NESTED_SIZE_LIMIT", "Root archive exceeds size limit", path);
            String hash = hash(path, limits.maxArchiveBytes());
            if (source.expectedSha256() != null && !source.expectedSha256().equals(hash)) {
                throw failure("NESTED_HASH_MISMATCH", "Pinned root failed SHA-256 verification", path);
            }
            resolver.visit(path.toRealPath(), hash, new Origin(source.label(), null, null, 0),
                    source.selectedNestedIds(), new HashSet<>());
        }
        return new Result(resolver.mods, resolver.libraries, resolver.seen.values().stream().map(Seen::archive).toList(),
                resolver.features, resolver.omitted);
    }

    /** Sorted external mod sources remain explicit; metadata-less root JARs are rejected. */
    public static List<Source> directorySources(Path directory) throws IOException {
        if (!Files.isDirectory(directory, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Missing mod directory: " + directory);
        try (var stream = Files.list(directory)) {
            return stream.filter(path -> path.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(".jar"))
                    .sorted(Comparator.comparing(path -> path.getFileName().toString())).map(Source::new).toList();
        }
    }

    private void visit(Path path, String hash, Origin origin, Set<String> selection, Set<String> ancestors) throws IOException {
        if (origin.depth() > limits.maxDepth()) throw failure("NESTED_DEPTH_LIMIT", "Nested archive depth exceeds " + limits.maxDepth(), path);
        if (!ancestors.add(hash)) throw failure("NESTED_CYCLE", "Nested archive repeats an ancestor content hash", path);
        try {
            Seen existing = seen.get(hash);
            if (existing != null) {
                if (!Objects.equals(selection, existing.selection)) throw failure("NESTED_SELECTION_CONFLICT", "Same archive requested with different nested module selections", path);
                existing.origins.add(origin);
                return;
            }
            inspectBounds(path);
            ArchiveMetadata metadata = MetadataReader.readArchive(path, MetadataReader.ReadPolicy.FABRIC_RUNTIME);
            boolean library = metadata.mods().isEmpty();
            if (library && (origin.depth() == 0 || !limits.allowMetadataLessNestedLibraries())) {
                throw failure("MISSING_METADATA", "Only explicitly declared nested libraries may omit metadata", path);
            }
            Seen current = new Seen(path, hash, Files.size(path), metadata, selection);
            current.origins.add(origin);
            registerIds(current);
            registerClasses(path);
            seen.put(hash, current);
            mods.addAll(metadata.mods());
            if (library) libraries.add(path);
            features.put(path, metadata.features());
            Set<String> foundSelection = new HashSet<>();
            try (JarFile jar = new JarFile(path.toFile(), true, JarFile.OPEN_READ, Runtime.version())) {
                List<String> declared = metadata.features().nestedJars();
                Enumeration<JarEntry> raw = jar.entries();
                while (raw.hasMoreElements()) {
                    String name = raw.nextElement().getName();
                    if (name.endsWith(".jar") && !declared.contains(name)) throw failure("NESTED_UNDECLARED", "Undeclared nested archive " + name, path);
                }
                for (String entry : declared) {
                    JarEntry nestedEntry = jar.getJarEntry(entry);
                    byte[] bytes = readNested(jar, nestedEntry, path);
                    String childHash = hash(bytes);
                    Path child = materialize(bytes, childHash);
                    if (selection != null) {
                        ArchiveMetadata childMetadata = MetadataReader.readArchive(child, MetadataReader.ReadPolicy.FABRIC_RUNTIME);
                        List<String> childIds = childMetadata.mods().stream().map(ModMetadata::id).toList();
                        List<String> matched = childIds.stream().filter(selection::contains).toList();
                        if (matched.isEmpty()) {
                            // Still validate omitted bytes and archive structure before accepting the closure.
                            inspectBounds(child);
                            omitted.add(new Omitted(hash, entry, childHash, childIds));
                            continue;
                        }
                        foundSelection.addAll(matched);
                    }
                    visit(child, childHash, new Origin(origin.source(), hash, entry, origin.depth() + 1), null, ancestors);
                }
            }
            if (selection != null && !foundSelection.equals(selection)) {
                Set<String> missing = new HashSet<>(selection); missing.removeAll(foundSelection);
                throw failure("NESTED_SELECTION_MISSING", "Selected nested module IDs absent from archive: " + missing, path);
            }
            if (!hash.equals(hash(path, limits.maxArchiveBytes()))) throw failure("NESTED_SOURCE_CHANGED", "Archive changed during discovery", path);
        } finally { ancestors.remove(hash); }
    }

    private void registerIds(Seen archive) {
        for (ModMetadata mod : archive.metadata.mods()) {
            Set<String> ids = new HashSet<>(mod.provides()); ids.add(mod.id());
            for (String id : ids) {
                IdOwner owner = new IdOwner(archive.hash, mod.id());
                IdOwner previous = idOwners.putIfAbsent(id, owner);
                if (previous != null && !previous.equals(owner)) throw failure("DUPLICATE_MOD_ID", "Conflicting mod ID/alias " + id + " from " + previous + " and " + owner, archive.path);
            }
        }
    }

    private void registerClasses(Path path) throws IOException {
        try (JarFile file = new JarFile(path.toFile(), true, JarFile.OPEN_READ, Runtime.version())) {
            for (JarEntry entry : file.versionedStream().toList()) {
                String name = entry.getName();
                if (entry.isDirectory() || !name.endsWith(".class") || name.equals("module-info.class") || name.startsWith("META-INF/")) continue;
                Path previous = classOwners.putIfAbsent(name, path);
                if (previous != null && !previous.equals(path)) throw failure("DUPLICATE_CLASS", "Class " + name + " occurs in " + previous + " and " + path, path);
            }
        }
    }

    private void inspectBounds(Path path) throws IOException {
        if (++inspected > limits.maxArchives()) throw failure("NESTED_ARCHIVE_LIMIT", "Archive closure exceeds " + limits.maxArchives(), path);
        if (Files.size(path) > limits.maxArchiveBytes()) throw failure("NESTED_SIZE_LIMIT", "Archive exceeds size limit", path);
        int entries = 0;
        Set<String> names = new HashSet<>();
        try (JarFile jar = new JarFile(path.toFile(), true, JarFile.OPEN_READ, Runtime.version())) {
            Enumeration<JarEntry> raw = jar.entries();
            while (raw.hasMoreElements()) {
                JarEntry entry = raw.nextElement();
                if (++entries > limits.maxEntries()) throw failure("NESTED_ENTRY_LIMIT", "Archive entry count exceeds limit", path);
                safeEntry(entry.getName(), path);
                if (!names.add(entry.getName())) throw failure("NESTED_DUPLICATE_ENTRY", "Duplicate ZIP entry " + entry.getName(), path);
                if (entry.isDirectory()) continue;
                long size = entry.getSize(); long compressed = entry.getCompressedSize();
                if (size < 0 || compressed < 0 || size > limits.maxArchiveBytes()) throw failure("NESTED_SIZE_LIMIT", "Unknown or excessive entry size: " + entry.getName(), path);
                if (size > 1_048_576 && (compressed == 0 || size / Math.max(1, compressed) > limits.maxCompressionRatio())) throw failure("NESTED_COMPRESSION_LIMIT", "Excessive compression ratio: " + entry.getName(), path);
                if (size > limits.maxExpandedBytes() - expanded) throw failure("NESTED_EXPANDED_LIMIT", "Archive closure expanded-byte budget exceeded", path);
                expanded += size;
                // Read the decompressed bytes to verify size and CRC, never trusting ZIP headers alone.
                try (InputStream input = jar.getInputStream(entry)) {
                    byte[] buffer = new byte[16_384]; long count = 0;
                    var crc = new java.util.zip.CRC32();
                    for (int n; (n = input.read(buffer)) != -1;) {
                        count += n;
                        crc.update(buffer, 0, n);
                        if (count > size || count > limits.maxArchiveBytes()) throw failure("NESTED_SIZE_MISMATCH", "Entry exceeds declared size: " + entry.getName(), path);
                    }
                    if (count != size) throw failure("NESTED_SIZE_MISMATCH", "Entry size mismatch: " + entry.getName(), path);
                    if (entry.getCrc() < 0 || crc.getValue() != entry.getCrc()) throw failure("NESTED_CRC_MISMATCH", "Entry CRC mismatch: " + entry.getName(), path);
                }
            }
        }
    }

    private byte[] readNested(JarFile jar, JarEntry entry, Path parent) throws IOException {
        if (entry == null || entry.isDirectory() || entry.getSize() < 1 || entry.getSize() > limits.maxNestedBytes()
                || entry.getSize() > Integer.MAX_VALUE - 1) throw failure("NESTED_SIZE_LIMIT", "Declared nested archive missing or too large", parent);
        try (InputStream input = jar.getInputStream(entry)) {
            byte[] bytes = input.readNBytes((int) entry.getSize() + 1);
            if (bytes.length != entry.getSize()) throw failure("NESTED_SIZE_MISMATCH", "Nested archive size differs from its ZIP header", parent);
            return bytes;
        }
    }

    private Path materialize(byte[] bytes, String hash) throws IOException {
        ensureNoSymlinks(cache); Files.createDirectories(cache);
        Path target = cache.resolve(hash + ".jar"); ensureNoSymlinks(target);
        Path lockPath = cache.resolve(hash + ".lock"); ensureNoSymlinks(lockPath);
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE, LinkOption.NOFOLLOW_LINKS);
                var lock = channel.tryLock()) {
            if (lock == null) throw failure("NESTED_CACHE_BUSY", "Another runtime is preparing the nested archive cache", target);
            return materializeLocked(bytes, hash, target);
        } catch (OverlappingFileLockException busy) {
            throw failure("NESTED_CACHE_BUSY", "Another runtime in this JVM is preparing the nested archive cache", target);
        }
    }

    private Path materializeLocked(byte[] bytes, String hash, Path target) throws IOException {
        if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) { verifyCache(target, hash, bytes.length); return target.toRealPath(); }
        Path temporary = Files.createTempFile(cache, ".nested-", ".tmp");
        try {
            Files.write(temporary, bytes);
            try { Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE); }
            catch (FileAlreadyExistsException race) { verifyCache(target, hash, bytes.length); }
            catch (AtomicMoveNotSupportedException unsupported) { throw failure("NESTED_CACHE_ATOMIC_UNSUPPORTED", "Nested cache requires atomic replacement", target); }
        } finally { Files.deleteIfExists(temporary); }
        verifyCache(target, hash, bytes.length);
        return target.toRealPath();
    }

    private void verifyCache(Path path, String hash, long size) throws IOException {
        checkRegular(path);
        if (Files.size(path) != size || !hash.equals(hash(path, limits.maxNestedBytes()))) throw failure("NESTED_CACHE_MISMATCH", "Existing nested cache is altered; preserving it", path);
    }
    private void checkRegular(Path path) {
        ensureNoSymlinks(path);
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) throw failure("NESTED_SOURCE_INVALID", "Archive must be a regular file", path);
    }
    private static void ensureNoSymlinks(Path path) {
        Path current = path.getRoot();
        for (Path part : path) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current)) throw failure("NESTED_CACHE_SYMLINK", "Archive/cache path contains a symbolic link", current);
        }
    }
    private static void safeEntry(String name, Path source) {
        if (name.isEmpty() || name.length() > 4096 || name.startsWith("/") || name.contains("\\") || name.contains(":")
                || name.chars().anyMatch(c -> c < 32 || c == 127)) throw failure("NESTED_UNSAFE_ENTRY", "Unsafe archive path", source);
        String path = name.endsWith("/") ? name.substring(0, name.length() - 1) : name;
        for (String piece : path.split("/", -1)) if (piece.isEmpty() || piece.equals(".") || piece.equals("..")) throw failure("NESTED_UNSAFE_ENTRY", "Unsafe archive path " + name, source);
    }
    private static String hash(byte[] bytes) { return HexFormat.of().formatHex(digest().digest(bytes)); }
    private static String hash(Path path, long limit) throws IOException {
        MessageDigest digest = digest(); long count = 0;
        try (InputStream input = Files.newInputStream(path)) {
            byte[] buffer = new byte[16_384];
            for (int n; (n = input.read(buffer)) != -1;) {
                count += n; if (count > limit) throw failure("NESTED_SIZE_LIMIT", "Archive exceeds hashing size limit", path);
                digest.update(buffer, 0, n);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }
    private static MessageDigest digest() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
    private static LoaderException failure(String code, String message, Path path) {
        return new LoaderException(new Diagnostic(code, message, null, "nested-discovery", path));
    }
}
