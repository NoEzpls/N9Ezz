package dev.n9ezz.loader.mixin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.spongepowered.asm.service.IGlobalPropertyService;
import org.spongepowered.asm.service.IPropertyKey;

/** Process-wide Mixin blackboard, independent of any upstream loader's globals. */
public final class UniversalGlobalPropertyService implements IGlobalPropertyService {
    private record Key(String name) implements IPropertyKey {}
    private static final Map<IPropertyKey, Object> VALUES = new ConcurrentHashMap<>();
    @Override public IPropertyKey resolveKey(String name) { return new Key(name); }
    @SuppressWarnings("unchecked") @Override public <T> T getProperty(IPropertyKey key) { return (T) VALUES.get(key); }
    @Override public void setProperty(IPropertyKey key, Object value) { if (value == null) VALUES.remove(key); else VALUES.put(key, value); }
    @Override public <T> T getProperty(IPropertyKey key, T fallback) { T value = getProperty(key); return value == null ? fallback : value; }
    @Override public String getPropertyString(IPropertyKey key, String fallback) { Object value = VALUES.get(key); return value == null ? fallback : value.toString(); }
}
