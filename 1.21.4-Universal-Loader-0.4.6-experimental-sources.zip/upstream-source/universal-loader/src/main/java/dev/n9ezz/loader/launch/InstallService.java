package dev.n9ezz.loader.launch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.n9ezz.loader.core.BuiltinModSource;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.jar.JarFile;

/** Installs one profile into an existing Java-21 vanilla launcher installation. */
public final class InstallService {
    public static final String MINECRAFT_VERSION = "1.21.11";
    public static final String PROFILE_ID = "N9Ezz-Universal-1.21.11";
    private static final String COORDINATE = "dev.n9ezz:universal-loader:" + Main.VERSION;
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();

    private InstallService() { }

    public static Map<String, Object> install(Path minecraftHome, Path installerJar) throws Exception {
        if (Runtime.version().feature() < 21) throw new IllegalStateException("Java 21 or newer is required.");
        Path home = minecraftHome.toAbsolutePath().normalize();
        if (!Files.isDirectory(home) || Files.isSymbolicLink(home)) {
            throw new IOException("Select an existing Minecraft directory (symlink roots are unsupported): " + home);
        }
        ensureWithin(home, home.resolve("versions"));
        Path vanilla = home.resolve("versions/1.21.11/1.21.11.json");
        Path vanillaJar = home.resolve("versions/1.21.11/1.21.11.jar");
        if (!Files.isRegularFile(vanilla, LinkOption.NOFOLLOW_LINKS) || !Files.isRegularFile(vanillaJar, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("BASE_VERSION_MISSING: install and start vanilla Minecraft 1.21.11 once in your launcher. No game binaries are bundled.");
        }
        ensureWithin(home, vanilla);
        ensureWithin(home, vanillaJar);
        JsonObject base = readObject(vanilla);
        if (!base.has("id") || !MINECRAFT_VERSION.equals(base.get("id").getAsString()) || base.has("inheritsFrom")) {
            throw new IOException("The base version must be unmodified vanilla 1.21.11.");
        }
        if (!base.has("javaVersion") || base.getAsJsonObject("javaVersion").get("majorVersion").getAsInt() != 21) {
            throw new IOException("Base version does not declare the required Java 21 runtime.");
        }
        try (JarFile jar = new JarFile(installerJar.toFile())) {
            if (jar.getManifest() == null || !Main.VERSION.equals(jar.getManifest().getMainAttributes().getValue("Implementation-Version"))) {
                throw new IOException("Installer manifest/version mismatch.");
            }
        }
        Path profilesPath = home.resolve("launcher_profiles.json");
        ensureWithin(home, profilesPath);
        byte[] profilesBefore = Files.exists(profilesPath) ? Files.readAllBytes(profilesPath) : null;
        JsonObject profilesRoot = Files.exists(profilesPath) ? readObject(profilesPath) : new JsonObject();
        if (profilesRoot.has("profiles") && !profilesRoot.get("profiles").isJsonObject()) {
            throw new IOException("Invalid launcher_profiles.json profiles object; preserving original file.");
        }
        JsonObject profiles = profilesRoot.has("profiles") ? profilesRoot.getAsJsonObject("profiles") : new JsonObject();
        if (profiles.has(PROFILE_ID)) {
            JsonObject existing = profiles.getAsJsonObject(PROFILE_ID);
            if (!existing.has("n9ezzManaged") || !existing.get("n9ezzManaged").getAsBoolean()) {
                throw new IOException("Profile id already belongs to another installation: " + PROFILE_ID);
            }
        }
        byte[] artifact = Files.readAllBytes(installerJar);
        BuiltinModSource clientSource = BuiltinModSource.embeddedClient();
        BuiltinModSource.BundleInfo client = clientSource.describe();
        String relativeLibrary = "dev/n9ezz/universal-loader/" + Main.VERSION + "/universal-loader-" + Main.VERSION + ".jar";
        Path library = home.resolve("libraries").resolve(relativeLibrary);
        Path versionPath = home.resolve("versions").resolve(PROFILE_ID).resolve(PROFILE_ID + ".json");
        Path instance = home.resolve("n9ezz-universal");
        Path clientTarget = instance.resolve(".n9ezz/builtin").resolve(client.sha256() + ".jar");
        for (Path path : new Path[] {library, versionPath, instance.resolve("mods"), clientTarget,
                clientTarget.resolveSibling(client.sha256() + ".lock"), home.resolve(".n9ezz-backups"), home.resolve(".n9ezz-install.lock")}) {
            ensureWithin(home, path);
        }
        JsonObject version = new JsonObject();
        version.addProperty("id", PROFILE_ID);
        version.addProperty("inheritsFrom", MINECRAFT_VERSION);
        version.addProperty("type", "release");
        version.addProperty("time", "2026-10-07T00:00:00+00:00");
        version.addProperty("releaseTime", "2026-10-07T00:00:00+00:00");
        version.addProperty("mainClass", "dev.n9ezz.loader.launch.GameBootstrap");
        version.addProperty("minimumLauncherVersion", 21);
        version.add("javaVersion", base.get("javaVersion").deepCopy());
        JsonObject lib = new JsonObject();
        lib.addProperty("name", COORDINATE);
        // Already copied into the launcher's Maven-layout library cache.
        // There is deliberately no invented remote distribution URL.
        com.google.gson.JsonArray libraries = new com.google.gson.JsonArray();
        libraries.add(lib);
        version.add("libraries", libraries);
        version.addProperty("n9ezzExperimental", true);

        JsonObject profile = new JsonObject();
        profile.addProperty("name", "N9Ezz Universal (experimental)");
        profile.addProperty("type", "custom");
        profile.addProperty("lastVersionId", PROFILE_ID);
        profile.addProperty("gameDir", instance.toString());
        profile.addProperty("n9ezzManaged", true);
        profiles.add(PROFILE_ID, profile);
        profilesRoot.add("profiles", profiles);
        Path lockPath = home.resolve(".n9ezz-install.lock");
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             var lock = channel.tryLock()) {
            if (lock == null) throw new IOException("Another N9Ezz installer is using this Minecraft directory.");
            // Read/prepare happened before locking: refuse a concurrent profile edit.
            byte[] profilesNow = Files.exists(profilesPath) ? Files.readAllBytes(profilesPath) : null;
            if (!java.util.Arrays.equals(profilesBefore, profilesNow))
                throw new IOException("Launcher profiles changed during installation; retry with launcher closed.");
            // The same verified, content-addressed source is used by bootstrap.
            // A modified cache is rejected before any launcher metadata changes.
            boolean clientPresent = Files.exists(clientTarget, LinkOption.NOFOLLOW_LINKS);
            Path preparedClient = clientSource.materialize(instance);
            Path backup = home.resolve(".n9ezz-backups").resolve(Instant.now().toString().replace(':', '-') + "-" + UUID.randomUUID());
            writePreserving(home, backup, library, artifact);
            writePreserving(home, backup, versionPath, JSON.toJson(version).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            Files.createDirectories(instance.resolve("mods"));
            Files.createDirectories(instance.resolve("logs"));
            writePreserving(home, backup, profilesPath, JSON.toJson(profilesRoot).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            Map<String, Object> report = new LinkedHashMap<>();
            report.put("profile", PROFILE_ID);
            report.put("minecraft", MINECRAFT_VERSION);
            report.put("runtime", "one N9Ezz core / " + Main.VERSION);
            report.put("instance", instance.toString());
            report.put("librarySha256", HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(artifact)));
            report.put("oldProfilesPreserved", true);
            report.put("clientBundled", true);
            report.put("clientSource", "built-in runtime module; no separate mod installation");
            report.put("clientPath", preparedClient.toString());
            report.put("clientSha256", client.sha256());
            report.put("clientSize", client.size());
            report.put("clientInstallStatus", clientPresent ? "already-present" : "installed");
            report.put("clientRunnableInUniversalCore", true);
            report.put("clientExecutionStatus", "pinned-client: shared mappings, Mixin, resources and selected API hooks; see release test report for verified scope");
            report.put("realMinecraftLaunchVerified", false);
            report.put("verificationScope", "This installation checks files and profiles; game launch is validated separately in the release report");
            return report;
        }
    }

    private static JsonObject readObject(Path path) throws IOException {
        if (Files.size(path) > 16 * 1024 * 1024) throw new IOException("Unexpectedly large JSON: " + path);
        try {
            var value = JsonParser.parseString(Files.readString(path));
            if (!value.isJsonObject()) throw new IllegalArgumentException("Root is not an object");
            return value.getAsJsonObject();
        } catch (RuntimeException failure) {
            throw new IOException("Malformed JSON, original file preserved: " + path, failure);
        }
    }

    private static void ensureWithin(Path home, Path path) throws IOException {
        Path normalized = path.toAbsolutePath().normalize();
        if (!normalized.startsWith(home)) throw new IOException("Path escapes Minecraft directory: " + path);
        Path relative = home.relativize(normalized);
        Path current = home;
        for (Path part : relative) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current)) throw new IOException("Symlink installation paths are unsupported: " + current);
        }
    }

    private static void writePreserving(Path home, Path backup, Path target, byte[] content) throws IOException {
        if (Files.exists(target) && java.util.Arrays.equals(Files.readAllBytes(target), content)) return;
        if (Files.exists(target)) {
            Path saved = backup.resolve(home.relativize(target));
            Files.createDirectories(saved.getParent());
            Files.copy(target, saved, StandardCopyOption.COPY_ATTRIBUTES);
        }
        Files.createDirectories(target.getParent());
        Path temporary = Files.createTempFile(target.getParent(), ".n9ezz-", ".tmp");
        try {
            Files.write(temporary, content);
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException unsupported) {
                throw new IOException("Atomic install unsupported; original file preserved: " + target, unsupported);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }
}
