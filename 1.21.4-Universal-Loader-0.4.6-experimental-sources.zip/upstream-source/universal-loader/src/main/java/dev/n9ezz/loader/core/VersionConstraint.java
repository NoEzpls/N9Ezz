package dev.n9ezz.loader.core;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deliberately bounded version grammar: comparisons, conjunction, OR, wildcards, caret, tilde, intervals. */
public final class VersionConstraint {
    private static final Pattern VERSION = Pattern.compile("[vV]?([0-9]+(?:\\.[0-9]+)*)(?:-([0-9A-Za-z.-]+))?(?:\\+[0-9A-Za-z.-]+)?");
    private static final Pattern TERM = Pattern.compile("(>=|<=|>|<|=|\\^|~)?\\s*([vV]?[0-9]+(?:\\.[0-9xX*]+)*(?:-[0-9A-Za-z.-]+)?(?:\\+[0-9A-Za-z.-]+)?|\\*|[xX])");
    private static final Pattern FABRIC_VERSION = Pattern.compile("([0-9]+(?:\\.[0-9]+)*)(?:-([0-9A-Za-z.-]*))?(?:\\+[0-9A-Za-z.-]+)?");
    private static final Pattern FABRIC_TERM = Pattern.compile("(>=|<=|>|<|=|\\^|~)?\\s*([0-9]+(?:\\.[0-9xX*]+)*(?:-[0-9A-Za-z.-]*)?(?:\\+[0-9A-Za-z.-]+)?|\\*|[xX])");
    private final List<Predicate<Version>> alternatives;
    private final boolean fabricSemantics;

    private VersionConstraint(List<Predicate<Version>> alternatives, boolean fabricSemantics) {
        this.alternatives = List.copyOf(alternatives); this.fabricSemantics = fabricSemantics;
    }

    public static VersionConstraint parse(String expression) {
        return parse(expression, false);
    }

    /**
     * Bounded semantic Fabric predicates. An empty prerelease boundary is smaller
     * than every prerelease of the same core; caret advances the major component
     * even when it is zero. Opaque non-semantic version predicates are unsupported.
     */
    public static VersionConstraint parseFabric(String expression) {
        return parse(expression, true);
    }

    private static VersionConstraint parse(String expression, boolean fabricSemantics) {
        if (expression == null || expression.isBlank()) throw invalid(expression);
        List<Predicate<Version>> alternatives = new ArrayList<>();
        for (String alternative : expression.split("\\|\\|", -1)) {
            String clause = alternative.strip();
            if (clause.isEmpty()) throw invalid(expression);
            if (clause.startsWith("[") || clause.startsWith("(")) {
                alternatives.add(interval(clause, expression, fabricSemantics));
                continue;
            }
            List<Predicate<Version>> terms = new ArrayList<>();
            Matcher matcher = (fabricSemantics ? FABRIC_TERM : TERM).matcher(clause);
            int end = 0;
            while (matcher.find()) {
                String gap = clause.substring(end, matcher.start());
                if (!(gap.isBlank() || (end > 0 && gap.matches("\\s*,\\s*")))) throw invalid(expression);
                if (end > 0 && gap.isEmpty()) throw invalid(expression);
                terms.add(term(matcher.group(1), matcher.group(2), expression, fabricSemantics));
                end = matcher.end();
            }
            if (terms.isEmpty() || !clause.substring(end).isBlank()) throw invalid(expression);
            alternatives.add(version -> terms.stream().allMatch(term -> term.test(version)));
        }
        return new VersionConstraint(alternatives, fabricSemantics);
    }

    public boolean matches(String version) {
        Version parsed = Version.parse(version, fabricSemantics);
        return alternatives.stream().anyMatch(alternative -> alternative.test(parsed));
    }

    private static Predicate<Version> interval(String clause, String original, boolean fabricSemantics) {
        if (clause.length() < 3) throw invalid(original);
        char left = clause.charAt(0), right = clause.charAt(clause.length() - 1);
        if ((left != '[' && left != '(') || (right != ']' && right != ')')) throw invalid(original);
        String body = clause.substring(1, clause.length() - 1);
        if (!body.contains(",")) {
            if (left != '[' || right != ']') throw invalid(original);
            Version exact = Version.parse(body.strip(), fabricSemantics);
            return v -> v.compareTo(exact) == 0;
        }
        String[] parts = body.split(",", -1);
        if (parts.length != 2 || (parts[0].isBlank() && parts[1].isBlank())) throw invalid(original);
        Version lower = parts[0].isBlank() ? null : Version.parse(parts[0].strip(), fabricSemantics);
        Version upper = parts[1].isBlank() ? null : Version.parse(parts[1].strip(), fabricSemantics);
        if (lower != null && upper != null && lower.compareTo(upper) > 0) throw invalid(original);
        return version -> (lower == null || (left == '[' ? version.compareTo(lower) >= 0 : version.compareTo(lower) > 0))
            && (upper == null || (right == ']' ? version.compareTo(upper) <= 0 : version.compareTo(upper) < 0));
    }

    private static Predicate<Version> term(String operator, String text, String original, boolean fabricSemantics) {
        String op = operator == null ? "=" : operator;
        if (text.equals("*") || text.equalsIgnoreCase("x")) {
            if (!op.equals("=")) throw invalid(original);
            return version -> true;
        }
        if (text.matches(".*(?:\\.[xX*]).*")) {
            if (!op.equals("=") || !text.matches("[0-9]+(?:\\.[0-9]+)*\\.[xX*](?:\\.[xX*])*")) throw invalid(original);
            String[] segments = text.split("\\.");
            List<Long> prefix = new ArrayList<>();
            for (String segment : segments) {
                if (segment.equals("*") || segment.equalsIgnoreCase("x")) break;
                prefix.add(number(segment, fabricSemantics));
            }
            return version -> {
                for (int i = 0; i < prefix.size(); i++) if (version.part(i) != prefix.get(i)) return false;
                return true;
            };
        }
        Version target = Version.parse(text, fabricSemantics);
        return switch (op) {
            case "=" -> v -> v.compareTo(target) == 0;
            case ">" -> v -> v.compareTo(target) > 0;
            case ">=" -> v -> v.compareTo(target) >= 0;
            case "<" -> v -> v.compareTo(target) < 0;
            case "<=" -> v -> v.compareTo(target) <= 0;
            case "~", "^" -> {
                int bump;
                if (fabricSemantics) bump = op.equals("~") ? 1 : 0;
                else if (op.equals("~")) bump = target.parts.size() < 2 ? 0 : 1;
                else {
                    bump = 0;
                    while (bump < target.parts.size() - 1 && target.part(bump) == 0) bump++;
                }
                List<Long> upperParts = new ArrayList<>(target.parts);
                while (upperParts.size() <= bump) upperParts.add(0L);
                long next;
                try { next = Math.addExact(upperParts.get(bump), 1L); }
                catch (ArithmeticException overflow) { throw invalid(original); }
                if (fabricSemantics && next > Integer.MAX_VALUE) throw invalid(original);
                upperParts.set(bump, next);
                for (int i = bump + 1; i < upperParts.size(); i++) upperParts.set(i, 0L);
                Version upper = new Version(upperParts, List.of(), fabricSemantics, fabricSemantics);
                yield v -> v.compareTo(target) >= 0 && v.compareTo(upper) < 0;
            }
            default -> throw invalid(original);
        };
    }

    private static long number(String value) {
        try { return Long.parseLong(value); }
        catch (NumberFormatException error) { throw new IllegalArgumentException("Invalid numeric version component: " + value, error); }
    }
    private static long number(String value, boolean fabricSemantics) {
        long parsed = number(value);
        if (fabricSemantics && parsed > Integer.MAX_VALUE) throw new IllegalArgumentException("Fabric semantic version component exceeds 2147483647: " + value);
        return parsed;
    }
    private static IllegalArgumentException invalid(String expression) {
        return new IllegalArgumentException("Unsupported or invalid version constraint: " + expression);
    }

    private record Version(List<Long> parts, List<String> prerelease, boolean prereleaseDeclared,
                           boolean fabricSemantics) implements Comparable<Version> {
        private static Version parse(String version, boolean fabricSemantics) {
            Matcher matcher = (fabricSemantics ? FABRIC_VERSION : VERSION).matcher(version == null ? "" : version);
            if (!matcher.matches()) throw new IllegalArgumentException("Unsupported version: " + version);
            List<Long> parts = Pattern.compile("\\.").splitAsStream(matcher.group(1)).map(part -> number(part, fabricSemantics)).toList();
            List<String> prerelease = matcher.group(2) == null || matcher.group(2).isEmpty() ? List.of() : List.of(matcher.group(2).split("\\.", -1));
            if (prerelease.stream().anyMatch(String::isEmpty)) throw new IllegalArgumentException("Invalid prerelease version: " + version);
            return new Version(parts, prerelease, matcher.group(2) != null, fabricSemantics);
        }
        private long part(int index) { return index < parts.size() ? parts.get(index) : 0; }
        @Override public int compareTo(Version other) {
            for (int i = 0; i < Math.max(parts.size(), other.parts.size()); i++) {
                int comparison = Long.compare(part(i), other.part(i));
                if (comparison != 0) return comparison;
            }
            if (prereleaseDeclared != other.prereleaseDeclared) return prereleaseDeclared ? -1 : 1;
            for (int i = 0; i < Math.min(prerelease.size(), other.prerelease.size()); i++) {
                String left = prerelease.get(i), right = other.prerelease.get(i);
                int comparison;
                String numeric = fabricSemantics ? "0|[1-9][0-9]*" : "[0-9]+";
                boolean leftNumeric = left.matches(numeric), rightNumeric = right.matches(numeric);
                if (leftNumeric && rightNumeric) comparison = new java.math.BigInteger(left).compareTo(new java.math.BigInteger(right));
                else if (leftNumeric != rightNumeric) comparison = leftNumeric ? -1 : 1;
                else comparison = left.compareTo(right);
                if (comparison != 0) return comparison;
            }
            return Integer.compare(prerelease.size(), other.prerelease.size());
        }
    }
}
