package dev.n9ezz.loader.metadata;

import java.util.Objects;

public record Dependency(String id, String constraint, boolean optional, boolean incompatible) {
    public Dependency {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(constraint, "constraint");
    }
}
