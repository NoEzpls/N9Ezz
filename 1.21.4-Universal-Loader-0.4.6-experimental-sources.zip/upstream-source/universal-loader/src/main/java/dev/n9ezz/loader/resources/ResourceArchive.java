package dev.n9ezz.loader.resources;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Comparator;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Deterministic resources-only export. No classes, nested archives, or data packs are exported. */
final class ResourceArchive {
    static final int MAX_ENTRIES = 8_192;
    static final int MAX_ENTRY_BYTES = 16 * 1024 * 1024;
    static final long MAX_TOTAL_BYTES = 128L * 1024 * 1024;
    static final long MAX_CACHE_BYTES = MAX_TOTAL_BYTES + MAX_ENTRIES * 2_048L + 4_096L;
    static final byte[] METADATA = ("{\"pack\":{\"description\":\"N9Ezz bundled client resources\","
            + "\"min_format\":[75,0],\"max_format\":[75,0]}}\n").getBytes(StandardCharsets.UTF_8);

    record Result(Path path, String sha256, int assets, long assetBytes) { }

    private ResourceArchive() { }

    static Result export(Path source, Path cacheDirectory, String cacheKey) throws IOException {
        if (!cacheKey.matches("[a-z0-9-]+")) throw new IOException("Unsafe resource cache key");
        checkedDirectory(cacheDirectory);
        Path target = cacheDirectory.resolve(cacheKey + ".zip");
        if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)
                && !Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Resource cache is not a regular file: " + target);
        Path temporary = Files.createTempFile(cacheDirectory, ".resources-", ".tmp");
        int count = 0;
        long total = 0;
        try {
            try (ZipFile archive = new ZipFile(source.toFile());
                 ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(temporary, StandardOpenOption.TRUNCATE_EXISTING))) {
                var entries = archive.stream().filter(entry -> !entry.isDirectory() && entry.getName().startsWith("assets/"))
                        .sorted(Comparator.comparing(ZipEntry::getName)).toList();
                if (entries.size() > MAX_ENTRIES) throw new IOException("Too many asset entries: " + entries.size());
                Set<String> seen = new HashSet<>();
                for (ZipEntry entry : entries) {
                    String name = entry.getName();
                    validateAssetPath(name);
                    if (!seen.add(name)) throw new IOException("Duplicate resource entry: " + name);
                    if (entry.getSize() < 0 || entry.getSize() > MAX_ENTRY_BYTES) throw new IOException("Asset entry exceeds limit: " + name);
                    byte[] bytes;
                    try (InputStream input = archive.getInputStream(entry)) { bytes = input.readNBytes(MAX_ENTRY_BYTES + 1); }
                    if (bytes.length > MAX_ENTRY_BYTES || bytes.length != entry.getSize()) throw new IOException("Asset entry size changed: " + name);
                    total += bytes.length;
                    if (total > MAX_TOTAL_BYTES) throw new IOException("Total asset size exceeds limit");
                    write(output, name, bytes);
                    count++;
                }
                write(output, "pack.mcmeta", METADATA);
            }
            String expected = hash(temporary);
            if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && Files.size(target) == Files.size(temporary) && hash(target).equals(expected)) {
                Files.delete(temporary);
            } else {
                try { Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
                catch (java.nio.file.AtomicMoveNotSupportedException ignored) { Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING); }
            }
            return new Result(target.toRealPath(), expected, count, total);
        } finally { Files.deleteIfExists(temporary); }
    }

    static void validateAssetPath(String name) throws IOException {
        if (name.length() > 1_024 || !name.startsWith("assets/") || name.contains("\\") || name.contains("\0") || name.contains(":")) throw new IOException("Unsafe asset path: " + name);
        String[] segments = name.split("/", -1);
        if (segments.length < 3 || !segments[1].matches("[a-z0-9_.-]+")) throw new IOException("Invalid asset namespace: " + name);
        for (String segment : segments) if (segment.isEmpty() || segment.equals(".") || segment.equals("..")) throw new IOException("Unsafe asset segment: " + name);
    }

    private static void checkedDirectory(Path path) throws IOException {
        Path absolute = path.toAbsolutePath().normalize();
        Path cursor = absolute.getRoot();
        for (Path component : absolute) {
            cursor = cursor.resolve(component);
            if (Files.exists(cursor, LinkOption.NOFOLLOW_LINKS)) {
                if (!Files.isDirectory(cursor, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Resource cache directory contains a symlink or non-directory: " + cursor);
            } else { Files.createDirectory(cursor); }
        }
    }

    private static void write(ZipOutputStream output, String name, byte[] bytes) throws IOException {
        ZipEntry entry = new ZipEntry(name);
        entry.setMethod(ZipEntry.STORED);
        entry.setTime(315_532_800_000L);
        entry.setSize(bytes.length);
        CRC32 crc = new CRC32(); crc.update(bytes); entry.setCrc(crc.getValue());
        output.putNextEntry(entry); output.write(bytes); output.closeEntry();
    }

    static String hash(Path path) throws IOException {
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) || Files.size(path) > MAX_CACHE_BYTES) throw new IOException("Resource cache is not a bounded regular file: " + path);
        MessageDigest digest;
        try { digest = MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
        try (InputStream input = Files.newInputStream(path)) {
            byte[] buffer = new byte[64 * 1024];
            long total = 0;
            for (int read; (read = input.read(buffer)) != -1;) {
                total += read;
                if (total > MAX_CACHE_BYTES) throw new IOException("Resource cache grew beyond its bound: " + path);
                digest.update(buffer, 0, read);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }
}
