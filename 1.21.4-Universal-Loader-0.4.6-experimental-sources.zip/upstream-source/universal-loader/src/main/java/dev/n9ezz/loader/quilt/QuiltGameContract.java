package dev.n9ezz.loader.quilt;

import com.google.gson.JsonParser;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.VersionConstraint;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.jar.JarFile;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.RecordComponentVisitor;
import org.objectweb.asm.Type;

/** Explicit, bounded Quilt game contract; it never injects or claims the stock QSL library. */
public final class QuiltGameContract {
    public static final String CONTRACT = "quilt-lifecycle-v1";
    private static final Pattern QUILT_TYPE = Pattern.compile("L(org/quiltmc/[^;<]+)");
    private static final Map<String, Set<String>> METHODS = methods();
    private static final Map<String, Set<String>> FIELDS = fields();
    private QuiltGameContract() {}

    /** Root invokes this before class indexing or user class initialization, including verify-only. */
    public static void validate(ModMetadata mod) throws IOException {
        if (mod.platform() != Platform.QUILT) throw new IllegalArgumentException("Expected Quilt mod metadata");
        if (!Set.of("none", "intermediary").contains(mod.namespace()))
            throw error(mod, "UNSUPPORTED_QUILT_NAMESPACE", "Quilt game contract requires none/intermediary namespace: " + mod.namespace());
        boolean pinnedLoader = false;
        for (var dependency : mod.dependencies()) {
            if (dependency.id().equals("quilt_loader") && !dependency.optional() && !dependency.incompatible()) {
                if (!VersionConstraint.parse(dependency.constraint()).matches(QuiltRuntime.VERIFIED_LOADER_ABI_VERSION))
                    throw error(mod, "UNSUPPORTED_QUILT_VERSION", "Quilt Loader dependency excludes the tested ABI " + QuiltRuntime.VERIFIED_LOADER_ABI_VERSION);
                pinnedLoader = true;
            }
            if (dependency.id().equals("qsl") || dependency.id().startsWith("quilt_base"))
                throw error(mod, "UNSUPPORTED_QSL_LIBRARY", "No stock QSL version or dependency provider is supplied");
        }
        if (!pinnedLoader) throw error(mod, "QUILT_ABI_DEPENDENCY_REQUIRED", "Declare a required quilt_loader dependency matching ABI " + QuiltRuntime.VERIFIED_LOADER_ABI_VERSION);
        if (mod.id().equals("qsl") || mod.id().equals("quilt_base") || mod.id().equals("quilt_loader")
                || mod.provides().stream().anyMatch(id -> Set.of("qsl", "quilt_base", "quilt_loader").contains(id)))
            throw error(mod, "UNSUPPORTED_QSL_LIBRARY", "Stock QSL modules and loader identity impersonation are outside the bounded game contract");
        try (JarFile archive = new JarFile(mod.jar().toFile())) {
            var metadata = archive.getJarEntry("quilt.mod.json");
            if (metadata == null) throw error(mod, "QUILT_CONTRACT_REQUIRED", "Missing quilt.mod.json for Quilt game contract");
            try (var input = archive.getInputStream(metadata)) {
                byte[] bytes = input.readNBytes(1024 * 1024 + 1);
                if (bytes.length > 1024 * 1024) throw error(mod, "QUILT_CONTRACT_REQUIRED", "Metadata exceeds 1 MiB");
                var root = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject();
                if (!root.has("n9ezz") || !root.getAsJsonObject("n9ezz").has("compatibility")
                        || !CONTRACT.equals(root.getAsJsonObject("n9ezz").get("compatibility").getAsString()))
                    throw error(mod, "QUILT_CONTRACT_REQUIRED", "Set root n9ezz.compatibility=" + CONTRACT + " to acknowledge registry-independent initialization semantics");
            } catch (RuntimeException failure) {
                if (failure instanceof LoaderException diagnostic) throw diagnostic;
                throw error(mod, "QUILT_CONTRACT_REQUIRED", "Malformed explicit Quilt game contract metadata: " + failure.getMessage());
            }
            var entries = archive.stream().filter(entry -> !entry.isDirectory() && entry.getName().endsWith(".class"))
                    .sorted(java.util.Comparator.comparing(java.util.jar.JarEntry::getName)).toList();
            if (entries.size() > 20_000) throw error(mod, "QUILT_CLASS_LIMIT", "Quilt archive exceeds 20000 classes");
            for (var entry : entries) {
                if (entry.getName().startsWith("META-INF/versions/"))
                    throw error(mod, "UNSUPPORTED_QUILT_MULTI_RELEASE", "Multi-release Quilt game mods are not supported");
                try (var input = archive.getInputStream(entry)) {
                    byte[] bytes = input.readNBytes(16 * 1024 * 1024 + 1);
                    if (bytes.length > 16 * 1024 * 1024) throw error(mod, "QUILT_CLASS_LIMIT", "Quilt class exceeds 16 MiB: " + entry.getName());
                    Set<String> unsupported = unsupportedReferences(bytes);
                    if (!unsupported.isEmpty()) throw error(mod, "UNSUPPORTED_QUILT_API", entry.getName() + " uses " + String.join(", ", unsupported));
                }
            }
        }
    }

    /** Statically referenced Quilt classes and members must exist in the exact documented ABI. */
    public static Set<String> unsupportedReferences(byte[] bytes) {
        Scanner scanner = new Scanner();
        new ClassReader(bytes).accept(scanner, 0);
        return Set.copyOf(scanner.unsupported);
    }
    private static Map<String, Set<String>> methods() {
        Map<String, Set<String>> values = new LinkedHashMap<>();
        for (Class<?> type : java.util.List.of(org.quiltmc.loader.api.QuiltLoader.class,
                org.quiltmc.loader.api.ModContainer.class, org.quiltmc.loader.api.ModContainer.BasicSourceType.class,
                org.quiltmc.loader.api.ModMetadata.class, org.quiltmc.loader.api.Version.class,
                org.quiltmc.loader.api.MappingResolver.class,
                org.quiltmc.qsl.base.api.entrypoint.ModInitializer.class,
                org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer.class)) {
            Set<String> signatures = new TreeSet<>();
            for (var method : type.getMethods()) if (Modifier.isPublic(method.getModifiers()))
                signatures.add(method.getName() + Type.getMethodDescriptor(method)
                        + ":" + (Modifier.isStatic(method.getModifiers()) ? "static" : "instance"));
            values.put(Type.getInternalName(type), Set.copyOf(signatures));
        }
        return Map.copyOf(values);
    }
    private static Map<String, Set<String>> fields() {
        Map<String, Set<String>> values = new LinkedHashMap<>();
        for (String name : METHODS.keySet()) {
            try {
                Set<String> signatures = new TreeSet<>();
                for (var field : Class.forName(name.replace('/', '.')).getFields())
                    signatures.add(field.getName() + ":" + Type.getDescriptor(field.getType())
                            + ":" + (Modifier.isStatic(field.getModifiers()) ? "static" : "instance"));
                values.put(name, Set.copyOf(signatures));
            } catch (ClassNotFoundException failure) { throw new ExceptionInInitializerError(failure); }
        }
        return Map.copyOf(values);
    }
    private static LoaderException error(ModMetadata mod, String code, String message) {
        return new LoaderException(new Diagnostic(code, message, mod.id(), "quilt-preflight", mod.jar()));
    }
    private static final class Scanner extends ClassVisitor {
        private final Set<String> unsupported = new TreeSet<>();
        private Scanner() { super(Opcodes.ASM9); }
        private void name(String name) {
            if (name != null && name.startsWith("[")) { descriptor(name); return; }
            if (name != null && name.startsWith("org/quiltmc/") && !METHODS.containsKey(name)) unsupported.add(name.replace('/', '.'));
        }
        private void descriptor(String descriptor) {
            if (descriptor == null) return;
            var matcher = QUILT_TYPE.matcher(descriptor);
            while (matcher.find()) name(matcher.group(1));
        }
        private void member(String owner, String name, String descriptor, boolean method, boolean staticReference) {
            name(owner); descriptor(descriptor);
            if (owner.startsWith("org/quiltmc/") && METHODS.containsKey(owner)
                    && !(method ? METHODS : FIELDS).get(owner).contains(name + (method ? "" : ":") + descriptor
                            + ":" + (staticReference ? "static" : "instance")))
                unsupported.add(owner.replace('/', '.') + "." + name + descriptor);
        }
        private void constant(Object value) {
            if (value instanceof Type type) descriptor(type.getDescriptor());
            else if (value instanceof Handle handle) {
                boolean method = handle.getTag() >= Opcodes.H_INVOKEVIRTUAL;
                boolean staticReference = handle.getTag() == Opcodes.H_INVOKESTATIC
                        || handle.getTag() == Opcodes.H_GETSTATIC || handle.getTag() == Opcodes.H_PUTSTATIC;
                member(handle.getOwner(), handle.getName(), handle.getDesc(), method, staticReference);
            } else if (value instanceof ConstantDynamic dynamic) {
                descriptor(dynamic.getDescriptor()); constant(dynamic.getBootstrapMethod());
                for (int index = 0; index < dynamic.getBootstrapMethodArgumentCount(); index++) constant(dynamic.getBootstrapMethodArgument(index));
            }
        }
        private AnnotationVisitor annotation(String descriptor) {
            descriptor(descriptor);
            return new AnnotationVisitor(Opcodes.ASM9) {
                @Override public void visit(String name, Object value) { constant(value); }
                @Override public void visitEnum(String name, String descriptor, String value) { descriptor(descriptor); }
                @Override public AnnotationVisitor visitAnnotation(String name, String descriptor) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitArray(String name) { return annotation(null); }
            };
        }
        @Override public void visit(int version, int access, String name, String signature, String parent, String[] interfaces) {
            name(name); name(parent); descriptor(signature);
            if (interfaces != null) for (String iface : interfaces) name(iface);
        }
        @Override public void visitOuterClass(String owner, String name, String descriptor) { name(owner); descriptor(descriptor); }
        @Override public void visitNestHost(String host) { name(host); }
        @Override public void visitNestMember(String member) { name(member); }
        @Override public void visitPermittedSubclass(String subclass) { name(subclass); }
        @Override public void visitInnerClass(String name, String outer, String inner, int access) { name(name); name(outer); }
        @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
        @Override public AnnotationVisitor visitTypeAnnotation(int reference, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
        @Override public RecordComponentVisitor visitRecordComponent(String name, String descriptor, String signature) {
            descriptor(descriptor); descriptor(signature);
            return new RecordComponentVisitor(Opcodes.ASM9) {
                @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTypeAnnotation(int reference, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
            };
        }
        @Override public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
            descriptor(descriptor); descriptor(signature); constant(value);
            return new FieldVisitor(Opcodes.ASM9) {
                @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTypeAnnotation(int reference, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
            };
        }
        @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            descriptor(descriptor); descriptor(signature);
            if (exceptions != null) for (String exception : exceptions) name(exception);
            return new MethodVisitor(Opcodes.ASM9) {
                @Override public AnnotationVisitor visitAnnotationDefault() { return annotation(null); }
                @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTypeAnnotation(int reference, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitParameterAnnotation(int parameter, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitInsnAnnotation(int reference, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTryCatchAnnotation(int reference, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public void visitTypeInsn(int opcode, String type) { if (type.startsWith("[")) descriptor(type); else name(type); }
                @Override public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
                    member(owner, name, descriptor, false, opcode == Opcodes.GETSTATIC || opcode == Opcodes.PUTSTATIC);
                }
                @Override public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
                    member(owner, name, descriptor, true, opcode == Opcodes.INVOKESTATIC);
                }
                @Override public void visitInvokeDynamicInsn(String name, String descriptor, Handle handle, Object... arguments) {
                    descriptor(descriptor); constant(handle); for (Object value : arguments) constant(value);
                }
                @Override public void visitLdcInsn(Object value) { constant(value); }
                @Override public void visitMultiANewArrayInsn(String descriptor, int dimensions) { descriptor(descriptor); }
                @Override public void visitTryCatchBlock(org.objectweb.asm.Label start, org.objectweb.asm.Label end, org.objectweb.asm.Label handler, String type) { name(type); }
                @Override public void visitLocalVariable(String name, String descriptor, String signature, org.objectweb.asm.Label start, org.objectweb.asm.Label end, int index) { descriptor(descriptor); descriptor(signature); }
                @Override public AnnotationVisitor visitLocalVariableAnnotation(int ref, org.objectweb.asm.TypePath path, org.objectweb.asm.Label[] start, org.objectweb.asm.Label[] end, int[] index, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public void visitFrame(int type, int localCount, Object[] locals, int stackCount, Object[] stack) {
                    if (locals != null) for (int index = 0; index < localCount; index++) if (locals[index] instanceof String name) name(name);
                    if (stack != null) for (int index = 0; index < stackCount; index++) if (stack[index] instanceof String name) name(name);
                }
            };
        }
    }
}
