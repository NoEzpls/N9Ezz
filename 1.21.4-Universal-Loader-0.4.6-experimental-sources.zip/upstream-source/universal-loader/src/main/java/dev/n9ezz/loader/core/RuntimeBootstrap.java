package dev.n9ezz.loader.core;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.compat.CompatibilityDispatcher;
import dev.n9ezz.loader.metadata.Entrypoint;
import dev.n9ezz.loader.metadata.MetadataException;
import dev.n9ezz.loader.metadata.ModMetadata;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** API-only runtime bootstrap; no hidden selection, installation or delegation to a platform engine. */
public final class RuntimeBootstrap {
    private RuntimeBootstrap() {}

    public static RuntimeSession run(Path gameDir, Path modsDir, List<Path> extraClasspath, EventBus events, boolean verifyOnly) {
        return runInternal(gameDir, modsDir, extraClasspath, null, List.of(), events, verifyOnly);
    }

    /** Explicit game ownership by the shared loader. Game hooks and game-linked mod support remain absent. */
    public static RuntimeSession runGame(Path gameDir, Path modsDir, Path gameJar, EventBus events, boolean verifyOnly) {
        return runInternal(gameDir, modsDir, List.of(), Objects.requireNonNull(gameJar, "gameJar"), List.of(), events, verifyOnly);
    }

    /** Packaged N9Ezz follows exactly the same dependency, feature and bytecode checks as external mods. */
    public static RuntimeSession runBundledGame(Path gameDir, Path modsDir, Path gameJar, EventBus events, boolean verifyOnly) {
        return runBundledGame(gameDir, modsDir, gameJar, List.of(), events, verifyOnly);
    }

    public static RuntimeSession runBundledGame(Path gameDir, Path modsDir, Path gameJar,
            List<Path> vanillaLibraries, EventBus events, boolean verifyOnly) {
        return GameRuntimeBootstrap.prepare(gameDir, modsDir, Objects.requireNonNull(gameJar), vanillaLibraries, events, verifyOnly);
    }

    public static RuntimeSession runBuiltins(Path gameDir, Path modsDir, List<Path> extraClasspath,
            List<BuiltinModSource> builtins, EventBus events, boolean verifyOnly) {
        return runInternal(gameDir, modsDir, extraClasspath, null, builtins, events, verifyOnly);
    }

    private static RuntimeSession runInternal(Path gameDir, Path modsDir, List<Path> extraClasspath, Path gameJar,
            List<BuiltinModSource> builtins, EventBus events, boolean verifyOnly) {
        Objects.requireNonNull(events, "events");
        List<String> trace = new ArrayList<>();
        UnifiedClassLoader classLoader = null;
        String step = "discovery";
        try {
            if (Runtime.version().feature() != 21) throw new LoaderException(new Diagnostic("JAVA_VERSION", "This prototype requires Java 21; actual feature version is " + Runtime.version().feature()));
            Path gameDirectory = Objects.requireNonNull(gameDir, "gameDir").toAbsolutePath().normalize();
            Path modDirectory = Objects.requireNonNull(modsDir, "modsDir").toAbsolutePath().normalize();
            Files.createDirectories(gameDirectory);
            Files.createDirectories(modDirectory);
            // Validate external inputs before any lifecycle callback or mod class is defined.
            for (Path library : Objects.requireNonNull(extraClasspath, "extraClasspath")) {
                ExternalModPolicy.validateLibrary(library);
            }
            List<ModMetadata> discovered = new ArrayList<>();
            for (BuiltinModSource source : Objects.requireNonNull(builtins, "builtins")) discovered.addAll(source.discover(gameDirectory));
            discovered.addAll(ModDiscovery.discover(modDirectory));
            publish(events, trace, LifecycleEvent.DISCOVERED);
            step = "resolve";
            List<ModMetadata> ordered = DependencyResolver.resolve(discovered);
            validateFeatures(ordered);
            publish(events, trace, LifecycleEvent.RESOLVED);
            step = "class-index";
            TransformationPipeline pipeline = new TransformationPipeline();
            // No implicit remapper, access-widener, or Mixin transformer exists in the API-only milestone.
            pipeline.freeze();
            List<Path> classpath = new ArrayList<>(Objects.requireNonNull(extraClasspath, "extraClasspath"));
            ordered.stream().map(ModMetadata::jar).forEach(classpath::add);
            classLoader = new UnifiedClassLoader(classpath, gameJar, RuntimeBootstrap.class.getClassLoader(), pipeline);
            validateEntrypointSources(ordered, classLoader);
            publish(events, trace, LifecycleEvent.TRANSFORMERS_READY);
            if (verifyOnly) {
                trace.add("VERIFY_ONLY_COMPLETE");
                return new RuntimeSession(classLoader, ordered, trace, List.of());
            }
            CompatibilityDispatcher dispatcher = new CompatibilityDispatcher();
            for (String phase : List.of("common", "client")) {
                step = phase;
                publish(events, trace, phase.equals("common") ? LifecycleEvent.COMMON_SETUP : LifecycleEvent.CLIENT_SETUP);
                for (ModMetadata mod : ordered) {
                    if (mod.entrypoints().stream().noneMatch(entrypoint -> entrypoint.phase().equals(phase))) continue;
                    trace.add("ENTRYPOINT:" + mod.id() + ":" + phase);
                    try {
                        dispatcher.initialize(mod, phase, classLoader, new ModContext(mod.id(), gameDirectory, events));
                    } catch (LoaderException error) {
                        throw error;
                    } catch (Exception | Error error) {
                        throw new LoaderException(new Diagnostic("ENTRYPOINT_FAILED", "Initialization failed: " + error.getClass().getName() + (error.getMessage() == null ? "" : ": " + error.getMessage()), mod.id(), phase, mod.jar()), error);
                    }
                }
            }
            step = "ready";
            publish(events, trace, LifecycleEvent.READY);
            return new RuntimeSession(classLoader, ordered, trace, List.of());
        } catch (Exception | Error error) {
            if (classLoader != null) classLoader.close();
            trace.add(LifecycleEvent.FAILED.name());
            try { events.publish(LifecycleEvent.FAILED); }
            catch (RuntimeException | Error handlerError) { if (error != handlerError) error.addSuppressed(handlerError); }
            if (error instanceof LoaderException loaderError) throw loaderError.withTrace(trace);
            if (error instanceof MetadataException metadataError) {
                throw new LoaderException(List.of(new Diagnostic(metadataError.code(), metadataError.getMessage(), null, step, metadataError.jar())), error, trace);
            }
            throw new LoaderException(List.of(new Diagnostic("BOOTSTRAP_FAILED", "Runtime failed during " + step + ": " + error.getClass().getName() + (error.getMessage() == null ? "" : ": " + error.getMessage()), null, step, null)), error, trace);
        }
    }

    private static void validateFeatures(List<ModMetadata> mods) {
        List<Diagnostic> diagnostics = new ArrayList<>();
        for (ModMetadata mod : mods) {
            if (!mod.mixins().isEmpty()) diagnostics.add(new Diagnostic("UNSUPPORTED_MIXIN", "Mixin configurations are declared but shared Mixin integration is not implemented: " + String.join(", ", mod.mixins()), mod.id(), "features", mod.jar()));
            if (!mod.namespace().equals("none") && !mod.namespace().equals("official")) diagnostics.add(new Diagnostic("UNSUPPORTED_NAMESPACE", "Namespace '" + mod.namespace() + "' requires an unimplemented shared remapper. Only none/official API-only bytecode is supported", mod.id(), "features", mod.jar()));
            for (Entrypoint entrypoint : mod.entrypoints()) {
                if (!entrypoint.phase().equals("common") && !entrypoint.phase().equals("client")) diagnostics.add(new Diagnostic("UNSUPPORTED_PHASE", "Entrypoint phase is unsupported: " + entrypoint.phase(), mod.id(), "features", mod.jar()));
            }
        }
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
    }

    static void validateEntrypointSources(List<ModMetadata> mods, UnifiedClassLoader loader) throws IOException {
        List<Diagnostic> diagnostics = new ArrayList<>();
        for (ModMetadata mod : mods) {
            for (Entrypoint entrypoint : mod.entrypoints()) {
                if (entrypoint.adapter().equals("annotation")) continue; // The compatibility bridge discovers @Mod owners from this Jar.
                // Language adapters can use Class::method notation; the class still must be owned by this Jar.
                String className = entrypoint.className().split("::", 2)[0];
                Path source = loader.sourceOf(className);
                if (source == null) diagnostics.add(new Diagnostic("ENTRYPOINT_NOT_FOUND", "Entrypoint class '" + className + "' is not present in the mod classpath", mod.id(), entrypoint.phase(), mod.jar()));
                else if (!source.equals(mod.jar().toRealPath())) diagnostics.add(new Diagnostic("ENTRYPOINT_WRONG_SOURCE", "Entrypoint class '" + className + "' comes from " + source + " instead of its declaring mod Jar", mod.id(), entrypoint.phase(), mod.jar()));
            }
        }
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
    }

    static void publish(EventBus events, List<String> trace, LifecycleEvent event) {
        trace.add(event.name());
        try { events.publish(event); }
        catch (RuntimeException | Error error) {
            throw new LoaderException(new Diagnostic("LIFECYCLE_HANDLER_FAILED", "Event handler failed while publishing " + event + ": " + error.getClass().getName(), null, event.name(), null), error);
        }
    }
}
