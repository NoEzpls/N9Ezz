package dev.n9ezz.loader.fabric;

import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/** Own initialization boundary pinned to Minecraft 1.21.11 intermediary constructor shape. */
public final class GameInitializationHook {
    public static final String TARGET = "net.minecraft.class_310";
    private GameInitializationHook() {}
    public static byte[] transform(String name, byte[] bytes) {
        if (!name.equals(TARGET)) return bytes;
        ClassNode node = new ClassNode(); new ClassReader(bytes).accept(node, 0);
        var constructors = node.methods.stream().filter(m -> m.name.equals("<init>") && m.desc.equals("(Lnet/minecraft/class_542;)V")).toList();
        if (constructors.size() != 1) throw shape("Expected one Minecraft(RunArgs) constructor");
        var method = constructors.getFirst();
        FieldInsnNode instance = null, thread = null;
        TypeInsnNode options = null;
        int instanceIndex = -1, threadIndex = -1, optionsIndex = -1, index = 0;
        for (AbstractInsnNode instruction : method.instructions) {
            if (instruction instanceof MethodInsnNode call && call.owner.equals("dev/n9ezz/loader/fabric/FabricRuntime") && call.name.equals("bootstrapGame")) throw shape("Initialization hook is already installed");
            if (instruction instanceof FieldInsnNode field && field.owner.equals("net/minecraft/class_310")) {
                if (field.getOpcode() == Opcodes.PUTSTATIC && field.name.equals("field_1700") && field.desc.equals("Lnet/minecraft/class_310;")) {
                    if (instance != null) throw shape("Multiple game instance assignments"); instance = field; instanceIndex = index;
                }
                if (field.getOpcode() == Opcodes.PUTFIELD && field.name.equals("field_1696") && field.desc.equals("Ljava/lang/Thread;")) {
                    if (thread != null) throw shape("Multiple game thread assignments"); thread = field; threadIndex = index;
                }
            }
            if (instruction instanceof TypeInsnNode type && type.getOpcode() == Opcodes.NEW && type.desc.equals("net/minecraft/class_315")) {
                if (options != null) throw shape("Multiple GameOptions constructions"); options = type; optionsIndex = index;
            }
            index++;
        }
        if (instance == null || thread == null || options == null || !(instanceIndex < threadIndex && threadIndex < optionsIndex)) throw shape("Required instance -> game thread -> GameOptions order was not found");
        InsnList hook = new InsnList();
        hook.add(new VarInsnNode(Opcodes.ALOAD, 0));
        hook.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "dev/n9ezz/loader/fabric/FabricRuntime", "bootstrapGame", "(Ljava/lang/Object;)V", false));
        method.instructions.insert(thread, hook);
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS); node.accept(writer);
        return writer.toByteArray();
    }
    private static LoaderException shape(String message) {
        return new LoaderException(new Diagnostic("GAME_INITIALIZATION_HOOK_MISMATCH", message, null, "core-game-hook", null));
    }
}
