package dev.n9ezz.loader.resources;

import dev.n9ezz.loader.core.BundledClientContract;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.metadata.ModMetadata;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.TypeInsnNode;

/** Own client resource-pack bridge, pinned to Minecraft 1.21.11 and the verified built-in client archive. */
public final class ModResourcePacks implements AutoCloseable {
    public static final String TARGET = "net.minecraft.class_310";
    private static final String PROVIDER = "net.minecraft.class_3285";
    private static final String ARRAY_DESCRIPTOR = "[Lnet/minecraft/class_3285;";
    private static final String BRIDGE = "dev/n9ezz/loader/resources/ModResourcePacks";
    private static final AtomicReference<ModResourcePacks> ACTIVE = new AtomicReference<>();
    public record Pack(String modId, Path archive, String sha256, int assets, long assetBytes) { }
    private final List<Pack> packs;
    private volatile boolean closed;

    private ModResourcePacks(List<Pack> packs) { this.packs = List.copyOf(packs); }

    public static ModResourcePacks prepare(Path gameDirectory, List<ModMetadata> mods) throws IOException {
        Files.createDirectories(gameDirectory);
        Path canonicalGameDirectory = gameDirectory.toRealPath();
        List<Pack> packs = new ArrayList<>();
        Set<Path> visited = new HashSet<>();
        for (ModMetadata mod : mods) {
            Path archive = mod.jar().toAbsolutePath().normalize();
            if (!visited.add(archive) || !BundledClientContract.isVerifiedArchive(archive)) continue;
            var exported = ResourceArchive.export(archive, canonicalGameDirectory.resolve(".n9ezz/cache/resources"),
                    "builtin-" + BundledClientContract.CLIENT_SHA256 + "-v1");
            if (!BundledClientContract.isVerifiedArchive(archive)) throw failure("RESOURCE_ARCHIVE_CHANGED", "Built-in resource archive changed while exporting", null);
            packs.add(new Pack(mod.id(), exported.path(), exported.sha256(), exported.assets(), exported.assetBytes()));
        }
        ModResourcePacks runtime = new ModResourcePacks(packs);
        if (!ACTIVE.compareAndSet(null, runtime)) throw failure("RESOURCE_RUNTIME_ALREADY_ACTIVE", "A resource-pack runtime is already active in this JVM", null);
        return runtime;
    }

    public List<Pack> packs() { return packs; }

    public void register(TransformationPipeline pipeline) {
        if (closed || ACTIVE.get() != this) throw failure("RESOURCE_RUNTIME_NOT_ACTIVE", "Resource-pack runtime is not active", null);
        pipeline.register(TransformationPipeline.Stage.CORE, 90, "n9ezz:client-resources", ModResourcePacks::transform);
    }

    /** Called exclusively by the transformed client constructor. The array stays owned by the shared game classloader. */
    public static Object appendProviders(Object originalProviders) {
        ModResourcePacks runtime = ACTIVE.get();
        if (runtime == null || runtime.closed) throw failure("RESOURCE_RUNTIME_NOT_ACTIVE", "Resource-pack runtime is not active", null);
        if (originalProviders == null || !originalProviders.getClass().isArray()
                || !originalProviders.getClass().getComponentType().getName().equals(PROVIDER)) {
            throw failure("RESOURCE_PROVIDER_SHAPE_MISMATCH", "Expected Minecraft ResourcePackProvider[]", null);
        }
        if (runtime.packs.isEmpty()) return originalProviders;
        Class<?> providerInterface = originalProviders.getClass().getComponentType();
        ClassLoader gameLoader = providerInterface.getClassLoader();
        Object provider = Proxy.newProxyInstance(gameLoader, new Class<?>[]{providerInterface}, (self, method, args) -> {
            if (method.getDeclaringClass() == Object.class) return switch (method.getName()) {
                case "toString" -> "N9EzzBuiltinResourcePackProvider";
                case "hashCode" -> System.identityHashCode(self);
                case "equals" -> self == args[0];
                default -> throw new UnsupportedOperationException(method.toString());
            };
            if (!method.getName().equals("method_14453") || method.getReturnType() != void.class
                    || method.getParameterCount() != 1 || method.getParameterTypes()[0] != Consumer.class) {
                throw failure("RESOURCE_PROVIDER_ABI_MISMATCH", "Unexpected resource provider method: " + method, null);
            }
            @SuppressWarnings("unchecked") Consumer<Object> consumer = (Consumer<Object>) args[0];
            for (Pack pack : runtime.packs) consumer.accept(createProfile(gameLoader, pack));
            return null;
        });
        int count = Array.getLength(originalProviders);
        Object combined = Array.newInstance(providerInterface, count + 1);
        System.arraycopy(originalProviders, 0, combined, 0, count);
        Array.set(combined, count, provider);
        return combined;
    }

    private static Object createProfile(ClassLoader loader, Pack pack) {
        try {
            Class<?> text = Class.forName("net.minecraft.class_2561", true, loader);
            Class<?> source = Class.forName("net.minecraft.class_5352", true, loader);
            Class<?> info = Class.forName("net.minecraft.class_9224", true, loader);
            Class<?> factory = Class.forName("net.minecraft.class_3288$class_7680", true, loader);
            Class<?> nativeZipFactory = Class.forName("net.minecraft.class_3258$class_8615", true, loader);
            Class<?> resourceType = Class.forName("net.minecraft.class_3264", true, loader);
            Class<?> insertion = Class.forName("net.minecraft.class_3288$class_3289", true, loader);
            Class<?> position = Class.forName("net.minecraft.class_9225", true, loader);
            Class<?> profile = Class.forName("net.minecraft.class_3288", true, loader);
            Object title = text.getMethod("method_43470", String.class).invoke(null, "N9Ezz: " + pack.modId());
            Object nativeInfo = info.getConstructor(String.class, text, source, Optional.class).newInstance(
                    "n9ezz/builtin/" + pack.modId(), title, source.getField("field_25348").get(null), Optional.empty());
            Object packFactory = nativeZipFactory.getConstructor(Path.class).newInstance(pack.archive());
            Object packPosition = position.getConstructor(boolean.class, insertion, boolean.class).newInstance(
                    true, insertion.getField("field_14281").get(null), true);
            Object result = profile.getMethod("method_45275", info, factory, resourceType, position).invoke(null,
                    nativeInfo, packFactory, resourceType.getField("field_14188").get(null), packPosition);
            if (result == null) throw failure("RESOURCE_PROFILE_REJECTED", "Minecraft rejected resource metadata for " + pack.modId(), null);
            if (!ResourceArchive.hash(pack.archive()).equals(pack.sha256())) throw failure("RESOURCE_CACHE_CHANGED", "Resource cache changed before profile registration", null);
            return result;
        } catch (InvocationTargetException error) {
            throw failure("RESOURCE_PROFILE_FAILED", "Could not create native resource profile for " + pack.modId(), error.getCause());
        } catch (ReflectiveOperationException | IOException error) {
            throw failure("RESOURCE_PROFILE_FAILED", "Could not create native resource profile for " + pack.modId(), error);
        }
    }

    /** Pinned injection only in the client constructor, never in server/datapack repositories. */
    public static byte[] transform(String name, byte[] bytes) {
        if (!name.equals(TARGET)) return bytes;
        ClassNode node = new ClassNode(); new ClassReader(bytes).accept(node, 0);
        var constructors = node.methods.stream().filter(method -> method.name.equals("<init>")
                && method.desc.equals("(Lnet/minecraft/class_542;)V")).toList();
        if (constructors.size() != 1) throw shape("Expected one Minecraft(RunArgs) constructor");
        var constructor = constructors.getFirst();
        MethodInsnNode managerCall = null;
        int arrayCount = 0;
        for (var instruction : constructor.instructions) {
            if (instruction instanceof MethodInsnNode call) {
                if (call.owner.equals(BRIDGE) && call.name.equals("appendProviders")) throw shape("Resource-pack hook is already installed");
                if (call.getOpcode() == Opcodes.INVOKESPECIAL && call.owner.equals("net/minecraft/class_3283")
                        && call.name.equals("<init>") && call.desc.equals("(" + ARRAY_DESCRIPTOR + ")V")) {
                    if (managerCall != null) throw shape("Multiple client ResourcePackManager constructions");
                    managerCall = call;
                }
            }
            if (instruction instanceof TypeInsnNode type && type.getOpcode() == Opcodes.ANEWARRAY
                    && type.desc.equals("net/minecraft/class_3285")) arrayCount++;
        }
        if (managerCall == null || arrayCount != 1) throw shape("Expected one client ResourcePackProvider[] and ResourcePackManager construction");
        InsnList hook = new InsnList();
        hook.add(new MethodInsnNode(Opcodes.INVOKESTATIC, BRIDGE, "appendProviders", "(Ljava/lang/Object;)Ljava/lang/Object;", false));
        hook.add(new TypeInsnNode(Opcodes.CHECKCAST, ARRAY_DESCRIPTOR));
        constructor.instructions.insertBefore(managerCall, hook);
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS); node.accept(writer);
        return writer.toByteArray();
    }

    @Override public void close() { closed = true; ACTIVE.compareAndSet(this, null); }
    private static LoaderException shape(String message) { return failure("RESOURCE_HOOK_SHAPE_MISMATCH", message, null); }
    private static LoaderException failure(String code, String message, Throwable cause) {
        return new LoaderException(new Diagnostic(code, message, null, "client-resources", null), cause);
    }
}
