package dev.n9ezz.loader.metadata;

import java.io.IOException;
import java.nio.file.Path;

/** A bounded, actionable discovery failure; descriptor contents are never executed. */
public final class MetadataException extends IOException {
    private static final long serialVersionUID = 1L;
    private final Path jar;
    private final String code;

    public MetadataException(Path jar, String code, String message) {
        super(code + " in " + jar.getFileName() + ": " + message);
        this.jar = jar;
        this.code = code;
    }

    public MetadataException(Path jar, String code, String message, Throwable cause) {
        super(code + " in " + jar.getFileName() + ": " + message, cause);
        this.jar = jar;
        this.code = code;
    }

    public Path jar() { return jar; }
    public String code() { return code; }
}
