package dev.n9ezz.loader.metadata;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.Strictness;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import org.tomlj.Toml;
import org.tomlj.TomlArray;
import org.tomlj.TomlParseResult;
import org.tomlj.TomlTable;

import java.io.IOException;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.regex.Pattern;

/**
 * Reads metadata into one engine-neutral model. This code does not delegate to
 * another loader, run plugins, expand nested archives, or claim the loaders' ABIs.
 * The explicit Fabric runtime policy retains declarations for a separate bounded
 * resolver; it does not enable these mechanisms by parsing their metadata.
 */
public final class MetadataReader {
    /** Advanced features are opt-in; the API-only reader keeps its old contract. */
    public enum ReadPolicy { FLAT_API_ONLY, FABRIC_RUNTIME }
    public static final int MAX_DESCRIPTOR_BYTES = 1_048_576;
    private static final int MAX_DEPTH = 48;
    private static final int MAX_ITEMS = 16_384;
    private static final int MAX_TEXT = 16_384;
    private static final Pattern ID = Pattern.compile("[a-z][a-z0-9_-]{0,63}");
    private static final Pattern CLASS = Pattern.compile("[A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*");
    private static final List<String> DESCRIPTORS = List.of("n9ezz.mod.json", "fabric.mod.json",
            "quilt.mod.json", "META-INF/mods.toml", "META-INF/neoforge.mods.toml");

    public MetadataReader() { }

    public static List<ModMetadata> read(Path path) throws IOException {
        return readArchive(path, ReadPolicy.FLAT_API_ONLY).mods();
    }

    public static List<ModMetadata> read(Path path, ReadPolicy policy) throws IOException {
        return readArchive(path, policy).mods();
    }

    public static ArchiveMetadata readArchive(Path path, ReadPolicy policy) throws IOException {
        java.util.Objects.requireNonNull(policy, "policy");
        Path jar = path.toAbsolutePath().normalize();
        try (JarFile file = new JarFile(jar.toFile(), true, JarFile.OPEN_READ, Runtime.version())) {
            List<String> found = inspectArchive(jar, file, policy);
            if (found.isEmpty()) return new ArchiveMetadata(List.of(), ArchiveFeatures.NONE);
            if (found.size() != 1) throw error(jar, "METADATA_AMBIGUOUS",
                    "multiple platform descriptors " + found + "; publish one explicit contract per JAR");
            String descriptor = found.getFirst();
            if (policy == ReadPolicy.FABRIC_RUNTIME && !descriptor.equals("fabric.mod.json")) {
                Enumeration<JarEntry> entries = file.entries();
                while (entries.hasMoreElements()) {
                    if (entries.nextElement().getName().endsWith(".jar")) throw unsupported(jar,
                            "nested discovery is implemented only for the explicit Fabric metadata contract");
                }
            }
            String source = readText(jar, file, descriptor);
            List<ModMetadata> metadata;
            ArchiveFeatures features = ArchiveFeatures.NONE;
            if (descriptor.endsWith(".toml")) {
                metadata = readToml(jar, file, source, descriptor.contains("neoforge") ? Platform.NEOFORGE : Platform.FORGE);
            } else {
                JsonObject root = json(jar, source);
                metadata = switch (descriptor) {
                    case "n9ezz.mod.json" -> List.of(readNative(jar, root));
                    case "fabric.mod.json" -> List.of(readFabric(jar, root, policy));
                    case "quilt.mod.json" -> List.of(readQuilt(jar, root, policy));
                    default -> throw new AssertionError(descriptor);
                };
                if (descriptor.equals("fabric.mod.json") && policy == ReadPolicy.FABRIC_RUNTIME) {
                    features = fabricFeatures(jar, file, root);
                }
            }
            Set<String> ids = new HashSet<>();
            for (ModMetadata mod : metadata) {
                if (!ids.add(mod.id())) throw invalid(jar, "duplicate mod ID " + mod.id() + " in one JAR");
                for (String config : mod.mixins()) {
                    if (file.getJarEntry(config) == null) throw invalid(jar, "missing declared mixin configuration " + config);
                }
            }
            return new ArchiveMetadata(metadata, features);
        } catch (MetadataException e) {
            throw e;
        } catch (RuntimeException | IOException e) {
            throw new MetadataException(jar, "METADATA_INVALID", "cannot read archive: " + e.getMessage(), e);
        }
    }

    private static List<String> inspectArchive(Path jar, JarFile file, ReadPolicy policy) throws IOException {
        List<String> found = new ArrayList<>();
        Set<String> names = new HashSet<>();
        Enumeration<JarEntry> entries = file.entries();
        int count = 0;
        while (entries.hasMoreElements()) {
            JarEntry entry = entries.nextElement();
            if (++count > 200_000) throw invalid(jar, "archive has too many entries");
            String name = entry.getName();
            safePath(jar, name, true);
            if (!names.add(name)) throw error(jar, "METADATA_UNSAFE", "duplicate ZIP entry " + name);
            if (DESCRIPTORS.contains(name)) found.add(name);
            if ((name.endsWith(".jar") && policy == ReadPolicy.FLAT_API_ONLY) || name.equals("META-INF/jarjar/metadata.json")) {
                throw unsupported(jar, "nested JARs/JarJar require shared dependency resolution, which is not implemented");
            }
            if (name.equals("META-INF/accesstransformer.cfg") || name.equals("META-INF/coremods.json")
                    || name.equals("META-INF/services/cpw.mods.modlauncher.api.ITransformationService")
                    || name.equals("META-INF/services/cpw.mods.modlauncher.serviceapi.ILaunchPluginService")) {
                throw unsupported(jar, "loader-specific transformer/service " + name + " has no shared-runtime implementation");
            }
        }
        return found;
    }

    private static String readText(Path jar, JarFile file, String name) throws IOException {
        JarEntry entry = file.getJarEntry(name);
        if (entry == null || entry.isDirectory()) throw invalid(jar, "descriptor is not a file: " + name);
        if (entry.getSize() > MAX_DESCRIPTOR_BYTES) throw invalid(jar, "descriptor exceeds 1 MiB: " + name);
        byte[] bytes;
        try (var stream = file.getInputStream(entry)) {
            bytes = stream.readNBytes(MAX_DESCRIPTOR_BYTES + 1);
        }
        if (bytes.length > MAX_DESCRIPTOR_BYTES) throw invalid(jar, "descriptor exceeds 1 MiB: " + name);
        try {
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException e) {
            throw invalid(jar, "descriptor is not valid UTF-8: " + name);
        }
    }

    private static JsonObject json(Path jar, String source) throws IOException {
        try (JsonReader reader = new JsonReader(new StringReader(source))) {
            reader.setStrictness(Strictness.STRICT);
            int[] items = {0};
            JsonElement value = readJsonValue(jar, reader, 0, items);
            if (reader.peek() != JsonToken.END_DOCUMENT) throw invalid(jar, "trailing JSON content");
            return object(jar, value, "descriptor");
        } catch (MetadataException e) {
            throw e;
        } catch (IOException | RuntimeException e) {
            throw new MetadataException(jar, "METADATA_INVALID", "malformed JSON: " + e.getMessage(), e);
        }
    }

    private static JsonElement readJsonValue(Path jar, JsonReader reader, int depth, int[] items) throws IOException {
        if (depth > MAX_DEPTH || ++items[0] > MAX_ITEMS) throw invalid(jar, "JSON structure exceeds parser limits");
        return switch (reader.peek()) {
            case BEGIN_OBJECT -> {
                JsonObject object = new JsonObject();
                reader.beginObject();
                while (reader.hasNext()) {
                    String name = reader.nextName();
                    if (name.length() > MAX_TEXT) throw invalid(jar, "JSON key exceeds parser limit");
                    if (object.has(name)) throw invalid(jar, "duplicate JSON key " + name);
                    object.add(name, readJsonValue(jar, reader, depth + 1, items));
                }
                reader.endObject();
                yield object;
            }
            case BEGIN_ARRAY -> {
                JsonArray array = new JsonArray();
                reader.beginArray();
                while (reader.hasNext()) array.add(readJsonValue(jar, reader, depth + 1, items));
                reader.endArray();
                yield array;
            }
            case STRING -> {
                String text = reader.nextString();
                if (text.length() > MAX_TEXT) throw invalid(jar, "JSON string exceeds parser limit");
                yield new JsonPrimitive(text);
            }
            case NUMBER -> {
                String number = reader.nextString();
                if (number.length() > 128) throw invalid(jar, "JSON number exceeds parser limit");
                try { yield new JsonPrimitive(new java.math.BigDecimal(number)); }
                catch (NumberFormatException e) { throw invalid(jar, "invalid JSON number"); }
            }
            case BOOLEAN -> new JsonPrimitive(reader.nextBoolean());
            case NULL -> { reader.nextNull(); yield JsonNull.INSTANCE; }
            default -> throw invalid(jar, "unexpected JSON token " + reader.peek());
        };
    }

    private static ModMetadata readNative(Path jar, JsonObject root) throws IOException {
        schema(jar, root, "schemaVersion", true);
        rejectNonempty(jar, root, "jars", "languageAdapters", "accessWidener", "access_widener", "plugins");
        environment(jar, root.get("environment"));
        String id = id(jar, string(jar, root, "id", true));
        String version = version(jar, string(jar, root, "version", true));
        List<Dependency> deps = jsonMapDependencies(jar, root);
        List<Entrypoint> entries = entrypoints(jar, root.get("entrypoints"), Platform.N9EZZ);
        return new ModMetadata(id, version, Platform.N9EZZ, jar, deps, entries,
                jsonMixins(jar, root.get("mixins")), namespace(jar, root, "none"),
                provides(jar, root.get("provides"), version));
    }

    private static ModMetadata readFabric(Path jar, JsonObject root, ReadPolicy policy) throws IOException {
        schema(jar, root, "schemaVersion", false);
        if (policy == ReadPolicy.FLAT_API_ONLY) {
            rejectNonempty(jar, root, "jars", "languageAdapters", "accessWidener", "access_widener",
                    "recommends", "suggests", "conflicts");
        } else rejectNonempty(jar, root, "languageAdapters", "access_widener");
        environment(jar, root.get("environment"));
        String id = id(jar, string(jar, root, "id", true));
        String version = version(jar, string(jar, root, "version", true));
        return new ModMetadata(id, version, Platform.FABRIC, jar, jsonMapDependencies(jar, root, policy == ReadPolicy.FABRIC_RUNTIME),
                entrypoints(jar, root.get("entrypoints"), Platform.FABRIC, policy), jsonMixins(jar, root.get("mixins")),
                extensionNamespace(jar, root, "intermediary"), provides(jar, root.get("provides"), version));
    }

    private static ArchiveFeatures fabricFeatures(Path jar, JarFile file, JsonObject root) throws IOException {
        List<String> nested = new ArrayList<>();
        if (root.has("jars")) {
            JsonElement value = root.get("jars");
            if (!value.isJsonArray()) throw invalid(jar, "jars must be an array");
            for (JsonElement item : value.getAsJsonArray()) {
                JsonObject declaration = object(jar, item, "nested jar");
                String name = string(jar, declaration, "file", true);
                safePath(jar, name, false);
                if (!name.endsWith(".jar")) throw invalid(jar, "nested jar must end in .jar: " + name);
                if (nested.contains(name)) throw invalid(jar, "duplicate nested JAR declaration " + name);
                nested.add(name);
                JarEntry entry = file.getJarEntry(name);
                if (entry == null || entry.isDirectory()) throw invalid(jar, "missing declared nested JAR " + name);
            }
        }
        Set<String> declared = new HashSet<>(nested);
        Enumeration<JarEntry> entries = file.entries();
        while (entries.hasMoreElements()) {
            String name = entries.nextElement().getName();
            if (name.endsWith(".jar") && !declared.contains(name)) throw unsupported(jar, "undeclared nested JAR " + name);
        }
        List<String> wideners = new ArrayList<>();
        if (root.has("accessWidener")) {
            String name = string(jar, root, "accessWidener", true);
            safePath(jar, name, false);
            if (!name.endsWith(".accesswidener")) throw invalid(jar, "accessWidener must end in .accesswidener");
            JarEntry entry = file.getJarEntry(name);
            if (entry == null || entry.isDirectory()) throw invalid(jar, "missing declared access widener " + name);
            wideners.add(name);
        }
        return new ArchiveFeatures(nested, wideners);
    }

    private static ModMetadata readQuilt(Path jar, JsonObject root, ReadPolicy policy) throws IOException {
        schema(jar, root, "schema_version", false);
        JsonObject loader = object(jar, root.get("quilt_loader"), "quilt_loader");
        rejectNonempty(jar, root, "jars", "access_widener", "accessWidener", "plugins");
        rejectNonempty(jar, loader, "jars", "language_adapters", "plugins");
        String loadType = string(jar, loader, "load_type", false);
        if (loadType != null && !loadType.equals("always")) throw unsupported(jar, "Quilt load_type=" + loadType);
        String intermediateMappings = string(jar, loader, "intermediate_mappings", false);
        if (intermediateMappings != null && !intermediateMappings.equals("net.fabricmc:intermediary")) {
            throw unsupported(jar, "Quilt intermediate_mappings=" + intermediateMappings);
        }
        if (root.has("minecraft")) environment(jar, object(jar, root.get("minecraft"), "minecraft").get("environment"));
        String id = id(jar, string(jar, loader, "id", true));
        String version = version(jar, string(jar, loader, "version", true));
        List<Dependency> dependencies = new ArrayList<>();
        quiltDependencies(jar, loader.get("depends"), false, dependencies);
        quiltDependencies(jar, loader.get("breaks"), true, dependencies);
        JsonElement mixin = root.has("mixin") ? root.get("mixin") : root.get("mixins");
        if (root.has("mixin") && root.has("mixins")) throw invalid(jar, "declare Quilt mixin only once");
        return new ModMetadata(id, version, Platform.QUILT, jar, dependencies,
                entrypoints(jar, loader.get("entrypoints"), Platform.QUILT, policy), jsonMixins(jar, mixin),
                extensionNamespace(jar, root, "intermediary"), provides(jar, loader.get("provides"), version));
    }

    private static void schema(Path jar, JsonObject root, String key, boolean defaultOne) throws IOException {
        if (!root.has(key) && defaultOne) return;
        JsonElement value = root.get(key);
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()
                || !value.getAsString().equals("1")) throw unsupported(jar, key + " must be integer 1");
    }

    private static List<Dependency> jsonMapDependencies(Path jar, JsonObject root) throws IOException {
        return jsonMapDependencies(jar, root, false);
    }

    private static List<Dependency> jsonMapDependencies(Path jar, JsonObject root, boolean fabricRuntime) throws IOException {
        List<Dependency> result = new ArrayList<>();
        for (String field : List.of("depends", "recommends", "suggests", "breaks", "conflicts")) {
            if (!root.has(field)) continue;
            JsonObject deps = object(jar, root.get(field), field);
            for (var dependency : deps.entrySet()) {
                result.add(new Dependency(id(jar, dependency.getKey()), constraint(jar, dependency.getValue()),
                        field.equals("recommends") || field.equals("suggests") || (fabricRuntime && field.equals("conflicts")), field.equals("breaks") || field.equals("conflicts")));
            }
        }
        return result;
    }

    private static void quiltDependencies(Path jar, JsonElement value, boolean incompatible, List<Dependency> out) throws IOException {
        if (value == null) return;
        if (!value.isJsonArray()) throw invalid(jar, "Quilt dependencies must be an array");
        for (JsonElement element : value.getAsJsonArray()) {
            if (element.isJsonArray()) throw unsupported(jar, "conditional/grouped Quilt dependency alternatives");
            JsonObject dep = object(jar, element, "Quilt dependency");
            rejectNonempty(jar, dep, "unless", "any", "all");
            boolean optional = bool(jar, dep.get("optional"), false, "optional");
            out.add(new Dependency(id(jar, string(jar, dep, "id", true)),
                    dep.has("versions") ? constraint(jar, dep.get("versions")) : "*", optional, incompatible));
        }
    }

    private static String constraint(Path jar, JsonElement value) throws IOException {
        if (value == null) throw invalid(jar, "missing dependency constraint");
        if (value.isJsonArray()) {
            List<String> alternatives = new ArrayList<>();
            for (JsonElement element : value.getAsJsonArray()) {
                if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) throw invalid(jar, "dependency alternative must be a string");
                alternatives.add(nonblank(jar, element.getAsString(), "dependency constraint"));
            }
            if (alternatives.isEmpty()) throw invalid(jar, "empty dependency alternatives");
            return String.join(" || ", alternatives);
        }
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) throw invalid(jar, "dependency constraint must be a string or OR-array");
        return nonblank(jar, value.getAsString(), "dependency constraint");
    }

    private static List<Entrypoint> entrypoints(Path jar, JsonElement value, Platform platform) throws IOException {
        return entrypoints(jar, value, platform, ReadPolicy.FLAT_API_ONLY);
    }

    private static List<Entrypoint> entrypoints(Path jar, JsonElement value, Platform platform, ReadPolicy policy) throws IOException {
        if (value == null) return List.of();
        JsonObject phases = object(jar, value, "entrypoints");
        List<Entrypoint> result = new ArrayList<>();
        Set<String> duplicate = new HashSet<>();
        for (var phase : phases.entrySet()) {
            String key = phase.getKey();
            String normalized;
            String adapter = "default";
            if (platform == Platform.N9EZZ && key.equals("common")) normalized = "common";
            else if (platform != Platform.N9EZZ && key.equals("main")) normalized = "common";
            else if (key.equals("client")) normalized = "client";
            else if (platform == Platform.QUILT && key.equals("init")) { normalized = "common"; adapter = "quilt-init"; }
            else if (platform == Platform.QUILT && key.equals("client_init") && policy == ReadPolicy.FABRIC_RUNTIME) {
                normalized = "client"; adapter = "quilt-client-init";
            }
            else throw unsupported(jar, "entrypoint phase " + key + " has no accurate client lifecycle hook");
            if (!phase.getValue().isJsonArray()) throw invalid(jar, "entrypoints." + key + " must be an array");
            for (JsonElement entry : phase.getValue().getAsJsonArray()) {
                String className;
                String actualAdapter = adapter;
                if (entry.isJsonPrimitive() && entry.getAsJsonPrimitive().isString()) className = entry.getAsString();
                else {
                    JsonObject object = object(jar, entry, "entrypoint");
                    className = string(jar, object, "value", true);
                    String declared = string(jar, object, "adapter", false);
                    if (declared != null && !declared.equals("default")) throw unsupported(jar, "custom language adapter " + declared);
                }
                boolean methodReference = false;
                if (policy == ReadPolicy.FABRIC_RUNTIME && platform == Platform.FABRIC && className.contains("::")) {
                    String[] pieces = className.split("::", -1);
                    methodReference = pieces.length == 2 && CLASS.matcher(pieces[0]).matches()
                            && pieces[1].matches("[A-Za-z_$][A-Za-z0-9_$]*");
                }
                if (!CLASS.matcher(className).matches() && !methodReference) throw unsupported(jar, "entrypoint must name a class or supported default adapter member: " + className);
                String identity = normalized + ":" + className + ":" + actualAdapter;
                if (!duplicate.add(identity)) throw invalid(jar, "duplicate entrypoint " + identity);
                result.add(new Entrypoint(normalized, className, actualAdapter));
            }
        }
        return result;
    }

    private static List<String> jsonMixins(Path jar, JsonElement value) throws IOException {
        if (value == null) return List.of();
        List<String> result = new ArrayList<>();
        List<JsonElement> entries = value.isJsonArray() ? value.getAsJsonArray().asList() : List.of(value);
        for (JsonElement entry : entries) {
            String config;
            if (entry.isJsonPrimitive() && entry.getAsJsonPrimitive().isString()) config = entry.getAsString();
            else {
                JsonObject object = object(jar, entry, "mixin");
                JsonElement environment = object.get("environment");
                if (environment != null && stringValue(jar, environment, "mixin.environment").equals("server")) continue;
                environment(jar, environment);
                config = string(jar, object, "config", true);
            }
            config = mixinPath(jar, config);
            if (!result.contains(config)) result.add(config);
        }
        return List.copyOf(result);
    }

    private static Set<String> provides(Path jar, JsonElement value, String modVersion) throws IOException {
        if (value == null) return Set.of();
        if (!value.isJsonArray()) throw invalid(jar, "provides must be an array");
        Set<String> ids = new LinkedHashSet<>();
        for (JsonElement element : value.getAsJsonArray()) {
            String alias;
            if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) alias = element.getAsString();
            else {
                JsonObject object = object(jar, element, "provides");
                alias = string(jar, object, "id", true);
                String suppliedVersion = string(jar, object, "version", false);
                if (suppliedVersion != null && !suppliedVersion.equals(modVersion)) throw unsupported(jar, "provides aliases with independent versions");
            }
            alias = id(jar, alias);
            if (!ids.add(alias)) throw invalid(jar, "duplicate provides alias " + alias);
        }
        return Collections.unmodifiableSet(ids);
    }

    private static List<ModMetadata> readToml(Path jar, JarFile file, String source, Platform platform) throws IOException {
        TomlParseResult root = Toml.parse(source);
        if (root.hasErrors()) throw invalid(jar, "malformed TOML: " + root.errors().getFirst());
        checkTomlSize(jar, root, 0, new int[] {0});
        String language = tomlString(jar, root, "modLoader", true);
        if (!language.equals("javafml") && !language.equals("n9ezz")) throw unsupported(jar, "modLoader=" + language);
        String languageVersion = nonblank(jar, tomlString(jar, root, "loaderVersion", true), "loaderVersion");
        tomlString(jar, root, "license", true);
        rejectToml(jar, root, "services", "coremods", "accessTransformers");
        Object modsValue = root.get("mods");
        if (!(modsValue instanceof TomlArray mods) || mods.size() == 0) throw invalid(jar, "TOML requires nonempty [[mods]] records");
        String namespace = "official";
        if (root.get("n9ezz") != null) {
            TomlTable extension = tomlTable(jar, root.get("n9ezz"), "n9ezz");
            namespace = validNamespace(jar, tomlString(jar, extension, "namespace", true));
            rejectToml(jar, extension, "entrypoints", "transformers");
        }
        List<String> mixins = tomlMixins(jar, root, file);
        List<ModMetadata> result = new ArrayList<>();
        Set<String> seenIds = new HashSet<>();
        for (int i = 0; i < mods.size(); i++) {
            TomlTable mod = tomlTable(jar, mods.get(i), "mods[" + i + "]");
            String id = id(jar, tomlString(jar, mod, "modId", true));
            if (!seenIds.add(id)) throw invalid(jar, "duplicate [[mods]] modId " + id);
            String version = resolveJarVersion(jar, file, tomlString(jar, mod, "version", true));
            if (mod.get("environment") != null) {
                String environment = tomlString(jar, mod, "environment", true);
                if (!environment.equals("client") && !environment.equals("*")) throw unsupported(jar, "server-only mod " + id);
            }
            rejectToml(jar, mod, "entrypoints", "languageAdapters", "features");
            List<Dependency> dependencies = new ArrayList<>();
            dependencies.add(new Dependency(language, languageVersion, false, false));
            if (root.get("dependencies") != null) {
                TomlTable all = tomlTable(jar, root.get("dependencies"), "dependencies");
                if (all.get(id) != null) {
                    Object array = all.get(id);
                    if (!(array instanceof TomlArray items)) throw invalid(jar, "dependencies." + id + " must use [[dependencies.ID]]");
                    for (int d = 0; d < items.size(); d++) {
                        TomlTable dep = tomlTable(jar, items.get(d), "dependencies." + id);
                        String dependencyId = id(jar, tomlString(jar, dep, "modId", true));
                        String constraint = nonblank(jar, tomlString(jar, dep, "versionRange", true), "versionRange");
                        String ordering = tomlString(jar, dep, "ordering", false);
                        if (ordering != null && !ordering.equals("NONE")) throw unsupported(jar,
                                "dependency ordering " + ordering + " for " + id + " -> " + dependencyId + " is unsupported");
                        String side = tomlString(jar, dep, "side", false);
                        if (side != null && !Set.of("CLIENT", "SERVER", "BOTH").contains(side)) throw invalid(jar, "unknown dependency side " + side);
                        String type = tomlString(jar, dep, "type", false);
                        Object mandatory = dep.get("mandatory");
                        if (mandatory != null && !(mandatory instanceof Boolean)) throw invalid(jar, "mandatory must be boolean");
                        if (type == null) type = mandatory == null || Boolean.TRUE.equals(mandatory) ? "required" : "optional";
                        if (!Set.of("required", "optional", "incompatible").contains(type)) throw unsupported(jar, "dependency type " + type);
                        if (mandatory != null && (!type.equals("required") && Boolean.TRUE.equals(mandatory)
                                || type.equals("required") && Boolean.FALSE.equals(mandatory))) throw invalid(jar, "conflicting dependency type and mandatory");
                        if ("SERVER".equals(side)) continue;
                        dependencies.add(new Dependency(dependencyId, constraint, type.equals("optional"), type.equals("incompatible")));
                    }
                }
            }
            result.add(new ModMetadata(id, version, platform, jar, dependencies,
                    List.of(new Entrypoint("common", "", "annotation")), mixins, namespace, Set.of()));
        }
        if (root.get("dependencies") != null) {
            TomlTable deps = tomlTable(jar, root.get("dependencies"), "dependencies");
            for (String owner : deps.keySet()) if (!seenIds.contains(owner)) throw invalid(jar, "dependency table references unknown mod " + owner);
        }
        return result;
    }

    private static List<String> tomlMixins(Path jar, TomlTable root, JarFile file) throws IOException {
        List<String> result = new ArrayList<>();
        Object declared = root.get("mixins");
        if (declared != null) {
            if (!(declared instanceof TomlArray mixins)) throw invalid(jar, "mixins must use [[mixins]]");
            for (int i = 0; i < mixins.size(); i++) {
                TomlTable entry = tomlTable(jar, mixins.get(i), "mixins");
                rejectToml(jar, entry, "requiredMods");
                String config = mixinPath(jar, tomlString(jar, entry, "config", true));
                if (!result.contains(config)) result.add(config);
            }
        }
        Manifest manifest = boundedManifest(jar, file);
        if (manifest != null) {
            String configs = manifest.getMainAttributes().getValue("MixinConfigs");
            if (configs != null) for (String config : configs.split(",", -1)) {
                config = mixinPath(jar, config.trim());
                if (!result.contains(config)) result.add(config);
            }
        }
        return List.copyOf(result);
    }

    private static Manifest boundedManifest(Path jar, JarFile file) throws IOException {
        JarEntry entry = file.getJarEntry("META-INF/MANIFEST.MF");
        if (entry == null) return null;
        // Bound the decompressed input before java.util.jar parses it.
        String source = readText(jar, file, "META-INF/MANIFEST.MF");
        return new Manifest(new java.io.ByteArrayInputStream(source.getBytes(StandardCharsets.UTF_8)));
    }

    private static String resolveJarVersion(Path jar, JarFile file, String value) throws IOException {
        if (value.equals("${file.jarVersion}")) {
            Manifest manifest = boundedManifest(jar, file);
            if (manifest == null) throw invalid(jar, "${file.jarVersion} requires a manifest Implementation-Version");
            value = manifest.getMainAttributes().getValue(Attributes.Name.IMPLEMENTATION_VERSION);
            if (value == null) throw invalid(jar, "manifest lacks Implementation-Version for ${file.jarVersion}");
        }
        return version(jar, value);
    }

    private static void checkTomlSize(Path jar, Object value, int depth, int[] items) throws IOException {
        if (depth > MAX_DEPTH || ++items[0] > MAX_ITEMS) throw invalid(jar, "TOML structure exceeds parser limits");
        if (value instanceof TomlTable table) for (String key : table.keySet()) checkTomlSize(jar, table.get(List.of(key)), depth + 1, items);
        else if (value instanceof TomlArray array) for (int i = 0; i < array.size(); i++) checkTomlSize(jar, array.get(i), depth + 1, items);
        else if (value instanceof String text && text.length() > MAX_TEXT) throw invalid(jar, "TOML string exceeds parser limit");
    }

    private static String tomlString(Path jar, TomlTable table, String key, boolean required) throws IOException {
        Object value = table.get(List.of(key));
        if (value == null && !required) return null;
        if (!(value instanceof String string)) throw invalid(jar, key + " must be a string");
        if (key.equals("version") && string.equals("${file.jarVersion}")) return string;
        return nonblank(jar, string, key);
    }

    private static TomlTable tomlTable(Path jar, Object value, String field) throws IOException {
        if (!(value instanceof TomlTable table)) throw invalid(jar, field + " must be a TOML table");
        return table;
    }

    private static void rejectToml(Path jar, TomlTable table, String... keys) throws IOException {
        for (String key : keys) if (table.get(List.of(key)) != null) throw unsupported(jar, key + " is unsupported in shared runtime");
    }

    private static String extensionNamespace(Path jar, JsonObject root, String defaultNamespace) throws IOException {
        if (!root.has("n9ezz")) return defaultNamespace;
        JsonObject extension = object(jar, root.get("n9ezz"), "n9ezz");
        return namespace(jar, extension, defaultNamespace);
    }

    private static String namespace(Path jar, JsonObject object, String defaultNamespace) throws IOException {
        String namespace = string(jar, object, "namespace", false);
        return namespace == null ? defaultNamespace : validNamespace(jar, namespace);
    }

    private static String validNamespace(Path jar, String namespace) throws IOException {
        if (!Set.of("none", "intermediary", "official", "named", "srg").contains(namespace)) throw unsupported(jar, "unknown mapping namespace " + namespace);
        return namespace;
    }

    private static void environment(Path jar, JsonElement value) throws IOException {
        if (value == null) return;
        String environment = stringValue(jar, value, "environment");
        if (environment.equals("server")) throw unsupported(jar, "server-only mod is unsupported by the client runtime");
        if (!Set.of("*", "client", "universal").contains(environment)) throw invalid(jar, "unknown environment " + environment);
    }

    private static void rejectNonempty(Path jar, JsonObject object, String... keys) throws IOException {
        for (String key : keys) {
            JsonElement value = object.get(key);
            if (value == null) continue;
            if (value.isJsonArray() && value.getAsJsonArray().isEmpty()) continue;
            if (value.isJsonObject() && value.getAsJsonObject().isEmpty()) continue;
            throw unsupported(jar, key + " is unsupported in the shared runtime");
        }
    }

    private static String mixinPath(Path jar, String path) throws IOException {
        safePath(jar, path, false);
        if (!path.endsWith(".json")) throw invalid(jar, "mixin configuration must name a JSON resource: " + path);
        return path;
    }

    private static void safePath(Path jar, String path, boolean directoryAllowed) throws IOException {
        if (path == null || path.isEmpty() || path.length() > 4096 || path.startsWith("/") || path.indexOf('\\') >= 0
                || path.indexOf(':') >= 0 || path.chars().anyMatch(c -> c < 32 || c == 127)) throw error(jar, "METADATA_UNSAFE", "unsafe archive/resource path");
        if (path.endsWith("/")) {
            if (!directoryAllowed) throw error(jar, "METADATA_UNSAFE", "resource path is a directory");
            path = path.substring(0, path.length() - 1);
        }
        for (String part : path.split("/", -1)) if (part.isEmpty() || part.equals(".") || part.equals("..")) throw error(jar, "METADATA_UNSAFE", "unsafe archive/resource path " + path);
    }

    private static String id(Path jar, String id) throws IOException {
        if (!ID.matcher(id).matches()) throw invalid(jar, "invalid mod/dependency ID " + id);
        return id;
    }

    private static String version(Path jar, String version) throws IOException {
        version = nonblank(jar, version, "version");
        if (version.contains("${")) throw unsupported(jar, "unresolved version placeholder");
        return version;
    }

    private static String nonblank(Path jar, String value, String field) throws IOException {
        if (value == null || value.isBlank() || value.length() > MAX_TEXT || value.chars().anyMatch(c -> c < 32 || c == 127)) throw invalid(jar, field + " must be nonempty text without control characters");
        if (value.contains("${")) throw unsupported(jar, "unresolved placeholder in " + field);
        return value;
    }

    private static JsonObject object(Path jar, JsonElement value, String field) throws IOException {
        if (value == null || !value.isJsonObject()) throw invalid(jar, field + " must be an object");
        return value.getAsJsonObject();
    }

    private static String string(Path jar, JsonObject object, String key, boolean required) throws IOException {
        JsonElement value = object.get(key);
        if (value == null && !required) return null;
        return nonblank(jar, stringValue(jar, value, key), key);
    }

    private static String stringValue(Path jar, JsonElement value, String field) throws IOException {
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) throw invalid(jar, field + " must be a string");
        return value.getAsString();
    }

    private static boolean bool(Path jar, JsonElement value, boolean defaultValue, String field) throws IOException {
        if (value == null) return defaultValue;
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isBoolean()) throw invalid(jar, field + " must be boolean");
        return value.getAsBoolean();
    }

    private static MetadataException invalid(Path jar, String message) { return error(jar, "METADATA_INVALID", message); }
    private static MetadataException unsupported(Path jar, String message) { return error(jar, "METADATA_UNSUPPORTED", message); }
    private static MetadataException error(Path jar, String code, String message) { return new MetadataException(jar, code, message); }
}
