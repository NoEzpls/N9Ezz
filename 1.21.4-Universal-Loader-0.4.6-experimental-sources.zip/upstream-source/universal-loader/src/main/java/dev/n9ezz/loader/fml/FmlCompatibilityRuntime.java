package dev.n9ezz.loader.fml;

import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import org.objectweb.asm.Type;

/**
 * One bounded Forge/NeoForge lifecycle adapter inside the existing N9Ezz runtime.
 * No ModLauncher, FMLLoader, Minecraft patches, registries, or extra classloader is installed.
 */
public final class FmlCompatibilityRuntime implements AutoCloseable {
    public static final String CONTRACT = "fml-lifecycle-v1";
    public static final String FORGE_API_BASELINE = "61.0-source";
    public static final String NEOFORGE_API_BASELINE = "21.11.45/FML-10.0.36";
    private static final AtomicLong RUNTIME_IDS = new AtomicLong();
    private final long runtimeId = RUNTIME_IDS.incrementAndGet();
    private final Thread owner = Thread.currentThread();
    private final Set<String> installed;
    private final Map<String, ModMetadata> expected = new LinkedHashMap<>();
    private final Map<String, Slot> slots = new LinkedHashMap<>();
    private final Map<String, LoaderException> attempts = new HashMap<>();
    private final DeferredTasks tasks = new DeferredTasks();
    private final List<String> trace = new ArrayList<>();
    private Phase phase = Phase.CONSTRUCT;
    private LoaderException failure;
    private boolean closed;
    private boolean dispatching;
    private enum Phase { CONSTRUCT, COMMON, CLIENT, COMPLETE }
    private record Slot(ModMetadata metadata, Object container, Object bus, ClassLoader loader) {}

    public FmlCompatibilityRuntime(List<ModMetadata> mods) throws IOException {
        Objects.requireNonNull(mods);
        Set<String> ids = new HashSet<>(Set.of("minecraft", "java", "n9ezz"));
        for (ModMetadata mod : mods) {
            ids.add(mod.id()); ids.addAll(mod.provides());
            if (fml(mod) && expected.putIfAbsent(mod.id(), mod) != null) throw error(mod, "fml-preflight", "DUPLICATE_MOD_ID", "Repeated FML metadata id", null);
        }
        installed = Set.copyOf(ids);
        // Preflight the entire selected platform graph before the first mod can run user code.
        for (ModMetadata mod : expected.values()) validate(mod);
    }
    /** Language API baselines only. These values never advertise a complete Forge/NeoForge game engine. */
    public static Map<String, String> providerVersions(Platform platform) {
        return switch (platform) {
            case FORGE -> Map.of("javafml", "61.0");
            case NEOFORGE -> Map.of("javafml", "10.0.36");
            default -> Map.of();
        };
    }
    private static boolean fml(ModMetadata mod) { return mod.platform() == Platform.FORGE || mod.platform() == Platform.NEOFORGE; }
    /** This can run for every selected JAR before ANY entrypoint or constructor executes. */
    public void validate(ModMetadata mod) throws IOException {
        Objects.requireNonNull(mod);
        FmlApiContract.validate(mod, installed);
    }
    private void usable() {
        if (Thread.currentThread() != owner) throw new IllegalStateException("FML lifecycle runtime must be used on its owner game thread");
        if (closed) throw new IllegalStateException("FML lifecycle runtime is closed");
        if (failure != null) throw failure;
    }
    public synchronized void construct(ModMetadata mod, ClassLoader loader) throws Exception {
        usable(); Objects.requireNonNull(mod); Objects.requireNonNull(loader);
        ModMetadata declared = expected.get(mod.id());
        if (declared == null || !declared.equals(mod)) throw error(mod, "construct", "FML_METADATA_MISMATCH", "Mod is not in the owning runtime's resolved graph", null);
        if (attempts.containsKey(mod.id())) { if (attempts.get(mod.id()) != null) throw attempts.get(mod.id()); return; }
        if (phase != Phase.CONSTRUCT) throw error(mod, "construct", "FML_LIFECYCLE_ORDER", "Construction cannot occur after common setup", null);
        attempts.put(mod.id(), null); // Reentrant or repeated requests cannot construct a second instance.
        Object container = null, bus = null;
        try {
            List<FmlApiContract.Candidate> candidates = FmlApiContract.validate(mod, installed);
            if (mod.platform() == Platform.FORGE) {
                var group = net.minecraftforge.eventbus.api.bus.BusGroup.create("n9ezz." + runtimeId + "." + mod.id(), net.minecraftforge.fml.event.IModBusEvent.class);
                bus = group;
                var forge = new net.minecraftforge.fml.javafmlmod.FMLModContainer(mod.id(), group);
                var context = new net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext(forge);
                container = forge;
                FmlBindings.bind(forge, tasks, loader, () -> net.minecraftforge.fml.ModLoadingContext.n9ezzEnter(context));
            } else {
                var neoBus = FmlEventBuses.neoBus(); bus = neoBus;
                var neo = new net.neoforged.fml.javafmlmod.FMLModContainer(mod.id(), neoBus);
                var context = new net.neoforged.fml.ModLoadingContext(neo);
                container = neo;
                FmlBindings.bind(neo, tasks, loader, () -> net.neoforged.fml.ModLoadingContext.n9ezzEnter(context));
            }
            Slot slot = new Slot(mod, container, bus, loader);
            slots.put(mod.id(), slot);
            for (FmlApiContract.Candidate candidate : candidates) {
                try (AutoCloseable ignored = FmlBindings.enter(container)) {
                    Class<?> type = ownedClass(mod, candidate.name(), loader);
                    Class<?>[] parameters = argumentTypes(candidate.constructor(), loader);
                    Constructor<?> constructor = type.getConstructor(parameters);
                    Object[] values = arguments(slot, parameters);
                    constructor.newInstance(values);
                    trace.add(mod.id() + ":construct:" + candidate.name());
                }
            }
        } catch (Throwable thrown) {
            Throwable cause = unwrap(thrown);
            LoaderException exception = thrown instanceof LoaderException known ? known : error(mod, "construct", cause instanceof LinkageError ? "UNSUPPORTED_PLATFORM_API" : "FML_CONSTRUCTION_FAILED", detail(cause), cause);
            attempts.put(mod.id(), exception); failure = exception;
            if (container != null) FmlBindings.unbind(container);
            if (bus != null) dispose(bus);
            slots.remove(mod.id());
            throw exception;
        }
    }
    private static Class<?> ownedClass(ModMetadata mod, String name, ClassLoader loader) throws Exception {
        if (name.startsWith("java.") || name.startsWith("net.minecraftforge.") || name.startsWith("net.neoforged.") || name.startsWith("dev.n9ezz.loader."))
            throw error(mod, "construct", "INVALID_ENTRYPOINT", "Reserved FML entrypoint class " + name, null);
        Class<?> type = Class.forName(name, false, loader);
        var source = type.getProtectionDomain().getCodeSource();
        Path path = source == null || source.getLocation() == null ? null : Path.of(source.getLocation().toURI()).toRealPath();
        if (type.getClassLoader() != loader || path == null || !path.equals(mod.jar().toRealPath()))
            throw error(mod, "construct", "ENTRYPOINT_SOURCE_MISMATCH", name + " resolves outside its owning mod JAR/classloader", null);
        if (!Modifier.isPublic(type.getModifiers()) || Modifier.isAbstract(type.getModifiers())) throw error(mod, "construct", "UNSUPPORTED_MOD_CONSTRUCTOR", "Non-public or abstract FML entrypoint " + name, null);
        return type;
    }
    private static Class<?>[] argumentTypes(String descriptor, ClassLoader loader) throws ClassNotFoundException {
        Type[] types = Type.getArgumentTypes(descriptor); Class<?>[] result = new Class<?>[types.length];
        for (int i = 0; i < types.length; i++) result[i] = Class.forName(types[i].getClassName(), false, loader);
        return result;
    }
    private static Object[] arguments(Slot slot, Class<?>[] parameters) {
        Object[] values = new Object[parameters.length];
        for (int i = 0; i < parameters.length; i++) {
            if (parameters[i] == net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.class) values[i] = net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get();
            else if (parameters[i] == net.neoforged.bus.api.IEventBus.class) values[i] = slot.bus;
            else if (parameters[i] == net.neoforged.fml.ModContainer.class || parameters[i] == net.neoforged.fml.javafmlmod.FMLModContainer.class) values[i] = slot.container;
            else if (parameters[i] == net.neoforged.api.distmarker.Dist.class) values[i] = net.neoforged.api.distmarker.Dist.CLIENT;
            else throw new IllegalStateException("Constructor argument bypassed FML preflight: " + parameters[i]);
        }
        return values;
    }
    public synchronized void dispatchCommonSetup() throws Exception { dispatch(Phase.CONSTRUCT, Phase.COMMON); }
    public synchronized void dispatchClientSetup() throws Exception { dispatch(Phase.COMMON, Phase.CLIENT); }
    public synchronized void dispatchLoadComplete() throws Exception { dispatch(Phase.CLIENT, Phase.COMPLETE); }
    private void dispatch(Phase required, Phase next) throws Exception {
        usable();
        if (dispatching) throw new LoaderException(new Diagnostic("FML_LIFECYCLE_REENTRANT", "A lifecycle barrier cannot be invoked from a listener or deferred task", null, "fml-lifecycle", null));
        if (phase.ordinal() >= next.ordinal()) return;
        if (phase != required) throw new LoaderException(new Diagnostic("FML_LIFECYCLE_ORDER", "Expected " + required + " before " + next, null, "fml-lifecycle", null));
        if (!slots.keySet().equals(expected.keySet())) throw new LoaderException(new Diagnostic("FML_UNCONSTRUCTED_MOD", "All FML constructors must finish before common setup; missing " + expected.keySet().stream().filter(id -> !slots.containsKey(id)).toList(), null, "fml-lifecycle", null));
        phase = next; // Claim before callbacks. A lifecycle cannot be recursively posted or retried on failure.
        tasks.begin();
        dispatching = true;
        Slot current = null;
        try {
            for (Slot slot : slots.values()) {
                current = slot;
                try (AutoCloseable ignored = FmlBindings.enter(slot.container)) {
                    if (slot.metadata.platform() == Platform.FORGE) dispatchForge(slot, next);
                    else dispatchNeo(slot, next);
                    trace.add(slot.metadata.id() + ":" + next.name().toLowerCase(java.util.Locale.ROOT));
                }
            }
            // Work executes only after every listener for this phase, with its own mod context and the shared loader.
            tasks.drain();
            trace.add("deferred:" + next.name().toLowerCase(java.util.Locale.ROOT));
        } catch (Throwable thrown) {
            Throwable cause = unwrap(thrown);
            if (thrown instanceof DeferredTasks.Failure deferred) {
                cause = deferred.getCause();
                for (Slot slot : slots.values()) if (slot.container == deferred.mod) { current = slot; break; }
            }
            tasks.abort(cause);
            failure = thrown instanceof LoaderException known ? known : error(current == null ? null : current.metadata, next.name().toLowerCase(java.util.Locale.ROOT), "FML_LIFECYCLE_FAILED", detail(cause), cause);
            throw failure;
        } finally { dispatching = false; }
    }
    private static void dispatchForge(Slot slot, Phase phase) {
        var container = (net.minecraftforge.fml.ModContainer) slot.container;
        var group = (net.minecraftforge.eventbus.api.bus.BusGroup) slot.bus;
        switch (phase) {
            case COMMON -> net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent.getBus(group).post(new net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent(container, net.minecraftforge.fml.ModLoadingStage.COMMON_SETUP));
            case CLIENT -> net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent.getBus(group).post(new net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent(container, net.minecraftforge.fml.ModLoadingStage.SIDED_SETUP));
            case COMPLETE -> net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent.getBus(group).post(new net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent(container, net.minecraftforge.fml.ModLoadingStage.COMPLETE));
            default -> throw new IllegalStateException("No dispatch event for " + phase);
        }
    }
    private static void dispatchNeo(Slot slot, Phase phase) {
        var container = (net.neoforged.fml.ModContainer) slot.container;
        var bus = (net.neoforged.bus.api.IEventBus) slot.bus;
        var queue = new net.neoforged.fml.DeferredWorkQueue();
        switch (phase) {
            case COMMON -> bus.post(new net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent(container, queue));
            case CLIENT -> bus.post(new net.neoforged.fml.event.lifecycle.FMLClientSetupEvent(container, queue));
            case COMPLETE -> bus.post(new net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent(container, queue));
            default -> throw new IllegalStateException("No dispatch event for " + phase);
        }
    }
    public synchronized List<String> trace() { return List.copyOf(trace); }
    @Override public synchronized void close() {
        if (Thread.currentThread() != owner) throw new IllegalStateException("FML runtime must be closed on its owner thread");
        if (closed) return;
        if (dispatching) throw new IllegalStateException("Cannot close the FML runtime during its lifecycle dispatch");
        closed = true;
        tasks.abort(new IllegalStateException("FML runtime closed"));
        for (Slot slot : slots.values()) { FmlBindings.unbind(slot.container); dispose(slot.bus); }
        slots.clear(); attempts.clear();
    }
    private static void dispose(Object bus) {
        if (bus instanceof net.minecraftforge.eventbus.api.bus.BusGroup group) group.dispose();
        else FmlEventBuses.disposeNeo((net.neoforged.bus.api.IEventBus) bus);
    }
    private static Throwable unwrap(Throwable thrown) { return thrown instanceof InvocationTargetException invocation && invocation.getCause() != null ? invocation.getCause() : thrown; }
    private static String detail(Throwable thrown) { return thrown.getClass().getName() + (thrown.getMessage() == null ? "" : ": " + thrown.getMessage()); }
    private static LoaderException error(ModMetadata mod, String phase, String code, String message, Throwable cause) { return new LoaderException(new Diagnostic(code, message, mod == null ? null : mod.id(), phase, mod == null ? null : mod.jar()), cause); }
}
