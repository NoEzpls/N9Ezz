package dev.n9ezz.loader.core;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.compat.CompatibilityDispatcher;
import dev.n9ezz.loader.discovery.NestedJarResolver;
import dev.n9ezz.loader.fabric.FabricMappingResolver;
import dev.n9ezz.loader.fabric.FabricRuntime;
import dev.n9ezz.loader.fabric.GameInitializationHook;
import dev.n9ezz.loader.fabric.SelectedFabricApi;
import dev.n9ezz.loader.fml.FmlCompatibilityRuntime;
import dev.n9ezz.loader.quilt.QuiltGameContract;
import dev.n9ezz.loader.quilt.QuiltRuntime;
import dev.n9ezz.loader.mapping.AccessWidenerSet;
import dev.n9ezz.loader.mapping.GameMappings;
import dev.n9ezz.loader.metadata.MetadataException;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import dev.n9ezz.loader.mixin.MixinRuntime;
import dev.n9ezz.loader.resources.ModResourcePacks;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.jar.JarFile;

/** Pinned game and explicit platform API contracts inside the own common runtime. */
final class GameRuntimeBootstrap {
    private GameRuntimeBootstrap() {}

    static RuntimeSession prepare(Path gameDir, Path modsDir, Path originalGame,
            List<Path> vanillaLibraries, EventBus events, boolean verifyOnly) {
        List<String> trace = new CopyOnWriteArrayList<>();
        List<AutoCloseable> resources = new ArrayList<>();
        List<Diagnostic> diagnostics = new CopyOnWriteArrayList<>();
        UnifiedClassLoader loader = null;
        ClassLoader prior = Thread.currentThread().getContextClassLoader();
        String step = "discovery";
        try {
            if (Runtime.version().feature() != 21) throw new LoaderException(new Diagnostic("JAVA_VERSION", "The pinned game runtime requires Java 21"));
            Path game = gameDir.toAbsolutePath().normalize();
            Path mods = modsDir.toAbsolutePath().normalize();
            Files.createDirectories(game); Files.createDirectories(mods);
            List<NestedJarResolver.Source> external = new ArrayList<>();
            try (var paths = Files.list(mods)) {
                for (Path jar : paths.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")).sorted().toList()) {
                    ExternalModPolicy.validate(jar);
                    external.add(new NestedJarResolver.Source(jar));
                }
            }
            for (Path library : vanillaLibraries) ExternalModPolicy.validateLibrary(library);
            // The exceptions below come only from packaged, hash-verified resources.
            // Copying a built-in ID/JAR into mods does not grant it this provenance.
            BuiltinModSource client = BuiltinModSource.embeddedClient();
            var identity = client.describe();
            Path clientJar = client.materialize(game);
            var api = SelectedFabricApi.resolve(game.resolve(".n9ezz/fabric-api"));
            List<NestedJarResolver.Source> sources = new ArrayList<>();
            sources.add(new NestedJarResolver.Source(clientJar, "builtin:" + identity.id(), identity.sha256(), null));
            sources.add(new NestedJarResolver.Source(api.umbrella(), "builtin:fabric-api-selected", api.sha256(), null));
            sources.addAll(external);
            var discovery = NestedJarResolver.discover(game, sources);
            var bundled = discovery.mods().stream().filter(mod -> mod.jar().equals(clientJar)).toList();
            if (bundled.size() != 1 || !bundled.getFirst().id().equals(identity.id()) || !bundled.getFirst().version().equals(identity.version()))
                throw new LoaderException(new Diagnostic("BUILTIN_METADATA_MISMATCH", "Packaged client metadata does not match the pinned identity"));
            RuntimeBootstrap.publish(events, trace, LifecycleEvent.DISCOVERED);
            step = "resolve";
            List<ModMetadata> ordered = DependencyResolver.resolveUniversalGame(discovery.mods(), diagnostics::add);
            validateFeatures(ordered);
            // Preflight the complete FML cohort before a single user constructor can run.
            FmlCompatibilityRuntime fml = new FmlCompatibilityRuntime(ordered);
            resources.add(fml);
            for (ModMetadata mod : ordered) if (mod.platform() == Platform.QUILT) QuiltGameContract.validate(mod);
            RuntimeBootstrap.publish(events, trace, LifecycleEvent.RESOLVED);
            step = "mapping";
            Path mappedGame = GameMappings.prepare(originalGame, game, vanillaLibraries);
            trace.add("MAPPING:official->intermediary:" + GameMappings.MAPPINGS_SHA256);
            step = "access";
            var wideners = AccessWidenerSet.fromJars(discovery.classpath(), "intermediary");
            List<Path> targets = new ArrayList<>(discovery.classpath()); targets.add(mappedGame);
            wideners.validateTargets(targets);
            TransformationPipeline pipeline = new TransformationPipeline();
            wideners.register(pipeline);
            var resourcePacks = ModResourcePacks.prepare(game, ordered);
            resources.add(resourcePacks);
            resourcePacks.register(pipeline);
            trace.add("RESOURCE_PACKS:" + resourcePacks.packs().size());
            pipeline.register(TransformationPipeline.Stage.CORE, 0, "n9ezz:game-initializers", GameInitializationHook::transform);
            MixinRuntime mixin = new MixinRuntime();
            resources.add(mixin);
            mixin.register(pipeline);
            pipeline.freeze();
            Set<Path> verifiedApi = new HashSet<>();
            for (Path jar : discovery.classpath()) if (SelectedFabricApi.isVerifiedModule(jar)) verifiedApi.add(jar.toRealPath());
            step = "class-index";
            loader = new UnifiedClassLoader(discovery.classpath(), mappedGame, GameRuntimeBootstrap.class.getClassLoader(), pipeline,
                    new UnifiedClassLoader.GameIntegration(verifiedApi, clientJar));
            RuntimeBootstrap.validateEntrypointSources(ordered, loader);
            var configs = configurations(ordered, loader);
            UnifiedClassLoader shared = loader;
            CompatibilityDispatcher dispatcher = new CompatibilityDispatcher(verifiedApi, fml);
            AtomicBoolean prepared = new AtomicBoolean();
            var mappings = new FabricMappingResolver(GameMappings.index(), "intermediary");
            resources.add(QuiltRuntime.install(game, ordered, shared, mappings));
            var services = FabricRuntime.install(game, ordered, mappings,
                    instance -> {
                        if (!prepared.get() || verifyOnly) throw new LoaderException(new Diagnostic("PREMATURE_GAME_INITIALIZATION", "Game initialization occurred before transformation preparation completed or during verify-only"));
                        QuiltRuntime.bindGame(instance);
                        initialize(ordered, shared, game, events, trace, dispatcher, fml);
                    });
            resources.add(services);
            shared.setGeneratedClassProvider(mixin::generate);
            Thread.currentThread().setContextClassLoader(shared);
            step = "mixin";
            mixin.initialize(new MixinRuntime.Host() {
                @Override public byte[] classBytes(String name, boolean transformed) throws IOException, ClassNotFoundException { return shared.classBytes(name, transformed); }
                @Override public Class<?> findClass(String name, boolean initialize) throws ClassNotFoundException { return Class.forName(name, initialize, shared); }
                @Override public InputStream resource(String path) { return shared.getResourceAsStream(path); }
                @Override public boolean isClassLoaded(String name) { return shared.isClassLoaded(name); }
                @Override public void registerInvalidClass(String name) { shared.registerInvalidClass(name); }
                @Override public URL[] classPath() { return shared.classPath(); }
            }, configs, MixinRuntime.Side.CLIENT);
            trace.addAll(pipeline.order());
            trace.add("MIXIN_SERVICE:" + mixin.serviceName());
            prepared.set(true);
            RuntimeBootstrap.publish(events, trace, LifecycleEvent.TRANSFORMERS_READY);
            trace.add(verifyOnly ? "VERIFY_ONLY_COMPLETE" : "AWAITING_GAME_CONSTRUCTOR");
            System.out.println("N9Ezz prepared " + ordered.size() + " mods, " + discovery.archives().size()
                    + " archives, " + configs.size() + " Mixin configurations and " + wideners.sources().size() + " access wideners.");
            return new RuntimeSession(shared, ordered, trace, diagnostics, resources);
        } catch (Exception | Error error) {
            if (loader != null) loader.close();
            for (AutoCloseable resource : resources.reversed()) try { resource.close(); } catch (Exception closeError) { error.addSuppressed(closeError); }
            failEvent(events, trace, error);
            if (error instanceof LoaderException failure) throw failure.withTrace(trace);
            if (error instanceof MetadataException failure) throw new LoaderException(List.of(new Diagnostic(failure.code(), failure.getMessage(), null, step, failure.jar())), error, trace);
            throw new LoaderException(List.of(new Diagnostic("BOOTSTRAP_FAILED", "Game preparation failed during " + step + ": " + error, null, step, null)), error, trace);
        } finally { Thread.currentThread().setContextClassLoader(prior); }
    }

    private static void initialize(List<ModMetadata> mods, UnifiedClassLoader loader, Path game,
            EventBus events, List<String> trace, CompatibilityDispatcher dispatcher, FmlCompatibilityRuntime fml) {
        try {
            for (String phase : List.of("common", "client")) {
                RuntimeBootstrap.publish(events, trace, phase.equals("common") ? LifecycleEvent.COMMON_SETUP : LifecycleEvent.CLIENT_SETUP);
                for (ModMetadata mod : mods) {
                    if (mod.entrypoints().stream().noneMatch(entry -> entry.phase().equals(phase))) continue;
                    trace.add("ENTRYPOINT:" + mod.id() + ":" + phase);
                    try { dispatcher.initialize(mod, phase, loader, new ModContext(mod.id(), game, events)); }
                    catch (LoaderException error) { throw error; }
                    catch (Exception | Error error) { throw new LoaderException(new Diagnostic("ENTRYPOINT_FAILED", "Initialization failed: " + error, mod.id(), phase, mod.jar()), error); }
                }
                // All constructors/listeners finish before phase-wide FIFO deferred work.
                // The shared game thread replaces the incompatible platform executors.
                if (phase.equals("common")) fml.dispatchCommonSetup();
                else fml.dispatchClientSetup();
            }
            fml.dispatchLoadComplete();
            trace.addAll(fml.trace());
            RuntimeBootstrap.publish(events, trace, LifecycleEvent.READY);
            System.out.println("N9Ezz lifecycle: " + String.join(" -> ", trace));
        } catch (Exception | Error error) {
            failEvent(events, trace, error);
            if (error instanceof LoaderException failure) throw failure.withTrace(trace);
            throw new LoaderException(List.of(new Diagnostic("INITIALIZATION_FAILED", error.toString())), error, trace);
        }
    }

    private static List<MixinRuntime.Configuration> configurations(List<ModMetadata> mods, UnifiedClassLoader loader) throws IOException {
        List<MixinRuntime.Configuration> configs = new ArrayList<>();
        Set<String> names = new HashSet<>();
        for (ModMetadata mod : mods) for (String resource : mod.mixins()) {
            if (!names.add(resource)) throw new LoaderException(new Diagnostic("MIXIN_CONFIG_COLLISION", "Mixin resource declared more than once: " + resource, mod.id(), "mixin", mod.jar()));
            try (JarFile jar = new JarFile(mod.jar().toFile(), true)) {
                if (jar.getJarEntry(resource) == null) throw new LoaderException(new Diagnostic("MIXIN_CONFIG_MISSING", "Declared configuration absent from owning mod: " + resource, mod.id(), "mixin", mod.jar()));
            }
            URL expected = new URL("jar:" + mod.jar().toRealPath().toUri().toURL().toExternalForm() + "!/" + resource);
            List<URL> found = java.util.Collections.list(loader.getResources(resource));
            if (found.size() != 1 || !found.getFirst().equals(expected)) throw new LoaderException(new Diagnostic("MIXIN_CONFIG_WRONG_SOURCE", "Mixin configuration has ambiguous or wrong resource ownership: " + resource, mod.id(), "mixin", mod.jar()));
            configs.add(new MixinRuntime.Configuration(mod.id(), resource));
        }
        return List.copyOf(configs);
    }

    private static void validateFeatures(List<ModMetadata> mods) {
        List<Diagnostic> diagnostics = new ArrayList<>();
        for (ModMetadata mod : mods) {
            try { GameCompatibilityPolicy.validate(mod); }
            catch (LoaderException failure) { diagnostics.addAll(failure.diagnostics()); }
        }
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
    }
    private static void failEvent(EventBus events, List<String> trace, Throwable error) {
        trace.add(LifecycleEvent.FAILED.name());
        try { events.publish(LifecycleEvent.FAILED); } catch (Exception | Error handlerError) { if (handlerError != error) error.addSuppressed(handlerError); }
    }
}
