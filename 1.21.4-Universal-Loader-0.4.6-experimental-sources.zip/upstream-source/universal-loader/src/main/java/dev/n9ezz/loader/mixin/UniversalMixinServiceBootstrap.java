package dev.n9ezz.loader.mixin;

import org.spongepowered.asm.service.IMixinServiceBootstrap;

/** Selects N9Ezz's host; it never starts Knot, LaunchWrapper, FML or ModLauncher. */
public final class UniversalMixinServiceBootstrap implements IMixinServiceBootstrap {
    @Override public String getName() { return "N9Ezz Universal"; }
    @Override public String getServiceClassName() { return UniversalMixinService.class.getName(); }
    @Override public void bootstrap() { MixinRuntime.active(); }
}
