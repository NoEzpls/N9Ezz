package dev.n9ezz.loader.launch;

import com.google.gson.GsonBuilder;
import dev.n9ezz.loader.core.BuiltinModSource;
import dev.n9ezz.loader.core.EventBus;
import dev.n9ezz.loader.core.LocalDiagnostics;
import dev.n9ezz.loader.core.RuntimeBootstrap;
import java.awt.GraphicsEnvironment;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** One executable JAR: installer, diagnostics, native smoke demonstration. */
public final class Main {
    public static final String VERSION = "0.4.1-experimental";

    private Main() { }

    public static void main(String[] args) {
        LocalDiagnostics.observeArguments(args);
        try {
            if (args.length == 0) {
                if (GraphicsEnvironment.isHeadless()) {
                    usage();
                    throw new IllegalStateException("Headless environment: choose a CLI operation.");
                }
                InstallerWindow.open();
                return;
            }
            String operation = args[0];
            Map<String, String> options = options(args);
            switch (operation) {
                case "--help" -> usage();
                case "--version" -> System.out.println("N9Ezz Universal Loader " + VERSION + " / Java " + Runtime.version().feature());
                case "--self-test" -> selfTest();
                case "--install" -> {
                    Path root = requiredPath(options, "--game-dir");
                    System.out.println(new GsonBuilder().setPrettyPrinting().create().toJson(
                            InstallService.install(root, ownJar())));
                }
                case "--run", "--verify", "--verify-bundled" -> {
                    Path game = requiredPath(options, "--game-dir");
                    Path mods = options.containsKey("--mods-dir") ? Path.of(options.get("--mods-dir")) : game.resolve("mods");
                    boolean bundled = operation.equals("--verify-bundled");
                    try (var session = bundled
                            ? RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(BuiltinModSource.embeddedClient()), new EventBus(), true)
                            : RuntimeBootstrap.run(game, mods, List.of(), new EventBus(), operation.equals("--verify"))) {
                        Map<String, Object> report = new LinkedHashMap<>();
                        report.put("mode", bundled ? "verify-builtin-no-entrypoints" : operation.equals("--verify") ? "verify-no-entrypoints" : "api-only-runtime");
                        report.put("mods", session.mods().stream().map(m -> m.id() + "@" + m.version()).toList());
                        report.put("lifecycle", session.lifecycleTrace());
                        report.put("diagnostics", session.diagnostics());
                        System.out.println(new GsonBuilder().setPrettyPrinting().create().toJson(report));
                    }
                }
                default -> throw new IllegalArgumentException("Unknown operation: " + operation);
            }
        } catch (Exception | LinkageError error) {
            System.err.println(LocalDiagnostics.redact("N9Ezz operation failed: " + error.getMessage()));
            LocalDiagnostics.printThrowable(error, System.err);
            System.exit(1);
        }
    }

    private static Map<String, String> options(String[] args) {
        Map<String, String> result = new LinkedHashMap<>();
        for (int index = 1; index < args.length; index++) {
            String key = args[index];
            if (!List.of("--game-dir", "--mods-dir").contains(key) || index + 1 == args.length || args[index + 1].startsWith("--")) {
                throw new IllegalArgumentException("Unsupported option or missing value: " + key);
            }
            if (result.putIfAbsent(key, args[++index]) != null) {
                throw new IllegalArgumentException("Duplicate option: " + key);
            }
        }
        return result;
    }

    private static Path requiredPath(Map<String, String> options, String key) {
        if (!options.containsKey(key)) throw new IllegalArgumentException("Required: " + key);
        return Path.of(options.get(key)).toAbsolutePath().normalize();
    }

    static Path ownJar() throws Exception {
        Path path = Path.of(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        if (!Files.isRegularFile(path) || !path.toString().endsWith(".jar")) {
            throw new IllegalStateException("Run the packaged installer JAR, not loose classes.");
        }
        return path;
    }

    private static void selfTest() throws Exception {
        Path directory = Files.createTempDirectory("n9ezz-native-smoke-");
        try {
            Path mods = Files.createDirectories(directory.resolve("mods"));
            System.clearProperty("n9ezz.smoke.initialized");
            System.clearProperty("n9ezz.smoke.ready");
            var smokeSource = BuiltinModSource.resource(Main.class.getClassLoader(), "examples/native-smoke-mod.json");
            try (var session = RuntimeBootstrap.runBuiltins(directory, mods, List.of(), List.of(smokeSource), new EventBus(), false)) {
                if (session.mods().size() != 1 || !"n9ezz_smoke".equals(System.getProperty("n9ezz.smoke.initialized"))
                        || !"true".equals(System.getProperty("n9ezz.smoke.ready"))) {
                    throw new IllegalStateException("Native entrypoint or READY callback did not execute.");
                }
                try (var modFiles = Files.list(mods)) {
                    if (modFiles.findAny().isPresent()) throw new IllegalStateException("Builtin smoke mod must not be installed into mods.");
                }
                System.out.println("PASS packaged builtin native JAR bootstrap: " + session.lifecycleTrace());
                System.out.println("Minecraft launch and upstream game APIs were not tested by this command.");
            }
        } finally {
            List<Path> paths;
            try (var stream = Files.walk(directory)) {
                paths = new ArrayList<>(stream.sorted(Comparator.reverseOrder()).toList());
            }
            for (Path path : paths) Files.deleteIfExists(path);
        }
    }

    private static void usage() {
        System.out.println("""
                N9Ezz Universal Loader 0.4.1-experimental — Java 21
                --self-test                       Load the packaged native test mod
                --run --game-dir DIR [--mods-dir DIR]     API-only mod runtime, not Minecraft
                --verify --game-dir DIR [--mods-dir DIR]  Validate without running entrypoints
                --verify-bundled --game-dir DIR          Validate the automatically bundled N9Ezz client
                --install --game-dir MINECRAFT_HOME       Install one experimental launcher profile
                --version | --help
                Without arguments: graphical installer. No platform/engine selection.
                N9Ezz is bundled into the loader. The installed game profile uses shared Mixin,
                intermediary mappings and six pinned Fabric API modules. External mods require
                n9ezz.mod.json and native N9Ezz entrypoints. Ordinary Fabric, Quilt, Forge and
                NeoForge mods, dual descriptors and external nested JARs are rejected.
                """);
    }
}
