package dev.n9ezz.loader.core;

import dev.n9ezz.loader.metadata.ModMetadata;
import java.util.List;

/** Owns the one shared mod classloader. Closing prevents future definitions, not already-running mod work. */
public final class RuntimeSession implements AutoCloseable {
    private final UnifiedClassLoader classLoader;
    private final List<ModMetadata> mods;
    private final List<String> lifecycleTrace;
    private final List<Diagnostic> diagnostics;
    private final List<AutoCloseable> resources;
    private boolean closed;
    RuntimeSession(UnifiedClassLoader classLoader, List<ModMetadata> mods, List<String> trace, List<Diagnostic> diagnostics) {
        this(classLoader, mods, List.copyOf(trace), diagnostics, List.of());
    }
    RuntimeSession(UnifiedClassLoader classLoader, List<ModMetadata> mods, List<String> trace,
            List<Diagnostic> diagnostics, List<AutoCloseable> resources) {
        this.classLoader = classLoader;
        this.mods = List.copyOf(mods);
        this.lifecycleTrace = trace;
        this.diagnostics = List.copyOf(diagnostics);
        this.resources = List.copyOf(resources);
    }
    public UnifiedClassLoader classLoader() { return classLoader; }
    public List<ModMetadata> mods() { return mods; }
    public List<String> lifecycleTrace() { return List.copyOf(lifecycleTrace); }
    public List<Diagnostic> diagnostics() { return diagnostics; }
    @Override public synchronized void close() {
        if (closed) return;
        closed = true;
        classLoader.close();
        RuntimeException failure = null;
        for (AutoCloseable resource : resources.reversed()) try { resource.close(); }
        catch (Exception | Error error) {
            if (failure == null) failure = new IllegalStateException("Runtime resource cleanup failed", error);
            else failure.addSuppressed(error);
        }
        if (failure != null) throw failure;
    }
}
