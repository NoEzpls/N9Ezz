package dev.n9ezz.loader.launch;

import dev.n9ezz.loader.core.EventBus;
import dev.n9ezz.loader.core.LocalDiagnostics;
import dev.n9ezz.loader.core.RuntimeBootstrap;
import dev.n9ezz.loader.fabric.FabricRuntime;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.jar.JarFile;

/** Launches the prepared game in the common runtime with deferred game lifecycle hooks. */
public final class GameBootstrap {
    private GameBootstrap() { }

    public static void main(String[] args) {
        LocalDiagnostics.observeArguments(args);
        try {
            launch(args);
        } catch (Throwable error) {
            // Print a full, redacted fatal trace and preserve the failure exit
            // status. Rethrowing the raw exception would print secrets again.
            System.err.print(LocalDiagnostics.redact("Exception in thread \"" + Thread.currentThread().getName() + "\" "));
            LocalDiagnostics.printThrowable(error, System.err);
            System.exit(1);
        }
    }

    private static void launch(String[] args) throws Throwable {
        Path game = Path.of(".").toAbsolutePath().normalize();
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals("--gameDir")) game = Path.of(args[i + 1]).toAbsolutePath().normalize();
        }
        List<Path> gameJars = new ArrayList<>();
        LinkedHashSet<Path> libraries = new LinkedHashSet<>();
        Path installer = Path.of(GameBootstrap.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
        for (String element : System.getProperty("java.class.path").split(java.util.regex.Pattern.quote(java.io.File.pathSeparator))) {
            Path path = Path.of(element).toAbsolutePath().normalize();
            if (!Files.isRegularFile(path) || !element.endsWith(".jar")) continue;
            path = path.toRealPath();
            if (path.equals(installer)) continue;
            try (JarFile jar = new JarFile(path.toFile())) {
                if (jar.getJarEntry("net/minecraft/client/main/Main.class") != null) {
                    if (!gameJars.contains(path)) gameJars.add(path);
                } else libraries.add(path);
            }
        }
        if (gameJars.size() != 1) throw new IllegalStateException("Expected exactly one Minecraft client JAR on launcher classpath; found " + gameJars.size());
        System.out.println("N9Ezz common runtime " + Main.VERSION + ": preparing Minecraft 1.21.11 and its shared transformations.");
        ClassLoader prior = Thread.currentThread().getContextClassLoader();
        // Game remapping and transformation preparation precede class definition.
        // Game-linked entrypoints are dispatched by the Minecraft initialization hook.
        try (var session = RuntimeBootstrap.runBundledGame(game, game.resolve("mods"), gameJars.getFirst(), List.copyOf(libraries), new EventBus(), false)) {
            Thread.currentThread().setContextClassLoader(session.classLoader());
            Class<?> main = Class.forName("net.minecraft.client.main.Main", false, session.classLoader());
            if (main.getClassLoader() != session.classLoader()) throw new IllegalStateException("Minecraft Main is not owned by the common runtime classloader");
            try {
                main.getMethod("main", String[].class).invoke(null, (Object) args);
            } catch (InvocationTargetException error) {
                throw error.getCause();
            }
            if (!FabricRuntime.initializationCompleted()) throw new IllegalStateException("Minecraft Main returned before the common/client initialization hook completed");
        } finally {
            Thread.currentThread().setContextClassLoader(prior);
        }
    }
}
