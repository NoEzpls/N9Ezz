package dev.n9ezz.loader.mixin;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collection;
import java.util.List;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.launch.platform.container.ContainerHandleVirtual;
import org.spongepowered.asm.launch.platform.container.IContainerHandle;
import org.spongepowered.asm.logging.ILogger;
import org.spongepowered.asm.logging.LoggerAdapterConsole;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.transformer.IMixinTransformerFactory;
import org.spongepowered.asm.service.IAdviceProvider;
import org.spongepowered.asm.service.IClassBytecodeProvider;
import org.spongepowered.asm.service.IClassProvider;
import org.spongepowered.asm.service.IClassTracker;
import org.spongepowered.asm.service.IFeatureValidator;
import org.spongepowered.asm.service.IMixinAuditTrail;
import org.spongepowered.asm.service.IMixinInternal;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.ITransformer;
import org.spongepowered.asm.service.ITransformerProvider;
import org.spongepowered.asm.util.ReEntranceLock;

/** Bytecode and class access exclusively through the common runtime's host. */
public final class UniversalMixinService implements IMixinService, IClassProvider, IClassBytecodeProvider, IClassTracker, ITransformerProvider {
    private final ReEntranceLock lock = new ReEntranceLock(1);
    private MixinRuntime runtime() { return MixinRuntime.active(); }
    @Override public String getName() { return "N9Ezz Universal"; }
    @Override public boolean isValid() { return MixinRuntime.hasHost(); }
    @Override public void prepare() { }
    @Override public MixinEnvironment.Phase getInitialPhase() { return MixinEnvironment.Phase.PREINIT; }
    @Override public void offer(IMixinInternal internal) { if (internal instanceof IMixinTransformerFactory factory) runtime().offerTransformer(factory.createTransformer()); }
    @Override public void init() { }
    @Override public void beginPhase() { }
    @Override public void checkEnv(Object bootSource) { }
    @Override public ReEntranceLock getReEntranceLock() { return lock; }
    @Override public IClassProvider getClassProvider() { return this; }
    @Override public IClassBytecodeProvider getBytecodeProvider() { return this; }
    @Override public ITransformerProvider getTransformerProvider() { return this; }
    @Override public IClassTracker getClassTracker() { return this; }
    @Override public IFeatureValidator getFeatureValidator() { return IFeatureValidator.ALLOW_ALL; }
    @Override public IAdviceProvider getAdviceProvider() { return IAdviceProvider.GENERIC; }
    @Override public IMixinAuditTrail getAuditTrail() {
        return new IMixinAuditTrail() {
            @Override public void onApply(String target, String mixin) { runtime().record("apply:" + target + ":" + mixin); }
            @Override public void onPostProcess(String target) { runtime().record("postprocess:" + target); }
            @Override public void onGenerate(String target, String generator) { runtime().record("generate:" + target + ":" + generator); }
        };
    }
    @Override public Collection<String> getPlatformAgents() { return List.of("org.spongepowered.asm.launch.platform.MixinPlatformAgentDefault"); }
    @Override public IContainerHandle getPrimaryContainer() { return new ContainerHandleVirtual("N9Ezz common runtime"); }
    @Override public Collection<IContainerHandle> getMixinContainers() { return List.of(); }
    @Override public InputStream getResourceAsStream(String name) { return runtime().host().resource(name); }
    @Override public String getSideName() { return runtime().sideName(); }
    @Override public MixinEnvironment.CompatibilityLevel getMinCompatibilityLevel() { return MixinEnvironment.CompatibilityLevel.JAVA_8; }
    @Override public MixinEnvironment.CompatibilityLevel getMaxCompatibilityLevel() { return MixinEnvironment.CompatibilityLevel.JAVA_21; }
    @Override public ILogger getLogger(String name) { return new LoggerAdapterConsole(name); }
    @Override public URL[] getClassPath() { return runtime().host().classPath(); }
    @Override public Class<?> findClass(String name) throws ClassNotFoundException { return findClass(name, false); }
    @Override public Class<?> findClass(String name, boolean initialize) throws ClassNotFoundException { return runtime().host().findClass(name, initialize); }
    @Override public Class<?> findAgentClass(String name, boolean initialize) throws ClassNotFoundException { return Class.forName(name, initialize, UniversalMixinService.class.getClassLoader()); }
    @Override public ClassNode getClassNode(String name) throws IOException, ClassNotFoundException { return getClassNode(name, true); }
    @Override public ClassNode getClassNode(String name, boolean runTransformers) throws IOException, ClassNotFoundException { return getClassNode(name, runTransformers, 0); }
    @Override public ClassNode getClassNode(String name, boolean runTransformers, int flags) throws IOException, ClassNotFoundException {
        byte[] bytes = runtime().host().classBytes(name.replace('/', '.'), runTransformers);
        if (bytes == null) throw new ClassNotFoundException(name);
        ClassNode node = new ClassNode(); new ClassReader(bytes).accept(node, flags); return node;
    }
    @Override public void registerInvalidClass(String name) { runtime().host().registerInvalidClass(name.replace('/', '.')); }
    @Override public boolean isClassLoaded(String name) { return runtime().host().isClassLoaded(name.replace('/', '.')); }
    @Override public String getClassRestrictions(String name) { return ""; }
    @Override public Collection<ITransformer> getTransformers() { return List.of(); }
    @Override public Collection<ITransformer> getDelegatedTransformers() { return List.of(); }
    @Override public void addTransformerExclusion(String name) { }
}
