package dev.n9ezz.loader.core;

import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.RecordComponentVisitor;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.AnalyzerException;
import org.objectweb.asm.tree.analysis.BasicVerifier;
import org.objectweb.asm.util.CheckClassAdapter;

/** Real ASM parsing and structural checks, independent of unavailable game classes. */
final class BytecodeValidator {
    private BytecodeValidator() {}

    static void validate(String name, byte[] bytes) {
        try {
            ClassReader reader = new ClassReader(bytes);
            if (!reader.getClassName().replace('/', '.').equals(name)) throw new IllegalArgumentException("Class name differs from its Jar entry");
            int version = reader.readUnsignedShort(6);
            if (version > Opcodes.V21) throw new IllegalArgumentException("Class requires a newer Java runtime than Java 21: major " + version);
            if (reader.readUnsignedShort(4) == 65535) throw new IllegalArgumentException("Preview class files require an unsupported --enable-preview runtime");
            reader.accept(new CheckClassAdapter(new ClassWriter(0), false), 0);
            ClassNode node = new ClassNode(Opcodes.ASM9);
            reader.accept(node, 0);
            for (MethodNode method : node.methods) {
                if ((method.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) == 0) {
                    new Analyzer<>(new BasicVerifier()).analyze(node.name, method);
                }
            }
        } catch (RuntimeException | AnalyzerException error) {
            throw new LoaderException(new Diagnostic("INVALID_BYTECODE", "Class '" + name + "' failed ASM structural validation: " + error.getMessage()), error);
        }
    }

    static List<String> unsupportedReferences(byte[] bytes) {
        List<String> references = new ArrayList<>();
        new ClassReader(bytes).accept(new ReferenceVisitor(references), 0);
        return references.stream().distinct().sorted().toList();
    }

    private static final class ReferenceVisitor extends ClassVisitor {
        private final List<String> references;
        private ReferenceVisitor(List<String> references) { super(Opcodes.ASM9); this.references = references; }
        private void check(String value) {
            if (value == null) return;
            if (value.contains("net/minecraft/")) references.add("Minecraft:" + value);
            for (String prefix : List.of("net/fabricmc/loader/impl/", "org/quiltmc/loader/impl/", "net/minecraftforge/fml/loading/", "net/neoforged/fml/loading/", "cpw/mods/modlauncher/")) {
                if (value.contains(prefix)) references.add("Engine internals:" + value);
            }
        }
        private void constant(Object value) {
            if (value instanceof Type type) check(type.getDescriptor());
            else if (value instanceof Handle handle) { check(handle.getOwner()); check(handle.getDesc()); }
            else if (value instanceof ConstantDynamic dynamic) {
                check(dynamic.getDescriptor()); constant(dynamic.getBootstrapMethod());
                for (int i = 0; i < dynamic.getBootstrapMethodArgumentCount(); i++) constant(dynamic.getBootstrapMethodArgument(i));
            }
        }
        private AnnotationVisitor annotation(String descriptor) {
            check(descriptor);
            return new AnnotationVisitor(Opcodes.ASM9) {
                @Override public void visit(String name, Object value) { constant(value); }
                @Override public void visitEnum(String name, String descriptor, String value) { check(descriptor); }
                @Override public AnnotationVisitor visitAnnotation(String name, String descriptor) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitArray(String name) { return annotation(null); }
            };
        }
        @Override public void visit(int version, int access, String name, String signature, String parent, String[] interfaces) {
            check(name); check(signature); check(parent); if (interfaces != null) for (String type : interfaces) check(type);
        }
        @Override public void visitOuterClass(String owner, String name, String descriptor) { check(owner); check(descriptor); }
        @Override public void visitNestHost(String nestHost) { check(nestHost); }
        @Override public void visitNestMember(String nestMember) { check(nestMember); }
        @Override public void visitPermittedSubclass(String subclass) { check(subclass); }
        @Override public void visitInnerClass(String name, String outerName, String innerName, int access) { check(name); check(outerName); }
        @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
        @Override public AnnotationVisitor visitTypeAnnotation(int ref, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
        @Override public RecordComponentVisitor visitRecordComponent(String name, String descriptor, String signature) {
            check(descriptor); check(signature);
            return new RecordComponentVisitor(Opcodes.ASM9) {
                @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTypeAnnotation(int ref, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
            };
        }
        @Override public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
            check(descriptor); check(signature); constant(value);
            return new FieldVisitor(Opcodes.ASM9) {
                @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTypeAnnotation(int ref, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
            };
        }
        @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            check(descriptor); check(signature); if (exceptions != null) for (String exception : exceptions) check(exception);
            return new MethodVisitor(Opcodes.ASM9) {
                @Override public AnnotationVisitor visitAnnotationDefault() { return annotation(null); }
                @Override public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTypeAnnotation(int ref, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitParameterAnnotation(int parameter, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitInsnAnnotation(int ref, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitTryCatchAnnotation(int ref, org.objectweb.asm.TypePath path, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public AnnotationVisitor visitLocalVariableAnnotation(int ref, org.objectweb.asm.TypePath path, org.objectweb.asm.Label[] start, org.objectweb.asm.Label[] end, int[] index, String descriptor, boolean visible) { return annotation(descriptor); }
                @Override public void visitTypeInsn(int opcode, String type) { check(type); }
                @Override public void visitFieldInsn(int opcode, String owner, String name, String descriptor) { check(owner); check(descriptor); }
                @Override public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) { check(owner); check(descriptor); }
                @Override public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrap, Object... arguments) {
                    check(descriptor); constant(bootstrap); for (Object argument : arguments) constant(argument);
                }
                @Override public void visitLdcInsn(Object value) { constant(value); }
                @Override public void visitMultiANewArrayInsn(String descriptor, int dimensions) { check(descriptor); }
                @Override public void visitTryCatchBlock(org.objectweb.asm.Label start, org.objectweb.asm.Label end, org.objectweb.asm.Label handler, String type) { check(type); }
                @Override public void visitLocalVariable(String name, String descriptor, String signature, org.objectweb.asm.Label start, org.objectweb.asm.Label end, int index) { check(descriptor); check(signature); }
                @Override public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {
                    if (local != null) for (int i = 0; i < nLocal; i++) if (local[i] instanceof String value) check(value);
                    if (stack != null) for (int i = 0; i < nStack; i++) if (stack[i] instanceof String value) check(value);
                }
            };
        }
    }
}
