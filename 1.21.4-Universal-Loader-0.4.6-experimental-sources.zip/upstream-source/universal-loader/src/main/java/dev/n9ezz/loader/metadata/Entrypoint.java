package dev.n9ezz.loader.metadata;

import java.util.Objects;

public record Entrypoint(String phase, String className, String adapter) {
    public Entrypoint {
        Objects.requireNonNull(phase, "phase");
        Objects.requireNonNull(className, "className");
        Objects.requireNonNull(adapter, "adapter");
    }
}
