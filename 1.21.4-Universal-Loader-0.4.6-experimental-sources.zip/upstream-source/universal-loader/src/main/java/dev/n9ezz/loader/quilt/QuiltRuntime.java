package dev.n9ezz.loader.quilt;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.jar.JarFile;
import org.quiltmc.loader.api.MappingResolver;
import org.quiltmc.loader.api.ModContainer;

/** Own read-only Quilt services over the already resolved common runtime and its one classloader. */
public final class QuiltRuntime {
    public static final String VERIFIED_LOADER_ABI_VERSION = "0.30.1";
    public static final String GAME_VERSION = "1.21.11";
    private static volatile Service active;
    private QuiltRuntime() {}

    /** Services become visible atomically only after all archives and identities have been validated. */
    public static synchronized Registration install(Path gameDirectory, List<ModMetadata> mods,
            ClassLoader sharedLoader, net.fabricmc.loader.api.MappingResolver mappings) throws IOException {
        if (active != null) throw new IllegalStateException("A Quilt compatibility runtime is already active");
        Service service = new Service(gameDirectory.toRealPath(), List.copyOf(mods),
                Objects.requireNonNull(sharedLoader, "sharedLoader"), Objects.requireNonNull(mappings, "mappings"));
        active = service;
        return new Registration(service);
    }

    public static Service service() {
        Service service = active;
        if (service == null) throw new IllegalStateException("Quilt services require a prepared universal game runtime");
        return service;
    }

    /** Root calls this at the validated Minecraft constructor boundary before either mod phase. */
    public static void bindGame(Object game) {
        Service service = service();
        synchronized (service) {
            service.ensureOpen();
            if (service.game != null) throw new IllegalStateException("Quilt game instance was already bound");
            Object value = Objects.requireNonNull(game, "game");
            if (value.getClass().getClassLoader() != service.sharedLoader)
                throw new IllegalArgumentException("Game instance must use the universal classloader");
            service.game = value;
        }
    }

    /** Canonical object, including aliases; both QSL callbacks receive this exact container. */
    public static ModContainer container(ModMetadata mod) {
        Service service = service();
        service.ensureOpen();
        ArchiveContainer container = service.byId.get(Objects.requireNonNull(mod, "mod").id());
        Path source;
        try { source = mod.jar().toRealPath(); }
        catch (IOException failure) { throw new IllegalArgumentException("Cannot establish active mod archive: " + mod.id(), failure); }
        if (container == null || container.source == null || !container.source.equals(source))
            throw new IllegalArgumentException("Mod metadata is outside the active Quilt compatibility session: " + mod.id());
        if (!container.metadata().version().raw().equals(mod.version()))
            throw new IllegalArgumentException("Mod version differs from the active Quilt compatibility session: " + mod.id());
        return container;
    }

    public static final class Registration implements AutoCloseable {
        private final Service service;
        private Registration(Service service) { this.service = service; }
        @Override public void close() throws IOException {
            synchronized (QuiltRuntime.class) {
                if (active != service) return;
                synchronized (service) { service.closed = true; service.game = null; }
                active = null;
            }
            service.closeArchives();
        }
    }

    /** Exposed only to the ABI facade; every lookup is an immutable resolved view. */
    public static final class Service {
        private final Path gameDirectory, configDirectory, cacheDirectory;
        private final ClassLoader sharedLoader;
        private final MappingResolver mappings;
        private final Map<String, ArchiveContainer> byId;
        private final Map<Path, List<ArchiveContainer>> bySource;
        private final List<ModContainer> allMods;
        private final List<FileSystem> archives = new ArrayList<>();
        private volatile Object game;
        private volatile boolean closed;

        private Service(Path gameDirectory, List<ModMetadata> mods, ClassLoader sharedLoader,
                net.fabricmc.loader.api.MappingResolver mappings) throws IOException {
            this.gameDirectory = gameDirectory;
            this.configDirectory = gameDirectory.resolve("config");
            this.cacheDirectory = gameDirectory.resolve(".n9ezz/cache");
            this.sharedLoader = sharedLoader;
            this.mappings = new SharedMappings(mappings);
            if (!"intermediary".equals(mappings.getCurrentRuntimeNamespace()))
                throw new IOException("Quilt lifecycle contract requires intermediary runtime mappings");
            Files.createDirectories(configDirectory); Files.createDirectories(cacheDirectory);
            Map<String, ArchiveContainer> identities = new LinkedHashMap<>();
            Map<Path, List<ArchiveContainer>> sources = new LinkedHashMap<>();
            List<ModContainer> containers = new ArrayList<>();
            Map<Path, FileSystem> opened = new LinkedHashMap<>();
            try {
                for (ModMetadata mod : mods) {
                    Path path = mod.jar().toRealPath();
                    if (List.of("quilt_loader", "minecraft", "java").contains(mod.id()))
                        throw new IOException("Mod impersonates builtin identity " + mod.id());
                    FileSystem filesystem = opened.get(path);
                    if (filesystem == null) {
                        filesystem = FileSystems.newFileSystem(path, Map.of());
                        opened.put(path, filesystem); archives.add(filesystem);
                    }
                    ArchiveContainer container = new ArchiveContainer(identity(mod), filesystem.getPath("/"), path,
                            sourceType(mod.platform()), sharedLoader);
                    putIdentity(identities, mod.id(), container); containers.add(container);
                    sources.computeIfAbsent(path, ignored -> new ArrayList<>()).add(container);
                    for (String alias : mod.provides()) putIdentity(identities, alias, container);
                }
                builtin(identities, containers, "quilt_loader", VERIFIED_LOADER_ABI_VERSION,
                        "N9Ezz Quilt Loader ABI compatibility");
                builtin(identities, containers, "minecraft", GAME_VERSION, "Minecraft");
                builtin(identities, containers, "java", Integer.toString(Runtime.version().feature()), "Java");
                this.byId = Map.copyOf(identities);
                Map<Path, List<ArchiveContainer>> frozen = new LinkedHashMap<>();
                sources.forEach((path, values) -> frozen.put(path, List.copyOf(values)));
                this.bySource = Map.copyOf(frozen);
                this.allMods = List.copyOf(containers);
            } catch (Throwable failure) {
                try { closeArchives(); } catch (IOException closeFailure) { failure.addSuppressed(closeFailure); }
                throw failure;
            }
        }

        private void ensureOpen() { if (closed) throw new IllegalStateException("Quilt compatibility session is closed"); }
        public Optional<ModContainer> getModContainer(String id) { ensureOpen(); return Optional.ofNullable(byId.get(Objects.requireNonNull(id))); }
        public boolean isModLoaded(String id) { return getModContainer(id).isPresent(); }
        public Collection<ModContainer> getAllMods() { ensureOpen(); return allMods; }
        public Optional<ModContainer> getModContainer(Class<?> type) {
            ensureOpen(); Objects.requireNonNull(type, "type");
            if (type.getClassLoader() != sharedLoader) return Optional.empty();
            CodeSource code = type.getProtectionDomain().getCodeSource();
            if (code == null || code.getLocation() == null) return Optional.empty();
            try {
                List<ArchiveContainer> candidates = bySource.get(Path.of(code.getLocation().toURI()).toRealPath());
                // Multiple mod identities in one archive cannot prove which identity owns a class.
                return candidates == null || candidates.size() != 1 ? Optional.empty() : Optional.of(candidates.getFirst());
            } catch (java.net.URISyntaxException | IOException | IllegalArgumentException failure) { return Optional.empty(); }
        }
        public Path getGameDir() { ensureOpen(); return gameDirectory; }
        public Path getConfigDir() { ensureOpen(); return configDirectory; }
        public Path getCacheDir() { ensureOpen(); return cacheDirectory; }
        public String getRawGameVersion() { ensureOpen(); return GAME_VERSION; }
        public boolean isDevelopmentEnvironment() { ensureOpen(); return false; }
        public Object getGameInstance() { ensureOpen(); return game; }
        public MappingResolver getMappingResolver() { ensureOpen(); return mappings; }
        private void closeArchives() throws IOException {
            IOException failure = null;
            for (FileSystem archive : archives.reversed()) try { archive.close(); }
            catch (IOException exception) { if (failure == null) failure = exception; else failure.addSuppressed(exception); }
            if (failure != null) throw failure;
        }
    }

    private static void putIdentity(Map<String, ArchiveContainer> values, String id, ArchiveContainer container) throws IOException {
        if (values.putIfAbsent(id, container) != null) throw new IOException("Duplicate Quilt compatibility mod identity " + id);
    }
    private static void builtin(Map<String, ArchiveContainer> identities, List<ModContainer> all,
            String id, String version, String name) throws IOException {
        ArchiveContainer container = new ArchiveContainer(new Identity(id, "dev.n9ezz", version, name,
                "Own common-runtime compatibility service; not the stock Quilt loader engine"), null, null,
                ModContainer.BasicSourceType.BUILTIN, null);
        putIdentity(identities, id, container); all.add(container);
    }
    private static ModContainer.BasicSourceType sourceType(Platform platform) {
        return switch (platform) {
            case QUILT -> ModContainer.BasicSourceType.NORMAL_QUILT;
            case FABRIC -> ModContainer.BasicSourceType.NORMAL_FABRIC;
            default -> ModContainer.BasicSourceType.OTHER;
        };
    }
    private static Identity identity(ModMetadata mod) throws IOException {
        String group = "", name = mod.id(), description = "";
        try (JarFile archive = new JarFile(mod.jar().toFile())) {
            var entry = archive.getJarEntry(mod.platform() == Platform.QUILT ? "quilt.mod.json" : "fabric.mod.json");
            if (entry != null) try (var input = archive.getInputStream(entry)) {
                byte[] bytes = input.readNBytes(1024 * 1024 + 1);
                if (bytes.length > 1024 * 1024) throw new IOException("Compatibility metadata exceeds 1 MiB");
                JsonObject root = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject();
                if (mod.platform() == Platform.QUILT) {
                    root = root.getAsJsonObject("quilt_loader"); group = text(root, "group", "");
                    if (root.has("metadata")) root = root.getAsJsonObject("metadata");
                }
                name = text(root, "name", name); description = text(root, "description", description);
            } catch (RuntimeException malformed) { throw new IOException("Invalid read-only metadata for " + mod.id(), malformed); }
        }
        return new Identity(mod.id(), group, mod.version(), name, description);
    }
    private static String text(JsonObject value, String key, String fallback) {
        return value.has(key) ? value.get(key).getAsString() : fallback;
    }
    private record Identity(String id, String group, String rawVersion, String name, String description)
            implements org.quiltmc.loader.api.ModMetadata {
        @Override public org.quiltmc.loader.api.Version version() { return () -> rawVersion; }
    }
    private static final class ArchiveContainer implements ModContainer {
        private final Identity metadata;
        private final Path root, source;
        private final BasicSourceType sourceType;
        private final ClassLoader classLoader;
        private ArchiveContainer(Identity metadata, Path root, Path source, BasicSourceType sourceType, ClassLoader classLoader) {
            this.metadata = metadata; this.root = root; this.source = source;
            this.sourceType = sourceType; this.classLoader = classLoader;
        }
        @Override public Identity metadata() { return metadata; }
        @Override public Path rootPath() {
            if (root == null) throw new UnsupportedOperationException("Builtin compatibility identities have no archive root");
            if (!root.getFileSystem().isOpen()) throw new IllegalStateException("Mod archive session is closed");
            return root;
        }
        @Override public Path getPath(String file) {
            Objects.requireNonNull(file, "file");
            if (file.isBlank() || file.startsWith("/") || file.indexOf('\\') >= 0 || file.indexOf('\0') >= 0)
                throw new IllegalArgumentException("Expected a relative archive path");
            for (String part : file.split("/", -1)) if (part.equals("..") || part.equals(".") || part.isBlank())
                throw new IllegalArgumentException("Archive path contains an unsafe segment");
            return rootPath().resolve(file);
        }
        @Override public List<List<Path>> getSourcePaths() { return source == null ? List.of() : List.of(List.of(source)); }
        @Override public BasicSourceType getSourceType() { return sourceType; }
        @Override public ClassLoader getClassLoader() { return classLoader; }
    }
    private record SharedMappings(net.fabricmc.loader.api.MappingResolver delegate) implements MappingResolver {
        @Override public Collection<String> getNamespaces() { return List.copyOf(delegate.getNamespaces()); }
        @Override public String getCurrentRuntimeNamespace() { return delegate.getCurrentRuntimeNamespace(); }
        @Override public String mapClassName(String from, String name) { return delegate.mapClassName(from, name); }
        @Override public String unmapClassName(String to, String name) { return delegate.unmapClassName(to, name); }
        @Override public String mapFieldName(String from, String owner, String name, String descriptor) { return delegate.mapFieldName(from, owner, name, descriptor); }
        @Override public String mapMethodName(String from, String owner, String name, String descriptor) { return delegate.mapMethodName(from, owner, name, descriptor); }
    }
}
