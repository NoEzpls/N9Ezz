package dev.n9ezz.loader.mapping;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.jar.JarFile;
import net.fabricmc.classtweaker.api.ClassTweaker;
import net.fabricmc.classtweaker.api.ClassTweakerReader;
import net.fabricmc.classtweaker.utils.EntryTriple;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;

/** Own collection/validation/stage adapter around the licensed Fabric access-widener component. */
public final class AccessWidenerSet {
    private static final int MAX_RESOURCE = 1024 * 1024;
    private final String namespace;
    private final ClassTweaker rules = ClassTweaker.newInstance();
    private final Set<String> sources = new LinkedHashSet<>();
    private boolean registered;

    public AccessWidenerSet(String namespace) {
        if (!namespace.equals("intermediary") && !namespace.equals("official")) throw new IllegalArgumentException("Unsupported access-widener namespace: " + namespace);
        this.namespace = namespace;
    }
    public static AccessWidenerSet fromJars(List<Path> jars, String namespace) throws IOException {
        AccessWidenerSet result = new AccessWidenerSet(namespace);
        for (Path path : jars.stream().sorted().toList()) {
            try (JarFile jar = new JarFile(path.toFile(), false)) {
                var metadata = jar.getJarEntry("fabric.mod.json");
                if (metadata == null) continue;
                JsonObject json;
                try (InputStream input = jar.getInputStream(metadata)) {
                    json = JsonParser.parseString(new String(bounded(input), StandardCharsets.UTF_8)).getAsJsonObject();
                }
                if (json.has("accessWidener")) result.add(path, json.get("accessWidener").getAsString());
            } catch (RuntimeException error) {
                if (error instanceof LoaderException loader) throw loader;
                throw new LoaderException(new Diagnostic("ACCESS_WIDENER_INVALID", "Cannot read access-widener metadata: " + error.getMessage(), null, "access", path), error);
            }
        }
        return result;
    }
    public void add(Path jarPath, String resource) throws IOException {
        if (resource == null || resource.isBlank() || resource.startsWith("/") || resource.contains("..") || resource.contains("\\")) throw new IOException("Unsafe access-widener resource: " + resource);
        Path jar = jarPath.toRealPath();
        String source = jar + "!/" + resource;
        if (sources.contains(source)) return;
        try (JarFile archive = new JarFile(jar.toFile(), false)) {
            var entry = archive.getJarEntry(resource);
            if (entry == null || entry.isDirectory()) throw new LoaderException(new Diagnostic("ACCESS_WIDENER_MISSING", "Missing access-widener resource: " + resource, null, "access", jar));
            try (InputStream input = archive.getInputStream(entry)) { add(bounded(input), source); }
        }
    }
    public void add(byte[] bytes, String source) throws IOException {
        if (registered) throw new IllegalStateException("Access wideners are frozen");
        if (bytes.length > MAX_RESOURCE) throw new IOException("Access-widener resource exceeds limit");
        if (sources.contains(source)) return;
        try {
            var header = ClassTweakerReader.readHeader(bytes);
            if (header.getVersion() != ClassTweaker.AW_V1 && header.getVersion() != ClassTweaker.AW_V2)
                throw new IOException("Only accessWidener v1/v2 declarations are supported");
            if (!namespace.equals(header.getNamespace())) throw new IOException("Access-widener namespace mismatch: expected " + namespace + ", got " + header.getNamespace());
            // Validate against a disposable ruleset before modifying the shared rules.
            ClassTweakerReader.create(ClassTweaker.newInstance()).read(bytes, namespace);
            ClassTweakerReader.create(rules).read(bytes, namespace);
            sources.add(source);
        } catch (RuntimeException error) {
            throw new LoaderException(new Diagnostic("ACCESS_WIDENER_INVALID", "Invalid declaration from " + source + ": " + error.getMessage()), error);
        }
    }
    public Set<String> targets() { return Collections.unmodifiableSet(new TreeSet<>(rules.getTargets())); }
    public List<String> sources() { return List.copyOf(sources); }
    public boolean isEmpty() { return sources.isEmpty(); }

    public void validateTargets(Path gameJar) throws IOException { validateTargets(List.of(gameJar)); }
    public void validateTargets(List<Path> jars) throws IOException {
        Map<String, ClassNode> classes = new TreeMap<>();
        List<Diagnostic> diagnostics = new ArrayList<>();
        for (Path path : jars) try (JarFile jar = new JarFile(path.toFile(), false)) {
            for (String name : targets()) {
                var entry = jar.getJarEntry(name + ".class");
                if (entry == null) continue;
                ClassNode node = new ClassNode();
                try (InputStream input = jar.getInputStream(entry)) {
                    new ClassReader(input.readAllBytes()).accept(node, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
                }
                if (classes.putIfAbsent(name, node) != null) diagnostics.add(new Diagnostic("ACCESS_WIDENER_DUPLICATE_TARGET", "Access-widener target occurs in multiple Jars: " + name, null, "access", path));
            }
        }
        for (var rule : rules.getAllAccessWideners().entrySet().stream().sorted(Map.Entry.comparingByKey()).toList()) {
            ClassNode node = classes.get(rule.getKey());
            if (node == null) {
                diagnostics.add(new Diagnostic("ACCESS_WIDENER_TARGET_MISSING", "Target class is absent: " + rule.getKey())); continue;
            }
            for (EntryTriple field : rule.getValue().getAllFieldAccesses().keySet().stream().sorted(Comparator.comparing(EntryTriple::toString)).toList()) if (node.fields.stream().noneMatch(item -> item.name.equals(field.getName()) && item.desc.equals(field.getDesc())))
                diagnostics.add(new Diagnostic("ACCESS_WIDENER_TARGET_MISSING", "Target field is absent: " + field));
            for (EntryTriple method : rule.getValue().getAllMethodAccesses().keySet().stream().sorted(Comparator.comparing(EntryTriple::toString)).toList()) if (node.methods.stream().noneMatch(item -> item.name.equals(method.getName()) && item.desc.equals(method.getDesc())))
                diagnostics.add(new Diagnostic("ACCESS_WIDENER_TARGET_MISSING", "Target method is absent: " + method));
        }
        if (!diagnostics.isEmpty()) throw new LoaderException(diagnostics);
    }
    public void register(TransformationPipeline pipeline) {
        if (registered) throw new IllegalStateException("Access wideners were already registered");
        if (!sources.isEmpty()) pipeline.register(TransformationPipeline.Stage.ACCESS, 0, "n9ezz:access-widener", this::transform);
        registered = true;
    }
    public byte[] transform(String binaryName, byte[] input) {
        if (!rules.getTargets().contains(binaryName.replace('.', '/'))) return input;
        ClassReader reader = new ClassReader(input);
        ClassWriter writer = new ClassWriter(0);
        reader.accept(rules.createClassVisitor(Opcodes.ASM9, writer, (name, bytes) -> {
            throw new LoaderException(new Diagnostic("ACCESS_WIDENER_UNSUPPORTED_GENERATION", "Access-widener component attempted generated class: " + name));
        }), 0);
        return writer.toByteArray();
    }
    private static byte[] bounded(InputStream input) throws IOException {
        byte[] bytes = input.readNBytes(MAX_RESOURCE + 1);
        if (bytes.length > MAX_RESOURCE) throw new IOException("Access-widener resource exceeds limit");
        return bytes;
    }
}
