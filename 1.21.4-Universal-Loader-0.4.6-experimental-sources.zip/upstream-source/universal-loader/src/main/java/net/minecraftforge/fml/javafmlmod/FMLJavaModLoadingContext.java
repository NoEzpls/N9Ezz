package net.minecraftforge.fml.javafmlmod;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public class FMLJavaModLoadingContext extends net.minecraftforge.fml.ModLoadingContext {
    private final FMLModContainer container;
    public FMLJavaModLoadingContext(FMLModContainer container) { super(container); this.container = container; }
    public net.minecraftforge.eventbus.api.bus.BusGroup getModBusGroup() { return container.getModBusGroup(); }
    @Override public FMLModContainer getContainer() { return container; }
    public static FMLJavaModLoadingContext get() { return net.minecraftforge.fml.ModLoadingContext.get().extension(); }
}
