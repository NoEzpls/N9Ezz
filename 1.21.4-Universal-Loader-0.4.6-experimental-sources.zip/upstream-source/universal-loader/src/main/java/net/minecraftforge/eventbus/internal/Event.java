package net.minecraftforge.eventbus.internal;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface Event {}
