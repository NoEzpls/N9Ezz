package net.minecraftforge.eventbus.api.event.characteristic;
/** Original lifecycle marker; the owned typed bus disposes listeners after one post. */
public interface SelfDestructing extends net.minecraftforge.eventbus.internal.EventCharacteristic {}
