package net.minecraftforge.eventbus.api.event;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface InheritableEvent extends net.minecraftforge.eventbus.internal.Event {}
