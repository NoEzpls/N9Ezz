package net.minecraftforge.eventbus.api.listener;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface EventListener {
    Class<? extends net.minecraftforge.eventbus.internal.Event> eventType();
    byte priority();
    default boolean alwaysCancelling() { return false; }
}
