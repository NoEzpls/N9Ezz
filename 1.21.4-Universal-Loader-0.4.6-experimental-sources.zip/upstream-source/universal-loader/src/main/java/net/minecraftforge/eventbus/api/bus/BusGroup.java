package net.minecraftforge.eventbus.api.bus;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface BusGroup {
    BusGroup DEFAULT = create("default");
    static BusGroup create(String name) { return create(name, net.minecraftforge.eventbus.internal.Event.class); }
    static BusGroup create(String name, Class<?> baseType) { return dev.n9ezz.loader.fml.FmlEventBuses.forgeGroup(name, baseType); }
    String name();
    void startup();
    void shutdown();
    void dispose();
    void trim();
}
