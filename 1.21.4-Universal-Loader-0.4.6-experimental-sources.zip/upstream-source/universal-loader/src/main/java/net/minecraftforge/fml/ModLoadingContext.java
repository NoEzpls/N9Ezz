package net.minecraftforge.fml;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public class ModLoadingContext {
    private static final ThreadLocal<ModLoadingContext> ACTIVE = new ThreadLocal<>();
    private final ModContainer container;
    protected ModLoadingContext(ModContainer container) { this.container = java.util.Objects.requireNonNull(container); }
    public static ModLoadingContext get() {
        ModLoadingContext value = ACTIVE.get();
        if (value == null) throw new IllegalStateException("No active N9Ezz FML mod lifecycle context");
        return value;
    }
    public ModContainer getContainer() { return container; }
    public ModContainer getActiveContainer() { return container; }
    public String getActiveNamespace() { return container.getNamespace(); }
    @SuppressWarnings("unchecked") public <T> T extension() { return (T) this; }
    /** Runtime binding only; not part of the accepted mod API. */
    public static AutoCloseable n9ezzEnter(ModLoadingContext value) {
        ModLoadingContext previous = ACTIVE.get(); ACTIVE.set(value);
        return () -> { if (previous == null) ACTIVE.remove(); else ACTIVE.set(previous); };
    }
}
