package net.minecraftforge.fml;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public class ModContainer {
    private final String id;
    public ModContainer(String id) { this.id = java.util.Objects.requireNonNull(id); }
    public final String getModId() { return id; }
    public final String getNamespace() { return id; }
    public net.minecraftforge.eventbus.api.bus.BusGroup getModBusGroup() { throw new IllegalStateException("Not a JavaFML mod container"); }
}
