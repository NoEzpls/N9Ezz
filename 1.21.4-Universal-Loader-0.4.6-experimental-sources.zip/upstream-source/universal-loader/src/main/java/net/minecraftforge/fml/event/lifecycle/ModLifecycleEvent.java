package net.minecraftforge.fml.event.lifecycle;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public abstract class ModLifecycleEvent implements net.minecraftforge.fml.event.IModBusEvent {
    private final net.minecraftforge.fml.ModContainer container;
    protected ModLifecycleEvent(net.minecraftforge.fml.ModContainer container) { this.container = java.util.Objects.requireNonNull(container); }
    public final String description() { return getClass().getSimpleName(); }
    net.minecraftforge.fml.ModContainer getContainer() { return container; }
    @Override public String toString() { return description(); }
}
