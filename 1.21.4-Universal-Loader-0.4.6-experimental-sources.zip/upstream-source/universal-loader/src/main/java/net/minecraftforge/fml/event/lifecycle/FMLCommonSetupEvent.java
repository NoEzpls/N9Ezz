package net.minecraftforge.fml.event.lifecycle;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public final class FMLCommonSetupEvent extends ParallelDispatchEvent implements net.minecraftforge.eventbus.api.event.characteristic.SelfDestructing {
    public FMLCommonSetupEvent(net.minecraftforge.fml.ModContainer container, net.minecraftforge.fml.ModLoadingStage stage) { super(container, stage); }
    public static net.minecraftforge.eventbus.api.bus.EventBus<FMLCommonSetupEvent> getBus(net.minecraftforge.eventbus.api.bus.BusGroup group) {
        return net.minecraftforge.fml.event.IModBusEvent.getBus(group, FMLCommonSetupEvent.class);
    }
}
