package net.minecraftforge.fml.javafmlmod;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public final class FMLModContainer extends net.minecraftforge.fml.ModContainer {
    private final net.minecraftforge.eventbus.api.bus.BusGroup group;
    public FMLModContainer(String id, net.minecraftforge.eventbus.api.bus.BusGroup group) { super(id); this.group = group; }
    public net.minecraftforge.eventbus.api.bus.BusGroup getModBusGroup() { return group; }
}
