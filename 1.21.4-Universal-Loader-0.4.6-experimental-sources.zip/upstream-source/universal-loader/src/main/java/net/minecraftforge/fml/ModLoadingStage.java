package net.minecraftforge.fml;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public enum ModLoadingStage {
    ERROR, VALIDATE, CONSTRUCT, COMMON_SETUP, SIDED_SETUP, ENQUEUE_IMC, PROCESS_IMC, COMPLETE, DONE;
    public ModLoadingStage currentState(Throwable exception) { return exception == null ? this : ERROR; }
}
