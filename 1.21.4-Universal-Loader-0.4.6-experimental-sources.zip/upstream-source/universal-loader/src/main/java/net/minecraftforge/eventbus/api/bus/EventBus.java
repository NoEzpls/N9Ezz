package net.minecraftforge.eventbus.api.bus;

import java.util.function.Consumer;
import net.minecraftforge.eventbus.internal.Event;
import net.minecraftforge.eventbus.api.listener.EventListener;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface EventBus<T extends Event> {
    EventListener addListener(Consumer<T> listener);
    EventListener addListener(byte priority, Consumer<T> listener);
    EventListener addListener(EventListener listener);
    void removeListener(EventListener listener);
    boolean post(T event);
    T fire(T event);
    boolean hasListeners();
    static <E extends Event> EventBus<E> create(Class<E> eventType) { return create(BusGroup.DEFAULT, eventType); }
    static <E extends Event> EventBus<E> create(BusGroup group, Class<E> eventType) {
        return dev.n9ezz.loader.fml.FmlEventBuses.forgeBus(group, eventType);
    }
}
