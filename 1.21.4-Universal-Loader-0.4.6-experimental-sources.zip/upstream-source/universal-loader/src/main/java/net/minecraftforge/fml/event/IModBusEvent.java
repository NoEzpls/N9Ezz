package net.minecraftforge.fml.event;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface IModBusEvent extends net.minecraftforge.eventbus.api.event.InheritableEvent {
    static <T extends IModBusEvent> net.minecraftforge.eventbus.api.bus.EventBus<T> getBus(
            net.minecraftforge.eventbus.api.bus.BusGroup group, Class<T> type) {
        return net.minecraftforge.eventbus.api.bus.EventBus.create(group, type);
    }
}
