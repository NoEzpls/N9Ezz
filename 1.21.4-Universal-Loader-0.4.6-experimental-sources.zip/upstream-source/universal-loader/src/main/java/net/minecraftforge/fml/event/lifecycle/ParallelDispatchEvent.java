package net.minecraftforge.fml.event.lifecycle;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public abstract class ParallelDispatchEvent extends ModLifecycleEvent {
    protected ParallelDispatchEvent(net.minecraftforge.fml.ModContainer container, net.minecraftforge.fml.ModLoadingStage stage) {
        super(container); java.util.Objects.requireNonNull(stage);
    }
    public java.util.concurrent.CompletableFuture<Void> enqueueWork(Runnable work) {
        return dev.n9ezz.loader.fml.FmlBindings.enqueue(getContainer(), work);
    }
    public <T> java.util.concurrent.CompletableFuture<T> enqueueWork(java.util.function.Supplier<T> work) {
        return dev.n9ezz.loader.fml.FmlBindings.enqueue(getContainer(), work);
    }
}
