package net.minecraftforge.eventbus.internal;
/** Original marker descriptor; only lifecycle self-destruction is supported. */
public interface EventCharacteristic {}
