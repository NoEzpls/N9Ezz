package net.minecraftforge.eventbus.api.listener;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public final class Priority {
    public static final byte HIGHEST = Byte.MAX_VALUE, HIGH = 64, NORMAL = 0, LOW = -64, LOWEST = Byte.MIN_VALUE + 1, MONITOR = Byte.MIN_VALUE;
    private Priority() {}
}
