package net.neoforged.fml.common;

import java.lang.annotation.*;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Mod {
    String value();
    net.neoforged.api.distmarker.Dist[] dist() default {net.neoforged.api.distmarker.Dist.CLIENT, net.neoforged.api.distmarker.Dist.DEDICATED_SERVER};
    String[] depends() default {};
}
