package net.neoforged.fml.event.lifecycle;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public class FMLLoadCompleteEvent extends ParallelDispatchEvent {
    public FMLLoadCompleteEvent(net.neoforged.fml.ModContainer container, net.neoforged.fml.DeferredWorkQueue queue) { super(container, queue); }
}
