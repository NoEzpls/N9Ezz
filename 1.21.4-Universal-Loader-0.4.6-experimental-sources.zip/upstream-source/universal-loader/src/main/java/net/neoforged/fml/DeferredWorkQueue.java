package net.neoforged.fml;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public final class DeferredWorkQueue {
    public java.util.concurrent.CompletableFuture<Void> enqueueWork(ModContainer mod, Runnable work) { return dev.n9ezz.loader.fml.FmlBindings.enqueue(mod, work); }
    public <T> java.util.concurrent.CompletableFuture<T> enqueueWork(ModContainer mod, java.util.function.Supplier<T> work) { return dev.n9ezz.loader.fml.FmlBindings.enqueue(mod, work); }
}
