package net.neoforged.bus.api;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public abstract class Event { protected Event() {} }
