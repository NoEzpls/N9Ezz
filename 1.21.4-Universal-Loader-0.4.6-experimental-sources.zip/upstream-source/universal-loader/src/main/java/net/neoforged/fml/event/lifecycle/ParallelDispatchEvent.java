package net.neoforged.fml.event.lifecycle;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public abstract class ParallelDispatchEvent extends ModLifecycleEvent {
    private final net.neoforged.fml.DeferredWorkQueue queue;
    public ParallelDispatchEvent(net.neoforged.fml.ModContainer container, net.neoforged.fml.DeferredWorkQueue queue) { super(container); this.queue = java.util.Objects.requireNonNull(queue); }
    public java.util.concurrent.CompletableFuture<Void> enqueueWork(Runnable work) { return queue.enqueueWork(getContainer(), work); }
    public <T> java.util.concurrent.CompletableFuture<T> enqueueWork(java.util.function.Supplier<T> work) { return queue.enqueueWork(getContainer(), work); }
}
