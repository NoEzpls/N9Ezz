package net.neoforged.bus.api;

import java.util.function.Consumer;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface IEventBus {
    <T extends Event> void addListener(Consumer<T> consumer);
    <T extends Event> void addListener(Class<T> type, Consumer<T> consumer);
    <T extends Event> void addListener(EventPriority priority, Consumer<T> consumer);
    <T extends Event> void addListener(EventPriority priority, Class<T> type, Consumer<T> consumer);
    <T extends Event> void addListener(EventPriority priority, boolean receiveCanceled, Consumer<T> consumer);
    <T extends Event> void addListener(EventPriority priority, boolean receiveCanceled, Class<T> type, Consumer<T> consumer);
    <T extends Event> void addListener(boolean receiveCanceled, Consumer<T> consumer);
    <T extends Event> void addListener(boolean receiveCanceled, Class<T> type, Consumer<T> consumer);
    void unregister(Object object);
    <T extends Event> T post(T event);
    <T extends Event> T post(EventPriority priority, T event);
    void start();
}
