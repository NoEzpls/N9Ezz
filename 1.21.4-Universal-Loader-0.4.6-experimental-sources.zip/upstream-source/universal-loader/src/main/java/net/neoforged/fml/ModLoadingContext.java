package net.neoforged.fml;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public class ModLoadingContext {
    private static final ThreadLocal<ModLoadingContext> ACTIVE = new ThreadLocal<>();
    private final ModContainer container;
    public ModLoadingContext(ModContainer container) { this.container = java.util.Objects.requireNonNull(container); }
    public static ModLoadingContext get() {
        ModLoadingContext context = ACTIVE.get();
        if (context == null) throw new IllegalStateException("No active N9Ezz FML mod lifecycle context");
        return context;
    }
    public ModContainer getActiveContainer() { return container; }
    public String getActiveNamespace() { return container.getNamespace(); }
    /** Runtime binding only; not part of the accepted mod API. */
    public static AutoCloseable n9ezzEnter(ModLoadingContext value) {
        ModLoadingContext previous = ACTIVE.get(); ACTIVE.set(value);
        return () -> { if (previous == null) ACTIVE.remove(); else ACTIVE.set(previous); };
    }
}
