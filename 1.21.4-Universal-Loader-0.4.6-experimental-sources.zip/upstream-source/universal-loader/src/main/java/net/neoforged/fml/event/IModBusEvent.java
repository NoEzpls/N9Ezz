package net.neoforged.fml.event;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public interface IModBusEvent {}
