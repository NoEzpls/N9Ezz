package net.neoforged.fml.javafmlmod;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public final class FMLModContainer extends net.neoforged.fml.ModContainer {
    public FMLModContainer(String id, net.neoforged.bus.api.IEventBus bus) { super(id, bus); }
}
