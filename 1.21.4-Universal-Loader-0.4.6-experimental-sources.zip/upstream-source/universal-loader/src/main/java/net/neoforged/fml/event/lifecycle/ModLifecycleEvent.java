package net.neoforged.fml.event.lifecycle;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public abstract class ModLifecycleEvent extends net.neoforged.bus.api.Event implements net.neoforged.fml.event.IModBusEvent {
    private final net.neoforged.fml.ModContainer container;
    public ModLifecycleEvent(net.neoforged.fml.ModContainer container) { this.container = java.util.Objects.requireNonNull(container); }
    public net.neoforged.fml.ModContainer getContainer() { return container; }
}
