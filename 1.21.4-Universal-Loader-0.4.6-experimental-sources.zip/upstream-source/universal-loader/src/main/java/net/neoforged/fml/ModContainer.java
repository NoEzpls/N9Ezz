package net.neoforged.fml;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public class ModContainer {
    private final String id;
    private final net.neoforged.bus.api.IEventBus bus;
    public ModContainer(String id, net.neoforged.bus.api.IEventBus bus) { this.id = java.util.Objects.requireNonNull(id); this.bus = java.util.Objects.requireNonNull(bus); }
    public final String getModId() { return id; }
    public final String getNamespace() { return id; }
    public net.neoforged.bus.api.IEventBus getEventBus() { return bus; }
}
