package net.neoforged.bus.api;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public enum EventPriority { HIGHEST, HIGH, NORMAL, LOW, LOWEST }
