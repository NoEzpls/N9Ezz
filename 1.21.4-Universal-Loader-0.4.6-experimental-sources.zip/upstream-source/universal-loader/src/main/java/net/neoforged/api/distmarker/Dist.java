package net.neoforged.api.distmarker;
/** Original N9Ezz interoperability implementation; limited to the documented FML lifecycle contract. */
public enum Dist { CLIENT, DEDICATED_SERVER;
    public boolean isClient() { return this == CLIENT; }
    public boolean isDedicatedServer() { return this == DEDICATED_SERVER; }
}
