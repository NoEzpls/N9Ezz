/* Copyright 2016 FabricMC. Licensed under Apache-2.0. */
package net.fabricmc.loader.api;

import java.util.Collection;

/** Public ABI copied from Fabric Loader 0.19.2; implementation is N9Ezz's mapping index. */
public interface MappingResolver {
    Collection<String> getNamespaces();
    String getCurrentRuntimeNamespace();
    String mapClassName(String namespace, String className);
    String unmapClassName(String targetNamespace, String className);
    String mapFieldName(String namespace, String owner, String name, String descriptor);
    String mapMethodName(String namespace, String owner, String name, String descriptor);
}
