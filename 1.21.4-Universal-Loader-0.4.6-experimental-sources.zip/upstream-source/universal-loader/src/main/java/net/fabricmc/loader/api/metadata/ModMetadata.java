/* Fabric Loader ABI: Copyright 2016 FabricMC. Licensed under Apache-2.0.
 * Modified by N9Ezz: immutable identification metadata subset. */
package net.fabricmc.loader.api.metadata;

import java.util.Collection;
import net.fabricmc.loader.api.Version;

public interface ModMetadata {
    String getType();
    String getId();
    Collection<String> getProvides();
    Version getVersion();
    String getName();
    String getDescription();
    Collection<String> getLicense();
}
