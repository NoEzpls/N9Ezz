/* Fabric Loader public ABI declarations: Copyright 2016 FabricMC, Apache-2.0.
 * Modified by N9Ezz: bounded read-only services backed by the universal runtime,
 * with no FabricLoaderImpl or Fabric engine. Unsupported ABI is not advertised. */
package net.fabricmc.loader.api;

import dev.n9ezz.loader.fabric.FabricRuntime;
import java.io.File;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Optional;
import net.fabricmc.api.EnvType;

/** Verified Fabric Loader 0.19.2 ABI subset; see the Fabric compatibility contract. */
public interface FabricLoader {
    static FabricLoader getInstance() { return FabricRuntime.loader(); }
    Path getConfigDir();
    Path getGameDir();
    default File getConfigDirectory() { return getConfigDir().toFile(); }
    default File getGameDirectory() { return getGameDir().toFile(); }
    boolean isDevelopmentEnvironment();
    EnvType getEnvironmentType();
    String getRawGameVersion();
    Object getGameInstance();
    boolean isModLoaded(String id);
    Optional<ModContainer> getModContainer(String id);
    Collection<ModContainer> getAllMods();
    MappingResolver getMappingResolver();
}
