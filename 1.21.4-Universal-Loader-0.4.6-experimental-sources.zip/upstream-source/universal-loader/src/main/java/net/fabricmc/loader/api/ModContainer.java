/* Fabric Loader ABI: Copyright 2016 FabricMC. Licensed under Apache-2.0.
 * Modified by N9Ezz: read-only identity and archive access subset. */
package net.fabricmc.loader.api;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import net.fabricmc.loader.api.metadata.ModMetadata;

public interface ModContainer {
    ModMetadata getMetadata();
    List<Path> getRootPaths();
    default Optional<Path> findPath(String file) {
        if (file == null || file.startsWith("/") || file.contains("\\") || java.util.Arrays.asList(file.split("/", -1)).contains("..")) throw new IllegalArgumentException("Archive path must be relative and contained");
        for (Path root : getRootPaths()) {
            Path path = root.resolve(file).normalize();
            if (!path.startsWith(root)) throw new IllegalArgumentException("Archive path escapes its root");
            if (Files.exists(path)) return Optional.of(path);
        }
        return Optional.empty();
    }
    default Path getRootPath() { return getRootPaths().getFirst(); }
    default Path getRoot() { return getRootPath(); }
    default Path getPath(String file) { return findPath(file).orElseGet(() -> getRootPath().resolve(file)); }
}
