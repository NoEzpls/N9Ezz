package net.fabricmc.api;

/** Original minimal binary interoperability definition; only the client callback is supported. */
@FunctionalInterface
public interface ClientModInitializer {
    void onInitializeClient();
}
