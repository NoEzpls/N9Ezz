package net.fabricmc.api;

/** Original minimal binary interoperability definition; not the Fabric loader implementation. */
@FunctionalInterface
public interface ModInitializer {
    void onInitialize();
}
