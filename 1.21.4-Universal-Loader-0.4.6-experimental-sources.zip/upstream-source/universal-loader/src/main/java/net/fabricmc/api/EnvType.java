package net.fabricmc.api;

/** Annotation values only. This does not provide Fabric environment stripping. */
public enum EnvType {
    CLIENT, SERVER
}
