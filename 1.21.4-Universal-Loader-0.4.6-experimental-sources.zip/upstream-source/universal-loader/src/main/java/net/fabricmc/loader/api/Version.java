/* Fabric Loader ABI: Copyright 2016 FabricMC. Licensed under Apache-2.0.
 * N9Ezz supports only the pinned semantic versions in this runtime. */
package net.fabricmc.loader.api;

public interface Version extends Comparable<Version> {
    String getFriendlyString();
}
