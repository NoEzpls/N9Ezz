package net.minecraft.client.main;

/** Simulated game entrypoint. This is test bytecode, never a Mojang implementation. */
public final class Main {
    private Main() {}
    public static void main(String[] arguments) throws ReflectiveOperationException {
        if (!System.getProperty("n9.test.trace", "").contains("native:ready;"))
            throw new IllegalStateException("simulated game started before loader READY");
        System.setProperty("n9.test.game.loader", Integer.toHexString(System.identityHashCode(Main.class.getClassLoader())));
        Class<?> obfuscated = Class.forName("g", true, Main.class.getClassLoader());
        System.setProperty("n9.test.game.obfuscated.loader", Integer.toHexString(System.identityHashCode(obfuscated.getClassLoader())));
        System.setProperty("n9.test.game.marker", String.valueOf(obfuscated.getMethod("marker").invoke(null)));
    }
}
