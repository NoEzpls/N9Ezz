package fixture;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import dev.n9ezz.loader.core.LifecycleEvent;

public final class NativeFixture implements N9ModInitializer {
    @Override public void onInitialize(ModContext context) {
        System.setProperty("n9.test.native.id", context.modId());
        System.setProperty("n9.test.native.dir", context.gameDirectory().toString());
        System.setProperty("n9.test.loader.native", Integer.toHexString(System.identityHashCode(getClass().getClassLoader())));
        System.setProperty("n9.test.tccl.native", Integer.toHexString(System.identityHashCode(Thread.currentThread().getContextClassLoader())));
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "native:common;");
        context.events().on(LifecycleEvent.READY, 0, event ->
            System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "native:ready;"));
    }
}
