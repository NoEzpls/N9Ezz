package fixture;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;

public final class ThrowingFixture implements N9ModInitializer {
    @Override public void onInitialize(ModContext context) {
        System.setProperty("n9.test.throwing.attempts", Integer.toString(Integer.parseInt(System.getProperty("n9.test.throwing.attempts", "0")) + 1));
        throw new IllegalStateException("fixture initialization failure");
    }
}
