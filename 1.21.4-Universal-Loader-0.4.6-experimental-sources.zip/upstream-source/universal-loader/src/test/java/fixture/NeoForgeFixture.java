package fixture;

@net.neoforged.fml.common.Mod("neo_smoke")
public final class NeoForgeFixture {
    public NeoForgeFixture() {
        System.setProperty("n9.test.loader.neo", Integer.toHexString(System.identityHashCode(getClass().getClassLoader())));
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "neo:common;");
    }
}
