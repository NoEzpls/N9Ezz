package fixture;

import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;

public final class QuiltFixture implements ModInitializer {
    @Override public void onInitialize(ModContainer mod) {
        System.setProperty("n9.test.quilt.id", mod.metadata().id());
        System.setProperty("n9.test.quilt.version", mod.metadata().version().raw());
        System.setProperty("n9.test.loader.quilt", Integer.toHexString(System.identityHashCode(getClass().getClassLoader())));
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "quilt:common;");
    }
}
