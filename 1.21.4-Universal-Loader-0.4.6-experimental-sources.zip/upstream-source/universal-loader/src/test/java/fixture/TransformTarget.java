package fixture;

public final class TransformTarget {
    public static int value() { return 7; }
}
