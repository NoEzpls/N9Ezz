package fixture;

@net.minecraftforge.fml.common.Mod("forge_smoke")
public final class ForgeFixture {
    public ForgeFixture() {
        System.setProperty("n9.test.loader.forge", Integer.toHexString(System.identityHashCode(getClass().getClassLoader())));
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "forge:common;");
    }
}
