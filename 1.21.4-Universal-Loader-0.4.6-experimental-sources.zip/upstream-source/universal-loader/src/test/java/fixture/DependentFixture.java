package fixture;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;

public final class DependentFixture implements N9ModInitializer {
    @Override public void onInitialize(ModContext context) {
        if (!System.getProperty("n9.test.trace", "").contains("native:common;"))
            throw new IllegalStateException("dependency was not initialized first");
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "dependent:common;");
    }
}
