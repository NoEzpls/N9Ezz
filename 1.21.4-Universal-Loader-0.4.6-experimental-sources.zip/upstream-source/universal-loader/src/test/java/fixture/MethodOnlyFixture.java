package fixture;

/** A method name alone must never count as implementing the declared platform ABI. */
public final class MethodOnlyFixture {
    public void onInitialize() { System.setProperty("n9.test.impostor", "ran"); }
}
