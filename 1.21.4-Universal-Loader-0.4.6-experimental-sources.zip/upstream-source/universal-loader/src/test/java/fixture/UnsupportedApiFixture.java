package fixture;

import net.fabricmc.api.ModInitializer;

public final class UnsupportedApiFixture implements ModInitializer {
    @Override public void onInitialize() {
        try {
            Class.forName("net.fabricmc.fabric.api.event.lifecycle.v1.ClientTickEvents", true, getClass().getClassLoader());
        } catch (ClassNotFoundException missingApi) {
            throw new IllegalStateException("Fabric API lifecycle events are outside supported API", missingApi);
        }
    }
}
