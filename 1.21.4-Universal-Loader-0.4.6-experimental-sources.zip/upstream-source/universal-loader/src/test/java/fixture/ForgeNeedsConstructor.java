package fixture;

@net.minecraftforge.fml.common.Mod("forge_smoke")
public final class ForgeNeedsConstructor {
    public ForgeNeedsConstructor(String injectedService) {
        System.setProperty("n9.test.forge.injected", injectedService);
    }
}
