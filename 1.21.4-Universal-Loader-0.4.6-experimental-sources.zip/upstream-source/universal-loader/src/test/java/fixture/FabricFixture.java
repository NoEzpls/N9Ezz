package fixture;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;

public final class FabricFixture implements ModInitializer, ClientModInitializer {
    @Override public void onInitialize() {
        System.setProperty("n9.test.fabric.instance", Integer.toHexString(System.identityHashCode(this)));
        System.setProperty("n9.test.loader.fabric", Integer.toHexString(System.identityHashCode(getClass().getClassLoader())));
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "fabric:common;");
    }
    @Override public void onInitializeClient() {
        if (!Integer.toHexString(System.identityHashCode(this)).equals(System.getProperty("n9.test.fabric.instance")))
            throw new IllegalStateException("common and client entrypoints must use the same instance");
        System.setProperty("n9.test.trace", System.getProperty("n9.test.trace", "") + "fabric:client;");
    }
}
