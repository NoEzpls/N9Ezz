package dev.n9ezz.loader.tests;

import dev.n9ezz.loader.core.DependencyResolver;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.VersionConstraint;
import dev.n9ezz.loader.discovery.NestedJarResolver;
import dev.n9ezz.loader.fabric.SelectedFabricApi;
import dev.n9ezz.loader.metadata.Dependency;
import dev.n9ezz.loader.metadata.MetadataException;
import dev.n9ezz.loader.metadata.MetadataReader;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

/** Dependency contracts, including the exact pinned client/API closure; no game code runs. */
public final class FabricDependencyTests {
    private static int passed;
    private static Path work;
    private FabricDependencyTests() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 0 && args.length != 2) throw new IllegalArgumentException("Usage: FabricDependencyTests [client.jar official-fabric-api.jar]");
        work = Files.createTempDirectory("n9ezz-fabric-dependencies-");
        try {
            versionTests();
            graphTests();
            metadataTests();
            if (args.length == 2) actualClosure(Path.of(args[0]), Path.of(args[1]));
            System.out.println("Fabric dependency resolution: " + passed + " checks PASS");
        } finally {
            try (var files = Files.walk(work)) {
                for (Path path : files.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }

    private static void versionTests() throws Exception {
        String minecraft = ">=1.21.11- <1.21.12-";
        for (String version : List.of("1.21.11-", "1.21.11-alpha.22.11.a", "1.21.11-rc.1", "1.21.11", "1.21.11+build.4")) {
            check(VersionConstraint.parseFabric(minecraft).matches(version), "official Minecraft interval accepts " + version);
        }
        for (String version : List.of("1.21.10", "1.21.12-", "1.21.12-alpha.1", "1.21.12", "2.0.0")) {
            check(!VersionConstraint.parseFabric(minecraft).matches(version), "official Minecraft interval excludes " + version);
        }
        expectInvalid(() -> VersionConstraint.parse(minecraft), "strict native grammar keeps empty prerelease boundary opt-in");
        check(VersionConstraint.parseFabric("^0.2.3").matches("0.9.0"), "Fabric caret permits same major when major is zero");
        check(!VersionConstraint.parseFabric("^0.2.3").matches("1.0.0-alpha.1"), "Fabric caret excludes next-major prereleases");
        check(!VersionConstraint.parse("^0.2.3").matches("0.9.0"), "native caret retains its existing zero-major contract");
        check(VersionConstraint.parseFabric("~1.2.3").matches("1.2.4-alpha.1"), "Fabric tilde permits later patches and their prereleases");
        check(!VersionConstraint.parseFabric("~1.2.3").matches("1.3.0-alpha.1"), "Fabric tilde excludes next-minor prereleases");
        check(VersionConstraint.parseFabric("~1").matches("1.0.7"), "single-component Fabric tilde holds implicit minor zero");
        check(!VersionConstraint.parseFabric("~1").matches("1.1.0"), "single-component Fabric tilde excludes minor one");
        check(VersionConstraint.parseFabric("1.2.x").matches("1.2.0-alpha.1"), "Fabric wildcard includes prereleases of its prefix");
        check(!VersionConstraint.parseFabric("1.2.x").matches("1.3.0-alpha.1"), "Fabric wildcard excludes adjacent minor");
        check(VersionConstraint.parseFabric("1.2").matches("1.2.0"), "omitted semantic components equal zero");
        check(VersionConstraint.parseFabric("1.0.5+4ebb5c083e").matches("1.0.5+other"), "build metadata does not alter precedence");
        check(VersionConstraint.parseFabric(">=1.0.0-1").matches("1.0.0-01"), "leading-zero prerelease identifier is non-numeric in Fabric");
        check(!VersionConstraint.parseFabric("<1.0.0-1").matches("1.0.0-01"), "non-numeric prerelease sorts after numeric identifier");
        check(VersionConstraint.parseFabric("1.0 || >=2.0 <3.0").matches("2.7"), "metadata alternatives retain OR semantics");
        check(!VersionConstraint.parseFabric("1.0 || >=2.0 <3.0").matches("1.5"), "OR alternatives do not bridge excluded gap");
        check(VersionConstraint.parse("v1.2").matches("1.2"), "native version prefix contract remains unchanged");
        for (String expression : List.of(">=1.21.11-<1.21.12-", "1.x.2", ">=1.2.x", "||1.0", "latest", "1.0.0-rc..1", "v1.2", "2147483648.0", "^2147483647.0")) {
            expectInvalid(() -> VersionConstraint.parseFabric(expression), "unsupported predicate fails explicitly: " + expression);
        }
    }

    private static void graphTests() throws Exception {
        ModMetadata client = mod("client", "1", Platform.FABRIC, List.of(dep("fabricloader", ">=0.17.0")), Set.of());
        expect("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolve(List.of(client)), "strict runtime advertises no Fabric engine identity");
        check(ids(DependencyResolver.resolveFabricRuntime(List.of(client))).equals(List.of("client")), "explicit runtime exposes the exact verified Fabric facade ABI");
        expect("DEPENDENCY_VERSION", () -> DependencyResolver.resolveFabricRuntime(List.of(mod("new_abi", "1", Platform.FABRIC, List.of(dep("fabricloader", ">=0.20.0")), Set.of()))), "newer Fabric loader API demand is rejected");
        for (String engine : List.of("forge", "neoforge", "javafml", "quilt_loader", "fabric-loader")) {
            expect("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolveFabricRuntime(List.of(mod("requires_engine", "1", Platform.FABRIC, List.of(dep(engine, "*")), Set.of()))), "Fabric facade does not advertise " + engine);
        }
        for (String identity : List.of("fabricloader", "forge", "minecraft", "n9ezz")) {
            expect("RESERVED_MOD_ID", () -> DependencyResolver.resolveFabricRuntime(List.of(mod("impersonator", "1", Platform.FABRIC, List.of(), Set.of(identity)))), "mod cannot provide runtime identity " + identity);
        }
        ModMetadata base = mod("z_base", "2.0", Platform.FABRIC, List.of(), Set.of("base_alias"));
        ModMetadata dependent = mod("a_dependent", "1", Platform.FABRIC, List.of(dep("base_alias", ">=2")), Set.of());
        check(ids(DependencyResolver.resolveFabricRuntime(List.of(dependent, base))).equals(List.of("z_base", "a_dependent")), "required alias resolves provider before dependent");
        expect("MISSING_DEPENDENCY", () -> DependencyResolver.resolveFabricRuntime(List.of(dependent)), "missing mandatory dependency prevents initialization");
        expect("DEPENDENCY_VERSION", () -> DependencyResolver.resolveFabricRuntime(List.of(base, mod("wrong", "1", Platform.FABRIC, List.of(dep("base_alias", ">=3")), Set.of()))), "installed mandatory dependency must match");
        expect("DUPLICATE_PROVIDER", () -> DependencyResolver.resolveFabricRuntime(List.of(base, mod("other", "1", Platform.FABRIC, List.of(), Set.of("base_alias")))), "alias cannot have multiple providers");
        expect("DUPLICATE_MOD", () -> DependencyResolver.resolveFabricRuntime(List.of(base, base)), "duplicate ID is detected before graph construction");
        expect("DEPENDENCY_CYCLE", () -> DependencyResolver.resolveFabricRuntime(List.of(mod("self", "1", Platform.FABRIC, List.of(dep("self_alias", "*")), Set.of("self_alias")))), "required self alias is a cycle");
        expect("DEPENDENCY_CYCLE", () -> DependencyResolver.resolveFabricRuntime(List.of(mod("a", "1", Platform.FABRIC, List.of(dep("z", "*")), Set.of()), mod("z", "1", Platform.FABRIC, List.of(dep("a", "*")), Set.of()))), "required cycle remains fatal");

        var warnings = new ArrayList<Diagnostic>();
        ModMetadata recommendation = mod("recommendation", "1", Platform.FABRIC, List.of(new Dependency("base_alias", ">=3", true, false)), Set.of());
        check(DependencyResolver.resolveFabricRuntime(List.of(base, recommendation), warnings::add).size() == 2 && codes(warnings).equals(List.of("OPTIONAL_DEPENDENCY_VERSION")), "Fabric installed optional mismatch is advisory");
        warnings.clear();
        check(DependencyResolver.resolveFabricRuntime(List.of(recommendation), warnings::add).size() == 1 && warnings.isEmpty(), "absent optional dependency remains optional");
        ModMetadata nativeOptional = mod("native_optional", "1", Platform.N9EZZ, recommendation.dependencies(), Set.of());
        expect("DEPENDENCY_VERSION", () -> DependencyResolver.resolveFabricRuntime(List.of(base, nativeOptional)), "native optional version contract stays strict in shared mode");
        ModMetadata optionalOrder = mod("a_optional", "1", Platform.FABRIC, List.of(new Dependency("base_alias", ">=2", true, false)), Set.of());
        check(ids(DependencyResolver.resolveFabricRuntime(List.of(optionalOrder, base))).equals(List.of("z_base", "a_optional")), "compatible advisory edge orders provider first");
        warnings.clear();
        var optionalCycle = List.of(mod("a", "1", Platform.FABRIC, List.of(new Dependency("z", "*", true, false)), Set.of()), mod("z", "1", Platform.FABRIC, List.of(new Dependency("a", "*", true, false)), Set.of()));
        check(ids(DependencyResolver.resolveFabricRuntime(optionalCycle, warnings::add)).equals(List.of("z", "a")) && codes(warnings).equals(List.of("OPTIONAL_DEPENDENCY_CYCLE")), "optional cycle is broken with deterministic ordering and diagnostic");
        warnings.clear();
        var mixedCycle = List.of(optionalCycle.getFirst(), mod("z", "1", Platform.FABRIC, List.of(dep("a", "*")), Set.of()));
        check(ids(DependencyResolver.resolveFabricRuntime(mixedCycle, warnings::add)).equals(List.of("a", "z")) && codes(warnings).equals(List.of("OPTIONAL_DEPENDENCY_CYCLE")), "required ordering wins over conflicting recommendation");
        expect("INVALID_VERSION_CONSTRAINT", () -> DependencyResolver.resolveFabricRuntime(List.of(mod("invalid_optional", "1", Platform.FABRIC, List.of(new Dependency("absent", "latest", true, false)), Set.of()))), "invalid optional predicate is diagnosed even when absent");
        warnings.clear();
        check(DependencyResolver.resolveFabricRuntime(List.of(base, mod("soft_conflict", "1", Platform.FABRIC, List.of(new Dependency("base_alias", ">=2", true, true)), Set.of())), warnings::add).size() == 2 && codes(warnings).equals(List.of("OPTIONAL_MOD_CONFLICT")), "Fabric conflicts produce a warning");
        expect("INCOMPATIBLE_MOD", () -> DependencyResolver.resolveFabricRuntime(List.of(base, mod("breaks", "1", Platform.FABRIC, List.of(new Dependency("base_alias", ">=2", false, true)), Set.of()))), "Fabric breaks remain hard incompatibilities");
    }

    private static void metadataTests() throws Exception {
        Path source = work.resolve("advisory.jar");
        String json = "{\"schemaVersion\":1,\"id\":\"advisory\",\"version\":\"1\",\"recommends\":{\"optional_mod\":\">=2\"},\"suggests\":{\"suggested_mod\":\"*\"},\"conflicts\":{\"conflicting_mod\":\"*\"},\"breaks\":{\"broken_mod\":\"*\"}}";
        try (var jar = new JarOutputStream(Files.newOutputStream(source))) {
            jar.putNextEntry(new JarEntry("fabric.mod.json")); jar.write(json.getBytes(StandardCharsets.UTF_8)); jar.closeEntry();
        }
        try { MetadataReader.read(source); throw new AssertionError("strict Fabric metadata accepted advisory fields"); }
        catch (MetadataException expected) { check(expected.code().equals("METADATA_UNSUPPORTED"), "advanced Fabric advisory metadata remains opt-in"); }
        var dependencies = MetadataReader.read(source, MetadataReader.ReadPolicy.FABRIC_RUNTIME).getFirst().dependencies();
        check(dependencies.stream().filter(d -> d.id().equals("optional_mod") || d.id().equals("suggested_mod")).allMatch(d -> d.optional() && !d.incompatible()), "recommendations and suggestions retain soft positive semantics");
        check(dependencies.stream().anyMatch(d -> d.id().equals("conflicting_mod") && d.optional() && d.incompatible()), "conflicts retain soft negative semantics");
        check(dependencies.stream().anyMatch(d -> d.id().equals("broken_mod") && !d.optional() && d.incompatible()), "breaks retain hard negative semantics");
    }

    private static void actualClosure(Path client, Path api) throws Exception {
        var curated = SelectedFabricApi.select(Files.readAllBytes(api), work.resolve("selected-api"));
        var closure = NestedJarResolver.discover(work.resolve("actual"), List.of(new NestedJarResolver.Source(client), new NestedJarResolver.Source(curated.umbrella(), "selected-api", curated.sha256(), null)));
        var warnings = new ArrayList<Diagnostic>();
        var resolved = DependencyResolver.resolveFabricRuntime(closure.mods(), warnings::add);
        check(resolved.size() == 14 && closure.archives().size() == 14, "actual pinned client/API closure resolves all 14 mod archives");
        check(warnings.isEmpty(), "actual pinned closure emits no dependency warnings");
        List<String> ordered = ids(resolved);
        check(ordered.indexOf("fabric-api") < ordered.indexOf("pulse"), "fabric alias orders selected API before actual Pulse client");
        for (String module : List.of("fabric-command-api-v2", "fabric-lifecycle-events-v1", "fabric-networking-api-v1", "fabric-rendering-v1")) {
            check(ordered.indexOf("fabric-api-base") < ordered.indexOf(module), "actual Event API precedes " + module);
        }
        check(ordered.indexOf("fabric-lifecycle-events-v1") < ordered.indexOf("fabric-rendering-v1"), "actual lifecycle API precedes renderer");
        expect("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolve(closure.mods()), "actual closure still cannot run through API-only resolver");
        System.out.println("ACTUAL resolved order: " + ordered);
    }

    private static ModMetadata mod(String id, String version, Platform platform, List<Dependency> deps, Set<String> provides) {
        return new ModMetadata(id, version, platform, work.resolve(id + ".jar"), deps, List.of(), List.of(), "none", provides);
    }
    private static Dependency dep(String id, String constraint) { return new Dependency(id, constraint, false, false); }
    private static List<String> ids(List<ModMetadata> mods) { return mods.stream().map(ModMetadata::id).toList(); }
    private static List<String> codes(List<Diagnostic> diagnostics) { return diagnostics.stream().map(Diagnostic::code).toList(); }
    private static void check(boolean condition, String description) { if (!condition) throw new AssertionError(description); passed++; System.out.println("PASS " + description); }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static void expect(String code, Checked action, String description) throws Exception {
        try { action.run(); throw new AssertionError("Expected " + code + ": " + description); }
        catch (LoaderException expected) { check(expected.diagnostics().getFirst().code().equals(code), description + " (" + expected.diagnostics().getFirst().code() + ")"); }
    }
    private static void expectInvalid(Checked action, String description) throws Exception {
        try { action.run(); throw new AssertionError("Expected invalid predicate: " + description); }
        catch (IllegalArgumentException expected) { check(true, description); }
    }
}
