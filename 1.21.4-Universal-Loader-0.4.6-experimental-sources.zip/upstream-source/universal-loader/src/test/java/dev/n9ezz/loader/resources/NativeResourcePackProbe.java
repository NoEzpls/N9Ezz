package dev.n9ezz.loader.resources;

import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.zip.ZipFile;

/** Optional native Minecraft pack/profile verification, compiled with no game dependency. */
public final class NativeResourcePackProbe {
    private NativeResourcePackProbe() { }
    public static void main(String[] args) throws Exception {
        java.io.PrintStream output = System.out;
        try { run(args, output); }
        catch (Throwable error) { error.printStackTrace(output); throw error; }
    }
    private static void run(String[] args, java.io.PrintStream output) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("Arguments: client.jar mapped-game.jar libraries-directory");
        List<URL> urls = new ArrayList<>(); urls.add(Path.of(args[1]).toUri().toURL());
        try (var files = Files.walk(Path.of(args[2]))) {
            for (Path library : files.filter(path -> path.toString().endsWith(".jar")).sorted().toList()) urls.add(library.toUri().toURL());
        }
        Path temp = Files.createTempDirectory("n9ezz-native-resource-probe-");
        var mod = new ModMetadata("pulse", "1.5.3-n9ezz", Platform.FABRIC, Path.of(args[0]), List.of(), List.of(), List.of(), "intermediary", Set.of());
        try (URLClassLoader loader = new URLClassLoader(urls.toArray(URL[]::new), NativeResourcePackProbe.class.getClassLoader());
             ModResourcePacks resources = ModResourcePacks.prepare(temp, List.of(mod))) {
            Thread.currentThread().setContextClassLoader(loader);
            Class.forName("net.minecraft.class_155", true, loader).getMethod("method_36208").invoke(null);
            Class.forName("net.minecraft.class_2966", true, loader).getMethod("method_12851").invoke(null);
            Class<?> provider = Class.forName("net.minecraft.class_3285", true, loader);
            Object appended = ModResourcePacks.appendProviders(Array.newInstance(provider, 0));
            List<Object> profiles = new ArrayList<>();
            provider.getMethod("method_14453", Consumer.class).invoke(Array.get(appended, 0), (Consumer<Object>) profiles::add);
            if (profiles.size() != 1) throw new AssertionError("Expected one resource profile");
            Class<?> profileClass = Class.forName("net.minecraft.class_3288", true, loader);
            Object profile = profiles.getFirst();
            Object compatibility = profileClass.getMethod("method_14460").invoke(profile);
            boolean compatible = (boolean) compatibility.getClass().getMethod("method_14437").invoke(compatibility);
            boolean required = (boolean) profileClass.getMethod("method_14464").invoke(profile);
            boolean pinned = (boolean) profileClass.getMethod("method_14465").invoke(profile);
            if (!compatible || !required || !pinned) throw new AssertionError("Wrong pack properties");
            output.println("PASS native metadata accepted, compatible=true required=true pinned=true");
            Class<?> managerClass = Class.forName("net.minecraft.class_3283", true, loader);
            Object manager = managerClass.getConstructor(appended.getClass()).newInstance(appended);
            managerClass.getMethod("method_14445").invoke(manager);
            List<?> enabled = new ArrayList<>((java.util.Collection<?>) managerClass.getMethod("method_29210").invoke(manager));
            if (!enabled.equals(List.of("n9ezz/builtin/pulse"))) throw new AssertionError("Required pack was not auto-enabled: " + enabled);
            output.println("PASS native ResourcePackManager auto-enables own pack " + enabled);
            Object pack = profileClass.getMethod("method_14458").invoke(profile);
            Class<?> packClass = Class.forName("net.minecraft.class_3262", true, loader);
            Class<?> type = Class.forName("net.minecraft.class_3264", true, loader);
            Class<?> identifier = Class.forName("net.minecraft.class_2960", true, loader);
            Object id = identifier.getMethod("method_60654", String.class).invoke(null, "pulse:textures/splash_logo.png");
            Object supplier = packClass.getMethod("method_14405", type, identifier).invoke(pack, type.getField("field_14188").get(null), id);
            if (supplier == null) throw new AssertionError("Native pack cannot find Pulse splash");
            byte[] actual;
            try (InputStream input = (InputStream) Class.forName("net.minecraft.class_7367", true, loader).getMethod("get").invoke(supplier)) { actual = input.readAllBytes(); }
            byte[] expected;
            try (ZipFile original = new ZipFile(args[0]); InputStream input = original.getInputStream(original.getEntry("assets/pulse/textures/splash_logo.png"))) { expected = input.readAllBytes(); }
            if (!java.util.Arrays.equals(actual, expected)) throw new AssertionError("Native returned resource bytes differ");
            packClass.getMethod("close").invoke(pack);
            output.println("PASS native ZipResourcePack returns exact builtin splash bytes=" + actual.length);
        }
    }
}
