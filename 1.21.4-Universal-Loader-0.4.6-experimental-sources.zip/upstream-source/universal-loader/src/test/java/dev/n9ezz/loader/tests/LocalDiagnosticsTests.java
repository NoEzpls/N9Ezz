package dev.n9ezz.loader.tests;

import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.LocalDiagnostics;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/** Tests local diagnostic privacy, not packet shaping or anti-cheat evasion. */
public final class LocalDiagnosticsTests {
    private static int checks;
    private LocalDiagnosticsTests() { }

    public static void main(String[] args) throws Exception {
        for (String input : List.of("accessToken=unregistered-secret", "access_token:unregistered-secret",
                "--accessToken unregistered-secret", "--api-key=unregistered-secret", "password='unregistered-secret'",
                "{\"clientSecret\":\"unregistered-secret\"}", "Authorization: Bearer unregistered-secret",
                "Authorization: Basic dXNlcjpwYXNz", "https://example.org/check?token=unregistered-secret&requestId=17")) {
            String safe = LocalDiagnostics.redact(input);
            check(!safe.contains("unregistered-secret") && !safe.contains("dXNlcjpwYXNz") && safe.contains("[REDACTED]"), "explicit credential field redacted: " + input.split("[=: ]", 2)[0]);
            check(LocalDiagnostics.redact(safe).equals(safe), "redaction remains idempotent");
        }
        check(LocalDiagnostics.redact("{\"password\":\"not-public\"}").equals("{\"password\":\"[REDACTED]\"}"), "quoted value keeps JSON structure");
        for (String input : List.of("Bearer bare-unregistered-secret", "bearer short", "Authorization: ApiKey api-credential",
                "Authorization: opaque-header-credential", "{\"Authorization\":\"ApiKey api-credential\"}",
                "Authorization: ApiKey \"quoted credential with spaces\"", "clientToken=client-credential", "id_token=id-credential",
                "--client-token client-credential", "--idToken=id-credential")) {
            String safe = LocalDiagnostics.redact(input);
            check(safe.contains("[REDACTED]") && !safe.contains("credential") && !safe.contains("unregistered-secret") && !safe.contains("short") && !safe.contains("with spaces"), "additional explicit credential syntax is redacted");
            check(LocalDiagnostics.redact(safe).equals(safe), "additional syntax remains idempotent");
        }
        check(LocalDiagnostics.redact("{\"password\":\"first\\\"second\"}").equals("{\"password\":\"[REDACTED]\"}"), "escaped JSON quote does not leak a password suffix");
        check(LocalDiagnostics.redact("{\"clientToken\":\"first\\\\second\"}").equals("{\"clientToken\":\"[REDACTED]\"}"), "escaped JSON backslash preserves closing quote detection");
        check(LocalDiagnostics.redact("password='first\\'second with spaces'").equals("password='[REDACTED]'"), "escaped single quote remains one credential value");
        check(LocalDiagnostics.redact("Authorization: \"Bearer first\\\"second\"").equals("Authorization: \"Bearer [REDACTED]\""), "quoted authorization retains its scheme and quote structure");
        String frame = "\n\tat Example.call(Example.java:7)";
        check(LocalDiagnostics.redact("bad password=\"first second" + frame).equals("bad password=\"[REDACTED]" + frame), "unclosed quoted value masks the remaining error line and retains frames");
        check(LocalDiagnostics.redact("bad token='first second\r\nnext diagnostic").equals("bad token='[REDACTED]\r\nnext diagnostic"), "malformed single quote does not consume the next diagnostic line");
        check(LocalDiagnostics.redact("empty token=\"\" password='' Authorization: Bearer\nnext diagnostic").equals("empty token=\"\" password='' Authorization: [REDACTED]\nnext diagnostic"), "empty values and incomplete schemes terminate without consuming later lines");
        String ordinary = "MISSING_DEPENDENCY mod=pulse phase=common /game/mods/test.jar https://example.org/api/check?requestId=17 ticks=4000";
        check(LocalDiagnostics.redact(ordinary).equals(ordinary), "codes, phases, paths, endpoints and counters stay visible");
        String identifiers = "TokenProvider passwordReset id_token_count=9 BearerTokenProvider /game/clientToken.jar AuthorizationFactory https://example.org/api/password-reset?requestId=17";
        check(LocalDiagnostics.redact(identifiers).equals(identifiers), "ordinary identifiers, filenames and endpoint names are not credential fields");
        check(LocalDiagnostics.redact("Authorization: ApiKey key-value endpoint=https://example.org/api/check?requestId=17").equals("Authorization: ApiKey [REDACTED] endpoint=https://example.org/api/check?requestId=17"), "authorization masks only its credential and retains the following endpoint");
        check(LocalDiagnostics.redact(null) == null, "null diagnostic message supported");

        String credential = "private$credential\\with[regex]+chars";
        String[] arguments = {"--accessToken", credential, "--refresh-token=private-refresh-credential", "--gameDir", "/game"};
        String[] before = arguments.clone();
        LocalDiagnostics.observeArguments(arguments);
        check(Arrays.equals(arguments, before), "Minecraft argument array is unchanged");
        check(LocalDiagnostics.redact("unexpected value " + credential).equals("unexpected value [REDACTED]"), "observed credential removed by literal replacement");
        check(!LocalDiagnostics.redact("private-refresh-credential").contains("private-refresh-credential"), "equals-style credential argument observed");
        String[] spaced = {"--password", "top secret pass", "--client-token", "observed-client-value", "--id_token=observed-id-value"};
        String[] spacedBefore = spaced.clone();
        LocalDiagnostics.observeArguments(spaced);
        check(LocalDiagnostics.redact("password=top secret pass endpoint=https://example.org/check").equals("password=[REDACTED] endpoint=https://example.org/check"), "field masking cannot strand the suffix of an observed multiword secret");
        check(LocalDiagnostics.redact("unexpected top secret pass, observed-client-value, observed-id-value").equals("unexpected [REDACTED], [REDACTED], [REDACTED]"), "observed password and additional token arguments mask bare values");
        check(Arrays.equals(spaced, spacedBefore), "additional token and multiword arguments remain unchanged");
        LocalDiagnostics.observeArguments(new String[] {"--password", "$literal\\regex[chars]+.*"});
        check(LocalDiagnostics.redact("password=$literal\\regex[chars]+.*").equals("password=[REDACTED]"), "metacharacter literal is matched before structural ranges are rendered");
        LocalDiagnostics.observeArguments(new String[] {"--accessToken", "0", "--password", "a", "--token", "", "--apiKey"});
        check(LocalDiagnostics.redact("ticks=4000, 0 failures, apple").equals("ticks=4000, 0 failures, apple"), "short placeholders never erase unrelated text");
        check(LocalDiagnostics.redact("accessToken=0 password=a").equals("accessToken=[REDACTED] password=[REDACTED]"), "short named credentials are still redacted");
        LocalDiagnostics.observeArguments(new String[] {"--token", "abcdefgh", "--sessionToken", "abcdefgh-longer"});
        check(LocalDiagnostics.redact("abcdefgh-longer").equals("[REDACTED]"), "longest overlapping credential removed first");
        LocalDiagnostics.observeArguments(new String[] {"--password", "REDACTED", "--token", "[REDACT"});
        String marker = "password=[REDACTED], Authorization: Bearer [REDACTED], \"[REDACTED]\"";
        check(LocalDiagnostics.redact(marker).equals(marker), "observed marker substrings never rewrite existing redaction markers");
        String freshMarker = LocalDiagnostics.redact("password=fresh-sensitive-value");
        check(freshMarker.equals("password=[REDACTED]") && LocalDiagnostics.redact(freshMarker).equals(freshMarker), "marker-like observed credentials cannot break idempotence");
        LocalDiagnostics.observeArguments(new String[] {"--password", "prefix[REDACTED]suffix"});
        check(LocalDiagnostics.redact("prefix[REDACTED]suffix").equals("[REDACTED]"), "full observed credential containing a marker is still removed");

        var cause = new IllegalArgumentException("Authorization: Bearer nested-sensitive-token");
        var error = new IllegalStateException("operation failed with " + credential, cause);
        error.addSuppressed(new IllegalArgumentException("password=suppressed-secret"));
        String trace = LocalDiagnostics.throwableText(error);
        check(!trace.contains(credential) && !trace.contains("nested-sensitive-token") && !trace.contains("suppressed-secret"), "full cause and suppressed traces are redacted");
        check(trace.contains("IllegalStateException") && trace.contains("Caused by") && trace.contains("Suppressed") && trace.contains("LocalDiagnosticsTests.main"), "exception types, frames and causal structure preserved");
        cause.initCause(error);
        check(LocalDiagnostics.throwableText(error).contains("CIRCULAR REFERENCE"), "cyclic exception trace terminates normally");
        var bytes = new ByteArrayOutputStream();
        LocalDiagnostics.printThrowable(error, new PrintStream(bytes, true, StandardCharsets.UTF_8));
        check(!bytes.toString(StandardCharsets.UTF_8).contains(credential), "actual output stream receives redacted trace");
        var diagnostic = new Diagnostic("ENTRYPOINT_FAILED", "accessToken=not-for-disk", "pulse", "common", Path.of("/game/mods/pulse.jar"));
        check(!diagnostic.message().contains("not-for-disk") && diagnostic.toString().contains("ENTRYPOINT_FAILED [mod=pulse] [phase=common]"), "structured Diagnostic keeps context and redacts message");

        Process process = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin", "java").toString(),
                "-cp", System.getProperty("java.class.path"), "dev.n9ezz.loader.launch.Main", "--accessToken=cli-secret-not-for-output")
                .redirectErrorStream(true).start();
        String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        check(process.waitFor() == 1 && !output.contains("cli-secret-not-for-output") && output.contains("Unknown operation") && output.contains("Main.main"), "CLI fatal boundary preserves failure and hides credential");
        LocalDiagnostics.observeArguments(new String[] {"--password", "password"});
        String collision = LocalDiagnostics.redact("password=unregistered-collision-value endpoint=https://example.org/check");
        check(!collision.contains("unregistered-collision-value") && collision.contains("endpoint=https://example.org/check"), "credential equal to a field name cannot suppress detection of its original value");
        check(LocalDiagnostics.redact(collision).equals(collision), "field-name collision is still idempotent");
        System.out.println("PASS " + checks + " local diagnostic privacy checks; network/gameplay unchanged");
    }

    private static void check(boolean result, String label) {
        if (!result) throw new AssertionError(label);
        checks++;
    }
}
