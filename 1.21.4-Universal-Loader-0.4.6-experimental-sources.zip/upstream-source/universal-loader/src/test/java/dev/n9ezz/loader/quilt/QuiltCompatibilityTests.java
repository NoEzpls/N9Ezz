package dev.n9ezz.loader.quilt;

import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.core.UnifiedClassLoader;
import dev.n9ezz.loader.core.EventBus;
import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.compat.CompatibilityDispatcher;
import dev.n9ezz.loader.fml.FmlCompatibilityRuntime;
import dev.n9ezz.loader.fabric.FabricMappingResolver;
import dev.n9ezz.loader.mapping.GameMappings;
import dev.n9ezz.loader.metadata.Dependency;
import dev.n9ezz.loader.metadata.Entrypoint;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import javax.tools.ToolProvider;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.loader.api.QuiltLoader;

/** Exercises actual archive provenance, lifecycle binding, closure and fail-closed Quilt ABI checks. */
public final class QuiltCompatibilityTests {
    private static int passed;
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private QuiltCompatibilityTests() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 0) throw new IllegalArgumentException("No arguments expected");
        Path directory = Files.createTempDirectory("n9ezz-quilt-contract-");
        Path fixture = jar(directory.resolve("fixture.jar"), metadata(true), plainClass(), Map.of());
        ModMetadata mod = mod(fixture, "intermediary", "=0.30.1", Set.of("test_alias"));
        var mappings = new FabricMappingResolver(GameMappings.index(), "intermediary");
        TransformationPipeline pipeline = new TransformationPipeline(); pipeline.freeze();
        check("Quilt service access fails before install", () -> expect(IllegalStateException.class, QuiltLoader::getAllMods));
        check("opt-in archive accepts only its registry-independent ABI", () -> QuiltGameContract.validate(mod));
        try (UnifiedClassLoader loader = new UnifiedClassLoader(List.of(fixture), QuiltCompatibilityTests.class.getClassLoader(), pipeline)) {
            Class<?> ownClass = loader.loadClass("quiltfixture.Owned");
            Object own = ownClass.getConstructor().newInstance();
            var binding = QuiltRuntime.install(directory, List.of(mod), loader, mappings);
            var retained = QuiltRuntime.service();
            ModContainer container = QuiltRuntime.container(mod);
            check("canonical containers preserve ids aliases and actual group/name/description", () -> {
                same(container, QuiltLoader.getModContainer("test_alias").orElseThrow());
                same(container, QuiltLoader.getModContainer("quilt_test").orElseThrow());
                eq("quilt_test", container.metadata().id()); eq("1.0.0", container.metadata().version().raw());
                eq("test.example", container.metadata().group()); eq("Quilt Test", container.metadata().name());
                eq("Fixture metadata", container.metadata().description()); eq(4, QuiltLoader.getAllMods().size());
            });
            check("archive paths and source type expose the actual owned jar", () -> {
                eq(ModContainer.BasicSourceType.NORMAL_QUILT, container.getSourceType()); same(loader, container.getClassLoader());
                eq(List.of(List.of(fixture.toRealPath())), container.getSourcePaths());
                eq(metadata(true), Files.readString(container.getPath("quilt.mod.json"))); eq(true, Files.isDirectory(container.rootPath()));
            });
            check("archive path traversal absolute malformed and backslash paths fail", () -> {
                for (String path : List.of("../outside", "/absolute", "a/../outside", "a\\outside", "a//b", "./root", "", "a/"))
                    expect(IllegalArgumentException.class, () -> container.getPath(path));
            });
            check("collection source-path and mod list views are immutable", () -> {
                expect(UnsupportedOperationException.class, () -> QuiltLoader.getAllMods().clear());
                expect(UnsupportedOperationException.class, () -> container.getSourcePaths().clear());
                expect(UnsupportedOperationException.class, () -> container.getSourcePaths().getFirst().clear());
            });
            check("only explicit loader/minecraft/java builtin ABI identities exist", () -> {
                eq("0.30.1", QuiltLoader.getModContainer("quilt_loader").orElseThrow().metadata().version().raw());
                eq(false, QuiltLoader.isModLoaded("qsl")); eq(false, QuiltLoader.isModLoaded("quilt_base"));
                var builtin = QuiltLoader.getModContainer("quilt_loader").orElseThrow();
                eq(ModContainer.BasicSourceType.BUILTIN, builtin.getSourceType()); eq(null, builtin.getClassLoader());
                eq(List.of(), builtin.getSourcePaths()); expect(UnsupportedOperationException.class, builtin::rootPath);
            });
            check("directories and game version remain the pinned instance values", () -> {
                eq(directory.toRealPath(), QuiltLoader.getGameDir()); eq(directory.toRealPath().resolve("config"), QuiltLoader.getConfigDir());
                eq(directory.toRealPath().resolve(".n9ezz/cache"), QuiltLoader.getCacheDir());
                eq("1.21.11", QuiltLoader.getRawGameVersion()); eq("1.21.11", QuiltLoader.getNormalizedGameVersion());
                eq(false, QuiltLoader.isDevelopmentEnvironment()); eq(null, QuiltLoader.getGameInstance());
            });
            check("mapping resolver delegates own index and rejects unsupported named namespace", () -> {
                var quilt = QuiltLoader.getMappingResolver(); eq("intermediary", quilt.getCurrentRuntimeNamespace());
                eq(Set.copyOf(mappings.getNamespaces()), Set.copyOf(quilt.getNamespaces()));
                String official = GameMappings.index().mapClass("intermediary", "official", "net/minecraft/class_310");
                eq("net.minecraft.class_310", quilt.mapClassName("official", official.replace('/', '.')));
                expect(IllegalArgumentException.class, () -> quilt.mapClassName("named", "net.minecraft.client.MinecraftClient"));
            });
            check("class-based ownership requires exact shared classloader and actual source", () -> {
                same(container, QuiltLoader.getModContainer(ownClass).orElseThrow()); eq(true, QuiltLoader.getModContainer(QuiltCompatibilityTests.class).isEmpty());
                try (URLClassLoader shadow = new URLClassLoader(new java.net.URL[] {fixture.toUri().toURL()}, null)) {
                    eq(true, QuiltLoader.getModContainer(shadow.loadClass("quiltfixture.Owned")).isEmpty());
                }
            });
            check("metadata cannot impersonate another version or source", () -> {
                ModMetadata wrongVersion = new ModMetadata(mod.id(), "9.0.0", Platform.QUILT, fixture, mod.dependencies(), List.of(), List.of(), "none", Set.of());
                expect(IllegalArgumentException.class, () -> QuiltRuntime.container(wrongVersion));
                Path other = jar(directory.resolve("other.jar"), metadata(true), plainClass(), Map.of());
                expect(IllegalArgumentException.class, () -> QuiltRuntime.container(mod(other, "none", "=0.30.1", Set.of())));
            });
            check("game binds once before callbacks and must use the actual shared loader", () -> {
                expect(IllegalArgumentException.class, () -> QuiltRuntime.bindGame(new Object()));
                QuiltRuntime.bindGame(own); same(own, QuiltLoader.getGameInstance());
                expect(IllegalStateException.class, () -> QuiltRuntime.bindGame(own));
            });
            check("concurrent installation attempts fail without replacing active service", () -> {
                AtomicInteger rejected = new AtomicInteger(); List<Thread> threads = new ArrayList<>(); AtomicReference<Throwable> failure = new AtomicReference<>();
                CountDownLatch gate = new CountDownLatch(1);
                for (int index = 0; index < 8; index++) {
                    Thread thread = new Thread(() -> {
                        try { gate.await(); QuiltRuntime.install(directory, List.of(mod), loader, mappings); failure.set(new AssertionError("Concurrent install replaced runtime")); }
                        catch (IllegalStateException expected) { rejected.incrementAndGet(); }
                        catch (Throwable unexpected) { failure.set(unexpected); }
                    }); threads.add(thread); thread.start();
                }
                gate.countDown(); for (Thread thread : threads) thread.join(); if (failure.get() != null) throw new AssertionError(failure.get());
                eq(8, rejected.get()); same(retained, QuiltRuntime.service());
            });
            binding.close();
            check("closing withdraws facade and invalidates retained live archive views", () -> {
                expect(IllegalStateException.class, QuiltLoader::getAllMods); expect(IllegalStateException.class, retained::getGameInstance);
                expect(IllegalStateException.class, container::rootPath);
            });
            check("stale registration close cannot withdraw a subsequent runtime", () -> {
                try (var next = QuiltRuntime.install(directory, List.of(mod), loader, mappings)) {
                    binding.close(); eq(true, QuiltLoader.isModLoaded("quilt_test"));
                }
            });
            check("failed duplicate alias installation closes archives and publishes no service", () -> {
                ModMetadata duplicate = new ModMetadata("duplicate", "1.0.0", Platform.QUILT, fixture,
                        List.of(), List.of(), List.of(), "none", Set.of("quilt_test"));
                expect(IOException.class, () -> QuiltRuntime.install(directory, List.of(mod, duplicate), loader, mappings));
                expect(IllegalStateException.class, QuiltLoader::getAllMods);
                try (var next = QuiltRuntime.install(directory, List.of(mod), loader, mappings)) { eq(true, QuiltLoader.isModLoaded("quilt_test")); }
            });
        }
        check("missing explicit opt-in fails before user code", () -> {
            Path missing = jar(directory.resolve("missing-contract.jar"), metadata(false), plainClass(), Map.of());
            expectCode("QUILT_CONTRACT_REQUIRED", () -> QuiltGameContract.validate(mod(missing, "none", "=0.30.1", Set.of())));
        });
        check("unsupported namespace and loader ABI constraints fail", () -> {
            expectCode("UNSUPPORTED_QUILT_NAMESPACE", () -> QuiltGameContract.validate(mod(fixture, "hashed", "=0.30.1", Set.of())));
            expectCode("UNSUPPORTED_QUILT_VERSION", () -> QuiltGameContract.validate(mod(fixture, "none", ">=0.31.0", Set.of())));
            ModMetadata noLoader = new ModMetadata("quilt_test", "1.0.0", Platform.QUILT, fixture, List.of(), List.of(), List.of(), "none", Set.of());
            expectCode("QUILT_ABI_DEPENDENCY_REQUIRED", () -> QuiltGameContract.validate(noLoader));
        });
        check("QSL library dependencies and aliases cannot be invented", () -> {
            ModMetadata qsl = new ModMetadata(mod.id(), mod.version(), Platform.QUILT, fixture,
                    List.of(new Dependency("quilt_loader", "=0.30.1", false, false), new Dependency("qsl", "*", true, false)), List.of(), List.of(), "none", Set.of());
            expectCode("UNSUPPORTED_QSL_LIBRARY", () -> QuiltGameContract.validate(qsl));
            expectCode("UNSUPPORTED_QSL_LIBRARY", () -> QuiltGameContract.validate(mod(fixture, "none", "=0.30.1", Set.of("quilt_loader"))));
        });
        check("allowed exact Quilt method and callback references pass preflight", () -> {
            eq(Set.of(), QuiltGameContract.unsupportedReferences(referenceClass("allowed", method -> {
                method.visitLdcInsn("quilt_test"); method.visitMethodInsn(Opcodes.INVOKESTATIC, "org/quiltmc/loader/api/QuiltLoader", "isModLoaded", "(Ljava/lang/String;)Z", false); method.visitInsn(Opcodes.POP);
                method.visitLdcInsn(Type.getType("Lorg/quiltmc/qsl/base/api/entrypoint/client/ClientModInitializer;")); method.visitInsn(Opcodes.POP);
            })));
        });
        check("unavailable exact Quilt member descriptors are rejected", () -> {
            String owner = "org/quiltmc/loader/api/QuiltLoader";
            var bad = QuiltGameContract.unsupportedReferences(referenceClass("missing", method -> {
                method.visitMethodInsn(Opcodes.INVOKESTATIC, owner, "getObjectShare", "()Lnet/fabricmc/loader/api/ObjectShare;", false); method.visitInsn(Opcodes.POP);
            })); eq(true, bad.stream().anyMatch(value -> value.contains("getObjectShare")));
        });
        check("known method with wrong invocation kind fails the exact ABI", () -> {
            var bad = QuiltGameContract.unsupportedReferences(referenceClass("invocationKind", method -> {
                method.visitInsn(Opcodes.ACONST_NULL); method.visitLdcInsn("quilt_test");
                method.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "org/quiltmc/loader/api/QuiltLoader", "isModLoaded", "(Ljava/lang/String;)Z", false);
                method.visitInsn(Opcodes.POP);
            })); eq(true, bad.stream().anyMatch(value -> value.contains("isModLoaded")));
        });
        check("unsupported QSL and loader implementation classes are rejected", () -> {
            for (String owner : List.of("org/quiltmc/qsl/lifecycle/api/client/event/ClientTickEvents", "org/quiltmc/loader/impl/QuiltLoaderImpl"))
                eq(true, QuiltGameContract.unsupportedReferences(referenceClass("type", method -> { method.visitLdcInsn(Type.getObjectType(owner)); method.visitInsn(Opcodes.POP); })).contains(owner.replace('/', '.')));
        });
        check("method handles expose unavailable exact method references", () -> {
            var references = QuiltGameContract.unsupportedReferences(referenceClass("handle", method -> {
                method.visitLdcInsn(new Handle(Opcodes.H_INVOKESTATIC, "org/quiltmc/loader/api/Version", "of", "(Ljava/lang/String;)Lorg/quiltmc/loader/api/Version;", true)); method.visitInsn(Opcodes.POP);
            })); eq(true, references.stream().anyMatch(value -> value.contains("Version.of")));
        });
        check("constant-dynamic nested bootstrap references are validated", () -> {
            var references = QuiltGameContract.unsupportedReferences(referenceClass("dynamic", method -> {
                Handle bootstrap = new Handle(Opcodes.H_INVOKESTATIC, "java/lang/invoke/ConstantBootstraps", "nullConstant", "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;", false);
                method.visitLdcInsn(new ConstantDynamic("quilt", "Ljava/lang/Object;", bootstrap,
                        new Handle(Opcodes.H_INVOKESTATIC, "org/quiltmc/loader/api/QuiltLoader", "getObjectShare", "()Lnet/fabricmc/loader/api/ObjectShare;", false))); method.visitInsn(Opcodes.POP);
            })); eq(true, references.stream().anyMatch(value -> value.contains("getObjectShare")));
        });
        check("unsupported references in non-entrypoint classes fail whole archive preflight", () -> {
            byte[] bad = referenceClass("hidden", method -> { method.visitLdcInsn(Type.getObjectType("org/quiltmc/qsl/registry/api/event/RegistryEvents")); method.visitInsn(Opcodes.POP); });
            Path hidden = jar(directory.resolve("hidden.jar"), metadata(true), plainClass(), Map.of("quiltfixture/hidden.class", bad));
            expectCode("UNSUPPORTED_QUILT_API", () -> QuiltGameContract.validate(mod(hidden, "none", "=0.30.1", Set.of())));
        });
        check("multi-release Quilt game classes fail closed", () -> {
            Path multi = jar(directory.resolve("multi.jar"), metadata(true), plainClass(), Map.of("META-INF/versions/21/quiltfixture/Owned.class", plainClass()));
            expectCode("UNSUPPORTED_QUILT_MULTI_RELEASE", () -> QuiltGameContract.validate(mod(multi, "none", "=0.30.1", Set.of())));
        });
        dispatcherTests(directory, mappings);
        System.out.println("Quilt compatibility: " + passed + " passed");
    }
    private static void dispatcherTests(Path directory, FabricMappingResolver mappings) throws Exception {
        Path callbackJar = callbackJar(directory);
        ModMetadata callback = new ModMetadata("quilt_test", "1.0.0", Platform.QUILT, callbackJar,
                List.of(new Dependency("quilt_loader", "=0.30.1", false, false)),
                List.of(new Entrypoint("common", "quiltfixture.Callback", "quilt-init"),
                        new Entrypoint("client", "quiltfixture.Callback", "quilt-client-init")),
                List.of(), "none", Set.of());
        ClassLoader caller = Thread.currentThread().getContextClassLoader();
        check("game dispatcher uses one initializer and canonical container for both phases exactly once", () -> {
            try (var loader = callbackLoader(callbackJar); var fml = new FmlCompatibilityRuntime(List.of(callback));
                    var binding = QuiltRuntime.install(directory, List.of(callback), loader, mappings)) {
                QuiltGameContract.validate(callback);
                var dispatcher = new CompatibilityDispatcher(Set.of(), fml);
                var context = new ModContext(callback.id(), directory, new EventBus());
                dispatcher.initialize(callback, "common", loader, context); same(caller, Thread.currentThread().getContextClassLoader());
                dispatcher.initialize(callback, "client", loader, context); same(caller, Thread.currentThread().getContextClassLoader());
                dispatcher.initialize(callback, "common", loader, context); dispatcher.initialize(callback, "client", loader, context);
                Class<?> fixture = loader.loadClass("quiltfixture.Callback");
                eq(1, fixture.getField("constructed").get(null)); eq(1, fixture.getField("common").get(null)); eq(1, fixture.getField("client").get(null));
                same(fixture.getField("commonInstance").get(null), fixture.getField("clientInstance").get(null));
                same(QuiltRuntime.container(callback), fixture.getField("commonContainer").get(null));
                same(fixture.getField("commonContainer").get(null), fixture.getField("clientContainer").get(null));
            }
        });
        for (String phase : List.of("common", "client")) check("failed Quilt " + phase + " callback is preserved without retry and restores TCCL", () -> {
            System.setProperty("quilt.dispatch.failure", phase);
            try (var loader = callbackLoader(callbackJar); var fml = new FmlCompatibilityRuntime(List.of(callback));
                    var binding = QuiltRuntime.install(directory, List.of(callback), loader, mappings)) {
                var dispatcher = new CompatibilityDispatcher(Set.of(), fml);
                var context = new ModContext(callback.id(), directory, new EventBus());
                if (phase.equals("client")) dispatcher.initialize(callback, "common", loader, context);
                LoaderException failure = captureCode("ENTRYPOINT_FAILED", () -> dispatcher.initialize(callback, phase, loader, context));
                eq(phase + " callback failure", failure.getCause().getMessage());
                same(failure, captureCode("ENTRYPOINT_FAILED", () -> dispatcher.initialize(callback, phase, loader, context)));
                same(caller, Thread.currentThread().getContextClassLoader());
                Class<?> fixture = loader.loadClass("quiltfixture.Callback");
                eq(1, fixture.getField("constructed").get(null)); eq(1, fixture.getField(phase).get(null));
            } finally { System.clearProperty("quilt.dispatch.failure"); }
        });
        check("failed Quilt constructor is attempted once with its original cause and caller loader restored", () -> {
            System.setProperty("quilt.dispatch.failure", "constructor");
            try (var loader = callbackLoader(callbackJar); var fml = new FmlCompatibilityRuntime(List.of(callback));
                    var binding = QuiltRuntime.install(directory, List.of(callback), loader, mappings)) {
                var dispatcher = new CompatibilityDispatcher(Set.of(), fml);
                var context = new ModContext(callback.id(), directory, new EventBus());
                LoaderException failure = captureCode("ENTRYPOINT_CONSTRUCTION_FAILED", () -> dispatcher.initialize(callback, "common", loader, context));
                eq("constructor failure", failure.getCause().getMessage());
                same(failure, captureCode("ENTRYPOINT_CONSTRUCTION_FAILED", () -> dispatcher.initialize(callback, "common", loader, context)));
                same(caller, Thread.currentThread().getContextClassLoader());
                Class<?> fixture = loader.loadClass("quiltfixture.Callback");
                eq(1, fixture.getField("constructed").get(null)); eq(0, fixture.getField("common").get(null));
            } finally { System.clearProperty("quilt.dispatch.failure"); }
        });
        check("reentrant Quilt common initialization cannot create or invoke a second initializer", () -> {
            try (var loader = callbackLoader(callbackJar); var fml = new FmlCompatibilityRuntime(List.of(callback));
                    var binding = QuiltRuntime.install(directory, List.of(callback), loader, mappings)) {
                var dispatcher = new CompatibilityDispatcher(Set.of(), fml);
                var context = new ModContext(callback.id(), directory, new EventBus());
                Class<?> fixture = loader.loadClass("quiltfixture.Callback");
                fixture.getField("reentrant").set(null, (Runnable) () -> {
                    try { dispatcher.initialize(callback, "common", loader, context); }
                    catch (Exception failure) { throw new AssertionError(failure); }
                });
                dispatcher.initialize(callback, "common", loader, context);
                eq(1, fixture.getField("constructed").get(null)); eq(1, fixture.getField("common").get(null));
                same(caller, Thread.currentThread().getContextClassLoader());
            }
        });
        check("flat and Fabric-only dispatchers still reject the Quilt game client adapter", () -> {
            try (var loader = callbackLoader(callbackJar)) {
                var context = new ModContext(callback.id(), directory, new EventBus());
                for (var dispatcher : List.of(new CompatibilityDispatcher(), new CompatibilityDispatcher(Set.of())))
                    expectCode("UNSUPPORTED_ADAPTER", () -> dispatcher.initialize(callback, "client", loader, context));
                eq(0, loader.loadClass("quiltfixture.Callback").getField("constructed").get(null));
                same(caller, Thread.currentThread().getContextClassLoader());
            }
        });
        check("invalid Quilt context fails before claiming the valid initialization attempt", () -> {
            try (var loader = callbackLoader(callbackJar); var fml = new FmlCompatibilityRuntime(List.of(callback));
                    var binding = QuiltRuntime.install(directory, List.of(callback), loader, mappings)) {
                var dispatcher = new CompatibilityDispatcher(Set.of(), fml);
                expectCode("INVALID_MOD_CONTEXT", () -> dispatcher.initialize(callback, "common", loader, new ModContext("other", directory, new EventBus())));
                dispatcher.initialize(callback, "common", loader, new ModContext(callback.id(), directory, new EventBus()));
                eq(1, loader.loadClass("quiltfixture.Callback").getField("common").get(null));
                same(caller, Thread.currentThread().getContextClassLoader());
            }
        });
    }
    private static UnifiedClassLoader callbackLoader(Path jar) throws IOException {
        TransformationPipeline pipeline = new TransformationPipeline(); pipeline.freeze();
        return new UnifiedClassLoader(List.of(jar), QuiltCompatibilityTests.class.getClassLoader(), pipeline);
    }
    private static Path callbackJar(Path directory) throws IOException {
        Path source = directory.resolve("callback-source/quiltfixture/Callback.java"); Files.createDirectories(source.getParent());
        Files.writeString(source, """
                package quiltfixture;
                import org.quiltmc.loader.api.ModContainer;
                import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
                import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;
                public final class Callback implements ModInitializer, ClientModInitializer {
                    public static int constructed, common, client;
                    public static Object commonInstance, clientInstance;
                    public static ModContainer commonContainer, clientContainer;
                    public static Runnable reentrant;
                    public Callback() {
                        constructed++; context();
                        if ("constructor".equals(System.getProperty("quilt.dispatch.failure"))) throw new IllegalStateException("constructor failure");
                    }
                    private void context() {
                        if (Thread.currentThread().getContextClassLoader() != getClass().getClassLoader()) throw new AssertionError("wrong callback context loader");
                    }
                    public void onInitialize(ModContainer container) {
                        context(); common++; commonInstance = this; commonContainer = container;
                        if (reentrant != null) reentrant.run();
                        if ("common".equals(System.getProperty("quilt.dispatch.failure"))) throw new IllegalStateException("common callback failure");
                    }
                    public void onInitializeClient(ModContainer container) {
                        context(); client++; clientInstance = this; clientContainer = container;
                        if ("client".equals(System.getProperty("quilt.dispatch.failure"))) throw new IllegalStateException("client callback failure");
                    }
                }
                """);
        Path output = directory.resolve("callback-classes"); Files.createDirectories(output);
        var compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("Quilt dispatcher tests require full JDK 21");
        int exit = compiler.run(null, null, null, "--release", "21", "-proc:none", "-cp", System.getProperty("java.class.path"), "-d", output.toString(), source.toString());
        if (exit != 0) throw new IOException("Quilt callback fixture compilation failed: " + exit);
        return jar(directory.resolve("callback.jar"), metadata(true), plainClass(),
                Map.of("quiltfixture/Callback.class", Files.readAllBytes(output.resolve("quiltfixture/Callback.class"))));
    }
    private static ModMetadata mod(Path jar, String namespace, String loaderConstraint, Set<String> aliases) {
        return new ModMetadata("quilt_test", "1.0.0", Platform.QUILT, jar,
                List.of(new Dependency("quilt_loader", loaderConstraint, false, false)), List.of(), List.of(), namespace, aliases);
    }
    private static String metadata(boolean optIn) {
        return "{\"schema_version\":1,\"quilt_loader\":{\"group\":\"test.example\",\"id\":\"quilt_test\",\"version\":\"1.0.0\",\"metadata\":{\"name\":\"Quilt Test\",\"description\":\"Fixture metadata\"}}"
                + (optIn ? ",\"n9ezz\":{\"compatibility\":\"quilt-lifecycle-v1\"}" : "") + "}";
    }
    private static Path jar(Path path, String metadata, byte[] fixture, Map<String, byte[]> additional) throws IOException {
        try (JarOutputStream archive = new JarOutputStream(Files.newOutputStream(path))) {
            Map<String, byte[]> entries = new java.util.TreeMap<>(additional);
            entries.put("quilt.mod.json", metadata.getBytes(StandardCharsets.UTF_8)); entries.put("quiltfixture/Owned.class", fixture);
            for (var entry : entries.entrySet()) { archive.putNextEntry(new JarEntry(entry.getKey())); archive.write(entry.getValue()); archive.closeEntry(); }
        }
        return path;
    }
    private static byte[] plainClass() { return referenceClass("Owned", ignored -> {}); }
    private static byte[] referenceClass(String name, java.util.function.Consumer<org.objectweb.asm.MethodVisitor> body) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "quiltfixture/" + name, null, "java/lang/Object", null);
        var init = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null); init.visitCode(); init.visitVarInsn(Opcodes.ALOAD, 0);
        init.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false); init.visitInsn(Opcodes.RETURN); init.visitMaxs(0, 0); init.visitEnd();
        var method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "references", "()V", null, null);
        method.visitCode(); body.accept(method); method.visitInsn(Opcodes.RETURN); method.visitMaxs(0, 0); method.visitEnd(); writer.visitEnd(); return writer.toByteArray();
    }
    private static void check(String name, Checked task) throws Exception { task.run(); passed++; System.out.println("PASS " + name); }
    private static void expect(Class<? extends Throwable> type, Checked task) throws Exception {
        try { task.run(); } catch (Throwable failure) { if (type.isInstance(failure)) return; throw failure; }
        throw new AssertionError("Expected " + type.getName());
    }
    private static void expectCode(String code, Checked task) throws Exception {
        captureCode(code, task);
    }
    private static LoaderException captureCode(String code, Checked task) throws Exception {
        try { task.run(); } catch (LoaderException failure) {
            if (failure.diagnostics().stream().anyMatch(diagnostic -> diagnostic.code().equals(code))) return failure;
            throw new AssertionError("Expected " + code + ", got " + failure.diagnostics(), failure);
        }
        throw new AssertionError("Expected " + code);
    }
    private static void same(Object expected, Object actual) { if (expected != actual) throw new AssertionError("Expected identical instances"); }
    private static void eq(Object expected, Object actual) { if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual); }
}
