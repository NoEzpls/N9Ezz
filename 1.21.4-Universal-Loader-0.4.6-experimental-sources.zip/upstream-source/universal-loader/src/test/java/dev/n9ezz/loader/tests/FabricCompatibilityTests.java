package dev.n9ezz.loader.tests;

import dev.n9ezz.loader.fabric.FabricMappingResolver;
import dev.n9ezz.loader.fabric.FabricRuntime;
import dev.n9ezz.loader.fabric.GameInitializationHook;
import dev.n9ezz.loader.fabric.SelectedFabricApi;
import dev.n9ezz.loader.mapping.GameMappings;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.jar.JarFile;
import java.util.zip.ZipFile;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;

/** Executes the actual initialization transform and audits the exact pinned official API bytes. */
public final class FabricCompatibilityTests {
    private static int passed;
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private FabricCompatibilityTests() {}
    public static void main(String[] args) throws Exception {
        if (args.length < 1 || args.length > 2) throw new IllegalArgumentException("FabricCompatibilityTests <official-fabric-api.jar> [intermediary-game.jar]");
        byte[] api = Files.readAllBytes(Path.of(args[0]));
        Path cache = Files.createTempDirectory("n9ezz-fabric-api-tests-");
        var mappings = new FabricMappingResolver(GameMappings.index(), "intermediary");
        check("service access before preparation fails", () -> expect(IllegalStateException.class, FabricLoader::getInstance));
        var selection = SelectedFabricApi.select(api, cache);
        check("selection preserves six official modules and real fabric alias", () -> {
            eq(6, selection.modules().size());
            try (ZipFile z = new ZipFile(selection.umbrella().toFile())) {
                var json = com.google.gson.JsonParser.parseString(new String(z.getInputStream(z.getEntry("fabric.mod.json")).readAllBytes(), java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
                eq("fabric-api", json.get("id").getAsString()); eq(SelectedFabricApi.VERSION, json.get("version").getAsString());
                eq("fabric", json.getAsJsonArray("provides").get(0).getAsString()); eq(6, json.getAsJsonArray("jars").size());
                eq(6L, z.stream().filter(e -> e.getName().endsWith(".jar")).count());
                for (var module : selection.modules()) {
                    byte[] bytes = z.getInputStream(z.getEntry(module.archiveEntry())).readAllBytes();
                    Path extracted = cache.resolve(module.sha256() + ".jar"); Files.write(extracted, bytes);
                    if (!SelectedFabricApi.isVerifiedModule(extracted)) throw new AssertionError("Unverified " + module.id());
                    try (JarFile nested = new JarFile(extracted.toFile())) {
                        if (nested.stream().noneMatch(e -> e.getName().toLowerCase().contains("license"))) throw new AssertionError("License lost: " + module.id());
                    }
                }
            }
        });
        check("curated archive generation is deterministic", () -> eq(selection.sha256(), SelectedFabricApi.select(api, Files.createTempDirectory("fabric-selection-repeat-")).sha256()));
        check("source integrity changes fail before selection", () -> { byte[] changed = api.clone(); changed[changed.length / 2] ^= 1; expect(IOException.class, () -> SelectedFabricApi.select(changed, cache)); });
        check("corrupt selected cache is preserved and rejected", () -> {
            byte[] original = Files.readAllBytes(selection.umbrella()); byte[] changed = original.clone(); changed[12] ^= 1; Files.write(selection.umbrella(), changed);
            expect(IOException.class, () -> SelectedFabricApi.select(api, cache)); eq((int) changed[12], (int) Files.readAllBytes(selection.umbrella())[12]); Files.write(selection.umbrella(), original);
        });
        check("Fabric MappingResolver uses the exact game index and rejects named", () -> {
            var index = GameMappings.index(); String original = index.mapClass("intermediary", "official", "net/minecraft/class_310");
            eq("net.minecraft.class_310", mappings.mapClassName("official", original.replace('/', '.')));
            eq(original.replace('/', '.'), mappings.unmapClassName("official", "net.minecraft.class_310"));
            expect(IllegalArgumentException.class, () -> mappings.mapClassName("named", "net.minecraft.client.MinecraftClient"));
            expect(IllegalArgumentException.class, () -> mappings.mapClassName("official", "net/minecraft/class_310"));
        });
        check("read-only services retain real identities, aliases, metadata and config location", () -> {
            Path game = Files.createTempDirectory("fabric-service-game-");
            ModMetadata metadata = new ModMetadata("fabric-api", SelectedFabricApi.VERSION, Platform.FABRIC, selection.umbrella(), List.of(), List.of(), List.of(), "intermediary", Set.of("fabric"));
            try (var binding = FabricRuntime.install(game, List.of(metadata), mappings, ignored -> {})) {
                var loader = FabricLoader.getInstance(); eq(game.toRealPath().resolve("config"), loader.getConfigDir());
                eq(game.toRealPath(), loader.getGameDir()); eq(false, loader.isDevelopmentEnvironment()); eq("1.21.11", loader.getRawGameVersion());
                eq(4, loader.getAllMods().size()); eq(true, loader.isModLoaded("fabric")); eq(false, loader.isModLoaded("unavailable"));
                var container = loader.getModContainer("fabric").orElseThrow(); eq("Fabric API", container.getMetadata().getName());
                eq(List.of("Apache-2.0"), container.getMetadata().getLicense()); eq("fabric-api", container.getMetadata().getId());
                if (container.findPath("fabric.mod.json").isEmpty()) throw new AssertionError("Archive access failed");
                expect(IllegalArgumentException.class, () -> container.findPath("../escape"));
                eq("N9Ezz Fabric Loader ABI compatibility", loader.getModContainer("fabricloader").orElseThrow().getMetadata().getName());
                eq(null, loader.getGameInstance());
            }
        });
        check("transformed constructor invokes initialization after thread and before options", () -> {
            byte[] transformed = GameInitializationHook.transform(GameInitializationHook.TARGET, gameFixture(true, false));
            FixtureLoader loader = new FixtureLoader(); loader.add("net.minecraft.class_542", emptyClass("net/minecraft/class_542")); loader.add("net.minecraft.class_315", emptyClass("net/minecraft/class_315")); loader.add(GameInitializationHook.TARGET, transformed);
            List<String> trace = new ArrayList<>(); Path game = Files.createTempDirectory("fabric-hook-game-");
            try (var binding = FabricRuntime.install(game, List.of(), mappings, client -> {
                try {
                    eq(client, client.getClass().getField("field_1700").get(null));
                    eq(Thread.currentThread(), client.getClass().getField("field_1696").get(client));
                    eq(null, client.getClass().getField("field_1690").get(client));
                    eq(client, FabricLoader.getInstance().getGameInstance()); trace.add("INITIALIZERS");
                } catch (ReflectiveOperationException e) { throw new AssertionError(e); }
            })) {
                Class<?> clientType = loader.loadClass(GameInitializationHook.TARGET); Class<?> argsType = loader.loadClass("net.minecraft.class_542");
                Object client = clientType.getConstructor(argsType).newInstance(argsType.getConstructor().newInstance());
                if (clientType.getField("field_1690").get(client) == null) throw new AssertionError("Constructor did not complete options construction");
                eq(List.of("INITIALIZERS"), trace); eq(true, FabricRuntime.initializationCompleted());
                try { clientType.getConstructor(argsType).newInstance(argsType.getConstructor().newInstance()); throw new AssertionError("Second hook attempt was allowed"); }
                catch (InvocationTargetException e) { if (!(e.getCause() instanceof IllegalStateException)) throw e; }
            }
        });
        check("constructor shape changes and repeated transform fail closed", () -> {
            expect(dev.n9ezz.loader.core.LoaderException.class, () -> GameInitializationHook.transform(GameInitializationHook.TARGET, gameFixture(false, false)));
            expect(dev.n9ezz.loader.core.LoaderException.class, () -> GameInitializationHook.transform(GameInitializationHook.TARGET, gameFixture(true, true)));
            byte[] transformed = GameInitializationHook.transform(GameInitializationHook.TARGET, gameFixture(true, false));
            expect(dev.n9ezz.loader.core.LoaderException.class, () -> GameInitializationHook.transform(GameInitializationHook.TARGET, transformed));
        });
        if (args.length == 2) check("actual Minecraft 1.21.11 constructor accepts the pinned hook exactly once", () -> {
            try (JarFile jar = new JarFile(args[1])) {
                byte[] real = jar.getInputStream(jar.getJarEntry("net/minecraft/class_310.class")).readAllBytes();
                byte[] transformed = GameInitializationHook.transform(GameInitializationHook.TARGET, real);
                ClassNode node = new ClassNode(); new ClassReader(transformed).accept(node, 0);
                long calls = node.methods.stream().flatMap(m -> java.util.stream.StreamSupport.stream(m.instructions.spliterator(), false)).filter(x -> x instanceof MethodInsnNode call && call.owner.equals("dev/n9ezz/loader/fabric/FabricRuntime") && call.name.equals("bootstrapGame")).count();
                eq(1L, calls); expect(dev.n9ezz.loader.core.LoaderException.class, () -> GameInitializationHook.transform(GameInitializationHook.TARGET, transformed));
            }
        });
        else System.out.println("SKIP actual Minecraft constructor bytes: no game JAR supplied; fixture execution above is not a real game launch");
        System.out.println("Fabric compatibility: " + passed + " passed");
    }
    private static void check(String name, Checked task) throws Exception { task.run(); passed++; System.out.println("PASS " + name); }
    private static void expect(Class<? extends Throwable> type, Checked task) throws Exception { try { task.run(); } catch (Throwable e) { if (type.isInstance(e)) return; throw e; } throw new AssertionError("Expected " + type.getName()); }
    private static void eq(Object expected, Object actual) { if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual); }
    private static byte[] emptyClass(String name) {
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS); w.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, name, null, "java/lang/Object", null);
        var m = w.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null); m.visitCode(); m.visitVarInsn(Opcodes.ALOAD, 0); m.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false); m.visitInsn(Opcodes.RETURN); m.visitMaxs(0, 0); m.visitEnd(); w.visitEnd(); return w.toByteArray();
    }
    private static byte[] gameFixture(boolean withThread, boolean optionsFirst) {
        String owner = "net/minecraft/class_310";
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS); w.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, owner, null, "java/lang/Object", null);
        w.visitField(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "field_1700", "L" + owner + ";", null, null).visitEnd();
        w.visitField(Opcodes.ACC_PUBLIC, "field_1696", "Ljava/lang/Thread;", null, null).visitEnd(); w.visitField(Opcodes.ACC_PUBLIC, "field_1690", "Lnet/minecraft/class_315;", null, null).visitEnd();
        var m = w.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "(Lnet/minecraft/class_542;)V", null, null); m.visitCode();
        m.visitVarInsn(Opcodes.ALOAD, 0); m.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        m.visitVarInsn(Opcodes.ALOAD, 0); m.visitFieldInsn(Opcodes.PUTSTATIC, owner, "field_1700", "L" + owner + ";");
        if (optionsFirst) options(m, owner);
        if (withThread) { m.visitVarInsn(Opcodes.ALOAD, 0); m.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/Thread", "currentThread", "()Ljava/lang/Thread;", false); m.visitFieldInsn(Opcodes.PUTFIELD, owner, "field_1696", "Ljava/lang/Thread;"); }
        if (!optionsFirst) options(m, owner);
        m.visitInsn(Opcodes.RETURN); m.visitMaxs(0, 0); m.visitEnd(); w.visitEnd(); return w.toByteArray();
    }
    private static void options(org.objectweb.asm.MethodVisitor m, String owner) { m.visitVarInsn(Opcodes.ALOAD, 0); m.visitTypeInsn(Opcodes.NEW, "net/minecraft/class_315"); m.visitInsn(Opcodes.DUP); m.visitMethodInsn(Opcodes.INVOKESPECIAL, "net/minecraft/class_315", "<init>", "()V", false); m.visitFieldInsn(Opcodes.PUTFIELD, owner, "field_1690", "Lnet/minecraft/class_315;"); }
    private static final class FixtureLoader extends ClassLoader {
        private final java.util.Map<String, byte[]> files = new java.util.HashMap<>();
        private FixtureLoader() { super(FabricCompatibilityTests.class.getClassLoader()); }
        private void add(String name, byte[] bytes) { files.put(name, bytes); }
        @Override protected Class<?> findClass(String name) throws ClassNotFoundException { byte[] bytes = files.get(name); if (bytes == null) throw new ClassNotFoundException(name); return defineClass(name, bytes, 0, bytes.length); }
    }
}
