package dev.n9ezz.loader.core;

import dev.n9ezz.loader.metadata.Dependency;
import dev.n9ezz.loader.metadata.Entrypoint;
import dev.n9ezz.loader.metadata.MetadataReader;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

/** Mixed-format graphs expose the incompatible language versions rather than hiding them. */
public final class UniversalGamePolicyTests {
    private static int checks;
    private static Path directory;
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private UniversalGamePolicyTests() { }

    public static void main(String[] args) throws Exception {
        directory = Files.createTempDirectory("n9ezz-universal-policy-");
        var forge = fml("forge_fixture", false, "[61,)", "fml-lifecycle-v1", "none", "");
        var neo = fml("neo_fixture", true, "[10,11)", "fml-lifecycle-v1", "none", "");
        var quilt = quilt("quilt_fixture", "quilt-lifecycle-v1", "none", true);
        var fabric = simple("fabric_fixture", Platform.FABRIC, List.of(new Dependency("fabricloader", "=0.19.2", false, false)));
        var nativeMod = simple("native_fixture", Platform.N9EZZ, List.of());
        equal(Set.of("forge_fixture", "neo_fixture", "quilt_fixture", "fabric_fixture", "native_fixture"),
                Set.copyOf(resolve(List.of(neo, forge, quilt, fabric, nativeMod)).stream().map(ModMetadata::id).toList()));
        fail("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolveFabricRuntime(List.of(forge)));
        fail("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolveFabricRuntime(List.of(quilt)));
        fail("DEPENDENCY_VERSION", () -> resolve(List.of(fml("wrong_language", true, "[61,)", "fml-lifecycle-v1", "none", ""))));
        fail("DEPENDENCY_VERSION", () -> resolve(List.of(fml("wrong_language", false, "[10,11)", "fml-lifecycle-v1", "none", ""))));
        fail("UNSUPPORTED_GAME_PLATFORM", () -> resolve(List.of(fml("unacknowledged", false, "[61,)", "", "none", ""))));
        fail("UNSUPPORTED_GAME_PLATFORM", () -> resolve(List.of(quilt("unacknowledged", "", "none", false))));
        fail("UNSUPPORTED_GAME_PLATFORM", () -> resolve(List.of(fml("wrong_contract", false, "[61,)", "quilt-lifecycle-v1", "none", ""))));
        fail("UNSUPPORTED_NAMESPACE", () -> resolve(List.of(fml("mojang_names", true, "[10,)", "fml-lifecycle-v1", "official", ""))));
        fail("UNSUPPORTED_NAMESPACE", () -> resolve(List.of(quilt("hashed_names", "quilt-lifecycle-v1", "named", false))));
        for (String platform : List.of("forge", "neoforge")) {
            fail("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> resolve(List.of(fml("full_engine", true, "[10,)", "fml-lifecycle-v1", "none",
                    "[[dependencies.full_engine]]\nmodId=\"" + platform + "\"\ntype=\"required\"\nversionRange=\"*\"\n"))));
        }
        fail("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> resolve(List.of(neo,
                simple("unrelated", Platform.FABRIC, List.of(new Dependency("javafml", "[10,)", false, false))))));
        fail("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> resolve(List.of(quilt,
                simple("unrelated", Platform.N9EZZ, List.of(new Dependency("quilt_loader", "=0.30.1", false, false))))));
        fail("RESERVED_MOD_ID", () -> resolve(List.of(new ModMetadata("spoof", "1", Platform.N9EZZ, nativeMod.jar(),
                List.of(), List.of(), List.of(), "none", Set.of("javafml")))));
        var ordered = resolve(List.of(fml("ordered", false, "[61,)", "fml-lifecycle-v1", "none",
                "[[dependencies.ordered]]\nmodId=\"native_fixture\"\nmandatory=true\nversionRange=\"*\"\n"), nativeMod));
        equal(List.of("native_fixture", "ordered"), ordered.stream().map(ModMetadata::id).toList());
        for (Platform platform : List.of(Platform.N9EZZ, Platform.FABRIC, Platform.QUILT)) {
            ModMetadata dependent = platform == Platform.QUILT ? quilt("after_fml", "quilt-lifecycle-v1", "none", true)
                    : simple("after_fml", platform, List.of());
            var callback = new ModMetadata(dependent.id(), dependent.version(), dependent.platform(), dependent.jar(),
                    List.of(new Dependency("neo_fixture", "*", false, false)),
                    List.of(new Entrypoint("common", "fixture.Initializer", "default")), List.of(), "none", Set.of());
            fail("UNSUPPORTED_CROSS_PHASE_DEPENDENCY", () -> resolve(List.of(callback, neo)));
        }
        var aliased = new ModMetadata(neo.id(), neo.version(), neo.platform(), neo.jar(), neo.dependencies(),
                neo.entrypoints(), neo.mixins(), neo.namespace(), Set.of("fml_alias"));
        var aliasDependent = new ModMetadata("alias_dependent", "1", Platform.N9EZZ, nativeMod.jar(),
                List.of(new Dependency("fml_alias", "*", false, false)),
                List.of(new Entrypoint("client", "fixture.Client", "default")), List.of(), "none", Set.of());
        fail("UNSUPPORTED_CROSS_PHASE_DEPENDENCY", () -> resolve(List.of(aliased, aliasDependent)));
        equal(Set.of("native_fixture", "neo_fixture"), Set.copyOf(resolve(List.of(neo,
                new ModMetadata(nativeMod.id(), "1", Platform.N9EZZ, nativeMod.jar(),
                        List.of(new Dependency("neo_fixture", "*", false, false)), List.of(), List.of(), "none", Set.of())))
                .stream().map(ModMetadata::id).toList()));
        equal("quilt-client-init", quilt.entrypoints().getFirst().adapter());
        fail("METADATA_UNSUPPORTED", () -> MetadataReader.read(quilt.jar()));
        System.out.println("PASS " + checks + " universal game policy and mixed-version graph checks");
    }

    private static List<ModMetadata> resolve(List<ModMetadata> mods) {
        return DependencyResolver.resolveUniversalGame(mods, warning -> { });
    }
    private static ModMetadata simple(String id, Platform platform, List<Dependency> dependencies) throws Exception {
        return new ModMetadata(id, "1", platform, archive(Map.of()), dependencies, List.of(), List.of(), "none", Set.of());
    }
    private static ModMetadata fml(String id, boolean neo, String language, String contract, String namespace, String dependencies) throws Exception {
        String text = "modLoader=\"javafml\"\nloaderVersion=\"" + language + "\"\nlicense=\"MIT\"\n"
                + "[n9ezz]\nnamespace=\"" + namespace + "\"\ncompatibility=\"" + contract + "\"\n"
                + "[[mods]]\nmodId=\"" + id + "\"\nversion=\"1\"\n" + dependencies;
        return MetadataReader.read(archive(Map.of(neo ? "META-INF/neoforge.mods.toml" : "META-INF/mods.toml", text)),
                MetadataReader.ReadPolicy.FABRIC_RUNTIME).getFirst();
    }
    private static ModMetadata quilt(String id, String contract, String namespace, boolean client) throws Exception {
        String text = "{\"schema_version\":1,\"quilt_loader\":{\"id\":\"" + id + "\",\"version\":\"1\","
                + "\"depends\":[{\"id\":\"quilt_loader\",\"versions\":\"=0.30.1\"}]"
                + (client ? ",\"entrypoints\":{\"client_init\":[\"fixture.Client\"]}" : "")
                + "},\"n9ezz\":{\"namespace\":\"" + namespace + "\",\"compatibility\":\"" + contract + "\"}}";
        return MetadataReader.read(archive(Map.of("quilt.mod.json", text)), MetadataReader.ReadPolicy.FABRIC_RUNTIME).getFirst();
    }
    private static Path archive(Map<String, String> entries) throws Exception {
        Path file = Files.createTempFile(directory, "mod-", ".jar");
        try (var output = new JarOutputStream(Files.newOutputStream(file))) {
            for (var entry : entries.entrySet()) {
                output.putNextEntry(new JarEntry(entry.getKey()));
                output.write(entry.getValue().getBytes(StandardCharsets.UTF_8));
                output.closeEntry();
            }
        }
        return file;
    }
    private static void equal(Object expected, Object actual) {
        if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + " but got " + actual);
        checks++;
    }
    private static void fail(String code, Checked work) throws Exception {
        try { work.run(); }
        catch (dev.n9ezz.loader.metadata.MetadataException error) {
            if (code.equals(error.code())) { checks++; return; }
            throw error;
        }
        catch (LoaderException error) {
            if (error.diagnostics().stream().anyMatch(diagnostic -> diagnostic.code().equals(code))) { checks++; return; }
            throw error;
        }
        throw new AssertionError("Expected diagnostic " + code);
    }
}
