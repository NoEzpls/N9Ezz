package dev.n9ezz.loader.core;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Archive provenance boundary checks against real corrected/original client inputs. */
public final class BundledClientContractTests {
    private static int checks;

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("Usage: corrected-client.jar base-client.jar");
        Path corrected = Path.of(args[0]);
        Path original = Path.of(args[1]);
        Path temporary = Files.createTempDirectory("n9ezz-render-bridge-tests-");
        try {
            check(BundledClientContract.isVerifiedArchive(corrected), "corrected client archive accepted");
            check(!BundledClientContract.isVerifiedArchive(original), "original client is not corrected pinned archive");
            check(!BundledClientContract.isVerifiedArchive(null), "absent archive rejected");
            check(!BundledClientContract.isVerifiedArchive(temporary.resolve("missing.jar")), "missing archive rejected");
            check(BundledClientContract.renderBridges().size() == 2, "exactly two bridge candidates");
            List<byte[]> bridgeBytes = new ArrayList<>();
            try (ZipFile jar = new ZipFile(corrected.toFile())) {
                for (String name : BundledClientContract.renderBridges().keySet().stream().sorted().toList()) {
                    byte[] bytes = jar.getInputStream(jar.getEntry(name.replace('.', '/') + ".class")).readAllBytes();
                    bridgeBytes.add(bytes);
                    check(BundledClientContract.isVerifiedClass(corrected, name, bytes), "pinned bridge accepted: " + name);
                    byte[] changed = bytes.clone();
                    changed[changed.length - 1] ^= 1;
                    check(!BundledClientContract.isVerifiedClass(corrected, name, changed), "changed bridge bytes rejected: " + name);
                    check(!BundledClientContract.isVerifiedClass(original, name, bytes), "correct bridge bytes in wrong archive rejected: " + name);
                    check(!BundledClientContract.isVerifiedClass(corrected, name + "Copy", bytes), "renamed bridge rejected: " + name);
                    check(!BundledClientContract.isVerifiedClass(corrected, name, null), "absent bridge bytes rejected: " + name);
                    Path impostor = temporary.resolve("impostor-" + bridgeBytes.size() + ".jar");
                    try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(impostor))) {
                        output.putNextEntry(new ZipEntry(name.replace('.', '/') + ".class"));
                        output.write(bytes);
                        output.closeEntry();
                    }
                    check(!BundledClientContract.isVerifiedClass(impostor, name, bytes), "external archive with identical bridge rejected: " + name);
                }
            }
            Path mutable = temporary.resolve("previously-verified.jar");
            Files.copy(corrected, mutable, StandardCopyOption.REPLACE_EXISTING);
            check(BundledClientContract.isVerifiedArchive(mutable), "identical copy verifies by content");
            try (FileChannel channel = FileChannel.open(mutable, StandardOpenOption.READ, StandardOpenOption.WRITE)) {
                ByteBuffer lastByte = ByteBuffer.allocate(1);
                channel.read(lastByte, BundledClientContract.CLIENT_SIZE - 1);
                lastByte.flip();
                byte changed = (byte) (lastByte.get() ^ 1);
                channel.write(ByteBuffer.wrap(new byte[] { changed }), BundledClientContract.CLIENT_SIZE - 1);
            }
            check(!BundledClientContract.isVerifiedArchive(mutable), "changed previously verified archive rejected without path trust cache");
            check(!BundledClientContract.isVerifiedClass(mutable, "net.minecraft.client.gl.ShaderProgramKeys", bridgeBytes.getFirst()), "intact class bytes cannot bypass changed archive checksum");
            check(!BundledClientContract.isVerifiedClass(corrected, "net.minecraft.class_310", bridgeBytes.getFirst()), "real game namespace class excluded");
            System.out.println("PASS: " + checks + " built-in render bridge provenance checks");
        } finally {
            try (var paths = Files.walk(temporary)) {
                for (Path path : paths.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
}
