package dev.n9ezz.loader.tests;

import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.core.UnifiedClassLoader;
import dev.n9ezz.loader.mixin.MixinRuntime;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnNode;

/** Each scenario uses its own JVM because Mixin has process-lifetime singleton state. */
public final class MixinIntegrationTests {
    private static final List<String> SCENARIOS = List.of("inject-redirect-extras", "missing-config", "duplicate-config", "malformed-config", "required-injection-failure", "helper-generation", "accessor-invoker", "config-plugin", "client-side", "server-side", "closed-runtime");
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            for (String scenario : SCENARIOS) {
                Process process = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin", "java").toString(), "-cp", System.getProperty("java.class.path"), MixinIntegrationTests.class.getName(), scenario)
                    .redirectErrorStream(true).start();
                String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                if (process.waitFor() != 0) throw new AssertionError("Mixin scenario failed: " + scenario + "\n" + output);
                System.out.print(output);
            }
            System.out.println("MIXIN_INTEGRATION_PASS " + SCENARIOS.size() + "/" + SCENARIOS.size());
            return;
        }
        runScenario(args[0]);
        System.out.println("PASS Mixin " + args[0]);
    }

    private static void runScenario(String scenario) throws Exception {
        Path fixture = Files.createTempFile("n9ezz-mixin-", ".jar");
        String mixin = scenario.equals("required-injection-failure") ? "BrokenMixin" : scenario.equals("helper-generation") ? "InnerMixin" : scenario.equals("accessor-invoker") ? "TargetAccessor" : "TargetMixin";
        String selectedList = scenario.equals("client-side") ? "client" : scenario.equals("server-side") ? "server" : "mixins";
        String config = "{\"required\":true,\"minVersion\":\"0.8.7\",\"package\":\"mixinfixture.mixins\",\"compatibilityLevel\":\"JAVA_21\",\"" + selectedList + "\":[\"" + mixin + "\"],"
            + (scenario.equals("client-side") ? "\"server\":[\"BrokenMixin\"]," : scenario.equals("server-side") ? "\"client\":[\"BrokenMixin\"]," : "")
            + (scenario.equals("config-plugin") ? "\"plugin\":\"mixinfixture.Plugin\"," : "") + "\"injectors\":{\"defaultRequire\":1}}";
        try (JarOutputStream jar = new JarOutputStream(Files.newOutputStream(fixture))) {
            add(jar, "mixinfixture/Target.class", resource("mixinfixture/Target.class"));
            add(jar, "mixinfixture/mixins/" + mixin + ".class", resource("mixinfixture/mixins/" + mixin + ".class"));
            if (mixin.equals("InnerMixin")) add(jar, "mixinfixture/mixins/InnerMixin$Helper.class", resource("mixinfixture/mixins/InnerMixin$Helper.class"));
            if (scenario.equals("config-plugin")) add(jar, "mixinfixture/Plugin.class", resource("mixinfixture/Plugin.class"));
            if (scenario.equals("client-side") || scenario.equals("server-side")) add(jar, "mixinfixture/mixins/BrokenMixin.class", resource("mixinfixture/mixins/BrokenMixin.class"));
            add(jar, "test.mixins.json", (scenario.equals("malformed-config") ? "{broken" : config).getBytes(StandardCharsets.UTF_8));
        }
        List<String> stages = new ArrayList<>();
        TransformationPipeline pipeline = new TransformationPipeline();
        pipeline.register(TransformationPipeline.Stage.CORE, 0, "fixture:core", (name, bytes) -> {
            if (name.equals("mixinfixture.Target")) stages.add("CORE");
            return preTransform(name, bytes);
        });
        MixinRuntime runtime = new MixinRuntime(); runtime.register(pipeline);
        pipeline.register(TransformationPipeline.Stage.POST, 0, "fixture:post", (name, bytes) -> {
            if (name.equals("mixinfixture.Target")) stages.add("POST");
            return bytes;
        });
        pipeline.freeze();
        try (UnifiedClassLoader loader = new UnifiedClassLoader(List.of(fixture), MixinIntegrationTests.class.getClassLoader(), pipeline)) {
            MixinRuntime.Host host = new MixinRuntime.Host() {
                @Override public byte[] classBytes(String name, boolean pre) throws IOException, ClassNotFoundException {
                    return loader.classBytes(name, pre);
                }
                @Override public Class<?> findClass(String name, boolean init) throws ClassNotFoundException { return Class.forName(name, init, loader); }
                @Override public InputStream resource(String path) { return loader.getResourceAsStream(path); }
                @Override public boolean isClassLoaded(String name) { return loader.isClassLoaded(name); }
                @Override public void registerInvalidClass(String name) { loader.registerInvalidClass(name); }
            };
            loader.setGeneratedClassProvider(runtime::generate);
            List<MixinRuntime.Configuration> configs = List.of(new MixinRuntime.Configuration("fixture", scenario.equals("missing-config") ? "absent.json" : "test.mixins.json"));
            if (scenario.equals("duplicate-config")) configs = List.of(new MixinRuntime.Configuration("one", "test.mixins.json"), new MixinRuntime.Configuration("two", "test.mixins.json"));
            if (scenario.equals("missing-config") || scenario.equals("duplicate-config") || scenario.equals("malformed-config")) {
                String expected = scenario.equals("missing-config") ? "MISSING_MIXIN_CONFIG" : scenario.equals("duplicate-config") ? "DUPLICATE_MIXIN_CONFIG" : "INVALID_MIXIN_CONFIG";
                List<MixinRuntime.Configuration> invalid = configs;
                expectCode(expected, () -> runtime.initialize(host, invalid, MixinRuntime.Side.CLIENT)); return;
            }
            runtime.initialize(host, configs, scenario.equals("server-side") ? MixinRuntime.Side.SERVER : MixinRuntime.Side.CLIENT);
            check(runtime.isReady(), "Mixin is ready");
            check(runtime.serviceName().equals("N9Ezz Universal"), "Own service selected");
            if (scenario.equals("closed-runtime")) {
                runtime.close(); expectCode("MIXIN_NOT_READY", () -> runtime.transform("mixinfixture.Target", host.classBytes("mixinfixture.Target", false))); return;
            }
            if (scenario.equals("required-injection-failure")) {
                expectCode("TRANSFORM_FAILED", () -> Class.forName("mixinfixture.Target", true, loader));
                check(!stages.isEmpty() && stages.stream().noneMatch("POST"::equals), "Failed mixin prevents POST and target definition");
                check(!loader.isClassLoaded("mixinfixture.Target"), "Failed target is never defined"); return;
            }
            Class<?> target = Class.forName("mixinfixture.Target", true, loader);
            Object instance = target.getConstructor().newInstance();
            check(target.getClassLoader() == loader, "Target uses common classloader");
            check(loader.isClassLoaded("mixinfixture.Target"), "Class tracker reports actual target definition");
            if (scenario.equals("helper-generation")) {
                check(target.getMethod("value").invoke(instance).equals(31), "Generated inner helper executes");
                check(runtime.auditTrail().stream().anyMatch(item -> item.startsWith("generate:mixinfixture.Target$Helper$")), "Helper generation is audited");
            } else if (scenario.equals("accessor-invoker")) {
                Class<?> accessor = Class.forName("mixinfixture.mixins.TargetAccessor", true, loader);
                check(accessor.getClassLoader() == loader && accessor.isInstance(instance), "Accessor interface loads and target implements it");
                check(accessor.getMethod("n9ezz$getSecret").invoke(instance).equals(4), "Accessor reads private field");
                accessor.getMethod("n9ezz$setSecret", int.class).invoke(instance, 12);
                check(accessor.getMethod("n9ezz$getSecret").invoke(instance).equals(12), "Accessor writes private field");
                check(accessor.getMethod("n9ezz$invokeHidden", int.class).invoke(instance, 6).equals(18), "Invoker calls private method");
            }
            else {
                check(target.getMethod("value").invoke(instance).equals(13), "CORE changes 2 to 3 before real Inject adds 10");
                check(target.getMethod("redirected").invoke(instance).equals(8), "Real Redirect replaces Math.abs call with 7");
                check(target.getMethod("extras").invoke(instance).equals(10), "Real MixinExtras ModifyReturnValue doubles 5");
                check(stages.getFirst().equals("CORE") && stages.getLast().equals("POST") && stages.stream().filter("POST"::equals).count() == 1,
                    "Pre-Mixin reads use CORE and one target definition reaches POST");
                try { Class.forName("mixinfixture.mixins.TargetMixin", true, loader); throw new AssertionError("Implementation mixin must not be defined"); }
                catch (ClassNotFoundException expected) { check(expected.getMessage().contains("cannot be loaded directly"), "Invalid mixin is blocked by actual class tracker"); }
            }
            if (scenario.equals("config-plugin")) {
                check(System.getProperty("n9ezz.fixture.plugin.constructed").equals("true"), "Plugin constructed during config load");
                check(System.getProperty("n9ezz.fixture.plugin.loaded").equals("true"), "Plugin onLoad executed");
                check(Class.forName("mixinfixture.Plugin", false, loader).getClassLoader() == loader, "Config plugin uses common classloader");
            }
            check(runtime.auditTrail().stream().anyMatch(item -> item.startsWith("apply:mixinfixture.Target:")), "Audit confirms actual mixin application");
            runtime.close();
        } finally { Files.deleteIfExists(fixture); }
    }
    private static byte[] preTransform(String name, byte[] bytes) {
        if (!name.equals("mixinfixture.Target")) return bytes;
        ClassNode node = new ClassNode(); new ClassReader(bytes).accept(node, 0);
        node.methods.stream().filter(method -> method.name.equals("value")).forEach(method -> {
            for (var instruction : method.instructions) if (instruction.getOpcode() == Opcodes.ICONST_2) method.instructions.set(instruction, new InsnNode(Opcodes.ICONST_3));
        });
        ClassWriter writer = new ClassWriter(0); node.accept(writer); return writer.toByteArray();
    }
    private static byte[] resource(String path) throws IOException {
        try (InputStream input = MixinIntegrationTests.class.getClassLoader().getResourceAsStream(path)) {
            if (input == null) throw new IOException("Missing fixture resource " + path); return input.readAllBytes();
        }
    }
    private static void add(JarOutputStream jar, String path, byte[] bytes) throws IOException { jar.putNextEntry(new JarEntry(path)); jar.write(bytes); jar.closeEntry(); }
    private static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static void expectCode(String code, Checked action) throws Exception {
        try { action.run(); throw new AssertionError("Expected " + code); }
        catch (LoaderException error) { check(error.diagnostics().stream().anyMatch(d -> d.code().equals(code)), "Expected " + code + ", got " + error); }
    }
}
