package dev.n9ezz.loader.mapping;

import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;

public final class AccessWidenerTests {
    private static int checks;
    public static void main(String[] arguments) throws Exception {
        byte[] original = fixture();
        AccessWidenerSet rules = new AccessWidenerSet("intermediary");
        rules.add(bytes("accessWidener v2 intermediary\nextendable class fixture/AccessTarget\n"
            + "transitive-accessible field fixture/AccessTarget value I\nmutable field fixture/AccessTarget value I\n"
            + "accessible method fixture/AccessTarget hidden ()V\n"), "fixture.aw");
        check(rules.targets().contains("fixture/AccessTarget"), "access-widener target collected");
        rules.add(bytes("accessWidener v2 intermediary\nextendable class fixture/AccessTarget\n"), "fixture.aw");
        check(rules.sources().size() == 1, "duplicate source is idempotent");
        Path jar = Files.createTempFile("n9ezz-access-fixture-", ".jar");
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(jar))) {
            output.putNextEntry(new ZipEntry("fixture/AccessTarget.class")); output.write(original); output.closeEntry();
        }
        rules.validateTargets(jar); check(true, "target declarations validated before class load");
        byte[] transformed = rules.transform("fixture.AccessTarget", original);
        ClassNode node = new ClassNode(); new ClassReader(transformed).accept(node, 0);
        check((node.access & Opcodes.ACC_PUBLIC) != 0 && (node.access & Opcodes.ACC_FINAL) == 0, "extendable class made public and nonfinal");
        check(node.permittedSubclasses == null || node.permittedSubclasses.isEmpty(), "extendable sealed restrictions removed");
        var field = node.fields.getFirst();
        check((field.access & Opcodes.ACC_PUBLIC) != 0 && (field.access & (Opcodes.ACC_FINAL | Opcodes.ACC_PRIVATE)) == 0, "transitive accessible/mutable field widened");
        var hidden = node.methods.stream().filter(method -> method.name.equals("hidden")).findFirst().orElseThrow();
        check((hidden.access & Opcodes.ACC_PUBLIC) != 0 && (hidden.access & Opcodes.ACC_PRIVATE) == 0, "private method made public");
        check((hidden.access & Opcodes.ACC_FINAL) != 0, "accessible method retains final dispatch semantics");
        boolean invocation = false, handle = false;
        for (var method : node.methods) for (var instruction : method.instructions) {
            if (instruction instanceof MethodInsnNode call && call.name.equals("hidden")) invocation |= call.getOpcode() == Opcodes.INVOKEVIRTUAL;
            if (instruction instanceof InvokeDynamicInsnNode indy) for (Object argument : indy.bsmArgs)
                if (argument instanceof Handle reference && reference.getName().equals("hidden")) handle |= reference.getTag() == Opcodes.H_INVOKEVIRTUAL;
        }
        check(invocation, "private invokespecial call adjusted after widening");
        check(handle, "private method-reference bootstrap handle adjusted");
        check(rules.transform("fixture.Untouched", original) == original, "unaffected class remains byte-identical");
        TransformationPipeline pipeline = new TransformationPipeline(); rules.register(pipeline); pipeline.freeze();
        check(pipeline.order().equals(List.of("ACCESS:n9ezz:access-widener")), "access stage registered before Mixin");
        rejects(() -> rules.add(bytes("accessWidener v2 intermediary\n"), "late"), IllegalStateException.class, "late declaration rejected");
        rejects(() -> rules.register(pipeline), IllegalStateException.class, "duplicate stage rejected");
        rejects(() -> new AccessWidenerSet("intermediary").add(bytes("accessWidener v2 named\n"), "wrong"), IOException.class, "namespace mismatch rejected");
        rejects(() -> new AccessWidenerSet("intermediary").add(bytes("classTweaker v1 intermediary\n"), "new format"), IOException.class, "unimplemented class-tweaker extensions rejected");
        AccessWidenerSet missing = new AccessWidenerSet("intermediary");
        missing.add(bytes("accessWidener v2 intermediary\naccessible method fixture/AccessTarget absent ()V\n"), "missing");
        rejects(() -> missing.validateTargets(jar), LoaderException.class, "missing member rejected before transformation");
        AccessWidenerSet v1 = new AccessWidenerSet("intermediary");
        v1.add(bytes("accessWidener v1 intermediary\naccessible class fixture/AccessTarget\n"), "v1");
        check(!v1.isEmpty(), "legacy v1 compatible declarations supported");
        System.out.println("PASS " + checks + " access-widener checks");
    }
    private static byte[] bytes(String text) { return text.getBytes(StandardCharsets.UTF_8); }
    private static byte[] fixture() {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, 0, "fixture/AccessTarget", null, "java/lang/Object", null);
        writer.visitPermittedSubclass("fixture/Child");
        writer.visitField(Opcodes.ACC_PRIVATE | Opcodes.ACC_FINAL, "value", "I", null, null).visitEnd();
        var hidden = writer.visitMethod(Opcodes.ACC_PRIVATE | Opcodes.ACC_FINAL, "hidden", "()V", null, null);
        hidden.visitCode(); hidden.visitInsn(Opcodes.RETURN); hidden.visitMaxs(0, 1); hidden.visitEnd();
        var caller = writer.visitMethod(Opcodes.ACC_PUBLIC, "caller", "()V", null, null);
        caller.visitCode(); caller.visitVarInsn(Opcodes.ALOAD, 0);
        caller.visitMethodInsn(Opcodes.INVOKESPECIAL, "fixture/AccessTarget", "hidden", "()V", false);
        Handle bootstrap = new Handle(Opcodes.H_INVOKESTATIC, "java/lang/invoke/LambdaMetafactory", "metafactory",
            "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite;", false);
        caller.visitVarInsn(Opcodes.ALOAD, 0);
        caller.visitInvokeDynamicInsn("run", "(Lfixture/AccessTarget;)Ljava/lang/Runnable;", bootstrap,
            org.objectweb.asm.Type.getMethodType("()V"), new Handle(Opcodes.H_INVOKESPECIAL, "fixture/AccessTarget", "hidden", "()V", false), org.objectweb.asm.Type.getMethodType("()V"));
        caller.visitInsn(Opcodes.POP); caller.visitInsn(Opcodes.RETURN); caller.visitMaxs(1, 1); caller.visitEnd();
        writer.visitEnd(); return writer.toByteArray();
    }
    private static void check(boolean condition, String description) { if (!condition) throw new AssertionError(description); checks++; System.out.println("PASS " + description); }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static void rejects(Checked operation, Class<? extends Throwable> type, String description) throws Exception {
        try { operation.run(); } catch (Throwable error) { if (type.isInstance(error)) { check(true, description); return; } throw error; }
        throw new AssertionError(description);
    }
}
