package dev.n9ezz.loader.compat;

import com.google.gson.JsonParser;
import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.core.EventBus;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.fabric.SelectedFabricApi;
import dev.n9ezz.loader.metadata.Entrypoint;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.jar.JarFile;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;

/** Adapter behavior and exact component gates; fixtures are not relabeled as official modules. */
public final class FabricEntrypointTests {
    private static int passed, calls;
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("FabricEntrypointTests <official-fabric-api.jar>");
        Path temporary = Files.createTempDirectory("fabric-entrypoint-tests-");
        var selection = SelectedFabricApi.select(Files.readAllBytes(Path.of(args[0])), temporary);
        List<Path> modules = new ArrayList<>(); List<ModMetadata> metadata = new ArrayList<>();
        try (JarFile umbrella = new JarFile(selection.umbrella().toFile())) {
            for (var module : selection.modules()) {
                Path jar = temporary.resolve(module.sha256() + ".jar"); Files.write(jar, umbrella.getInputStream(umbrella.getJarEntry(module.archiveEntry())).readAllBytes()); modules.add(jar);
                try (JarFile source = new JarFile(jar.toFile())) {
                    var json = JsonParser.parseString(new String(source.getInputStream(source.getJarEntry("fabric.mod.json")).readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
                    List<Entrypoint> entries = new ArrayList<>();
                    if (json.has("entrypoints")) for (var phase : json.getAsJsonObject("entrypoints").entrySet()) {
                        for (var definition : phase.getValue().getAsJsonArray()) entries.add(new Entrypoint(phase.getKey().equals("main") ? "common" : phase.getKey(), definition.getAsString(), "default"));
                    }
                    metadata.add(new ModMetadata(module.id(), module.version(), Platform.FABRIC, jar, List.of(), entries, List.of(), "intermediary", Set.of()));
                }
            }
        }
        check("all six selected module entrypoints match actual binary contracts", () -> {
            int methods = 0, constructors = 0;
            for (var mod : metadata) try (JarFile jar = new JarFile(mod.jar().toFile())) {
                for (var entry : mod.entrypoints()) {
                    String[] parts = entry.className().split("::", -1); var archiveClass = jar.getJarEntry(parts[0].replace('.', '/') + ".class");
                    if (archiveClass == null) throw new AssertionError("Absent actual entrypoint " + entry.className());
                    ClassNode node = new ClassNode(); new ClassReader(jar.getInputStream(archiveClass).readAllBytes()).accept(node, ClassReader.SKIP_CODE);
                    if ((node.access & Opcodes.ACC_PUBLIC) == 0) throw new AssertionError("Nonpublic API entrypoint");
                    if (parts.length == 2) {
                        var method = node.methods.stream().filter(m -> m.name.equals(parts[1]) && m.desc.equals("()V")).findFirst().orElseThrow();
                        if ((method.access & (Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC)) != (Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC)) throw new AssertionError("Invalid actual static contract"); methods++;
                    } else {
                        String contract = entry.phase().equals("client") ? "net/fabricmc/api/ClientModInitializer" : "net/fabricmc/api/ModInitializer";
                        if (!node.interfaces.contains(contract) || node.methods.stream().noneMatch(m -> m.name.equals("<init>") && m.desc.equals("()V") && (m.access & Opcodes.ACC_PUBLIC) != 0)) throw new AssertionError("Invalid actual initializer contract"); constructors++;
                    }
                }
            }
            eq(3, methods); eq(3, constructors);
        });
        check("opt-in constructor rejects unverified and modified module bytes", () -> {
            new CompatibilityDispatcher(Set.copyOf(modules));
            Path fake = temporary.resolve("unverified.jar"); Files.write(fake, new byte[]{1,2,3}); expect(IOException.class, () -> new CompatibilityDispatcher(Set.of(fake)));
            Path changed = temporary.resolve("changed-module.jar"); byte[] bytes = Files.readAllBytes(modules.getFirst()); bytes[bytes.length / 2] ^= 1; Files.write(changed, bytes); expect(IOException.class, () -> new CompatibilityDispatcher(Set.of(changed)));
        });
        ModMetadata networking = metadata.stream().filter(m -> m.id().equals("fabric-networking-api-v1")).findFirst().orElseThrow();
        check("strict dispatcher still rejects real official method references", () -> {
            var strict = new CompatibilityDispatcher(); var context = new ModContext(networking.id(), temporary, new EventBus());
            expectCode("UNSUPPORTED_ADAPTER", () -> strict.initialize(networking, "common", FabricEntrypointTests.class.getClassLoader(), context));
        });
        check("opt-in does not allow method references for external mods", () -> {
            var external = new ModMetadata("external", "1.0.0", Platform.FABRIC, modules.getFirst(), List.of(), List.of(new Entrypoint("common", Callback.class.getName() + "::run", "default")), List.of(), "intermediary", Set.of());
            var dispatcher = new CompatibilityDispatcher(Set.of(networking.jar()));
            expectCode("UNSUPPORTED_ADAPTER", () -> dispatcher.initialize(external, "common", FabricEntrypointTests.class.getClassLoader(), new ModContext(external.id(), temporary, new EventBus()))); eq(0, calls);
        });
        check("verified jar role does not permit loader engine namespace entrypoints", () -> {
            var spoof = replacement(networking, "net.fabricmc.loader.api.FabricLoader"); var dispatcher = new CompatibilityDispatcher(Set.copyOf(modules));
            expectCode("INVALID_ENTRYPOINT", () -> dispatcher.initialize(spoof, "common", FabricEntrypointTests.class.getClassLoader(), new ModContext(spoof.id(), temporary, new EventBus())));
        });
        check("verified role retains declared source ownership and rejects malformed method refs", () -> {
            var missing = replacement(networking, "net.fabricmc.fabric.Missing::init");
            expectCode("ENTRYPOINT_SOURCE_MISMATCH", () -> new CompatibilityDispatcher(Set.copyOf(modules)).initialize(missing, "common", FabricEntrypointTests.class.getClassLoader(), new ModContext(missing.id(), temporary, new EventBus())));
            var malformed = replacement(networking, "net.fabricmc.fabric.impl.networking.NetworkingImpl::init::other");
            expectCode("UNSUPPORTED_ADAPTER", () -> new CompatibilityDispatcher(Set.copyOf(modules)).initialize(malformed, "common", FabricEntrypointTests.class.getClassLoader(), new ModContext(malformed.id(), temporary, new EventBus())));
        });
        check("static void no-argument adapter executes representative callback", () -> {
            CompatibilityDispatcher.invokeStaticNoArg(networking, "common", Callback.class.getDeclaredMethod("run")); eq(1, calls);
        });
        check("static adapter rejects instance, argument and return-value contracts", () -> {
            expectCode("UNSUPPORTED_ADAPTER", () -> CompatibilityDispatcher.invokeStaticNoArg(networking, "common", Callback.class.getDeclaredMethod("instance")));
            expectCode("UNSUPPORTED_ADAPTER", () -> CompatibilityDispatcher.invokeStaticNoArg(networking, "common", Callback.class.getDeclaredMethod("argument", String.class)));
            expectCode("UNSUPPORTED_ADAPTER", () -> CompatibilityDispatcher.invokeStaticNoArg(networking, "common", Callback.class.getDeclaredMethod("value"))); eq(1, calls);
        });
        check("static callback exceptions preserve the original cause", () -> {
            try { CompatibilityDispatcher.invokeStaticNoArg(networking, "common", Callback.class.getDeclaredMethod("failure")); throw new AssertionError("Failure swallowed"); }
            catch (InvocationTargetException failure) { eq("fixture-static-failure", failure.getCause().getMessage()); }
        });
        System.out.println("Fabric entrypoints: " + passed + " passed");
    }
    private static ModMetadata replacement(ModMetadata mod, String definition) { return new ModMetadata(mod.id(), mod.version(), mod.platform(), mod.jar(), List.of(), List.of(new Entrypoint("common", definition, "default")), List.of(), "intermediary", Set.of()); }
    private static void check(String name, Checked task) throws Exception { task.run(); passed++; System.out.println("PASS " + name); }
    private static void expect(Class<? extends Throwable> type, Checked task) throws Exception { try { task.run(); } catch (Throwable error) { if (type.isInstance(error)) return; throw error; } throw new AssertionError("Expected " + type.getName()); }
    private static void expectCode(String code, Checked task) throws Exception { try { task.run(); } catch (LoaderException error) { if (error.diagnostics().stream().anyMatch(d -> d.code().equals(code))) return; throw error; } throw new AssertionError("Expected diagnostic " + code); }
    private static void eq(Object expected, Object actual) { if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual); }
    public static final class Callback {
        public static void run() { calls++; }
        public void instance() { calls++; }
        public static void argument(String value) { calls++; }
        public static int value() { calls++; return 1; }
        public static void failure() { throw new IllegalStateException("fixture-static-failure"); }
    }
}
