package dev.n9ezz.loader.resources;

import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.util.CheckClassAdapter;

/** Export integrity, hostile archive paths, fail-closed pinned injection, and optional real archive checks. */
public final class ResourcePackTests {
    private static int checks;
    private ResourcePackTests() { }

    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("n9ezz-resource-tests-");
        Path source = archive(root.resolve("source.jar"), Map.of("assets/pulse/textures/test.png", new byte[]{1,2,3},
                "assets/minecraft/lang/en_us.json", "{}".getBytes(), "example/Unused.class", new byte[]{4},
                "data/pulse/recipe/ignored.json", "{}".getBytes(), "pack.mcmeta", "untrusted".getBytes()));
        var one = ResourceArchive.export(source, root.resolve("cache-a"), "fixture");
        var two = ResourceArchive.export(source, root.resolve("cache-b"), "fixture");
        check(one.sha256().equals(two.sha256()), "Deterministic resource ZIP across cache directories");
        check(one.assets() == 2 && one.assetBytes() == 5, "Correct resource accounting");
        try (ZipFile zip = new ZipFile(one.path().toFile())) {
            check(zip.size() == 3 && zip.getEntry("example/Unused.class") == null && zip.getEntry("data/pulse/recipe/ignored.json") == null,
                    "Resource export excludes classes and data packs");
            check(Arrays.equals(zip.getInputStream(zip.getEntry("pack.mcmeta")).readAllBytes(), ResourceArchive.METADATA), "Synthesized pinned client metadata");
            check(Arrays.equals(zip.getInputStream(zip.getEntry("assets/pulse/textures/test.png")).readAllBytes(), new byte[]{1,2,3}), "Original asset bytes retained");
        }
        long unchangedTime = Files.getLastModifiedTime(one.path()).toMillis();
        ResourceArchive.export(source, root.resolve("cache-a"), "fixture");
        check(unchangedTime == Files.getLastModifiedTime(one.path()).toMillis(), "Verified cache reuse does not replace identical bytes");
        Files.writeString(one.path(), "tampered");
        var repaired = ResourceArchive.export(source, root.resolve("cache-a"), "fixture");
        check(repaired.sha256().equals(two.sha256()) && ResourceArchive.hash(repaired.path()).equals(two.sha256()), "Corrupted resource cache regenerated from archive");
        for (String bad : List.of("assets/pulse/../escape", "assets/pulse//file", "assets/Upper/file", "assets/pulse/./file", "assets/pulse\\file", "assets/pulse/x:y", "assets//file")) {
            Path hostile = archive(root.resolve("bad-" + checks + ".jar"), Map.of(bad, new byte[]{1}));
            reject(IOException.class, () -> ResourceArchive.export(hostile, root.resolve("hostile-cache"), "fixture"), "Reject unsafe path " + bad);
        }
        Path oversize = archive(root.resolve("oversize.jar"), Map.of("assets/pulse/large.bin", new byte[ResourceArchive.MAX_ENTRY_BYTES + 1]));
        reject(IOException.class, () -> ResourceArchive.export(oversize, root.resolve("oversize-cache"), "fixture"), "Reject oversized asset before decompression");
        Path directory = Files.createDirectory(root.resolve("symlink-target"));
        Files.createSymbolicLink(root.resolve("cache-link"), directory);
        reject(IOException.class, () -> ResourceArchive.export(source, root.resolve("cache-link"), "fixture"), "Reject symlink resource-cache directory");
        reject(IOException.class, () -> ResourceArchive.export(source, root.resolve("cache-a"), "../key"), "Reject traversal cache key");
        reject(IOException.class, () -> ResourceArchive.validateAssetPath("assets/pulse/" + "x".repeat(1_024)), "Reject oversized asset path");

        byte[] fixture = fixture();
        byte[] transformed = ModResourcePacks.transform(ModResourcePacks.TARGET, fixture);
        validate(transformed);
        ClassNode node = new ClassNode(); new ClassReader(transformed).accept(node, 0);
        long hookCount = node.methods.stream().flatMap(method -> Arrays.stream(method.instructions.toArray()))
                .filter(instruction -> instruction instanceof MethodInsnNode call && call.owner.equals("dev/n9ezz/loader/resources/ModResourcePacks") && call.name.equals("appendProviders")).count();
        check(hookCount == 1, "Exactly one provider append call in pinned client constructor");
        check(ModResourcePacks.transform("example.Unrelated", fixture) == fixture, "Non-target class bytes untouched");
        reject(LoaderException.class, () -> ModResourcePacks.transform(ModResourcePacks.TARGET, transformed), "Reject duplicate hook installation");
        reject(LoaderException.class, () -> ModResourcePacks.transform(ModResourcePacks.TARGET, emptyFixture()), "Reject changed constructor shape");
        try (ModResourcePacks runtime = ModResourcePacks.prepare(root.resolve("runtime"), List.of(metadata(source)))) {
            check(runtime.packs().isEmpty(), "Unverified external mod cannot acquire builtin resource-pack role");
            TransformationPipeline pipeline = new TransformationPipeline(); runtime.register(pipeline); pipeline.freeze();
            check(pipeline.order().equals(List.of("CORE:n9ezz:client-resources")), "Own bridge is registered in CORE stage");
            reject(LoaderException.class, () -> ModResourcePacks.prepare(root.resolve("second-runtime"), List.of()), "Reject concurrent second active resource runtime");
            reject(LoaderException.class, () -> ModResourcePacks.appendProviders(new Object[0]), "Reject wrong provider ABI array");
        }
        reject(LoaderException.class, () -> ModResourcePacks.appendProviders(new Object[0]), "Reject closed runtime bridge");

        if (args.length >= 1) try (ModResourcePacks real = ModResourcePacks.prepare(root.resolve("real-runtime"), List.of(metadata(Path.of(args[0]))))) {
            check(real.packs().size() == 1 && real.packs().getFirst().assets() == 398 && real.packs().getFirst().assetBytes() == 47_203_943,
                    "Actual verified client exports 398 original assets");
            try (ZipFile zip = new ZipFile(real.packs().getFirst().archive().toFile())) {
                check(zip.getEntry("assets/pulse/textures/splash_logo.png") != null, "Actual requested Pulse splash texture exists in native pack ZIP");
            }
        }
        if (args.length >= 2) try (ZipFile game = new ZipFile(args[1])) {
            byte[] original = game.getInputStream(game.getEntry("net/minecraft/class_310.class")).readAllBytes();
            validate(ModResourcePacks.transform(ModResourcePacks.TARGET, original));
            check(true, "Pinned injection matches actual Minecraft 1.21.11 client bytes");
        }
        System.out.println("Resource pack checks passed: " + checks);
    }

    private static ModMetadata metadata(Path jar) { return new ModMetadata("pulse", "1.5.3-n9ezz", Platform.FABRIC, jar, List.of(), List.of(), List.of(), "intermediary", Set.of()); }
    private static Path archive(Path path, Map<String, byte[]> entries) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(path))) {
            for (var entry : entries.entrySet()) { zip.putNextEntry(new ZipEntry(entry.getKey())); zip.write(entry.getValue()); zip.closeEntry(); }
        }
        return path;
    }
    private static byte[] fixture() {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "net/minecraft/class_310", null, "java/lang/Object", null);
        var constructor = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "(Lnet/minecraft/class_542;)V", null, null);
        constructor.visitCode(); constructor.visitVarInsn(Opcodes.ALOAD, 0); constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        constructor.visitTypeInsn(Opcodes.NEW, "net/minecraft/class_3283"); constructor.visitInsn(Opcodes.DUP); constructor.visitInsn(Opcodes.ICONST_0);
        constructor.visitTypeInsn(Opcodes.ANEWARRAY, "net/minecraft/class_3285");
        constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "net/minecraft/class_3283", "<init>", "([Lnet/minecraft/class_3285;)V", false);
        constructor.visitInsn(Opcodes.POP); constructor.visitInsn(Opcodes.RETURN); constructor.visitMaxs(0, 0); constructor.visitEnd(); writer.visitEnd(); return writer.toByteArray();
    }
    private static byte[] emptyFixture() {
        ClassWriter writer = new ClassWriter(0); writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "net/minecraft/class_310", null, "java/lang/Object", null); writer.visitEnd(); return writer.toByteArray();
    }
    private interface Checked { void run() throws Exception; }
    private static void validate(byte[] bytes) { new ClassReader(bytes).accept(new CheckClassAdapter(new ClassWriter(0), true), 0); }
    private static void reject(Class<? extends Throwable> expected, Checked action, String message) throws Exception {
        try { action.run(); } catch (Throwable error) { if (expected.isInstance(error)) { check(true, message); return; } throw error; }
        throw new AssertionError(message);
    }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message); checks++; System.out.println("PASS " + message);
    }
}
