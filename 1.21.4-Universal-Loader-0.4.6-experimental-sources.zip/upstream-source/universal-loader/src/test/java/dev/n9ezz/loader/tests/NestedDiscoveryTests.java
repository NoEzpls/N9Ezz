package dev.n9ezz.loader.tests;

import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.discovery.NestedJarResolver;
import dev.n9ezz.loader.metadata.MetadataException;
import dev.n9ezz.loader.metadata.MetadataReader;

import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;

/** Black-box archive fixtures exercise a closure; no test mod executes code. */
public final class NestedDiscoveryTests {
    private static int passed;
    private static Path work;
    private NestedDiscoveryTests() { }

    public static void main(String[] args) throws Exception {
        work = Files.createTempDirectory("n9ezz-nested-tests-");
        try {
            tests();
            if (args.length == 2) actualClosure(Path.of(args[0]), Path.of(args[1]));
            System.out.println("Nested discovery: " + passed + " checks PASS");
        } finally {
            try (var stream = Files.walk(work)) {
                for (Path path : stream.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }

    private static void tests() throws Exception {
        byte[] leaf = archive("leaf", Map.of("fixture/Leaf.class", new byte[] {1}), List.of());
        byte[] root = archive("root", Map.of("libs/leaf.jar", leaf, "fixture/Root.class", new byte[] {2}), List.of("libs/leaf.jar"));
        Path file = write("root.jar", root);
        var result = discover("valid", List.of(new NestedJarResolver.Source(file)));
        check(result.mods().stream().map(m -> m.id()).toList().equals(List.of("root", "leaf")), "parent then nested ordering");
        check(result.archives().size() == 2 && result.libraries().isEmpty(), "two metadata archives");
        check(result.archives().get(1).origins().getFirst().parentSha256().equals(hash(root)), "parent content provenance");
        check(result.archives().get(1).sha256().equals(hash(leaf)), "nested byte hash");
        check(java.util.Arrays.equals(Files.readAllBytes(result.archives().get(1).jar()), leaf), "cache contains original bytes");
        expectMetadata("METADATA_UNSUPPORTED", () -> MetadataReader.read(file), "old flat API rejects nested archives");
        byte[] altered = leaf.clone(); altered[0] ^= 1;
        Files.write(result.archives().get(1).jar(), altered);
        expect("NESTED_CACHE_MISMATCH", () -> discover("valid", List.of(new NestedJarResolver.Source(file))), "tampered cache preserved");
        check(java.util.Arrays.equals(Files.readAllBytes(result.archives().get(1).jar()), altered), "tampered cache was not overwritten");
        Path lockedCache = work.resolve("busy/.n9ezz/nested"); Files.createDirectories(lockedCache);
        try (var channel = java.nio.channels.FileChannel.open(lockedCache.resolve(hash(leaf) + ".lock"), java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.WRITE);
                var lock = channel.lock()) {
            expect("NESTED_CACHE_BUSY", () -> discover("busy", List.of(new NestedJarResolver.Source(file))), "concurrent extraction lock respected");
        }
        expect("NESTED_HASH_MISMATCH", () -> discover("pin", List.of(new NestedJarResolver.Source(file, "pinned", "0".repeat(64), null))), "incorrect pinned root hash");
        var duplicate = discover("dedup", List.of(new NestedJarResolver.Source(file), new NestedJarResolver.Source(file)));
        check(duplicate.archives().size() == 2 && duplicate.archives().getFirst().origins().size() == 2, "same content deduplicated with both provenances");

        byte[] other = archive("other", Map.of("libs/leaf.jar", leaf), List.of("libs/leaf.jar"));
        var shared = discover("shared", List.of(new NestedJarResolver.Source(file), new NestedJarResolver.Source(write("other.jar", other))));
        check(shared.mods().size() == 3 && shared.archives().get(1).origins().size() == 2, "same nested dependency shared by parents");
        byte[] conflict = archive("leaf", Map.of("other.class", new byte[] {3}), List.of());
        expect("DUPLICATE_MOD_ID", () -> discover("id", List.of(new NestedJarResolver.Source(file), new NestedJarResolver.Source(write("conflict.jar", conflict)))), "external mod ID conflicts with nested dependency");
        byte[] collision = archive("collision", Map.of("fixture/Leaf.class", new byte[] {8}), List.of());
        expect("DUPLICATE_CLASS", () -> discover("class", List.of(new NestedJarResolver.Source(file), new NestedJarResolver.Source(write("collision.jar", collision)))), "duplicate class among root and nested archives");
        byte[] alias = raw(Map.of("fabric.mod.json", "{\"schemaVersion\":1,\"id\":\"alias\",\"version\":\"1\",\"provides\":[\"leaf\"]}".getBytes()));
        expect("DUPLICATE_MOD_ID", () -> discover("alias", List.of(new NestedJarResolver.Source(file), new NestedJarResolver.Source(write("alias.jar", alias)))), "external alias conflict");

        var selected = discover("select", List.of(new NestedJarResolver.Source(file, Set.of("leaf"))));
        check(selected.mods().size() == 2 && selected.omitted().isEmpty(), "exact child ID selection");
        var omitted = discover("omit", List.of(new NestedJarResolver.Source(file, Set.of())));
        check(omitted.mods().size() == 1 && omitted.omitted().size() == 1, "unselected children inventoried without classpath exposure");
        expect("NESTED_SELECTION_MISSING", () -> discover("missing", List.of(new NestedJarResolver.Source(file, Set.of("absent")))), "missing selected child diagnostic");
        expect("NESTED_SELECTION_CONFLICT", () -> discover("ambiguous", List.of(new NestedJarResolver.Source(file), new NestedJarResolver.Source(file, Set.of()))), "conflicting selection of same bytes");

        byte[] library = raw(Map.of("lib/Utility.class", new byte[] {6}));
        Path libraryRoot = write("library-root.jar", archive("library_root", Map.of("libs/utility.jar", library), List.of("libs/utility.jar")));
        var libraries = discover("library", List.of(new NestedJarResolver.Source(libraryRoot)));
        check(libraries.libraries().size() == 1 && libraries.mods().size() == 1, "declared metadata-less library accepted separately");
        expect("MISSING_METADATA", () -> discover("flatlib", List.of(new NestedJarResolver.Source(write("flatlib.jar", library)))), "external metadata-less libraries rejected");
        var strict = limits(8, 256, 128L << 20, 64L << 20, 256L << 20, 200_000, 1000, false);
        expect("MISSING_METADATA", () -> NestedJarResolver.discover(work.resolve("strictlib"), List.of(new NestedJarResolver.Source(libraryRoot)), strict), "optional metadata-less library policy disabled");

        byte[] middle = archive("middle", Map.of("libs/leaf.jar", leaf), List.of("libs/leaf.jar"));
        Path deep = write("deep.jar", archive("deep", Map.of("libs/middle.jar", middle), List.of("libs/middle.jar")));
        expect("NESTED_DEPTH_LIMIT", () -> NestedJarResolver.discover(work.resolve("depth"), List.of(new NestedJarResolver.Source(deep)), limits(1, 256, 128L << 20, 64L << 20, 256L << 20, 200_000, 1000, true)), "deep recursive fixture bounded");
        expect("NESTED_ARCHIVE_LIMIT", () -> NestedJarResolver.discover(work.resolve("count"), List.of(new NestedJarResolver.Source(file)), limits(8, 1, 128L << 20, 64L << 20, 256L << 20, 200_000, 1000, true)), "closure count bounded");
        expect("NESTED_EXPANDED_LIMIT", () -> NestedJarResolver.discover(work.resolve("budget"), List.of(new NestedJarResolver.Source(file)), limits(8, 256, 128L << 20, 64L << 20, 50, 200_000, 1000, true)), "expanded bytes bounded");
        expect("NESTED_SIZE_LIMIT", () -> NestedJarResolver.discover(work.resolve("size"), List.of(new NestedJarResolver.Source(file)), limits(8, 256, 128L << 20, 10, 256L << 20, 200_000, 1000, true)), "individual nested bytes bounded");
        expect("NESTED_ENTRY_LIMIT", () -> NestedJarResolver.discover(work.resolve("entries"), List.of(new NestedJarResolver.Source(file)), limits(8, 256, 128L << 20, 64L << 20, 256L << 20, 1, 1000, true)), "archive entries bounded");
        Path bomb = write("bomb.jar", archive("bomb", Map.of("zeros.dat", new byte[2 << 20]), List.of()));
        expect("NESTED_COMPRESSION_LIMIT", () -> NestedJarResolver.discover(work.resolve("bomb"), List.of(new NestedJarResolver.Source(bomb)), limits(8, 256, 128L << 20, 64L << 20, 256L << 20, 200_000, 100, true)), "compressed bomb fixture rejected before decompression");
        byte[] duplicateZip = raw(Map.of("a.class", new byte[] {1}, "b.class", new byte[] {2}));
        replace(duplicateZip, "b.class".getBytes(), "a.class".getBytes());
        Path duplicateEntries = write("duplicatezip.jar", duplicateZip);
        expect("NESTED_DUPLICATE_ENTRY", () -> discover("duplicatezip", List.of(new NestedJarResolver.Source(duplicateEntries))), "duplicate ZIP entry rejected");
        byte[] badCrc = stored("crc.dat", new byte[] {25, 26, 27, 28});
        replace(badCrc, new byte[] {25, 26, 27, 28}, new byte[] {25, 26, 27, 29});
        Path corrupt = write("corrupt.jar", badCrc);
        expect("NESTED_CRC_MISMATCH", () -> discover("corrupt", List.of(new NestedJarResolver.Source(corrupt))), "ZIP entry CRC mismatch rejected");
        // A physical finite archive cannot contain its own SHA-256-identical byte
        // representation without a hash fixed point. Inject the traversal ancestry
        // state to exercise the defense before any archive parsing/extraction.
        var constructor = NestedJarResolver.class.getDeclaredConstructor(Path.class, NestedJarResolver.Limits.class);
        constructor.setAccessible(true);
        Object resolver = constructor.newInstance(work.resolve("cycle"), NestedJarResolver.Limits.DEFAULT);
        var visit = NestedJarResolver.class.getDeclaredMethod("visit", Path.class, String.class, NestedJarResolver.Origin.class, Set.class, Set.class);
        visit.setAccessible(true);
        try {
            visit.invoke(resolver, file, hash(root), new NestedJarResolver.Origin("cycle", hash(root), "cycle.jar", 1), null, new HashSet<>(Set.of(hash(root))));
            throw new AssertionError("cyclic ancestry was accepted");
        } catch (java.lang.reflect.InvocationTargetException expected) {
            check(expected.getCause() instanceof LoaderException loader && loader.diagnostics().getFirst().code().equals("NESTED_CYCLE"), "content cycle ancestry rejected before extraction");
        }
        Path unsafe = write("unsafe.jar", raw(Map.of("../escape.class", new byte[] {0})));
        expect("NESTED_UNSAFE_ENTRY", () -> discover("unsafe", List.of(new NestedJarResolver.Source(unsafe))), "ZIP traversal rejected");
        Path link = work.resolve("link.jar"); Files.createSymbolicLink(link, file);
        expect("NESTED_CACHE_SYMLINK", () -> discover("link", List.of(new NestedJarResolver.Source(link))), "symlink source rejected");
        Path cacheDir = work.resolve("cachelink/.n9ezz"); Files.createDirectories(cacheDir);
        Files.createSymbolicLink(cacheDir.resolve("nested"), work.resolve("dedup/.n9ezz/nested"));
        expect("NESTED_CACHE_SYMLINK", () -> discover("cachelink", List.of(new NestedJarResolver.Source(file))), "symlink cache rejected");

        Path undeclared = write("undeclared.jar", archive("undeclared", Map.of("hidden.jar", leaf), List.of()));
        expectMetadata("METADATA_UNSUPPORTED", () -> discover("undeclared", List.of(new NestedJarResolver.Source(undeclared))), "undeclared archive rejected");
        Path missing = write("declaredmissing.jar", archive("missing", Map.of(), List.of("missing.jar")));
        expectMetadata("METADATA_INVALID", () -> discover("declaredmissing", List.of(new NestedJarResolver.Source(missing))), "missing declared nested archive rejected");
        String advanced = "{\"schemaVersion\":1,\"id\":\"advanced\",\"version\":\"1\",\"entrypoints\":{\"main\":[\"fixture.Factory::init\"]},\"accessWidener\":\"test.accesswidener\",\"suggests\":{\"optional\":\"*\"}}";
        Path advancedJar = write("advanced.jar", raw(Map.of("fabric.mod.json", advanced.getBytes(), "test.accesswidener", "accessWidener v2 intermediary\n".getBytes())));
        expectMetadata("METADATA_UNSUPPORTED", () -> MetadataReader.read(advancedJar), "flat advanced descriptor rejected");
        var advancedMetadata = MetadataReader.readArchive(advancedJar, MetadataReader.ReadPolicy.FABRIC_RUNTIME);
        check(advancedMetadata.mods().getFirst().entrypoints().getFirst().className().equals("fixture.Factory::init"), "method reference retained without execution");
        check(advancedMetadata.features().accessWideners().equals(List.of("test.accesswidener")), "access widener declaration retained");
        check(advancedMetadata.mods().getFirst().dependencies().getFirst().optional(), "optional dependency retains semantics");
    }

    private static void actualClosure(Path client, Path api) throws Exception {
        Set<String> modules = Set.of("fabric-api-base", "fabric-lifecycle-events-v1", "fabric-networking-api-v1", "fabric-command-api-v2", "fabric-key-binding-api-v1", "fabric-rendering-v1");
        var closure = NestedJarResolver.discover(work.resolve("actual"), List.of(new NestedJarResolver.Source(client), new NestedJarResolver.Source(api, modules)));
        check(closure.mods().size() == 14, "real client six nested libraries plus API six selected modules");
        check(closure.archives().size() == 14 && closure.omitted().size() == 37, "actual selected closure inventory");
        check(closure.mods().stream().filter(m -> m.id().equals("fabric-api")).findFirst().orElseThrow().provides().contains("fabric"), "official umbrella fabric alias retained");
        check(closure.features().values().stream().mapToInt(f -> f.accessWideners().size()).sum() == 3, "selected API three declared access wideners");
        for (var archive : closure.archives()) System.out.println("ARCHIVE " + archive.sha256() + " " + archive.size() + " " + archive.modIds() + " " + archive.origins());
    }

    private static NestedJarResolver.Result discover(String name, List<NestedJarResolver.Source> sources) throws Exception { return NestedJarResolver.discover(work.resolve(name), sources); }
    private static NestedJarResolver.Limits limits(int depth, int count, long archive, long nested, long expanded, int entries, int ratio, boolean libraries) { return new NestedJarResolver.Limits(depth, count, archive, nested, expanded, entries, ratio, libraries); }
    private static Path write(String name, byte[] bytes) throws Exception { Path path = work.resolve(name); Files.write(path, bytes); return path; }
    private static byte[] archive(String id, Map<String, byte[]> entries, List<String> jars) throws Exception {
        String declared = String.join(",", jars.stream().map(n -> "{\"file\":\"" + n + "\"}").toList());
        var all = new LinkedHashMap<>(entries);
        all.put("fabric.mod.json", ("{\"schemaVersion\":1,\"id\":\"" + id + "\",\"version\":\"1.0.0\",\"n9ezz\":{\"namespace\":\"none\"},\"jars\":[" + declared + "]}").getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return raw(all);
    }
    private static byte[] raw(Map<String, byte[]> entries) throws Exception {
        var bytes = new ByteArrayOutputStream();
        try (var jar = new JarOutputStream(bytes)) {
            for (var item : entries.entrySet()) { var entry = new JarEntry(item.getKey()); entry.setTime(0); jar.putNextEntry(entry); jar.write(item.getValue()); jar.closeEntry(); }
        }
        return bytes.toByteArray();
    }
    private static byte[] stored(String name, byte[] data) throws Exception {
        var bytes = new ByteArrayOutputStream();
        var crc = new CRC32(); crc.update(data);
        try (var jar = new JarOutputStream(bytes)) {
            var entry = new JarEntry(name); entry.setMethod(ZipEntry.STORED); entry.setSize(data.length); entry.setCompressedSize(data.length); entry.setCrc(crc.getValue());
            jar.putNextEntry(entry); jar.write(data); jar.closeEntry();
        }
        return bytes.toByteArray();
    }
    private static void replace(byte[] bytes, byte[] from, byte[] to) {
        if (from.length != to.length) throw new IllegalArgumentException();
        for (int offset = 0; offset <= bytes.length - from.length; offset++) {
            boolean match = true;
            for (int i = 0; i < from.length; i++) if (bytes[offset + i] != from[i]) { match = false; break; }
            if (match) { System.arraycopy(to, 0, bytes, offset, to.length); offset += to.length - 1; }
        }
    }
    private static String hash(byte[] bytes) throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
    private static void check(boolean success, String message) { if (!success) throw new AssertionError(message); passed++; System.out.println("PASS " + message); }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static void expect(String code, Checked checked, String message) throws Exception {
        try { checked.run(); throw new AssertionError("Expected " + code + ": " + message); }
        catch (LoaderException expected) { check(expected.diagnostics().getFirst().code().equals(code), message + " (" + expected.diagnostics().getFirst().code() + ")"); }
    }
    private static void expectMetadata(String code, Checked checked, String message) throws Exception {
        try { checked.run(); throw new AssertionError("Expected " + code + ": " + message); }
        catch (MetadataException expected) { check(expected.code().equals(code), message + " (" + expected.code() + ")"); }
    }
}
