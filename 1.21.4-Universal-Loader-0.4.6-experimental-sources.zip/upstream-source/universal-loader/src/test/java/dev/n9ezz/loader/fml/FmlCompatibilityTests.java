package dev.n9ezz.loader.fml;

import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.core.UnifiedClassLoader;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import javax.tools.ToolProvider;
import org.objectweb.asm.*;

/** Executable archive/API provenance, phase barriers, contexts and rejection regression checks. */
public final class FmlCompatibilityTests {
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static int passed, sequence;
    private static Path directory;
    private FmlCompatibilityTests() {}
    public static void main(String[] args) throws Exception {
        if (args.length != 0) throw new IllegalArgumentException("No arguments expected");
        directory = Files.createTempDirectory("n9ezz-fml-tests-");
        Path forge = sourceJar(Map.of("flt/Forge.java", FORGE));
        Path neo = sourceJar(Map.of("flt/Neo.java", NEO));
        ModMetadata fm = metadata("forge_life", Platform.FORGE, forge), nm = metadata("neo_life", Platform.NEOFORGE, neo);
        check("language baselines do not advertise whole platform providers", () -> {
            eq(Map.of("javafml", "61.0"), FmlCompatibilityRuntime.providerVersions(Platform.FORGE));
            eq(Map.of("javafml", "10.0.36"), FmlCompatibilityRuntime.providerVersions(Platform.NEOFORGE));
            eq(Map.of(), FmlCompatibilityRuntime.providerVersions(Platform.FABRIC));
        });
        check("common/client/complete barriers run after every constructor with deferred phase FIFO", () -> {
            reset();
            ClassLoader caller = Thread.currentThread().getContextClassLoader();
            try (var loader = loader(List.of(forge, neo)); var runtime = new FmlCompatibilityRuntime(List.of(fm, nm))) {
                runtime.construct(fm, loader); runtime.construct(nm, loader);
                eq("forge:construct;neo:construct;", trace());
                runtime.dispatchCommonSetup();
                eq("forge:construct;neo:construct;forge:high;forge:common;neo:common;forge:work;neo:work;", trace());
                runtime.dispatchClientSetup(); runtime.dispatchLoadComplete();
                eq("forge:construct;neo:construct;forge:high;forge:common;neo:common;forge:work;neo:work;forge:client;neo:client;forge:clientWork;neo:clientWork;forge:complete;neo:complete;", trace());
                eq(loader.toString(), System.getProperty("flt.forgeLoader")); eq(loader.toString(), System.getProperty("flt.neoLoader"));
                eq(List.of("forge_life:construct:flt.Forge", "neo_life:construct:flt.Neo", "forge_life:common", "neo_life:common", "deferred:common", "forge_life:client", "neo_life:client", "deferred:client", "forge_life:complete", "neo_life:complete", "deferred:complete"), runtime.trace());
                eq(true, ((CompletableFuture<?>) loader.loadClass("flt.Forge").getField("future").get(null)).isDone());
            }
            same(caller, Thread.currentThread().getContextClassLoader());
        });
        check("constructors and successful lifecycle phases run at most once", () -> {
            reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                runtime.construct(fm, loader); runtime.construct(fm, loader);
                runtime.dispatchCommonSetup(); runtime.dispatchCommonSetup(); runtime.dispatchClientSetup(); runtime.dispatchClientSetup(); runtime.dispatchLoadComplete(); runtime.dispatchLoadComplete();
                eq("forge:construct;forge:high;forge:common;forge:work;forge:client;forge:clientWork;forge:complete;", trace());
            }
        });
        check("all declared FML constructors must finish before common setup", () -> {
            reset(); try (var loader = loader(List.of(forge, neo)); var runtime = new FmlCompatibilityRuntime(List.of(fm, nm))) {
                runtime.construct(fm, loader); code("FML_UNCONSTRUCTED_MOD", runtime::dispatchCommonSetup); eq("forge:construct;", trace());
                runtime.construct(nm, loader); runtime.dispatchCommonSetup();
            }
        });
        check("client setup cannot run before common setup", () -> {
            reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                runtime.construct(fm, loader); code("FML_LIFECYCLE_ORDER", runtime::dispatchClientSetup); eq("forge:construct;", trace());
            }
        });
        check("constructor failures preserve cause and are never retried", () -> {
            reset(); System.setProperty("flt.mode", "constructor");
            try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                LoaderException failure = code("FML_CONSTRUCTION_FAILED", () -> runtime.construct(fm, loader));
                eq("constructor failure", failure.getCause().getMessage());
                same(failure, code("FML_CONSTRUCTION_FAILED", () -> runtime.construct(fm, loader))); eq("forge:construct;", trace());
            } finally { System.clearProperty("flt.mode"); }
        });
        check("listener failure aborts pending deferred futures and restores contexts", () -> {
            reset(); System.setProperty("flt.mode", "listener"); ClassLoader caller = Thread.currentThread().getContextClassLoader();
            try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                runtime.construct(fm, loader); LoaderException failure = code("FML_LIFECYCLE_FAILED", runtime::dispatchCommonSetup);
                eq("listener failure", failure.getCause().getMessage());
                eq(true, ((CompletableFuture<?>) loader.loadClass("flt.Forge").getField("future").get(null)).isCompletedExceptionally());
                same(failure, code("FML_LIFECYCLE_FAILED", runtime::dispatchClientSetup)); same(caller, Thread.currentThread().getContextClassLoader());
            } finally { System.clearProperty("flt.mode"); }
        });
        check("deferred failure completes its future exceptionally and prevents later phases", () -> {
            reset(); System.setProperty("flt.mode", "work");
            try (var loader = loader(List.of(forge, neo)); var runtime = new FmlCompatibilityRuntime(List.of(fm, nm))) {
                runtime.construct(fm, loader); runtime.construct(nm, loader); LoaderException failure = code("FML_LIFECYCLE_FAILED", runtime::dispatchCommonSetup);
                eq("forge_life", failure.diagnostics().getFirst().modId());
                eq(true, ((CompletableFuture<?>) loader.loadClass("flt.Forge").getField("future").get(null)).isCompletedExceptionally());
                eq(true, ((CompletableFuture<?>) loader.loadClass("flt.Neo").getField("future").get(null)).isCompletedExceptionally());
                eq(false, trace().contains("client"));
            } finally { System.clearProperty("flt.mode"); }
        });
        check("platform context does not leak beyond constructor/listener/deferred work", () -> {
            expect(IllegalStateException.class, net.minecraftforge.fml.ModLoadingContext::get);
            expect(IllegalStateException.class, net.neoforged.fml.ModLoadingContext::get);
        });
        check("retained events cannot enqueue outside a lifecycle barrier", () -> {
            reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                runtime.construct(fm, loader); runtime.dispatchCommonSetup();
                var event = (net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent) loader.loadClass("flt.Forge").getField("retained").get(null);
                expect(IllegalStateException.class, () -> event.enqueueWork(() -> {}));
                runtime.close(); expect(IllegalStateException.class, () -> event.enqueueWork(() -> {}));
            }
        });
        check("wrong thread cannot construct or dispatch a platform lifecycle", () -> {
            reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                AtomicReference<Throwable> captured = new AtomicReference<>();
                Thread thread = new Thread(() -> { try { runtime.construct(fm, loader); } catch (Throwable error) { captured.set(error); } }); thread.start(); thread.join();
                eq(true, captured.get() instanceof IllegalStateException); eq("", trace()); runtime.construct(fm, loader);
            }
        });
        check("wrong classloader/source is rejected before static initialization or construction", () -> {
            reset(); Path duplicate = sourceJar(Map.of("flt/Forge.java", FORGE));
            try (URLClassLoader wrong = new URLClassLoader(new java.net.URL[] {duplicate.toUri().toURL()}, FmlCompatibilityTests.class.getClassLoader()); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                code("ENTRYPOINT_SOURCE_MISMATCH", () -> runtime.construct(fm, wrong)); eq("", trace());
            }
        });
        check("metadata identity cannot substitute a different version after resolution", () -> {
            try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                ModMetadata wrong = new ModMetadata(fm.id(), "9", fm.platform(), fm.jar(), fm.dependencies(), fm.entrypoints(), fm.mixins(), fm.namespace(), fm.provides());
                code("FML_METADATA_MISMATCH", () -> runtime.construct(wrong, loader));
            }
        });
        check("all-archive preflight catches unsupported API in an unannotated helper before any mod starts", () -> {
            reset(); Path bad = augment(forge, "flt/Unused.class", helper("flt/Unused", writer -> writer.visitField(Opcodes.ACC_PUBLIC, "unavailable", "Lnet/minecraftforge/registries/DeferredRegister;", null, null).visitEnd()));
            code("UNSUPPORTED_PLATFORM_API", () -> new FmlCompatibilityRuntime(List.of(fm, metadata("bad_helper", Platform.FORGE, bad))).close()); eq("", trace());
        });
        check("all-archive preflight rejects Minecraft namespace references", () -> {
            Path bad = augment(forge, "flt/Unused.class", helper("flt/Unused", writer -> writer.visitField(Opcodes.ACC_PUBLIC, "game", "Lnet/minecraft/client/Minecraft;", null, null).visitEnd()));
            contains(code("UNSUPPORTED_PLATFORM_API", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, bad))).close()).getMessage(), "unmapped/patched Minecraft");
        });
        check("generic signature references do not bypass API preflight", () -> {
            Path bad = augment(forge, "flt/Unused.class", helper("flt/Unused", writer -> writer.visitField(Opcodes.ACC_PUBLIC, "generic", "Ljava/util/List;", "Ljava/util/List<Lnet/neoforged/fml/config/ModConfig;>;", null).visitEnd()));
            code("UNSUPPORTED_PLATFORM_API", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, bad))).close());
        });
        check("unimplemented member of an otherwise supported platform type fails before callbacks", () -> badMember(forge, method -> method.visitMethodInsn(Opcodes.INVOKESTATIC, "net/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext", "missing", "()V", false)));
        check("wrong static/instance platform member usage fails before callbacks", () -> badMember(forge, method -> method.visitMethodInsn(Opcodes.INVOKESTATIC, "net/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext", "getModBusGroup", "()Lnet/minecraftforge/eventbus/api/bus/BusGroup;", false)));
        check("runtime-only platform binding helpers are not granted to mods", () -> badMember(forge, method -> method.visitMethodInsn(Opcodes.INVOKESTATIC, "net/minecraftforge/fml/ModLoadingContext", "n9ezzEnter", "(Lnet/minecraftforge/fml/ModLoadingContext;)Ljava/lang/AutoCloseable;", false)));
        check("nested ConstantDynamic platform handles are validated", () -> badMember(forge, method -> {
            Handle bootstrap = new Handle(Opcodes.H_INVOKESTATIC, "java/lang/invoke/ConstantBootstraps", "nullConstant", "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;", false);
            ConstantDynamic inner = new ConstantDynamic("inner", "Ljava/lang/Object;", bootstrap, new Handle(Opcodes.H_INVOKESTATIC, "net/minecraftforge/fml/ModLoadingContext", "missing", "()V", false));
            method.visitLdcInsn(new ConstantDynamic("outer", "Ljava/lang/Object;", bootstrap, inner)); method.visitInsn(Opcodes.POP);
        }));
        check("Forge context constructor takes precedence over no-arg constructor", () -> {
            reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) { runtime.construct(fm, loader); eq("forge:construct;", trace()); }
        });
        check("Neo repeated constructor argument types and multiple public constructors fail preflight", () -> {
            for (String source : List.of("package flt; @net.neoforged.fml.common.Mod(\"neo_bad\") public class Bad {public Bad(net.neoforged.bus.api.IEventBus a, net.neoforged.bus.api.IEventBus b){}}",
                    "package flt; @net.neoforged.fml.common.Mod(\"neo_bad\") public class Bad {public Bad(){} public Bad(net.neoforged.bus.api.IEventBus b){}}")) {
                Path jar = sourceJar(Map.of("flt/Bad.java", source)); code("UNSUPPORTED_MOD_CONSTRUCTOR", () -> new FmlCompatibilityRuntime(List.of(metadata("neo_bad", Platform.NEOFORGE, jar))).close());
            }
        });
        check("Neo unsupported constructor services fail preflight", () -> {
            Path jar = sourceJar(Map.of("flt/Bad.java", "package flt; @net.neoforged.fml.common.Mod(\"neo_bad\") public class Bad {public Bad(String service){}}"));
            code("UNSUPPORTED_MOD_CONSTRUCTOR", () -> new FmlCompatibilityRuntime(List.of(metadata("neo_bad", Platform.NEOFORGE, jar))).close());
        });
        check("Neo side filters and optional missing depends skip constructors", () -> {
            reset(); Path jar = sourceJar(Map.of("flt/Server.java", "package flt; @net.neoforged.fml.common.Mod(value=\"neo_side\",dist={net.neoforged.api.distmarker.Dist.DEDICATED_SERVER}) public class Server {public Server(){throw new AssertionError(\"server constructed\");}}",
                    "flt/Optional.java", "package flt; @net.neoforged.fml.common.Mod(value=\"neo_side\",depends={\"absent\"}) public class Optional {public Optional(){throw new AssertionError(\"optional constructed\");}}"));
            ModMetadata mod = metadata("neo_side", Platform.NEOFORGE, jar);
            try (var loader = loader(List.of(jar)); var runtime = new FmlCompatibilityRuntime(List.of(mod))) { runtime.construct(mod, loader); runtime.dispatchCommonSetup(); runtime.dispatchClientSetup(); runtime.dispatchLoadComplete(); eq("", trace()); }
        });
        check("private platform engine references and module descriptors are rejected", () -> {
            Path jar = augment(forge, "flt/Unused.class", helper("flt/Unused", writer -> writer.visitField(Opcodes.ACC_PUBLIC, "engine", "Lcpw/mods/modlauncher/Launcher;", null, null).visitEnd()));
            code("UNSUPPORTED_PLATFORM_API", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, jar))).close());
            Path module = augment(forge, "module-info.class", helper("module-info", writer -> {}));
            code("UNSUPPORTED_FML_MODULE", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, module))).close());
        });
        check("typed Forge bus priorities, remove/re-add and same-instance identity are preserved", FmlCompatibilityTests::forgeBus);
        check("Neo explicit class listener ordering and unregister preserve consumer identity", FmlCompatibilityTests::neoBus);
        check("erased Neo lambdas require an explicit event class rather than silently matching all events", () -> {
            var bus = FmlEventBuses.neoBus(); try { expect(UnsupportedOperationException.class, () -> bus.addListener((net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent event) -> {})); }
            finally { FmlEventBuses.disposeNeo(bus); }
        });
        check("reentrant phase barriers cannot advance client setup during common dispatch", () -> {
            reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                runtime.construct(fm, loader);
                var group = (net.minecraftforge.eventbus.api.bus.BusGroup) loader.loadClass("flt.Forge").getField("retainedGroup").get(null);
                net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent.getBus(group).addListener((byte) 100, event -> {
                    try { runtime.dispatchClientSetup(); throw new AssertionError("Nested phase accepted"); }
                    catch (LoaderException expected) { eq("FML_LIFECYCLE_REENTRANT", expected.diagnostics().getFirst().code()); }
                    catch (Exception unexpected) { throw new AssertionError(unexpected); }
                });
                runtime.dispatchCommonSetup(); eq(false, trace().contains("client")); runtime.dispatchClientSetup();
            }
        });
        check("type annotations and malformed bytecode cannot bypass all-class preflight", () -> {
            Path annotation = augment(forge, "flt/Unused.class", helper("flt/Unused", writer -> writer.visitTypeAnnotation(TypeReference.newSuperTypeReference(-1).getValue(), null, "Lnet/neoforged/fml/config/Unsupported;", true).visitEnd()));
            code("UNSUPPORTED_PLATFORM_API", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, annotation))).close());
            Path broken = augment(forge, "flt/Unused.class", new byte[] {1, 2, 3});
            code("INVALID_FML_BYTECODE", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, broken))).close());
        });
        check("mismatched class path cannot impersonate an owned archive entry", () -> {
            Path bad = augment(forge, "flt/Unused.class", helper("flt/Different", writer -> {}));
            code("FML_CLASS_PATH_MISMATCH", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, bad))).close());
        });
        check("canceled and explicitly completed deferred futures skip their suppliers", () -> {
            for (boolean cancel : List.of(true, false)) {
                reset(); try (var loader = loader(List.of(forge)); var runtime = new FmlCompatibilityRuntime(List.of(fm))) {
                    runtime.construct(fm, loader);
                    var group = (net.minecraftforge.eventbus.api.bus.BusGroup) loader.loadClass("flt.Forge").getField("retainedGroup").get(null);
                    net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent.getBus(group).addListener((byte) -100, event -> {
                        try {
                            @SuppressWarnings("unchecked") var future = (CompletableFuture<Void>) loader.loadClass("flt.Forge").getField("future").get(null);
                            eq(true, cancel ? future.cancel(false) : future.complete(null));
                        } catch (Exception unexpected) { throw new AssertionError(unexpected); }
                    });
                    runtime.dispatchCommonSetup(); eq("forge:construct;forge:high;forge:common;", trace());
                    runtime.dispatchClientSetup(); runtime.dispatchLoadComplete();
                }
            }
        });
        check("trace snapshots are immutable and close is idempotent", () -> {
            var runtime = new FmlCompatibilityRuntime(List.of()); expect(UnsupportedOperationException.class, () -> runtime.trace().add("fake")); runtime.close(); runtime.close(); expect(IllegalStateException.class, runtime::dispatchCommonSetup);
        });
        System.out.println("FML compatibility: " + passed + " passed, 0 failed");
        System.out.println("Fixtures verify bounded lifecycle ABI and real archive ownership, not complete Forge/NeoForge Minecraft support.");
    }
    private static void forgeBus() throws Exception {
        var group = net.minecraftforge.eventbus.api.bus.BusGroup.create("test." + sequence++);
        var bus = net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent.getBus(group);
        List<String> order = new ArrayList<>();
        var low = bus.addListener((byte) -64, event -> order.add("low")); var first = bus.addListener((byte) 64, event -> order.add("first"));
        bus.addListener((byte) 64, event -> order.add("second")); bus.removeListener(low); bus.addListener(low);
        same(first, bus.addListener(first)); eq(true, bus.hasListeners());
        group.shutdown(); bus.post(new net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent(new net.minecraftforge.fml.ModContainer("test"), net.minecraftforge.fml.ModLoadingStage.COMMON_SETUP)); eq(List.of(), order);
        group.startup(); bus.post(new net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent(new net.minecraftforge.fml.ModContainer("test"), net.minecraftforge.fml.ModLoadingStage.COMMON_SETUP));
        eq(List.of("first", "second", "low"), order); eq(false, bus.hasListeners());
        expect(IllegalStateException.class, () -> bus.post(new net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent(new net.minecraftforge.fml.ModContainer("test"), net.minecraftforge.fml.ModLoadingStage.COMMON_SETUP)));
        group.dispose(); group.dispose(); expect(IllegalStateException.class, () -> bus.addListener(event -> {}));
    }
    private static void neoBus() throws Exception {
        var bus = FmlEventBuses.neoBus(); List<String> order = new ArrayList<>();
        java.util.function.Consumer<net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent> remove = event -> order.add("removed");
        bus.addListener(net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent.class, remove); bus.unregister(remove);
        bus.addListener(net.neoforged.bus.api.EventPriority.LOW, net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent.class, event -> order.add("low"));
        bus.addListener(net.neoforged.bus.api.EventPriority.HIGH, net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent.class, event -> order.add("high"));
        var container = new net.neoforged.fml.ModContainer("test", bus);
        var event = new net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent(container, new net.neoforged.fml.DeferredWorkQueue()); same(event, bus.post(event)); eq(List.of("high", "low"), order);
        expect(IllegalStateException.class, () -> bus.post(event)); FmlEventBuses.disposeNeo(bus); expect(IllegalStateException.class, () -> bus.post(event));
    }
    private static void badMember(Path forge, java.util.function.Consumer<MethodVisitor> body) throws Exception {
        byte[] bytes = helper("flt/Unused", writer -> {
            var method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "unused", "()V", null, null); method.visitCode(); body.accept(method); method.visitInsn(Opcodes.RETURN); method.visitMaxs(8, 8); method.visitEnd();
        });
        Path jar = augment(forge, "flt/Unused.class", bytes); code("UNSUPPORTED_PLATFORM_API", () -> new FmlCompatibilityRuntime(List.of(metadata("forge_life", Platform.FORGE, jar))).close());
    }
    private static byte[] helper(String name, java.util.function.Consumer<ClassWriter> body) { ClassWriter writer = new ClassWriter(0); writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, name, null, "java/lang/Object", null); body.accept(writer); writer.visitEnd(); return writer.toByteArray(); }
    private static Path augment(Path original, String name, byte[] bytes) throws Exception {
        Map<String, byte[]> entries = new LinkedHashMap<>(); try (var jar = new java.util.jar.JarFile(original.toFile())) { for (var entry : jar.stream().toList()) if (!entry.isDirectory()) try (var stream = jar.getInputStream(entry)) { entries.put(entry.getName(), stream.readAllBytes()); } }
        entries.put(name, bytes); return jar(entries);
    }
    private static Path sourceJar(Map<String, String> sources) throws Exception {
        Path source = Files.createDirectory(directory.resolve("src" + sequence++)); Path output = Files.createDirectory(directory.resolve("classes" + sequence++));
        List<String> command = new ArrayList<>(List.of("--release", "21", "-proc:none", "-classpath", System.getProperty("java.class.path"), "-d", output.toString()));
        for (var entry : sources.entrySet()) { Path file = source.resolve(entry.getKey()); Files.createDirectories(file.getParent()); Files.writeString(file, entry.getValue()); command.add(file.toString()); }
        var compiler = ToolProvider.getSystemJavaCompiler(); if (compiler == null) throw new IllegalStateException("Full JDK21 compiler required for test fixtures");
        eq(0, compiler.run(null, null, null, command.toArray(String[]::new)));
        Map<String, byte[]> entries = new LinkedHashMap<>(); try (var files = Files.walk(output)) { for (Path file : files.filter(Files::isRegularFile).toList()) entries.put(output.relativize(file).toString().replace('\\', '/'), Files.readAllBytes(file)); }
        return jar(entries);
    }
    private static Path jar(Map<String, byte[]> entries) throws Exception {
        Path file = directory.resolve("fixture" + sequence++ + ".jar"); try (var stream = new JarOutputStream(Files.newOutputStream(file))) { for (var entry : entries.entrySet()) { stream.putNextEntry(new JarEntry(entry.getKey())); stream.write(entry.getValue()); stream.closeEntry(); } } return file;
    }
    private static ModMetadata metadata(String id, Platform platform, Path jar) { return new ModMetadata(id, "1.0.0", platform, jar, List.of(), List.of(), List.of(), "none", Set.of()); }
    private static UnifiedClassLoader loader(List<Path> jars) throws Exception { var pipeline = new TransformationPipeline(); pipeline.freeze(); return new UnifiedClassLoader(jars, FmlCompatibilityTests.class.getClassLoader(), pipeline); }
    private static void reset() { System.clearProperty("flt.trace"); System.clearProperty("flt.mode"); }
    private static String trace() { return System.getProperty("flt.trace", ""); }
    private static void check(String name, Checked action) throws Exception { action.run(); passed++; System.out.println("PASS " + name); }
    private static void eq(Object expected, Object actual) { if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual); }
    private static void same(Object expected, Object actual) { if (expected != actual) throw new AssertionError("Expected identical references"); }
    private static void contains(String value, String expected) { if (!value.contains(expected)) throw new AssertionError("Expected text " + expected + " in " + value); }
    private static <T extends Throwable> T expect(Class<T> type, Checked action) throws Exception { try { action.run(); } catch (Throwable failure) { if (type.isInstance(failure)) return type.cast(failure); throw new AssertionError("Expected " + type + ", got " + failure, failure); } throw new AssertionError("Expected " + type); }
    private static LoaderException code(String code, Checked action) throws Exception { LoaderException failure = expect(LoaderException.class, action); if (failure.diagnostics().stream().noneMatch(diagnostic -> diagnostic.code().equals(code))) throw new AssertionError("Expected diagnostic " + code + ", got " + failure, failure); return failure; }
    private static final String FORGE = """
        package flt;
        @net.minecraftforge.fml.common.Mod("forge_life") public final class Forge {
          public static java.util.concurrent.CompletableFuture<Void> future;
          public static net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent retained;
          public static net.minecraftforge.eventbus.api.bus.BusGroup retainedGroup;
          private static void add(String value){System.setProperty("flt.trace",System.getProperty("flt.trace","")+value+";");}
          public Forge(){throw new AssertionError("fallback constructor incorrectly selected");}
          public Forge(net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext context){
            add("forge:construct");
            if("constructor".equals(System.getProperty("flt.mode")))throw new IllegalArgumentException("constructor failure");
            if(context!=net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get())throw new AssertionError("context mismatch");
            if(Thread.currentThread().getContextClassLoader()!=getClass().getClassLoader())throw new AssertionError("loader mismatch");
            System.setProperty("flt.forgeLoader",getClass().getClassLoader().toString());
            var group=context.getModBusGroup(); retainedGroup=group;
            net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent.getBus(group).addListener((byte)64,e->add("forge:high"));
            net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent.getBus(group).addListener(e->{
              retained=e; add("forge:common"); future=e.enqueueWork(()->{add("forge:work");
                if(!"forge_life".equals(net.minecraftforge.fml.ModLoadingContext.get().getContainer().getModId()))throw new AssertionError("work context");
                if("work".equals(System.getProperty("flt.mode")))throw new IllegalArgumentException("work failure");});
              if("listener".equals(System.getProperty("flt.mode")))throw new IllegalArgumentException("listener failure");});
            net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent.getBus(group).addListener(e->{add("forge:client");e.enqueueWork(()->add("forge:clientWork"));});
            net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent.getBus(group).addListener(e->add("forge:complete"));
          }
        }
        """;
    private static final String NEO = """
        package flt;
        @net.neoforged.fml.common.Mod("neo_life") public final class Neo {
          public static java.util.concurrent.CompletableFuture<Void> future;
          private static void add(String value){System.setProperty("flt.trace",System.getProperty("flt.trace","")+value+";");}
          public Neo(net.neoforged.bus.api.IEventBus bus,net.neoforged.fml.ModContainer container,net.neoforged.fml.javafmlmod.FMLModContainer same,net.neoforged.api.distmarker.Dist dist){
            if(container!=same||!dist.isClient())throw new AssertionError("injection");
            if(net.neoforged.fml.ModLoadingContext.get().getActiveContainer()!=container)throw new AssertionError("context mismatch");
            if(Thread.currentThread().getContextClassLoader()!=getClass().getClassLoader())throw new AssertionError("loader mismatch");
            System.setProperty("flt.neoLoader",getClass().getClassLoader().toString()); add("neo:construct");
            bus.addListener(net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent.class,e->{add("neo:common");future=e.enqueueWork(()->{
              if(!"neo_life".equals(net.neoforged.fml.ModLoadingContext.get().getActiveNamespace()))throw new AssertionError("work context");add("neo:work");});});
            bus.addListener(net.neoforged.fml.event.lifecycle.FMLClientSetupEvent.class,e->{add("neo:client");e.enqueueWork(()->add("neo:clientWork"));});
            bus.addListener(net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent.class,e->add("neo:complete"));
          }
        }
        """;
}
