package dev.n9ezz.loader.mapping;

import com.google.gson.JsonObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;

/** Exercises replacement binaries and cache receipts without redistributing game classes. */
public final class MappingFingerprintTests {
    private static final String PACKAGE = "net/fabricmc/tinyremapper/";
    private static int checks;
    public static void main(String[] arguments) throws Exception { run(); }

    static void run() throws Exception {
        Path directory = Files.createTempDirectory("n9ezz-remapper-fingerprint-");
        Map<String, byte[]> originalClasses = Map.of(PACKAGE + "TinyRemapper.class", bytes("primary-v1"),
            PACKAGE + "Helper.class", bytes("helper-v1"));
        Path original = directory.resolve("tiny-remapper-0.13.0.jar");
        Files.write(original, jar(originalClasses));
        Path owner = directory.resolve("application.jar");
        TreeMap<String, byte[]> shaded = new TreeMap<>(originalClasses);
        shaded.put("META-INF/n9ezz/dependencies/tiny-remapper-0.13.0.jar", Files.readAllBytes(original));
        shaded.put("embedded/client.jar", bytes("unrelated large application payload"));
        Files.write(owner, jar(shaded));
        String originalHash = GameMappings.sha256(original);
        check(fingerprint(original, owner).equals(originalHash), "external loaded remapper hashes its own binary");
        check(fingerprint(owner, owner).equals(originalHash), "matching shaded library hashes the preserved exact archive");

        TreeMap<String, byte[]> modifiedClasses = new TreeMap<>(originalClasses);
        modifiedClasses.put(PACKAGE + "Helper.class", bytes("helper-v2"));
        Path replacement = directory.resolve("replacement.jar");
        Files.write(replacement, jar(modifiedClasses));
        String replacementHash = fingerprint(replacement, owner);
        check(replacementHash.equals(GameMappings.sha256(replacement)), "replacement binary takes precedence over embedded original");
        check(!replacementHash.equals(originalHash), "same version label with changed bytecode changes fingerprint");
        String originalKey = GameMappings.cacheKey("classpath-fixture", originalHash);
        String replacementKey = GameMappings.cacheKey("classpath-fixture", replacementHash);
        check(!originalKey.equals(replacementKey), "binary replacement automatically selects a different game cache");
        check(originalKey.equals(GameMappings.cacheKey("classpath-fixture", originalHash)), "fingerprint cache key is deterministic");

        TreeMap<String, byte[]> patched = new TreeMap<>(shaded);
        patched.put(PACKAGE + "Helper.class", bytes("helper-v2"));
        Path patchedOwner = directory.resolve("patched-application.jar");
        Files.write(patchedOwner, jar(patched));
        String patchedHash = fingerprint(patchedOwner, patchedOwner);
        check(!patchedHash.equals(originalHash), "manual shaded helper edits invalidate the original archive fingerprint");
        TreeMap<String, byte[]> repackaged = new TreeMap<>(patched);
        repackaged.put("embedded/client.jar", bytes("another unrelated application payload"));
        Path repackagedOwner = directory.resolve("repackaged-application.jar");
        Files.write(repackagedOwner, jar(repackaged));
        check(fingerprint(repackagedOwner, repackagedOwner).equals(patchedHash), "shaded fallback ignores unrelated installer payloads");
        TreeMap<String, byte[]> rebuilt = new TreeMap<>(modifiedClasses);
        rebuilt.put("META-INF/n9ezz/dependencies/tiny-remapper-0.13.0-modified.jar", Files.readAllBytes(replacement));
        Path rebuiltOwner = directory.resolve("rebuilt-application.jar");
        Files.write(rebuiltOwner, jar(rebuilt));
        check(fingerprint(rebuiltOwner, rebuiltOwner).equals(replacementHash), "rebuilt modified archive is accepted without a fixed file name");

        Path loose = directory.resolve("loose-classes");
        Files.createDirectories(loose.resolve(PACKAGE));
        for (var entry : originalClasses.entrySet()) Files.write(loose.resolve(entry.getKey()), entry.getValue());
        String looseHash = fingerprint(loose, owner);
        check(looseHash.equals(fingerprint(loose, owner)), "loose library classes have a stable fingerprint");
        Files.write(loose.resolve(PACKAGE + "Helper.class"), bytes("helper-v2"));
        check(!fingerprint(loose, owner).equals(looseHash), "loose helper replacement invalidates the cache");
        rejects(() -> GameMappings.remapperFingerprint(java.net.URI.create("https://example.invalid/library.jar").toURL(), owner.toUri().toURL()),
            "unsupported provenance is rejected without fetching a binary");

        Path game = directory.resolve("mapped-game-fixture.jar");
        Files.write(game, jar(Map.of("net/minecraft/client/main/Main.class", fixtureClass("net/minecraft/client/main/Main"),
            "net/minecraft/class_310.class", gameClientFixture())));
        JsonObject receipt = new JsonObject();
        receipt.addProperty("schema", "n9ezz-game-remap-v2");
        receipt.addProperty("cacheKey", originalKey);
        receipt.addProperty("originalSha256", GameMappings.GAME_SHA256);
        receipt.addProperty("mappingsSha256", GameMappings.MAPPINGS_SHA256);
        receipt.addProperty("remapperSha256", originalHash);
        receipt.addProperty("outputSha256", GameMappings.sha256(game));
        Path metadata = directory.resolve("remap.json");
        Files.writeString(metadata, receipt.toString());
        check(GameMappings.validCache(game, metadata, originalKey, originalHash), "matching remapper receipt validates cache symbols and integrity");
        check(!GameMappings.validCache(game, metadata, originalKey, replacementHash), "receipt rejects a different remapper even when its key field is retained");
        receipt.remove("remapperSha256"); Files.writeString(metadata, receipt.toString());
        check(!GameMappings.validCache(game, metadata, originalKey, originalHash), "missing remapper provenance invalidates an old receipt");
        receipt.addProperty("remapperSha256", originalHash); receipt.addProperty("schema", "n9ezz-game-remap-v1");
        Files.writeString(metadata, receipt.toString());
        check(!GameMappings.validCache(game, metadata, originalKey, originalHash), "version-only cache schema is not reused");
        check(GameMappings.remapperFingerprint().matches("[0-9a-f]{64}"), "actual running JVM remapper has a binary fingerprint");
        System.out.println("PASS " + checks + " remapper binary/cache checks");
    }

    private static String fingerprint(Path binary, Path owner) throws IOException {
        return GameMappings.remapperFingerprint(binary.toUri().toURL(), owner.toUri().toURL());
    }
    private static byte[] bytes(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static byte[] jar(Map<String, byte[]> entries) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            for (var entry : new TreeMap<>(entries).entrySet()) {
                ZipEntry item = new ZipEntry(entry.getKey()); item.setTime(315532800000L);
                zip.putNextEntry(item); zip.write(entry.getValue()); zip.closeEntry();
            }
        }
        return bytes.toByteArray();
    }
    private static byte[] fixtureClass(String name) {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, name, null, "java/lang/Object", null);
        writer.visitEnd(); return writer.toByteArray();
    }
    private static byte[] gameClientFixture() {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "net/minecraft/class_310", null, "java/lang/Object", null);
        writer.visitField(Opcodes.ACC_PUBLIC, "field_1724", "Lnet/minecraft/class_746;", null, null).visitEnd();
        var method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "method_1551", "()Lnet/minecraft/class_310;", null, null);
        method.visitCode(); method.visitInsn(Opcodes.ACONST_NULL); method.visitInsn(Opcodes.ARETURN); method.visitMaxs(1, 0); method.visitEnd();
        writer.visitEnd(); return writer.toByteArray();
    }
    @FunctionalInterface private interface Checked { void run() throws IOException; }
    private static void rejects(Checked operation, String description) throws IOException {
        try { operation.run(); } catch (IOException expected) { check(true, description); return; }
        throw new AssertionError(description);
    }
    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
        checks++; System.out.println("PASS " + description);
    }
}
