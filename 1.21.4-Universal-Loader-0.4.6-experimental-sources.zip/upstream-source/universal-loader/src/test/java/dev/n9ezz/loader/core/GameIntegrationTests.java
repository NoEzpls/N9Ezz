package dev.n9ezz.loader.core;

import dev.n9ezz.loader.metadata.Dependency;
import dev.n9ezz.loader.metadata.ModMetadata;
import dev.n9ezz.loader.metadata.Platform;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;

/** Regression checks of game integration boundaries using actual temporary JARs. */
public final class GameIntegrationTests {
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private record Test(String name, Checked task) {}
    private static Path directory;
    private static int next;
    private GameIntegrationTests() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 0) throw new IllegalArgumentException("GameIntegrationTests takes no arguments");
        directory = Files.createTempDirectory("n9ezz-game-integration-");
        List<Test> tests = List.of(
            new Test("intermediary game and game-linked mod share ownership only in opt-in mode", GameIntegrationTests::gameLinkedMod),
            new Test("game integration preserves engine implementation restrictions", GameIntegrationTests::engineRestrictions),
            new Test("unverified Fabric API classes cannot claim an official role", GameIntegrationTests::fabricRole),
            new Test("game role cannot also be listed as a library", GameIntegrationTests::gameRoleCollision),
            new Test("Java 21 selects the highest eligible multi-release implementation and resource", GameIntegrationTests::multiRelease),
            new Test("versioned entries without a multi-release manifest are ignored", GameIntegrationTests::notMultiRelease),
            new Test("malformed multi-release paths fail with bounded diagnostics", GameIntegrationTests::malformedMultiRelease),
            new Test("logical multi-release classes still participate in duplicate detection", GameIntegrationTests::multiReleaseDuplicate),
            new Test("Mixin byte lookup executes only the pre-Mixin transformation stages", GameIntegrationTests::preMixinLookup),
            new Test("generated helpers use the common classloader and retain bytecode checks", GameIntegrationTests::generatedHelpers),
            new Test("closed runtime cannot define a new generated helper", GameIntegrationTests::closedGeneratedHelper),
            new Test("parent-owned loader APIs never pass to the generated-class provider", GameIntegrationTests::parentOwned),
            new Test("Mixin-enabled definitions are serialized and reentrant", GameIntegrationTests::serializedDefinitions),
            new Test("configuration must belong to its declaring archive", GameIntegrationTests::configurationOwnership),
            new Test("configuration names and resource sources must be unique", GameIntegrationTests::configurationCollision),
            new Test("game features reject unsupported platforms and namespaces", GameIntegrationTests::unsupportedFeatures),
            new Test("game resolver advertises only the implemented Fabric ABI", GameIntegrationTests::dependencyServices),
            new Test("deferred session trace remains live and callers receive immutable snapshots", GameIntegrationTests::liveTrace),
            new Test("session closes resources in reverse order and preserves cleanup failures", GameIntegrationTests::cleanup),
            new Test("a cleanup Error does not leak remaining resources", GameIntegrationTests::cleanupError)
        );
        int passed = 0;
        for (Test test : tests) try {
            test.task().run(); passed++; System.out.println("PASS " + test.name());
        } catch (Throwable error) {
            System.out.println("FAIL " + test.name() + ": " + error);
            error.printStackTrace(System.out);
        }
        System.out.println("Game integration: " + passed + " passed, " + (tests.size() - passed) + " failed");
        System.out.println("These fixtures are not a Minecraft or N9Ezz game launch.");
        if (passed != tests.size()) System.exit(1);
    }

    private static void gameLinkedMod() throws Exception {
        Path game = game();
        Path mod = jar(Map.of("fixture/Linked.class", type("fixture.Linked", 7, "Lnet/minecraft/class_999;")));
        expectCode("UNSUPPORTED_GAME_OR_ENGINE_REFERENCE", () -> new UnifiedClassLoader(List.of(mod), game, parent(), pipeline()).close());
        try (var loader = integrated(List.of(mod), game, pipeline())) {
            Class<?> linked = loader.loadClass("fixture.Linked");
            eq(loader, linked.getClassLoader());
            eq(loader, linked.getField("reference").getType().getClassLoader());
            eq(game.toRealPath(), loader.sourceOf("net.minecraft.class_999"));
            eq(mod.toRealPath(), loader.sourceOf("fixture.Linked"));
        }
    }
    private static void engineRestrictions() throws Exception {
        for (String engine : List.of("net/fabricmc/loader/impl/Knot", "org/quiltmc/loader/impl/QuiltLoaderImpl", "net/minecraftforge/fml/loading/FMLLoader", "net/neoforged/fml/loading/FMLLoader", "cpw/mods/modlauncher/Launcher")) {
            Path mod = jar(Map.of("fixture/EngineReference.class", type("fixture.EngineReference", 0, "L" + engine + ";")));
            expectCode("UNSUPPORTED_GAME_OR_ENGINE_REFERENCE", () -> integrated(List.of(mod), null, pipeline()).close());
        }
    }
    private static void fabricRole() throws Exception {
        Path spoof = jar(Map.of("net/fabricmc/fabric/api/Forged.class", type("net.fabricmc.fabric.api.Forged", 0, null)));
        expectCode("RESERVED_CLASS", () -> integrated(List.of(spoof), null, pipeline()).close());
        expect(IOException.class, () -> new UnifiedClassLoader(List.of(spoof), null, parent(), pipeline(), new UnifiedClassLoader.GameIntegration(Set.of(spoof))).close());
    }
    private static void gameRoleCollision() throws Exception {
        Path game = game();
        expectCode("GAME_ROLE_COLLISION", () -> integrated(List.of(game), game, pipeline()).close());
    }
    private static void multiRelease() throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("META-INF/MANIFEST.MF", bytes("Manifest-Version: 1.0\r\nMulti-Release: true\r\n\r\n"));
        files.put("fixture/Versioned.class", type("fixture.Versioned", 8, null));
        for (int version : List.of(9, 17, 21, 22)) {
            files.put("META-INF/versions/" + version + "/fixture/Versioned.class", type("fixture.Versioned", version, null));
            files.put("META-INF/versions/" + version + "/version.txt", bytes("resource-" + version));
        }
        Path archive = jar(files);
        try (var loader = integrated(List.of(archive), null, pipeline())) {
            eq(21, loader.loadClass("fixture.Versioned").getMethod("value").invoke(null));
            try (var input = loader.getResourceAsStream("version.txt")) { eq("resource-21", new String(input.readAllBytes(), StandardCharsets.UTF_8)); }
            if (!loader.getResource("fixture/Versioned.class").toString().contains("META-INF/versions/21/")) throw new AssertionError("Class resource differs from selected definition");
            eq(List.of("fixture.Versioned"), loader.classNames());
        }
    }
    private static void notMultiRelease() throws Exception {
        Path archive = jar(Map.of("fixture/Versioned.class", type("fixture.Versioned", 8, null), "META-INF/versions/21/fixture/Versioned.class", type("fixture.Versioned", 21, null)));
        try (var loader = integrated(List.of(archive), null, pipeline())) { eq(8, loader.loadClass("fixture.Versioned").getMethod("value").invoke(null)); }
    }
    private static void malformedMultiRelease() throws Exception {
        for (String path : List.of("META-INF/versions/21", "META-INF/versions/nope/fixture/Bad.class")) {
            Path archive = jar(Map.of(path, type("fixture.Bad", 0, null)));
            expect(IOException.class, () -> integrated(List.of(archive), null, pipeline()).close());
        }
    }
    private static void multiReleaseDuplicate() throws Exception {
        Path one = jar(Map.of("fixture/Duplicate.class", type("fixture.Duplicate", 1, null)));
        Path two = jar(Map.of("META-INF/MANIFEST.MF", bytes("Manifest-Version: 1.0\r\nMulti-Release: true\r\n\r\n"), "META-INF/versions/21/fixture/Duplicate.class", type("fixture.Duplicate", 2, null)));
        expectCode("DUPLICATE_CLASS", () -> integrated(List.of(one, two), null, pipeline()).close());
    }
    private static void preMixinLookup() throws Exception {
        List<String> calls = new ArrayList<>(); TransformationPipeline pipeline = new TransformationPipeline();
        for (var stage : TransformationPipeline.Stage.values()) pipeline.register(stage, 0, stage.name(), (name, input) -> { calls.add(stage.name()); return input; });
        pipeline.freeze(); Path archive = jar(Map.of("fixture/Transformed.class", type("fixture.Transformed", 12, null)));
        try (var loader = integrated(List.of(archive), null, pipeline)) {
            loader.classBytes("fixture.Transformed", false); eq(List.of(), calls);
            loader.classBytes("fixture.Transformed", true); eq(List.of("MAPPING", "ACCESS", "CORE"), calls);
            calls.clear(); eq(12, loader.loadClass("fixture.Transformed").getMethod("value").invoke(null));
            eq(List.of("MAPPING", "ACCESS", "CORE", "MIXIN", "POST"), calls);
        }
    }
    private static void generatedHelpers() throws Exception {
        try (var loader = integrated(List.of(), null, pipeline())) {
            loader.setGeneratedClassProvider(name -> name.equals("fixture.Helper") ? type(name, 39, null) : name.equals("fixture.Invalid") ? type("fixture.Other", 0, null) : null);
            Class<?> helper = loader.loadClass("fixture.Helper"); eq(loader, helper.getClassLoader()); eq(39, helper.getMethod("value").invoke(null));
            eq(helper, loader.loadClass("fixture.Helper"));
            expectCode("INVALID_BYTECODE", () -> loader.loadClass("fixture.Invalid"));
        }
    }
    private static void closedGeneratedHelper() throws Exception {
        var loader = integrated(List.of(), null, pipeline());
        AtomicInteger calls = new AtomicInteger();
        loader.setGeneratedClassProvider(name -> { calls.incrementAndGet(); return type(name, 19, null); });
        loader.loadClass("fixture.BeforeClose"); int prior = calls.get(); loader.close();
        expect(ClassNotFoundException.class, () -> loader.loadClass("fixture.AfterClose"));
        eq(prior, calls.get()); eq(loader, loader.loadClass("fixture.BeforeClose").getClassLoader());
        expect(IllegalStateException.class, () -> loader.setGeneratedClassProvider(name -> null));
    }
    private static void parentOwned() throws Exception {
        try (var loader = integrated(List.of(), null, pipeline())) {
            AtomicInteger calls = new AtomicInteger(); loader.setGeneratedClassProvider(name -> { calls.incrementAndGet(); return null; });
            eq(net.fabricmc.loader.api.FabricLoader.class, loader.loadClass("net.fabricmc.loader.api.FabricLoader"));
            eq(0, calls.get());
        }
    }
    private static void serializedDefinitions() throws Exception {
        var activeThreads = new java.util.concurrent.ConcurrentHashMap<Thread, AtomicInteger>();
        AtomicInteger concurrentThreads = new AtomicInteger(); TransformationPipeline pipeline = new TransformationPipeline();
        UnifiedClassLoader[] runtime = new UnifiedClassLoader[1];
        pipeline.register(TransformationPipeline.Stage.CORE, 0, "fixture-concurrent", (name, input) -> {
            Thread current = Thread.currentThread();
            AtomicInteger depth = activeThreads.computeIfAbsent(current, ignored -> new AtomicInteger()); depth.incrementAndGet();
            if (activeThreads.size() > 1) concurrentThreads.incrementAndGet();
            try {
                if (name.equals("fixture.ConcurrentA")) runtime[0].loadClass("fixture.Reentrant");
                if (!name.equals("fixture.Reentrant")) Thread.sleep(75);
                return input;
            } finally { if (depth.decrementAndGet() == 0) activeThreads.remove(current); }
        }); pipeline.freeze();
        Path archive = jar(Map.of("fixture/ConcurrentA.class", type("fixture.ConcurrentA", 1, null), "fixture/ConcurrentB.class", type("fixture.ConcurrentB", 2, null), "fixture/Reentrant.class", type("fixture.Reentrant", 3, null)));
        try (var loader = integrated(List.of(archive), null, pipeline); var executor = Executors.newFixedThreadPool(2)) {
            runtime[0] = loader; loader.setGeneratedClassProvider(name -> null); CountDownLatch start = new CountDownLatch(1);
            var one = executor.submit(() -> { start.await(); return loader.loadClass("fixture.ConcurrentA"); });
            var two = executor.submit(() -> { start.await(); return loader.loadClass("fixture.ConcurrentB"); }); start.countDown();
            eq(loader, one.get(5, TimeUnit.SECONDS).getClassLoader()); eq(loader, two.get(5, TimeUnit.SECONDS).getClassLoader());
            eq(0, concurrentThreads.get()); eq(loader, loader.loadClass("fixture.Reentrant").getClassLoader());
        }
    }
    private static void configurationOwnership() throws Exception {
        Path owner = jar(Map.of("own.mixins.json", bytes("{}"))); Path other = jar(Map.of("other.mixins.json", bytes("{}")));
        try (var loader = integrated(List.of(owner, other), null, pipeline())) {
            eq(1, ((List<?>) gameMethod("configurations", new Class<?>[] { List.class, UnifiedClassLoader.class }, List.of(mod("owner", owner, List.of("own.mixins.json"))), loader)).size());
            expectCode("MIXIN_CONFIG_MISSING", () -> gameMethod("configurations", new Class<?>[] { List.class, UnifiedClassLoader.class }, List.of(mod("owner", owner, List.of("other.mixins.json"))), loader));
        }
    }
    private static void configurationCollision() throws Exception {
        Path one = jar(Map.of("collision.mixins.json", bytes("{}"))); Path two = jar(Map.of("collision.mixins.json", bytes("{}")));
        try (var loader = integrated(List.of(one, two), null, pipeline())) {
            expectCode("MIXIN_CONFIG_WRONG_SOURCE", () -> gameMethod("configurations", new Class<?>[] { List.class, UnifiedClassLoader.class }, List.of(mod("one", one, List.of("collision.mixins.json"))), loader));
        }
        try (var loader = integrated(List.of(one), null, pipeline())) {
            expectCode("MIXIN_CONFIG_COLLISION", () -> gameMethod("configurations", new Class<?>[] { List.class, UnifiedClassLoader.class }, List.of(mod("one", one, List.of("collision.mixins.json", "collision.mixins.json"))), loader));
        }
        Path parentJar = jar(Map.of("collision.mixins.json", bytes("{}")));
        try (var parent = new URLClassLoader(new java.net.URL[] { parentJar.toUri().toURL() }, parent()); var loader = new UnifiedClassLoader(List.of(one), null, parent, pipeline(), new UnifiedClassLoader.GameIntegration(Set.of()))) {
            expectCode("MIXIN_CONFIG_WRONG_SOURCE", () -> gameMethod("configurations", new Class<?>[] { List.class, UnifiedClassLoader.class }, List.of(mod("one", one, List.of("collision.mixins.json"))), loader));
        }
    }
    private static void unsupportedFeatures() throws Exception {
        Path archive = jar(Map.of());
        for (Platform platform : List.of(Platform.QUILT, Platform.FORGE, Platform.NEOFORGE)) {
            var metadata = new ModMetadata("unsupported", "1.0", platform, archive, List.of(), List.of(), List.of(), "intermediary", Set.of());
            expectCode("UNSUPPORTED_GAME_PLATFORM", () -> gameMethod("validateFeatures", new Class<?>[] { List.class }, List.of(metadata)));
        }
        var metadata = new ModMetadata("unsupported", "1.0", Platform.FABRIC, archive, List.of(), List.of(), List.of(), "official", Set.of());
        expectCode("UNSUPPORTED_NAMESPACE", () -> gameMethod("validateFeatures", new Class<?>[] { List.class }, List.of(metadata)));
    }
    private static void dependencyServices() throws Exception {
        Path archive = jar(Map.of());
        var compatible = new ModMetadata("fabric_contract", "1.0", Platform.FABRIC, archive, List.of(new Dependency("fabricloader", ">=0.19.2", false, false)), List.of(), List.of(), "intermediary", Set.of());
        eq(List.of(compatible), DependencyResolver.resolveFabricRuntime(List.of(compatible)));
        expectCode("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolve(List.of(compatible)));
        for (String engine : List.of("quilt_loader", "forge", "neoforge", "javafml")) {
            var unsupported = new ModMetadata("engine_contract", "1.0", Platform.FABRIC, archive, List.of(new Dependency(engine, "*", false, false)), List.of(), List.of(), "intermediary", Set.of());
            expectCode("UNSUPPORTED_PLATFORM_DEPENDENCY", () -> DependencyResolver.resolveFabricRuntime(List.of(unsupported)));
        }
        var spoof = new ModMetadata("spoof", "1.0", Platform.FABRIC, archive, List.of(), List.of(), List.of(), "intermediary", Set.of("fabricloader"));
        expectCode("RESERVED_MOD_ID", () -> DependencyResolver.resolveFabricRuntime(List.of(spoof)));
    }
    private static void liveTrace() throws Exception {
        List<String> trace = new CopyOnWriteArrayList<>(List.of("TRANSFORMERS_READY"));
        try (var session = new RuntimeSession(integrated(List.of(), null, pipeline()), List.of(), trace, List.of(), List.of())) {
            List<String> snapshot = session.lifecycleTrace(); trace.add("READY");
            eq(List.of("TRANSFORMERS_READY"), snapshot); eq(List.of("TRANSFORMERS_READY", "READY"), session.lifecycleTrace());
            expect(UnsupportedOperationException.class, () -> session.lifecycleTrace().add("FORGED"));
        }
    }
    private static void cleanup() throws Exception {
        List<String> closed = new ArrayList<>();
        var session = new RuntimeSession(integrated(List.of(), null, pipeline()), List.of(), List.of(), List.of(), List.of(
            () -> closed.add("first"), () -> { closed.add("second"); throw new IOException("second failure"); }, () -> { closed.add("third"); throw new IOException("third failure"); }));
        try { session.close(); throw new AssertionError("Cleanup failure was hidden"); }
        catch (RuntimeException failure) { eq("third failure", failure.getCause().getMessage()); eq(1, failure.getSuppressed().length); }
        eq(List.of("third", "second", "first"), closed); session.close(); eq(3, closed.size());
    }
    private static void cleanupError() throws Exception {
        List<String> closed = new ArrayList<>();
        var session = new RuntimeSession(integrated(List.of(), null, pipeline()), List.of(), List.of(), List.of(), List.of(
            () -> closed.add("first"), () -> { closed.add("second"); throw new AssertionError("cleanup error"); }, () -> closed.add("third")));
        Throwable failure = null;
        try { session.close(); } catch (RuntimeException | AssertionError error) { failure = error; }
        if (failure == null) throw new AssertionError("Cleanup Error was hidden");
        eq(List.of("third", "second", "first"), closed);
    }
    private static Object gameMethod(String name, Class<?>[] types, Object... arguments) throws Exception {
        Method method = GameRuntimeBootstrap.class.getDeclaredMethod(name, types); method.setAccessible(true);
        try { return method.invoke(null, arguments); }
        catch (InvocationTargetException failure) { Throwable cause = failure.getCause(); if (cause instanceof Exception error) throw error; if (cause instanceof Error error) throw error; throw failure; }
    }
    private static ModMetadata mod(String id, Path jar, List<String> mixins) { return new ModMetadata(id, "1.0", Platform.FABRIC, jar, List.of(), List.of(), mixins, "intermediary", Set.of()); }
    private static ClassLoader parent() { return GameIntegrationTests.class.getClassLoader(); }
    private static TransformationPipeline pipeline() { var pipeline = new TransformationPipeline(); pipeline.freeze(); return pipeline; }
    private static UnifiedClassLoader integrated(List<Path> archives, Path game, TransformationPipeline pipeline) throws IOException { return new UnifiedClassLoader(archives, game, parent(), pipeline, new UnifiedClassLoader.GameIntegration(Set.of())); }
    private static Path game() throws IOException { return jar(Map.of("net/minecraft/client/main/Main.class", type("net.minecraft.client.main.Main", 0, null), "net/minecraft/class_999.class", type("net.minecraft.class_999", 0, null))); }
    private static Path jar(Map<String, byte[]> entries) throws IOException {
        Path target = directory.resolve("fixture-" + next++ + ".jar");
        try (var archive = new JarOutputStream(Files.newOutputStream(target))) {
            for (var entry : new java.util.TreeMap<>(entries).entrySet()) { var name = new JarEntry(entry.getKey()); name.setTime(0); archive.putNextEntry(name); archive.write(entry.getValue()); archive.closeEntry(); }
        }
        return target;
    }
    private static byte[] bytes(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static byte[] type(String name, int value, String fieldDescriptor) {
        String owner = name.replace('.', '/'); ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, owner, null, "java/lang/Object", null);
        if (fieldDescriptor != null) writer.visitField(Opcodes.ACC_PUBLIC, "reference", fieldDescriptor, null, null).visitEnd();
        var constructor = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null); constructor.visitCode(); constructor.visitVarInsn(Opcodes.ALOAD, 0); constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false); constructor.visitInsn(Opcodes.RETURN); constructor.visitMaxs(0, 0); constructor.visitEnd();
        var method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "value", "()I", null, null); method.visitCode(); method.visitLdcInsn(value); method.visitInsn(Opcodes.IRETURN); method.visitMaxs(0, 0); method.visitEnd(); writer.visitEnd(); return writer.toByteArray();
    }
    private static void expectCode(String code, Checked task) throws Exception {
        try { task.run(); } catch (LoaderException failure) { if (failure.diagnostics().stream().anyMatch(d -> d.code().equals(code))) return; throw failure; }
        throw new AssertionError("Expected loader diagnostic " + code);
    }
    private static void expect(Class<? extends Throwable> type, Checked task) throws Exception {
        try { task.run(); } catch (Throwable error) { if (type.isInstance(error)) return; if (error instanceof Exception exception) throw exception; if (error instanceof Error fatal) throw fatal; throw new IllegalStateException(error); }
        throw new AssertionError("Expected " + type.getName());
    }
    private static void eq(Object expected, Object actual) { if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual); }
}
