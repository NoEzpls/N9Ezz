package dev.n9ezz.loader.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/** User-facing admission checks use real archives and the production bootstraps. */
public final class ExternalModPolicyTests {
    private static final String NATIVE = "n9ezz.mod.json";
    private static final List<String> FOREIGN = List.of("fabric.mod.json", "quilt.mod.json", "META-INF/mods.toml", "META-INF/neoforge.mods.toml");
    private static final String TYPE = "fixture.ExternalAdmissionProbe";
    private static final String PREFIX = "n9.external.admission.";
    private static Path root;
    private static int sequence;
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private record Test(String name, Checked check) { }

    public static void main(String[] args) throws Exception {
        root = Files.createTempDirectory("n9ezz-external-admission-");
        List<Test> tests = new ArrayList<>();
        tests.add(new Test("native external mod executes in the common runtime", ExternalModPolicyTests::nativeLoads));
        for (String descriptor : FOREIGN) {
            tests.add(new Test("external " + descriptor + " is rejected before user code", () -> rejectMod(Map.of(descriptor, bytes(foreign(descriptor, "ordinary"))), "EXTERNAL_MOD_NOT_N9EZZ")));
            tests.add(new Test("native plus " + descriptor + " is rejected as ambiguous", () -> rejectMod(Map.of(NATIVE, bytes(nativeMetadata("native_mod", "")), descriptor, bytes(foreign(descriptor, "ordinary"))), "EXTERNAL_MOD_AMBIGUOUS")));
            tests.add(new Test("game path rejects " + descriptor + " before mapping or Mixin", () -> rejectGame(Map.of(descriptor, bytes(foreign(descriptor, "ordinary"))), "EXTERNAL_MOD_NOT_N9EZZ")));
            tests.add(new Test("extraClasspath cannot hide " + descriptor, () -> rejectLibrary(Map.of(descriptor, bytes(foreign(descriptor, "ordinary"))), "EXTERNAL_CLASSPATH_MOD")));
            tests.add(new Test("game library classpath cannot hide " + descriptor, () -> rejectGameLibrary(descriptor)));
        }
        tests.add(new Test("descriptor-free archive is not a native mod", () -> rejectMod(Map.of(), "EXTERNAL_MOD_NOT_N9EZZ")));
        tests.add(new Test("native descriptor must be at the archive root", () -> rejectMod(Map.of("data/n9ezz.mod.json", bytes(nativeMetadata("native_mod", ""))), "EXTERNAL_MOD_NOT_N9EZZ")));
        tests.add(new Test("renaming a Fabric archive and its id does not grant admission", () -> rejectMod(Map.of("fabric.mod.json", bytes(foreign("fabric.mod.json", "n9ezz"))), "EXTERNAL_MOD_NOT_N9EZZ")));
        tests.add(new Test("Fabric provides aliases and opt-in metadata cannot grant admission", () -> rejectMod(Map.of("fabric.mod.json", bytes("{\"schemaVersion\":1,\"id\":\"n9ezz_addon\",\"version\":\"1.0\",\"provides\":[\"n9ezz\"],\"n9ezz\":{\"namespace\":\"none\",\"compatibility\":\"quilt-lifecycle-v1\"}}")), "EXTERNAL_MOD_NOT_N9EZZ")));
        tests.add(new Test("native id and provides cannot conceal a second platform descriptor", () -> rejectMod(Map.of(NATIVE, bytes(nativeMetadata("n9ezz_addon", ",\"provides\":[\"native_alias\"]")), "fabric.mod.json", bytes(foreign("fabric.mod.json", "n9ezz_addon"))), "EXTERNAL_MOD_AMBIGUOUS")));
        for (String entry : List.of("META-INF/jars/hidden.jar", "lib/HIDDEN.JaR")) {
            tests.add(new Test("native mod cannot carry nested archive " + entry, () -> rejectMod(nested(entry), "EXTERNAL_NESTED_MOD_UNSUPPORTED")));
            tests.add(new Test("game admission rejects nested archive " + entry + " before mapping", () -> rejectGame(nested(entry), "EXTERNAL_NESTED_MOD_UNSUPPORTED")));
        }
        tests.add(new Test("mixed folder rejects the entire launch before valid native entrypoints", ExternalModPolicyTests::mixedFolder));
        tests.add(new Test("game admission rejects ambiguous metadata before mapping", () -> rejectGame(Map.of(NATIVE, bytes(nativeMetadata("native_mod", "")), "fabric.mod.json", bytes(foreign("fabric.mod.json", "ordinary"))), "EXTERNAL_MOD_AMBIGUOUS")));
        tests.add(new Test("extraClasspath cannot hide a native mod", () -> rejectLibrary(Map.of(NATIVE, bytes(nativeMetadata("native_mod", ""))), "EXTERNAL_CLASSPATH_MOD")));
        tests.add(new Test("extraClasspath cannot hide a nested archive", () -> rejectLibrary(Map.of("payload/hidden.JAR", archiveBytes(Map.of("fabric.mod.json", bytes(foreign("fabric.mod.json", "ordinary"))))), "EXTERNAL_CLASSPATH_MOD")));
        tests.add(new Test("ordinary descriptor-free library is usable on extraClasspath", ExternalModPolicyTests::plainLibrary));
        tests.add(new Test("verify-only enforces admission without executing native code", ExternalModPolicyTests::verifyOnly));
        int passed = 0;
        for (Test test : tests) {
            for (String phase : List.of("static", "constructor", "common")) System.clearProperty(PREFIX + phase);
            try { test.check().run(); passed++; System.out.println("PASS " + test.name()); }
            catch (Throwable failure) { System.out.println("FAIL " + test.name() + ": " + failure); failure.printStackTrace(System.out); }
        }
        System.out.println("External mod admission: " + passed + " passed, " + (tests.size() - passed) + " failed");
        if (passed != tests.size()) System.exit(1);
    }

    private static void nativeLoads() throws Exception {
        Path game = game();
        Path jar = write(game.resolve("mods/n9ezz-test.jar"), Map.of(NATIVE, bytes(nativeMetadata("native_mod", ""))));
        List<LifecycleEvent> events = new ArrayList<>();
        try (RuntimeSession session = RuntimeBootstrap.run(game, game.resolve("mods"), List.of(), events(events), false)) {
            eq(List.of("native_mod"), session.mods().stream().map(mod -> mod.id()).toList());
            eq(jar.toRealPath(), session.classLoader().sourceOf(TYPE));
            eq(session.classLoader(), session.classLoader().loadClass(TYPE).getClassLoader());
            eq(List.of(LifecycleEvent.DISCOVERED, LifecycleEvent.RESOLVED, LifecycleEvent.TRANSFORMERS_READY,
                    LifecycleEvent.COMMON_SETUP, LifecycleEvent.CLIENT_SETUP, LifecycleEvent.READY), events);
            for (String phase : List.of("static", "constructor", "common")) eq("executed", System.getProperty(PREFIX + phase));
        }
    }

    private static void rejectMod(Map<String, byte[]> entries, String code) throws Exception {
        Path game = game();
        write(game.resolve("mods/N9Ezz-Addon.jar"), entries);
        List<LifecycleEvent> events = new ArrayList<>();
        expect(code, () -> RuntimeBootstrap.run(game, game.resolve("mods"), List.of(), events(events), false).close());
        eq(List.of(LifecycleEvent.FAILED), events);
        noUserCode();
    }

    private static void rejectGame(Map<String, byte[]> entries, String code) throws Exception {
        Path game = game();
        write(game.resolve("mods/external.jar"), entries);
        // An invalid game input makes ordering observable: admission must fail first.
        Path dummyGame = Files.writeString(game.resolve("vanilla.jar"), "not a Minecraft archive");
        List<LifecycleEvent> events = new ArrayList<>();
        LoaderException failure = expect(code, () -> RuntimeBootstrap.runBundledGame(game, game.resolve("mods"), dummyGame, events(events), true).close());
        eq(List.of(LifecycleEvent.FAILED), events);
        eq(List.of("FAILED"), failure.lifecycleTrace());
        noUserCode();
    }

    private static void rejectLibrary(Map<String, byte[]> entries, String code) throws Exception {
        Path game = game();
        Path library = write(game.resolve("helper-library.jar"), entries);
        List<LifecycleEvent> events = new ArrayList<>();
        expect(code, () -> RuntimeBootstrap.run(game, game.resolve("mods"), List.of(library), events(events), false).close());
        if (events.contains(LifecycleEvent.COMMON_SETUP) || events.contains(LifecycleEvent.READY)) throw new AssertionError("Library admission occurred after initialization: " + events);
        eq(LifecycleEvent.FAILED, events.getLast());
        noUserCode();
    }

    private static void rejectGameLibrary(String descriptor) throws Exception {
        Path game = game();
        Path library = write(game.resolve("helper-library.jar"), Map.of(descriptor, bytes(foreign(descriptor, "ordinary"))));
        Path dummyGame = Files.writeString(game.resolve("vanilla.jar"), "not a Minecraft archive");
        List<LifecycleEvent> events = new ArrayList<>();
        LoaderException failure = expect("EXTERNAL_CLASSPATH_MOD", () -> RuntimeBootstrap.runBundledGame(
                game, game.resolve("mods"), dummyGame, List.of(library), events(events), true).close());
        eq(List.of(LifecycleEvent.FAILED), events);
        eq(List.of("FAILED"), failure.lifecycleTrace());
        noUserCode();
    }

    private static void mixedFolder() throws Exception {
        Path game = game();
        write(game.resolve("mods/00-native.jar"), Map.of(NATIVE, bytes(nativeMetadata("native_mod", ""))));
        write(game.resolve("mods/99-foreign.jar"), Map.of("fabric.mod.json", bytes(foreign("fabric.mod.json", "ordinary"))));
        List<LifecycleEvent> events = new ArrayList<>();
        expect("EXTERNAL_MOD_NOT_N9EZZ", () -> RuntimeBootstrap.run(game, game.resolve("mods"), List.of(), events(events), false).close());
        eq(List.of(LifecycleEvent.FAILED), events);
        noUserCode();
    }

    private static void plainLibrary() throws Exception {
        Path game = game();
        Path library = write(game.resolve("ordinary-library.jar"), Map.of("readme.txt", bytes("ordinary resource")));
        try (RuntimeSession session = RuntimeBootstrap.run(game, game.resolve("mods"), List.of(library), new EventBus(), false)) {
            eq(0, session.mods().size());
            eq(library.toRealPath(), session.classLoader().sourceOf(TYPE));
            eq(session.classLoader(), session.classLoader().loadClass(TYPE).getClassLoader());
            noUserCode(); // Merely defining a library class must not initialize it.
            eq(17, session.classLoader().loadClass(TYPE).getMethod("value").invoke(null));
            eq("executed", System.getProperty(PREFIX + "static"));
            eq(null, System.getProperty(PREFIX + "constructor"));
            eq(null, System.getProperty(PREFIX + "common"));
        }
    }

    private static void verifyOnly() throws Exception {
        Path game = game();
        write(game.resolve("mods/native.jar"), Map.of(NATIVE, bytes(nativeMetadata("native_mod", ""))));
        try (RuntimeSession session = RuntimeBootstrap.run(game, game.resolve("mods"), List.of(), new EventBus(), true)) {
            if (!session.lifecycleTrace().contains("VERIFY_ONLY_COMPLETE")) throw new AssertionError("Verification did not complete");
            noUserCode();
        }
        write(game.resolve("mods/foreign.jar"), Map.of("fabric.mod.json", bytes(foreign("fabric.mod.json", "ordinary"))));
        expect("EXTERNAL_MOD_NOT_N9EZZ", () -> RuntimeBootstrap.run(game, game.resolve("mods"), List.of(), new EventBus(), true).close());
        noUserCode();
    }

    private static Map<String, byte[]> nested(String path) throws Exception {
        return Map.of(NATIVE, bytes(nativeMetadata("native_mod", "")), path,
                archiveBytes(Map.of("fabric.mod.json", bytes(foreign("fabric.mod.json", "ordinary")))));
    }
    private static Path game() throws Exception {
        Path game = Files.createDirectories(root.resolve("case-" + (++sequence)));
        Files.createDirectories(game.resolve("mods"));
        return game;
    }
    private static Path write(Path output, Map<String, byte[]> entries) throws Exception {
        Map<String, byte[]> files = new LinkedHashMap<>(entries);
        files.put(TYPE.replace('.', '/') + ".class", probe());
        return Files.write(output, archiveBytes(files));
    }
    private static byte[] archiveBytes(Map<String, byte[]> entries) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (JarOutputStream output = new JarOutputStream(bytes)) {
            for (var entry : entries.entrySet()) {
                JarEntry part = new JarEntry(entry.getKey()); part.setTime(0);
                output.putNextEntry(part); output.write(entry.getValue()); output.closeEntry();
            }
        }
        return bytes.toByteArray();
    }
    private static byte[] probe() {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, TYPE.replace('.', '/'), null, "java/lang/Object", new String[] {"dev/n9ezz/loader/api/N9ModInitializer"});
        MethodVisitor initializer = writer.visitMethod(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
        initializer.visitCode(); marker(initializer, "static"); initializer.visitInsn(Opcodes.RETURN); initializer.visitMaxs(2, 0); initializer.visitEnd();
        MethodVisitor constructor = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        constructor.visitCode(); constructor.visitVarInsn(Opcodes.ALOAD, 0); constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        marker(constructor, "constructor"); constructor.visitInsn(Opcodes.RETURN); constructor.visitMaxs(2, 1); constructor.visitEnd();
        MethodVisitor entrypoint = writer.visitMethod(Opcodes.ACC_PUBLIC, "onInitialize", "(Ldev/n9ezz/loader/api/ModContext;)V", null, null);
        entrypoint.visitCode(); marker(entrypoint, "common"); entrypoint.visitInsn(Opcodes.RETURN); entrypoint.visitMaxs(2, 2); entrypoint.visitEnd();
        MethodVisitor value = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "value", "()I", null, null);
        value.visitCode(); value.visitIntInsn(Opcodes.BIPUSH, 17); value.visitInsn(Opcodes.IRETURN); value.visitMaxs(1, 0); value.visitEnd();
        writer.visitEnd(); return writer.toByteArray();
    }
    private static void marker(MethodVisitor method, String name) {
        method.visitLdcInsn(PREFIX + name); method.visitLdcInsn("executed");
        method.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/System", "setProperty", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", false);
        method.visitInsn(Opcodes.POP);
    }
    private static String nativeMetadata(String id, String extra) {
        return "{\"schemaVersion\":1,\"id\":\"" + id + "\",\"version\":\"1.0.0\",\"namespace\":\"none\",\"entrypoints\":{\"common\":[\"" + TYPE + "\"]}" + extra + "}";
    }
    private static String foreign(String descriptor, String id) {
        if (descriptor.equals("fabric.mod.json")) return "{\"schemaVersion\":1,\"id\":\"" + id + "\",\"version\":\"1.0.0\",\"n9ezz\":{\"namespace\":\"none\"},\"entrypoints\":{\"main\":[\"" + TYPE + "\"]}}";
        if (descriptor.equals("quilt.mod.json")) return "{\"schema_version\":1,\"quilt_loader\":{\"id\":\"" + id + "\",\"version\":\"1.0.0\",\"entrypoints\":{\"init\":[\"" + TYPE + "\"]}},\"n9ezz\":{\"namespace\":\"none\"}}";
        return "modLoader=\"n9ezz\"\nloaderVersion=\">=0.2.0\"\nlicense=\"MIT\"\n[[mods]]\nmodId=\"" + id + "\"\nversion=\"1.0.0\"\n[n9ezz]\nnamespace=\"none\"\n";
    }
    private static EventBus events(List<LifecycleEvent> trace) {
        EventBus bus = new EventBus();
        for (LifecycleEvent event : LifecycleEvent.values()) bus.on(event, 0, trace::add);
        return bus;
    }
    private static LoaderException expect(String code, Checked operation) throws Exception {
        try { operation.run(); } catch (LoaderException failure) {
            if (failure.diagnostics().stream().anyMatch(diagnostic -> diagnostic.code().equals(code))) return failure;
            throw new AssertionError("Expected " + code + " but got " + failure.diagnostics(), failure);
        }
        throw new AssertionError("Expected " + code);
    }
    private static void noUserCode() {
        for (String phase : List.of("static", "constructor", "common")) eq(null, System.getProperty(PREFIX + phase));
    }
    private static byte[] bytes(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static void eq(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + " but got " + actual);
    }
}
