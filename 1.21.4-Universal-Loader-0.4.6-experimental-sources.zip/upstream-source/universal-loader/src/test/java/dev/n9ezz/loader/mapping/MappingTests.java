package dev.n9ezz.loader.mapping;

import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.jar.JarFile;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;

/** Executable mapping semantics checks; no Minecraft binary is part of these fixtures. */
public final class MappingTests {
    private static int checks;
    public static void main(String[] arguments) throws Exception {
        TinyMappingIndex index = TinyMappingIndex.read(new StringReader("tiny\t2\t0\tofficial\tintermediary\n"
            + "c\tobf/A\tfixture/Base\n\tf\tLobf/A;\tx\towner\n\tm\t(Lobf/A;)Lobf/A;\ta\troundTrip\n"
            + "c\tobf/B\tfixture/Child\n"));
        check(index.classCount() == 2 && index.fieldCount() == 1 && index.methodCount() == 1, "index counts");
        check(index.mapClass("official", "intermediary", "obf/A").equals("fixture/Base"), "class mapping");
        check(index.mapClass("intermediary", "official", "fixture/Base").equals("obf/A"), "reverse class mapping");
        check(index.mapField("official", "intermediary", "obf/A", "x", "Lobf/A;").equals("owner"), "field mapping");
        check(index.mapField("intermediary", "official", "fixture/Base", "owner", "Lfixture/Base;").equals("x"), "reverse field descriptor mapping");
        check(index.mapMethod("intermediary", "official", "fixture/Base", "roundTrip", "(Lfixture/Base;)Lfixture/Base;").equals("a"), "reverse method mapping");
        check(index.mapDescriptor("official", "intermediary", "([[Lobf/A;ILjava/lang/String;)[Lobf/B;")
            .equals("([[Lfixture/Base;ILjava/lang/String;)[Lfixture/Child;"), "array/method descriptor mapping");
        check(index.mapClass("official", "intermediary", "java/lang/String").equals("java/lang/String"), "external class preserved");
        check(index.mapClass("official", "official", "obf/A").equals("obf/A"), "identity namespace");
        rejects(() -> index.mapClass("named", "intermediary", "obf/A"), IllegalArgumentException.class, "unknown namespace rejected");
        rejects(() -> TinyMappingIndex.read(new StringReader("tiny\t2\t0\tofficial\tintermediary\tnamed\n")), IOException.class, "unsupported namespace count rejected");
        rejects(() -> TinyMappingIndex.read(new StringReader("tiny\t2\t0\ta\tb\nc\tA\tB\nc\tA\tC\n")), IOException.class, "duplicate mapping rejected");
        rejects(() -> TinyMappingIndex.read(new StringReader("tiny\t2\t0\ta\tb\nc\tA\tB\n\tm\tI\ta\tb\n")), IOException.class, "invalid method descriptor rejected");
        Path directory = Files.createTempDirectory("n9ezz-mapping-tests-");
        Path original = directory.resolve("original.jar");
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(original))) {
            entry(output, "obf/A.class", base()); entry(output, "obf/B.class", child());
            entry(output, "pack.mcmeta", "{\"fixture\":true}".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            entry(output, "META-INF/fixture.SF", "old signature".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        Path one = directory.resolve("one.jar"), two = directory.resolve("two.jar");
        GameMappings.remap(original, one, List.of(), index);
        GameMappings.remap(original, two, List.of(), index);
        check(GameMappings.sha256(one).equals(GameMappings.sha256(two)), "remapping output is deterministic");
        try (JarFile output = new JarFile(one.toFile())) {
            check(output.getJarEntry("obf/A.class") == null && output.getJarEntry("fixture/Base.class") != null, "class entries renamed");
            check(output.getJarEntry("pack.mcmeta") != null && output.getJarEntry("META-INF/fixture.SF") == null, "resources preserved and obsolete signatures removed");
            ClassNode base = node(output, "fixture/Base.class"), child = node(output, "fixture/Child.class");
            check(base.fields.stream().anyMatch(field -> field.name.equals("owner") && field.desc.equals("Lfixture/Base;")), "field declaration name/descriptor remapped");
            check(base.methods.stream().anyMatch(method -> method.name.equals("roundTrip") && method.desc.equals("(Lfixture/Base;)Lfixture/Base;")), "method declaration remapped");
            check(child.superName.equals("fixture/Base"), "superclass remapped");
            check(child.methods.stream().anyMatch(method -> method.name.equals("roundTrip")), "override inherited mapping propagated");
            boolean invocation = false;
            for (var method : child.methods) for (var instruction : method.instructions) if (instruction instanceof MethodInsnNode call)
                invocation |= call.owner.equals("fixture/Base") && call.name.equals("roundTrip") && call.desc.equals("(Lfixture/Base;)Lfixture/Base;");
            check(invocation, "method invocation owner/name/descriptor remapped");
        }
        rejects(() -> GameMappings.prepare(original, directory, List.of()), dev.n9ezz.loader.core.LoaderException.class, "unverified game rejected before preparation");
        TinyMappingIndex pinned = GameMappings.index();
        check(pinned.classCount() == 10242 && pinned.fieldCount() == 45245 && pinned.methodCount() == 49671, "pinned mapping resource validated");
        check(pinned.mapClass("official", "intermediary", "gfj").equals("net/minecraft/class_310"), "MinecraftClient class pin");
        check(pinned.mapField("official", "intermediary", "gfj", "s", "Lhnh;").equals("field_1724"), "MinecraftClient player field pin");
        check(pinned.mapMethod("official", "intermediary", "gfj", "V", "()Lgfj;").equals("method_1551"), "MinecraftClient singleton method pin");
        System.out.println("PASS " + checks + " mapping checks");
        MappingFingerprintTests.run();
    }
    private static ClassNode node(JarFile jar, String entry) throws IOException {
        ClassNode node = new ClassNode();
        try (var input = jar.getInputStream(jar.getJarEntry(entry))) { new org.objectweb.asm.ClassReader(input.readAllBytes()).accept(node, 0); }
        return node;
    }
    private static byte[] base() {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "obf/A", null, "java/lang/Object", null);
        writer.visitField(Opcodes.ACC_PUBLIC, "x", "Lobf/A;", null, null).visitEnd();
        var method = writer.visitMethod(Opcodes.ACC_PUBLIC, "a", "(Lobf/A;)Lobf/A;", null, null);
        method.visitCode(); method.visitVarInsn(Opcodes.ALOAD, 1); method.visitInsn(Opcodes.ARETURN); method.visitMaxs(1, 2); method.visitEnd();
        writer.visitEnd(); return writer.toByteArray();
    }
    private static byte[] child() {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "obf/B", null, "obf/A", null);
        var method = writer.visitMethod(Opcodes.ACC_PUBLIC, "a", "(Lobf/A;)Lobf/A;", null, null);
        method.visitCode(); method.visitVarInsn(Opcodes.ALOAD, 0); method.visitVarInsn(Opcodes.ALOAD, 1);
        method.visitMethodInsn(Opcodes.INVOKESPECIAL, "obf/A", "a", "(Lobf/A;)Lobf/A;", false);
        method.visitInsn(Opcodes.ARETURN); method.visitMaxs(2, 2); method.visitEnd();
        writer.visitEnd(); return writer.toByteArray();
    }
    private static void entry(ZipOutputStream output, String name, byte[] bytes) throws IOException { output.putNextEntry(new ZipEntry(name)); output.write(bytes); output.closeEntry(); }
    private static void check(boolean condition, String description) { if (!condition) throw new AssertionError(description); checks++; System.out.println("PASS " + description); }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static void rejects(Checked operation, Class<? extends Throwable> type, String description) throws Exception {
        try { operation.run(); } catch (Throwable error) { if (type.isInstance(error)) { check(true, description); return; } throw error; }
        throw new AssertionError(description);
    }
}
