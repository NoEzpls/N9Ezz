package dev.n9ezz.loader.tests;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.compat.CompatibilityDispatcher;
import dev.n9ezz.loader.core.BuiltinModSource;
import dev.n9ezz.loader.core.Diagnostic;
import dev.n9ezz.loader.core.EventBus;
import dev.n9ezz.loader.core.LifecycleEvent;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.core.RuntimeBootstrap;
import dev.n9ezz.loader.core.RuntimeSession;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.core.VersionConstraint;
import dev.n9ezz.loader.metadata.MetadataReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URLClassLoader;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/** Executable Java 21 integration checks. Every mod is loaded from a real temporary JAR. */
public final class RuntimeTests {
    private RuntimeTests() {}
    @FunctionalInterface private interface Check { void run() throws Exception; }
    private record Test(String name, Check check) {}
    private static Path artifacts;

    public static void main(String[] args) throws Exception {
        if (args.length == 2 && args[0].equals("--write-demo")) {
            Path directory = Path.of(args[1]);
            Files.createDirectories(directory);
            Path jar = jar(directory, "n9ezz-smoke.jar", "n9ezz.mod.json",
                nativeMetadata("native_smoke", "fixture.NativeFixture", ""), "fixture.NativeFixture");
            System.out.println(jar.toAbsolutePath());
            return;
        }
        if (args.length != 0) throw new IllegalArgumentException("Usage: RuntimeTests [--write-demo <directory>]");
        artifacts = Files.createTempDirectory("n9ezz-runtime-tests-");
        List<Test> tests = List.of(
            new Test("pinned internal platform fixtures share one runtime with external native mods", RuntimeTests::fivePlatforms),
            new Test("packaged native mod runs in the shared classloader without a mods copy", RuntimeTests::builtinNative),
            new Test("packaged and external mod identities cannot collide", RuntimeTests::builtinDuplicate),
            new Test("packaged resource verification rejects modified bytes", RuntimeTests::builtinResourceMismatch),
            new Test("packaged cache verification preserves modified files", RuntimeTests::builtinCacheMismatch),
            new Test("packaged mod cannot bypass nested archive restrictions", RuntimeTests::builtinFeatureRestriction),
            new Test("packaged manifests reject duplicate integrity keys", RuntimeTests::builtinManifestAmbiguous),
            new Test("simulated game and obfuscated class share mod runtime ownership", RuntimeTests::simulatedGameOwnership),
            new Test("game bytecode needs an explicit game classpath role", RuntimeTests::implicitGameRejected),
            new Test("explicit game JAR requires the supported main class", RuntimeTests::missingGameMain),
            new Test("game classpath role does not permit game-linked mod bytecode", RuntimeTests::gameLinkedModRejected),
            new Test("dependencies initialize before dependents", RuntimeTests::dependencyOrder),
            new Test("absent optional dependencies remain optional", RuntimeTests::optionalDependency),
            new Test("installed optional dependencies must match versions", RuntimeTests::optionalVersionMismatch),
            new Test("incompatible dependencies are rejected", RuntimeTests::incompatibleDependency),
            new Test("dependency aliases resolve to their real mod", RuntimeTests::providedAlias),
            new Test("mods cannot impersonate engine identities", RuntimeTests::reservedEngineIdentity),
            new Test("missing required dependency is diagnosed", RuntimeTests::missingDependency),
            new Test("wrong dependency version is rejected", RuntimeTests::versionMismatch),
            new Test("bounded version grammars preserve endpoint semantics", RuntimeTests::versionConstraints),
            new Test("invalid optional dependency constraint is still diagnosed", RuntimeTests::invalidOptionalConstraint),
            new Test("dependency cycles are rejected", RuntimeTests::dependencyCycle),
            new Test("duplicate mod identifiers are rejected", RuntimeTests::duplicateIds),
            new Test("duplicate bytecode classes are rejected", RuntimeTests::duplicateClasses),
            new Test("reserved loader classes cannot be shadowed", RuntimeTests::reservedClass),
            new Test("descriptor-free engine JAR cannot evade verification", RuntimeTests::descriptorFreeEngine),
            new Test("explicit shared classpath libraries load once", RuntimeTests::explicitLibrary),
            new Test("missing entrypoint cannot fall back to parent test classes", RuntimeTests::missingEntrypoint),
            new Test("entrypoints cannot execute another mod's class", RuntimeTests::wrongEntrypointOwner),
            new Test("malformed metadata is diagnosed before initialization", RuntimeTests::malformedMetadata),
            new Test("ambiguous metadata formats are rejected", RuntimeTests::ambiguousMetadata),
            new Test("duplicate JSON keys are rejected", RuntimeTests::duplicateJsonKeys),
            new Test("nested archives and access wideners are rejected", RuntimeTests::unsupportedMetadataFeatures),
            new Test("TOML ordering requirements are not silently dropped", RuntimeTests::unsupportedTomlOrdering),
            new Test("multi-mod TOML and manifest version are read consistently", RuntimeTests::tomlVersions),
            new Test("declared mixins fail closed", RuntimeTests::unsupportedMixin),
            new Test("game namespace requiring remapping fails closed", RuntimeTests::unsupportedNamespace),
            new Test("Minecraft bytecode references fail before initialization", RuntimeTests::unsupportedGameReference),
            new Test("standard Forge JavaFML ABI is not fabricated", RuntimeTests::unsupportedJavaFml),
            new Test("unsupported Fabric API fails with mod context", RuntimeTests::unsupportedApi),
            new Test("method names cannot impersonate platform interfaces", RuntimeTests::interfaceMismatch),
            new Test("unsupported Forge service constructor is diagnosed", RuntimeTests::unsupportedConstructor),
            new Test("compatibility callbacks run once per phase", RuntimeTests::phaseCaching),
            new Test("failed compatibility callbacks are never retried", RuntimeTests::failureCaching),
            new Test("initializer failure publishes FAILED and never READY", RuntimeTests::initializerFailure),
            new Test("verify-only does not execute entrypoints", RuntimeTests::verifyOnly),
            new Test("ignored file extensions cannot initialize mods", RuntimeTests::ignoredFiles),
            new Test("event priorities, ties, snapshots and unsubscribe", RuntimeTests::eventBus),
            new Test("lifecycle subscriber failure aborts startup with diagnostics", RuntimeTests::lifecycleSubscriberFailure),
            new Test("ASM transformations execute in deterministic stage order", RuntimeTests::transformations),
            new Test("frozen transformer registration is rejected", RuntimeTests::frozenTransformers),
            new Test("duplicate transformer IDs are rejected", RuntimeTests::duplicateTransformers),
            new Test("transform failures retain transformer diagnostics", RuntimeTests::transformerFailure),
            new Test("invalid JVM dataflow is rejected before class definition", RuntimeTests::invalidBytecode)
        );
        int passed = 0;
        int failed = 0;
        for (Test test : tests) {
            resetProperties();
            try {
                test.check.run();
                passed++;
                System.out.println("PASS " + test.name);
            } catch (Throwable error) {
                failed++;
                System.out.println("FAIL " + test.name + ": " + error);
                error.printStackTrace(System.out);
            }
        }
        System.out.println("RESULT passed=" + passed + " failed=" + failed + " total=" + tests.size());
        System.out.println("FIXTURE_ARTIFACTS " + artifacts);
        if (failed != 0) System.exit(1);
    }

    private static void fivePlatforms() throws Exception {
        Path game = workspace("five-formats");
        Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "50-native.jar", "n9ezz.mod.json", nativeMetadata("native_smoke", "fixture.NativeFixture", ""), "fixture.NativeFixture");
        jar(mods, "10-fabric.jar", "fabric.mod.json", """
            {"schemaVersion":1,"id":"fabric_smoke","version":"1.0.0",
             "n9ezz":{"namespace":"none"},
             "depends":{"native_smoke":">=1.0.0"},
             "entrypoints":{"main":["fixture.FabricFixture"],"client":["fixture.FabricFixture"]}}
            """, "fixture.FabricFixture");
        jar(mods, "20-quilt.jar", "quilt.mod.json", """
            {"schema_version":1,"quilt_loader":{"id":"quilt_smoke","version":"1.0.0","metadata":{},
             "depends":[{"id":"fabric_smoke","versions":">=1.0.0"}],
             "entrypoints":{"init":["fixture.QuiltFixture"]}},"n9ezz":{"namespace":"none"}}
            """, "fixture.QuiltFixture");
        jar(mods, "30-forge.jar", "META-INF/mods.toml", toml("forge_smoke", "n9ezz", """
            [[dependencies.forge_smoke]]
            modId="quilt_smoke"
            versionRange="[1.0.0,)"
            mandatory=true
            ordering="NONE"
            side="BOTH"
            """), "fixture.ForgeFixture");
        jar(mods, "40-neo.jar", "META-INF/neoforge.mods.toml", toml("neo_smoke", "n9ezz", """
            [[dependencies.neo_smoke]]
            modId="forge_smoke"
            versionRange="[1.0.0,)"
            type="required"
            ordering="NONE"
            side="BOTH"
            """), "fixture.NeoForgeFixture");
        List<LifecycleEvent> events = new ArrayList<>();
        EventBus bus = captureEvents(events);
        ClassLoader previousContext = Thread.currentThread().getContextClassLoader();
        try (PinnedFixtures pinned = pinCompatibilityFixtures(game, mods);
                RuntimeSession session = RuntimeBootstrap.runBuiltins(game, mods, List.of(), pinned.sources(), bus, false)) {
            equal(5, session.mods().size(), "all metadata formats discovered");
            equal(List.of("native_smoke", "fabric_smoke", "quilt_smoke", "forge_smoke", "neo_smoke"),
                session.mods().stream().map(mod -> mod.id()).toList(), "dependency order across platform formats");
            equal(List.of(LifecycleEvent.DISCOVERED, LifecycleEvent.RESOLVED, LifecycleEvent.TRANSFORMERS_READY,
                LifecycleEvent.COMMON_SETUP, LifecycleEvent.CLIENT_SETUP, LifecycleEvent.READY), events, "runtime lifecycle");
            equal("native:common;fabric:common;quilt:common;forge:common;neo:common;fabric:client;native:ready;",
                System.getProperty("n9.test.trace"), "all common phases before client and READY");
            equal("native_smoke", System.getProperty("n9.test.native.id"), "native context identifies mod");
            equal(game.toAbsolutePath().normalize().toString(), System.getProperty("n9.test.native.dir"), "context game directory");
            equal("quilt_smoke", System.getProperty("n9.test.quilt.id"), "Quilt metadata facade");
            equal("1.0.0", System.getProperty("n9.test.quilt.version"), "Quilt version facade");
            String loader = Integer.toHexString(System.identityHashCode(session.classLoader()));
            equal(loader, System.getProperty("n9.test.tccl.native"), "initializer thread context uses shared runtime");
            equal(previousContext, Thread.currentThread().getContextClassLoader(), "thread context restored after initialization");
            for (String platform : List.of("native", "fabric", "quilt", "forge", "neo"))
                equal(loader, System.getProperty("n9.test.loader." + platform), "shared runtime loader for " + platform);
            for (String className : List.of("fixture.NativeFixture", "fixture.FabricFixture", "fixture.QuiltFixture",
                    "fixture.ForgeFixture", "fixture.NeoForgeFixture")) {
                Class<?> type = session.classLoader().loadClass(className);
                equal(session.classLoader(), type.getClassLoader(), "fixture uses child loader rather than test parent");
                Path source = Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI());
                truth(source.startsWith(mods) || source.startsWith(game.resolve(".n9ezz/builtin")), "class source is its admitted native or pinned internal JAR: " + source);
            }
            truth(!session.lifecycleTrace().isEmpty(), "session supplies lifecycle trace");
        }
    }

    private record BuiltinFixture(BuiltinModSource source, URLClassLoader resources, String hash) implements AutoCloseable {
        @Override public void close() throws IOException { resources.close(); }
    }

    private static BuiltinFixture builtinFixture(Path game, String metadata, Map<String, byte[]> additionalEntries) throws Exception {
        Path resources = Files.createDirectories(game.resolve("resources"));
        Path jar = resources.resolve("builtin.jar");
        Map<String, byte[]> entries = new LinkedHashMap<>(additionalEntries);
        entries.put("n9ezz.mod.json", metadata.getBytes(StandardCharsets.UTF_8));
        jarEntries(jar, entries);
        byte[] bytes = Files.readAllBytes(jar);
        String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        Files.writeString(resources.resolve("builtin.json"), "{\"resource\":\"builtin.jar\",\"id\":\"native_smoke\",\"version\":\"1.0.0\",\"sha256\":\"" + hash + "\",\"size\":" + bytes.length + "}");
        URLClassLoader loader = new URLClassLoader(new java.net.URL[] { resources.toUri().toURL() }, RuntimeTests.class.getClassLoader());
        return new BuiltinFixture(BuiltinModSource.resource(loader, "builtin.json"), loader, hash);
    }

    private static void builtinNative() throws Exception {
        Path game = workspace("builtin-native"); Path mods = Files.createDirectories(game.resolve("mods"));
        try (BuiltinFixture builtin = builtinFixture(game, nativeMetadata("native_smoke", "fixture.NativeFixture", ""), Map.of("fixture/NativeFixture.class", classBytes("fixture.NativeFixture")))) {
            jar(mods, "dependent.jar", "n9ezz.mod.json", nativeMetadata("dependent", "fixture.DependentFixture", ",\"depends\":{\"native_smoke\":\">=1.0.0\"}"), "fixture.DependentFixture");
            try (RuntimeSession session = RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), false)) {
                equal(List.of("native_smoke", "dependent"), session.mods().stream().map(mod -> mod.id()).toList(), "builtin participates in the ordinary dependency resolver");
                equal(game.resolve(".n9ezz/builtin/" + builtin.hash() + ".jar").toRealPath(), session.mods().getFirst().jar(), "builtin has a verified internal source outside mods");
                equal(session.classLoader(), session.classLoader().loadClass("fixture.NativeFixture").getClassLoader(), "builtin uses the same unified classloader");
                equal("native_smoke", System.getProperty("n9.test.native.id"), "builtin entrypoint ran");
                truth(session.lifecycleTrace().contains("READY"), "accepted builtin reaches READY");
                try (var files = Files.list(mods)) { equal(1L, files.count(), "mods contains only the external dependent"); }
            }
            try (RuntimeSession session = RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), true)) {
                equal(2, session.mods().size(), "cached builtin is verified again for a second run");
            }
        }
    }

    private static void builtinDuplicate() throws Exception {
        Path game = workspace("builtin-duplicate"); Path mods = Files.createDirectories(game.resolve("mods"));
        try (BuiltinFixture builtin = builtinFixture(game, nativeMetadata("native_smoke", "fixture.NativeFixture", ""), Map.of("fixture/NativeFixture.class", classBytes("fixture.NativeFixture")))) {
            jar(mods, "duplicate.jar", "n9ezz.mod.json", nativeMetadata("native_smoke", null, ""));
            try {
                RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), false).close();
                throw new AssertionError("external mod cannot replace packaged identity");
            } catch (LoaderException error) {
                truth(diagnostics(error).contains("DUPLICATE_MOD"), "builtin/external identity collision uses ordinary duplicate diagnostic");
                truth(!error.lifecycleTrace().contains("READY"), "duplicate cannot initialize");
            }
        }
    }

    private static void builtinResourceMismatch() throws Exception {
        Path game = workspace("builtin-resource-mismatch"); Path mods = Files.createDirectories(game.resolve("mods"));
        try (BuiltinFixture builtin = builtinFixture(game, nativeMetadata("native_smoke", null, ""), Map.of())) {
            Files.write(game.resolve("resources/builtin.jar"), new byte[] { 1, 2, 3 });
            try {
                RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), false).close();
                throw new AssertionError("altered resource cannot enter shared runtime");
            } catch (LoaderException error) {
                truth(diagnostics(error).contains("BUILTIN_RESOURCE_MISMATCH"), "altered bundle identified before discovery");
                equal(List.of("FAILED"), error.lifecycleTrace(), "corrupt packaged resource never publishes DISCOVERED");
            }
        }
    }

    private static void builtinCacheMismatch() throws Exception {
        Path game = workspace("builtin-cache-mismatch"); Path mods = Files.createDirectories(game.resolve("mods"));
        try (BuiltinFixture builtin = builtinFixture(game, nativeMetadata("native_smoke", null, ""), Map.of())) {
            try (RuntimeSession ignored = RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), true)) { }
            Path cache = game.resolve(".n9ezz/builtin/" + builtin.hash() + ".jar");
            byte[] changed = new byte[] { 4, 5, 6 }; Files.write(cache, changed);
            try {
                RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), true).close();
                throw new AssertionError("altered cache must fail closed");
            } catch (LoaderException error) {
                truth(diagnostics(error).contains("BUILTIN_CACHE_MISMATCH"), "altered cache identified");
                truth(java.util.Arrays.equals(changed, Files.readAllBytes(cache)), "altered existing file is preserved");
            }
        }
    }

    private static void builtinFeatureRestriction() throws Exception {
        Path game = workspace("builtin-feature-restriction"); Path mods = Files.createDirectories(game.resolve("mods"));
        try (BuiltinFixture builtin = builtinFixture(game, nativeMetadata("native_smoke", null, ""), Map.of("nested.jar", new byte[] { 1 }))) {
            try {
                RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), false).close();
                throw new AssertionError("builtin must obey metadata feature restrictions");
            } catch (LoaderException error) {
                truth(diagnostics(error).contains("METADATA_UNSUPPORTED"), "builtin has the same nested archive restriction");
                equal(List.of("FAILED"), error.lifecycleTrace(), "unsupported builtin never reaches entrypoints");
            }
        }
    }

    private static void builtinManifestAmbiguous() throws Exception {
        Path game = workspace("builtin-manifest-ambiguous"); Path mods = Files.createDirectories(game.resolve("mods"));
        try (BuiltinFixture builtin = builtinFixture(game, nativeMetadata("native_smoke", null, ""), Map.of())) {
            Path manifest = game.resolve("resources/builtin.json");
            String json = Files.readString(manifest);
            Files.writeString(manifest, json.replace("{", "{\"sha256\":\"" + builtin.hash() + "\","));
            try {
                RuntimeBootstrap.runBuiltins(game, mods, List.of(), List.of(builtin.source()), new EventBus(), false).close();
                throw new AssertionError("ambiguous integrity manifest must be rejected");
            } catch (LoaderException error) {
                truth(diagnostics(error).contains("BUILTIN_MANIFEST_INVALID"), "duplicate manifest key has explicit diagnostic");
                equal(List.of("FAILED"), error.lifecycleTrace(), "ambiguous manifest never reaches DISCOVERED");
            }
        }
    }

    private static void dependencyOrder() throws Exception {
        Path game = workspace("dependency-order"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "a-dependent.jar", "n9ezz.mod.json",
            nativeMetadata("a_dependent", "fixture.DependentFixture", ",\"depends\":{\"z_base\":\">=1.0.0\"}"), "fixture.DependentFixture");
        jar(mods, "z-base.jar", "n9ezz.mod.json", nativeMetadata("z_base", "fixture.NativeFixture", ""), "fixture.NativeFixture");
        try (RuntimeSession session = RuntimeBootstrap.run(game, mods, List.of(), new EventBus(), false)) {
            equal(List.of("z_base", "a_dependent"), session.mods().stream().map(mod -> mod.id()).toList(), "topological order overrides filename/id order");
            truth(System.getProperty("n9.test.trace", "").startsWith("native:common;dependent:common;"), "dependent sees dependency side effect");
        }
    }

    private static void simulatedGameOwnership() throws Exception {
        Path game = workspace("simulated-game"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "native.jar", "n9ezz.mod.json", nativeMetadata("native_smoke", "fixture.NativeFixture", ""), "fixture.NativeFixture");
        Path gameJar = simulatedGameJar(game.resolve("simulated-game.jar"));
        try (RuntimeSession session = RuntimeBootstrap.runGame(game, mods, gameJar, new EventBus(), false)) {
            equal(1, session.mods().size(), "game JAR never becomes a synthetic mod");
            Class<?> gameMain = session.classLoader().loadClass("net.minecraft.client.main.Main");
            equal(session.classLoader(), gameMain.getClassLoader(), "explicit game main is child-owned despite reserved package");
            equal(gameJar.toRealPath(), Path.of(gameMain.getProtectionDomain().getCodeSource().getLocation().toURI()), "game code source recorded");
            gameMain.getMethod("main", String[].class).invoke(null, (Object) new String[0]);
            String identity = Integer.toHexString(System.identityHashCode(session.classLoader()));
            equal(identity, System.getProperty("n9.test.game.loader"), "game entrypoint shares mod loader");
            equal(identity, System.getProperty("n9.test.game.obfuscated.loader"), "obfuscated root class shares mod loader");
            equal("game-owned", System.getProperty("n9.test.game.marker"), "game helper executes from explicit game JAR");
            equal(identity, System.getProperty("n9.test.loader.native"), "game and mod classloader identity agree");
        }
    }

    private static void implicitGameRejected() throws Exception {
        Path game = workspace("implicit-game"); Path mods = Files.createDirectories(game.resolve("mods"));
        Path gameJar = simulatedGameJar(game.resolve("simulated-game.jar"));
        try {
            RuntimeBootstrap.run(game, mods, List.of(gameJar), new EventBus(), true).close();
            throw new AssertionError("game class must not enter a normal library role");
        } catch (LoaderException error) {
            truth(diagnostics(error).contains("RESERVED_CLASS"), "ordinary classpath cannot define Minecraft classes");
        }
    }

    private static void missingGameMain() throws Exception {
        Path game = workspace("missing-game-main"); Path mods = Files.createDirectories(game.resolve("mods"));
        Path gameJar = game.resolve("invalid-game.jar");
        jarEntries(gameJar, Map.of("fixture/TransformTarget.class", classBytes("fixture.TransformTarget")));
        try {
            RuntimeBootstrap.runGame(game, mods, gameJar, new EventBus(), true).close();
            throw new AssertionError("game jar without supported main should fail");
        } catch (LoaderException error) {
            truth(diagnostics(error).toLowerCase().contains("main"), "invalid game role reports missing main");
        }
    }

    private static void gameLinkedModRejected() throws Exception {
        Path game = workspace("game-linked-mod-role"); Path mods = Files.createDirectories(game.resolve("mods"));
        Path gameJar = simulatedGameJar(game.resolve("simulated-game.jar"));
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "fixture/GameLinked", null, "java/lang/Object", null);
        writer.visitField(Opcodes.ACC_PUBLIC, "gameMain", "Lnet/minecraft/client/main/Main;", null, null).visitEnd();
        writer.visitEnd();
        jarEntries(mods.resolve("game-linked-mod.jar"), Map.of(
            "n9ezz.mod.json", nativeMetadata("game_linked", null, "").getBytes(StandardCharsets.UTF_8),
            "fixture/GameLinked.class", writer.toByteArray()));
        try {
            RuntimeBootstrap.runGame(game, mods, gameJar, new EventBus(), true).close();
            throw new AssertionError("API-only mod must remain API-only when game is present");
        } catch (LoaderException error) {
            truth(diagnostics(error).contains("UNSUPPORTED_GAME_OR_ENGINE_REFERENCE"), "game role cannot waive mod mapping/API restrictions");
        }
    }

    private static Path simulatedGameJar(Path output) throws IOException {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "g", null, "java/lang/Object", null);
        MethodVisitor method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "marker", "()Ljava/lang/String;", null, null);
        method.visitCode(); method.visitLdcInsn("game-owned"); method.visitInsn(Opcodes.ARETURN);
        method.visitMaxs(1, 0); method.visitEnd(); writer.visitEnd();
        jarEntries(output, Map.of("net/minecraft/client/main/Main.class", classBytes("net.minecraft.client.main.Main"), "g.class", writer.toByteArray()));
        return output;
    }

    private static void optionalDependency() throws Exception {
        Path game = workspace("optional"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "optional.jar", "n9ezz.mod.json", nativeMetadata("optional_smoke", "fixture.NativeFixture",
            ",\"recommends\":{\"not_installed\":\">=2.0.0\"}"), "fixture.NativeFixture");
        try (RuntimeSession ignored = RuntimeBootstrap.run(game, mods, List.of(), new EventBus(), false)) {
            truth(System.getProperty("n9.test.trace", "").contains("native:common;"), "optional absence does not prevent initialization");
        }
    }

    private static void missingDependency() throws Exception {
        Path game = workspace("missing"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "missing.jar", "n9ezz.mod.json", nativeMetadata("missing_smoke", "fixture.NativeFixture",
            ",\"depends\":{\"not_installed\":\">=2.0.0\"}"), "fixture.NativeFixture");
        bootstrapFailure(game, "not_installed");
        equal(null, System.getProperty("n9.test.trace"), "resolver failure prevents code execution");
    }

    private static void optionalVersionMismatch() throws Exception {
        Path game = workspace("optional-version"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "base.jar", "n9ezz.mod.json", nativeMetadata("base", null, ""));
        jar(mods, "dependent.jar", "n9ezz.mod.json", nativeMetadata("dependent", null, ",\"recommends\":{\"base\":\">=2.0.0\"}"));
        bootstrapFailure(game, "base");
    }

    private static void incompatibleDependency() throws Exception {
        Path game = workspace("incompatible"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "base.jar", "n9ezz.mod.json", nativeMetadata("base", null, ""));
        jar(mods, "dependent.jar", "n9ezz.mod.json", nativeMetadata("dependent", null, ",\"breaks\":{\"base\":\">=1.0.0\"}"));
        bootstrapFailure(game, "incompatible");
    }

    private static void providedAlias() throws Exception {
        Path game = workspace("provided-alias"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "base.jar", "n9ezz.mod.json", nativeMetadata("z_base", "fixture.NativeFixture", ",\"provides\":[\"alias_base\"]"), "fixture.NativeFixture");
        jar(mods, "dependent.jar", "n9ezz.mod.json", nativeMetadata("a_dependent", "fixture.DependentFixture", ",\"depends\":{\"alias_base\":\">=1.0.0\"}"), "fixture.DependentFixture");
        try (RuntimeSession session = RuntimeBootstrap.run(game, mods, List.of(), new EventBus(), false)) {
            equal(List.of("z_base", "a_dependent"), session.mods().stream().map(mod -> mod.id()).toList(), "alias selects actual owning mod");
            truth(System.getProperty("n9.test.trace", "").startsWith("native:common;dependent:common;"), "alias dependency executes first");
        }
    }

    private static void reservedEngineIdentity() throws Exception {
        Path game = workspace("reserved-identity"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "spoof.jar", "n9ezz.mod.json", nativeMetadata("spoof", null, ",\"provides\":[\"fabricloader\"]"));
        bootstrapFailure(game, "fabricloader");
    }

    private static void versionMismatch() throws Exception {
        Path game = workspace("wrong-version"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "base.jar", "n9ezz.mod.json", nativeMetadata("base", null, ""));
        jar(mods, "dependent.jar", "n9ezz.mod.json", nativeMetadata("dependent", null, ",\"depends\":{\"base\":\">=2.0.0\"}"));
        bootstrapFailure(game, "base");
    }

    private static void versionConstraints() throws Exception {
        record Case(String expression, String version, boolean expected) {}
        List<Case> cases = List.of(
            new Case("~1.2.3", "1.2.3", true), new Case("~1.2.3", "1.2.99", true), new Case("~1.2.3", "1.3.0", false),
            new Case("^0.2.3", "0.2.99", true), new Case("^0.2.3", "0.3.0", false), new Case("^0.2.3", "0.2.2", false),
            new Case(">=1 <2 || >=3 <4", "1.9.0", true), new Case(">=1 <2 || >=3 <4", "2.9.0", false), new Case(">=1 <2 || >=3 <4", "3.5.0", true),
            new Case("[1,2)", "1.0.0", true), new Case("[1,2)", "2.0.0", false),
            new Case("(,2]", "2.0.0", true), new Case("(,2]", "2.0.1", false),
            new Case("[1,)", "99.0.0", true), new Case("[1,)", "0.9.0", false),
            new Case("[1.2.3]", "1.2.3", true), new Case("[1.2.3]", "1.2.4", false),
            new Case("1.2.x", "1.2.7", true), new Case("1.2.x", "1.3.0", false),
            new Case(">1.0.0-beta.2", "1.0.0-beta.11", true), new Case(">1.0.0-beta.2", "1.0.0-beta.1", false),
            new Case("<1.0.0", "1.0.0-rc.1", true), new Case("=1.0.0", "1.0.0+build.99", true)
        );
        for (Case test : cases) equal(test.expected, VersionConstraint.parse(test.expression).matches(test.version),
            "constraint " + test.expression + " against " + test.version);
        for (String invalid : List.of("", "[1,2", "[2,1]", "(,)", ">=*", "1.2.x.4", ">=1 ||", "latest"))
            failure(() -> VersionConstraint.parse(invalid), IllegalArgumentException.class, "invalid constraint " + invalid);
    }

    private static void invalidOptionalConstraint() throws Exception {
        Path game = workspace("invalid-optional"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "invalid.jar", "n9ezz.mod.json", nativeMetadata("invalid_optional", null, ",\"recommends\":{\"not_installed\":\"latest\"}"));
        bootstrapFailure(game, "INVALID_VERSION_CONSTRAINT");
    }

    private static void dependencyCycle() throws Exception {
        Path game = workspace("cycle"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "a.jar", "n9ezz.mod.json", nativeMetadata("a", null, ",\"depends\":{\"b\":\"*\"}"));
        jar(mods, "b.jar", "n9ezz.mod.json", nativeMetadata("b", null, ",\"depends\":{\"a\":\"*\"}"));
        bootstrapFailure(game, "cycle");
    }

    private static void duplicateIds() throws Exception {
        Path game = workspace("duplicate-ids"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "a.jar", "n9ezz.mod.json", nativeMetadata("same", null, ""));
        jar(mods, "b.jar", "n9ezz.mod.json", nativeMetadata("same", null, ""));
        bootstrapFailure(game, "same");
    }

    private static void duplicateClasses() throws Exception {
        Path game = workspace("duplicate-classes"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "a.jar", "n9ezz.mod.json", nativeMetadata("a", null, ""), "fixture.NativeFixture");
        jar(mods, "b.jar", "n9ezz.mod.json", nativeMetadata("b", null, ""), "fixture.NativeFixture");
        bootstrapFailure(game, "NativeFixture");
    }

    private static void reservedClass() throws Exception {
        Path game = workspace("reserved-class"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "reserved.jar", "n9ezz.mod.json", nativeMetadata("reserved", null, ""), "dev.n9ezz.loader.core.EventBus");
        bootstrapFailure(game, "EventBus");
    }

    private static void descriptorFreeEngine() throws Exception {
        Path game = workspace("no-descriptor-engine"); Path mods = Files.createDirectories(game.resolve("mods"));
        jarEntries(mods.resolve("engine.jar"), Map.of("net/fabricmc/api/ModInitializer.class", classBytes("net.fabricmc.api.ModInitializer")));
        bootstrapFailure(game, "engine.jar");
    }

    private static void explicitLibrary() throws Exception {
        Path game = workspace("explicit-library"); Path mods = Files.createDirectories(game.resolve("mods"));
        Path library = game.resolve("plain-library.jar");
        jarEntries(library, Map.of("fixture/TransformTarget.class", classBytes("fixture.TransformTarget")));
        try (RuntimeSession session = RuntimeBootstrap.run(game, mods, List.of(library), new EventBus(), false)) {
            equal(0, session.mods().size(), "explicit library is not a synthetic mod");
            Class<?> type = session.classLoader().loadClass("fixture.TransformTarget");
            equal(session.classLoader(), type.getClassLoader(), "shared library uses runtime classloader");
            equal(7, type.getMethod("value").invoke(null), "actual library bytecode executes");
            equal(library.toRealPath(), Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI()), "library class source tracked");
        }
    }

    private static void missingEntrypoint() throws Exception {
        Path game = workspace("missing-entrypoint"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "missing.jar", "n9ezz.mod.json", nativeMetadata("missing_entry", "fixture.NativeFixture", ""));
        bootstrapFailure(game, "NativeFixture");
        equal(null, System.getProperty("n9.test.trace"), "test parent class cannot satisfy missing mod class");
    }

    private static void wrongEntrypointOwner() throws Exception {
        Path game = workspace("wrong-entrypoint-owner"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "borrower.jar", "n9ezz.mod.json", nativeMetadata("borrower", "fixture.NativeFixture", ""));
        jar(mods, "owner.jar", "n9ezz.mod.json", nativeMetadata("owner", null, ""), "fixture.NativeFixture");
        bootstrapFailure(game, "borrower");
        equal(null, System.getProperty("n9.test.trace"), "foreign-owned class never executes");
    }

    private static void malformedMetadata() throws Exception {
        Path game = workspace("malformed"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "broken.jar", "n9ezz.mod.json", "{ invalid json", "fixture.NativeFixture");
        bootstrapFailure(game, "metadata");
        equal(null, System.getProperty("n9.test.trace"), "metadata error does not invoke mod");
    }

    private static void ambiguousMetadata() throws Exception {
        Path game = workspace("ambiguous"); Path mods = Files.createDirectories(game.resolve("mods"));
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("n9ezz.mod.json", nativeMetadata("native", null, "").getBytes(StandardCharsets.UTF_8));
        entries.put("fabric.mod.json", "{\"schemaVersion\":1,\"id\":\"fabric\",\"version\":\"1.0.0\"}".getBytes(StandardCharsets.UTF_8));
        jarEntries(mods.resolve("ambiguous.jar"), entries);
        bootstrapFailure(game, "EXTERNAL_MOD_AMBIGUOUS");
    }

    private static void duplicateJsonKeys() throws Exception {
        Path game = workspace("duplicate-json-keys"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "duplicate-keys.jar", "n9ezz.mod.json", "{\"schemaVersion\":1,\"id\":\"one\",\"id\":\"two\",\"version\":\"1.0.0\"}");
        bootstrapFailure(game, "duplicate JSON key");
    }

    private static void unsupportedMetadataFeatures() throws Exception {
        Path nestedGame = workspace("nested-archive"); Path nestedMods = Files.createDirectories(nestedGame.resolve("mods"));
        jarEntries(nestedMods.resolve("nested.jar"), Map.of(
            "n9ezz.mod.json", nativeMetadata("nested", null, "").getBytes(StandardCharsets.UTF_8),
            "lib/hidden.jar", new byte[]{0}));
        bootstrapFailure(nestedGame, "EXTERNAL_NESTED_MOD_UNSUPPORTED");
        Path awGame = workspace("access-widener"); Path awMods = Files.createDirectories(awGame.resolve("mods"));
        jar(awMods, "aw.jar", "fabric.mod.json", """
            {"schemaVersion":1,"id":"aw_smoke","version":"1.0.0","n9ezz":{"namespace":"none"},"accessWidener":"fixture.accesswidener"}
            """);
        metadataFailure(awMods.resolve("aw.jar"), "accessWidener");
    }

    private static void unsupportedTomlOrdering() throws Exception {
        Path game = workspace("toml-ordering"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "ordering.jar", "META-INF/mods.toml", toml("forge_smoke", "n9ezz", """
            [[dependencies.forge_smoke]]
            modId="native_smoke"
            versionRange="[1.0.0,)"
            mandatory=true
            ordering="BEFORE"
            side="BOTH"
            """));
        metadataFailure(mods.resolve("ordering.jar"), "ordering");
    }

    private static void tomlVersions() throws Exception {
        Path game = workspace("toml-versions");
        String descriptor = """
            modLoader="n9ezz"
            loaderVersion=">=0.2.0"
            license="MIT"
            [[mods]]
            modId="first"
            version="${file.jarVersion}"
            [[mods]]
            modId="second"
            version="2.0.0"
            [n9ezz]
            namespace="none"
            """;
        Path jar = game.resolve("multiple.jar");
        jarEntries(jar, Map.of("META-INF/mods.toml", descriptor.getBytes(StandardCharsets.UTF_8),
            "META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\nImplementation-Version: 1.2.3\r\n\r\n".getBytes(StandardCharsets.UTF_8)));
        var metadata = MetadataReader.read(jar);
        equal(List.of("first", "second"), metadata.stream().map(mod -> mod.id()).toList(), "all TOML mods discovered in declared order");
        equal(List.of("1.2.3", "2.0.0"), metadata.stream().map(mod -> mod.version()).toList(), "manifest placeholder and fixed version remain distinct");
        Path missing = game.resolve("missing-manifest.jar");
        jarEntries(missing, Map.of("META-INF/mods.toml", descriptor.getBytes(StandardCharsets.UTF_8)));
        failure(() -> MetadataReader.read(missing), dev.n9ezz.loader.metadata.MetadataException.class, "missing manifest version");
    }

    private static void unsupportedMixin() throws Exception {
        Path game = workspace("mixin"); Path mods = Files.createDirectories(game.resolve("mods"));
        jarEntries(mods.resolve("mixin.jar"), Map.of(
            "n9ezz.mod.json", nativeMetadata("mixin_smoke", "fixture.NativeFixture", ",\"mixins\":[\"fixture.mixins.json\"]").getBytes(StandardCharsets.UTF_8),
            "fixture.mixins.json", "{\"required\":true,\"package\":\"fixture.mixin\",\"mixins\":[]}".getBytes(StandardCharsets.UTF_8),
            "fixture/NativeFixture.class", classBytes("fixture.NativeFixture")));
        bootstrapFailure(game, "mixin");
        equal(null, System.getProperty("n9.test.trace"), "unsupported transformation fails before mod code");
    }

    private static void unsupportedNamespace() throws Exception {
        Path game = workspace("namespace"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "mapped.jar", "n9ezz.mod.json", """
            {"schemaVersion":1,"id":"mapped_smoke","version":"1.0.0",
             "namespace":"intermediary","entrypoints":{"common":["fixture.NativeFixture"]}}
            """, "fixture.NativeFixture");
        bootstrapFailure(game, "namespace");
    }

    private static void unsupportedJavaFml() throws Exception {
        Path game = workspace("javafml"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "standard-forge.jar", "META-INF/mods.toml", toml("forge_smoke", "javafml", ""), "fixture.ForgeFixture");
        pinnedBootstrapFailure(game, "javafml");
    }

    private static void unsupportedGameReference() throws Exception {
        Path game = workspace("game-reference"); Path mods = Files.createDirectories(game.resolve("mods"));
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "fixture/GameLinked", null, "java/lang/Object", null);
        writer.visitField(Opcodes.ACC_PUBLIC, "client", "Lnet/minecraft/class_310;", null, null).visitEnd();
        writer.visitEnd();
        jarEntries(mods.resolve("game-linked.jar"), Map.of(
            "n9ezz.mod.json", nativeMetadata("game_linked", null, "").getBytes(StandardCharsets.UTF_8),
            "fixture/GameLinked.class", writer.toByteArray()));
        bootstrapFailure(game, "Minecraft");
    }

    private static void unsupportedApi() throws Exception {
        Path game = workspace("unsupported-api"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "fabric-api.jar", "fabric.mod.json", """
            {"schemaVersion":1,"id":"unsupported_api","version":"1.0.0","n9ezz":{"namespace":"none"},
             "entrypoints":{"main":["fixture.UnsupportedApiFixture"]}}
            """, "fixture.UnsupportedApiFixture");
        pinnedBootstrapFailure(game, "unsupported_api");
    }

    private static void interfaceMismatch() throws Exception {
        Path game = workspace("interface-mismatch"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "impostor.jar", "fabric.mod.json", """
            {"schemaVersion":1,"id":"impostor","version":"1.0.0","n9ezz":{"namespace":"none"},"entrypoints":{"main":["fixture.MethodOnlyFixture"]}}
            """, "fixture.MethodOnlyFixture");
        pinnedBootstrapFailure(game, "ENTRYPOINT_INTERFACE_MISMATCH");
        equal(null, System.getProperty("n9.test.impostor"), "unrelated method cannot execute");
    }

    private static void unsupportedConstructor() throws Exception {
        Path game = workspace("unsupported-constructor"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "constructor.jar", "META-INF/mods.toml", toml("forge_smoke", "n9ezz", ""), "fixture.ForgeNeedsConstructor");
        pinnedBootstrapFailure(game, "UNSUPPORTED_MOD_CONSTRUCTOR");
        equal(null, System.getProperty("n9.test.forge.injected"), "service constructor never executes");
    }

    private static void phaseCaching() throws Exception {
        Path game = workspace("phase-cache"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "fabric.jar", "fabric.mod.json", """
            {"schemaVersion":1,"id":"fabric_smoke","version":"1.0.0","n9ezz":{"namespace":"none"},
             "entrypoints":{"main":["fixture.FabricFixture"],"client":["fixture.FabricFixture"]}}
            """, "fixture.FabricFixture");
        EventBus events = new EventBus();
        try (PinnedFixtures pinned = pinCompatibilityFixtures(game, mods);
                RuntimeSession session = RuntimeBootstrap.runBuiltins(game, mods, List.of(), pinned.sources(), events, true)) {
            var metadata = session.mods().getFirst();
            var context = new ModContext(metadata.id(), game, events);
            CompatibilityDispatcher dispatcher = new CompatibilityDispatcher();
            dispatcher.initialize(metadata, "common", session.classLoader(), context);
            dispatcher.initialize(metadata, "common", session.classLoader(), context);
            dispatcher.initialize(metadata, "client", session.classLoader(), context);
            dispatcher.initialize(metadata, "client", session.classLoader(), context);
            equal("fabric:common;fabric:client;", System.getProperty("n9.test.trace"), "one callback and shared instance per phase");
        }
    }

    private static void failureCaching() throws Exception {
        Path game = workspace("failure-cache"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "throwing.jar", "n9ezz.mod.json", nativeMetadata("throwing", "fixture.ThrowingFixture", ""), "fixture.ThrowingFixture");
        EventBus events = new EventBus(); ClassLoader previous = Thread.currentThread().getContextClassLoader();
        try (RuntimeSession session = RuntimeBootstrap.run(game, mods, List.of(), events, true)) {
            var metadata = session.mods().getFirst(); var context = new ModContext(metadata.id(), game, events);
            CompatibilityDispatcher dispatcher = new CompatibilityDispatcher();
            for (int attempt = 0; attempt < 2; attempt++) {
                failure(() -> dispatcher.initialize(metadata, "common", session.classLoader(), context), LoaderException.class, "cached initializer failure");
                equal(previous, Thread.currentThread().getContextClassLoader(), "context loader restored even after failure");
            }
            equal("1", System.getProperty("n9.test.throwing.attempts"), "failed callback attempted once only");
        }
    }

    private static void initializerFailure() throws Exception {
        Path game = workspace("initializer-failure"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "throwing.jar", "n9ezz.mod.json", nativeMetadata("throwing", "fixture.ThrowingFixture", ""), "fixture.ThrowingFixture");
        List<LifecycleEvent> events = new ArrayList<>();
        try {
            RuntimeBootstrap.run(game, mods, List.of(), captureEvents(events), false).close();
            throw new AssertionError("initializer should fail");
        } catch (LoaderException error) {
            truth(!error.diagnostics().isEmpty(), "initializer exposes structured diagnostics");
            truth(diagnostics(error).contains("throwing"), "failure identifies mod");
            truth(!events.contains(LifecycleEvent.READY), "failure cannot publish READY");
            equal(LifecycleEvent.FAILED, events.getLast(), "failure terminates lifecycle");
        }
    }

    private static void verifyOnly() throws Exception {
        Path game = workspace("verify-only"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "native.jar", "n9ezz.mod.json", nativeMetadata("verify_smoke", "fixture.NativeFixture", ""), "fixture.NativeFixture");
        List<LifecycleEvent> events = new ArrayList<>();
        try (RuntimeSession session = RuntimeBootstrap.run(game, mods, List.of(), captureEvents(events), true)) {
            equal(1, session.mods().size(), "verify discovers metadata");
            equal(null, System.getProperty("n9.test.trace"), "verify mode never executes initializer");
            equal(List.of(LifecycleEvent.DISCOVERED, LifecycleEvent.RESOLVED, LifecycleEvent.TRANSFORMERS_READY), events, "verify has no initialization/ready lifecycle");
            truth(session.lifecycleTrace().contains("VERIFY_ONLY_COMPLETE"), "verify completion explicitly identified");
        }
    }

    private static void ignoredFiles() throws Exception {
        Path game = workspace("ignored"); Path mods = Files.createDirectories(game.resolve("mods"));
        Path jar = jar(mods, "disabled.jar", "n9ezz.mod.json", nativeMetadata("disabled", "fixture.NativeFixture", ""), "fixture.NativeFixture");
        Files.move(jar, mods.resolve("disabled.jar.disabled"));
        Files.writeString(mods.resolve("readme.txt"), "Not a mod");
        try (RuntimeSession session = RuntimeBootstrap.run(game, mods, List.of(), new EventBus(), false)) {
            equal(0, session.mods().size(), "disabled and text files ignored");
            equal(null, System.getProperty("n9.test.trace"), "ignored mod never runs");
        }
    }

    private static void eventBus() throws Exception {
        EventBus bus = new EventBus(); List<String> trace = new ArrayList<>();
        AutoCloseable low = bus.on(LifecycleEvent.READY, -1, event -> trace.add("low"));
        bus.on(LifecycleEvent.READY, 10, event -> {
            trace.add("first");
            bus.on(LifecycleEvent.READY, 20, later -> trace.add("added"));
        });
        bus.on(LifecycleEvent.READY, 10, event -> trace.add("second"));
        bus.publish(LifecycleEvent.READY);
        equal(List.of("first", "second", "low"), trace, "priority and stable ties; new subscriber waits for next publication");
        low.close(); trace.clear(); bus.publish(LifecycleEvent.READY);
        equal(List.of("added", "first", "second"), trace, "unsubscribe and later registration respected");
        low.close();
    }

    private static void lifecycleSubscriberFailure() throws Exception {
        Path game = workspace("subscriber-failure"); Path mods = Files.createDirectories(game.resolve("mods"));
        jar(mods, "native.jar", "n9ezz.mod.json", nativeMetadata("subscriber_smoke", "fixture.NativeFixture", ""), "fixture.NativeFixture");
        List<LifecycleEvent> trace = new ArrayList<>(); EventBus events = captureEvents(trace);
        events.on(LifecycleEvent.RESOLVED, 0, event -> { throw new AssertionError("fixture event failure"); });
        try {
            RuntimeBootstrap.run(game, mods, List.of(), events, false).close();
            throw new AssertionError("event failure should abort runtime");
        } catch (LoaderException error) {
            truth(diagnostics(error).contains("LIFECYCLE_HANDLER_FAILED"), "event callback failure has structured code");
            equal(List.of(LifecycleEvent.DISCOVERED, LifecycleEvent.RESOLVED, LifecycleEvent.FAILED), trace, "event failure halts later phases");
            equal(null, System.getProperty("n9.test.trace"), "event failure precedes mod execution");
        }
    }

    private static void transformations() throws Exception {
        TransformationPipeline pipeline = new TransformationPipeline(); List<String> trace = new ArrayList<>();
        pipeline.register(TransformationPipeline.Stage.POST, 0, "post", (name, bytes) -> { trace.add("post"); return replaceInt(bytes, 41, 51); });
        pipeline.register(TransformationPipeline.Stage.CORE, 0, "core-b", (name, bytes) -> { trace.add("core-b"); return bytes; });
        pipeline.register(TransformationPipeline.Stage.MIXIN, 0, "mixin", (name, bytes) -> { trace.add("mixin"); return replaceInt(bytes, 31, 41); });
        pipeline.register(TransformationPipeline.Stage.CORE, 10, "core-first", (name, bytes) -> { trace.add("core-first"); return replaceInt(bytes, 21, 31); });
        pipeline.register(TransformationPipeline.Stage.ACCESS, 0, "access", (name, bytes) -> { trace.add("access"); return replaceInt(bytes, 11, 21); });
        pipeline.register(TransformationPipeline.Stage.CORE, 0, "core-a", (name, bytes) -> { trace.add("core-a"); return bytes; });
        pipeline.register(TransformationPipeline.Stage.MAPPING, 0, "mapping", (name, bytes) -> { trace.add("mapping"); return replaceInt(bytes, 7, 11); });
        pipeline.freeze();
        byte[] output = pipeline.apply("fixture.TransformTarget", classBytes("fixture.TransformTarget"));
        equal(List.of("mapping", "access", "core-first", "core-a", "core-b", "mixin", "post"), trace, "stage, priority and stable identifier order");
        class IsolatedLoader extends ClassLoader {
            IsolatedLoader() { super(null); }
            Class<?> define(byte[] bytes) { return defineClass("fixture.TransformTarget", bytes, 0, bytes.length); }
        }
        Object value = new IsolatedLoader().define(output).getMethod("value").invoke(null);
        equal(51, value, "transformed JVM bytecode actually executes");
    }

    private static void frozenTransformers() throws Exception {
        TransformationPipeline pipeline = new TransformationPipeline(); pipeline.freeze();
        failure(() -> pipeline.register(TransformationPipeline.Stage.CORE, 0, "late", (name, bytes) -> bytes), IllegalStateException.class, "freeze");
    }

    private static void duplicateTransformers() throws Exception {
        TransformationPipeline pipeline = new TransformationPipeline();
        pipeline.register(TransformationPipeline.Stage.CORE, 0, "same", (name, bytes) -> bytes);
        failure(() -> pipeline.register(TransformationPipeline.Stage.POST, 5, "same", (name, bytes) -> bytes), IllegalArgumentException.class, "duplicate");
    }

    private static void transformerFailure() throws Exception {
        TransformationPipeline pipeline = new TransformationPipeline();
        pipeline.register(TransformationPipeline.Stage.CORE, 0, "broken-transform", (name, bytes) -> { throw new IOException("transform fixture failure"); });
        pipeline.freeze();
        try {
            pipeline.apply("fixture.TransformTarget", classBytes("fixture.TransformTarget"));
            throw new AssertionError("transform should fail");
        } catch (LoaderException error) {
            truth(diagnostics(error).contains("broken-transform"), "failed transformer is identified");
            truth(diagnostics(error).contains("TransformTarget"), "failed class is identified");
        }
    }

    private static void invalidBytecode() throws Exception {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC, "fixture/BadDataflow", null, "java/lang/Object", null);
        MethodVisitor method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "bad", "()Ljava/lang/Object;", null, null);
        method.visitCode(); method.visitInsn(Opcodes.ARETURN); method.visitMaxs(1, 0); method.visitEnd(); writer.visitEnd();
        TransformationPipeline pipeline = new TransformationPipeline(); pipeline.freeze();
        try {
            pipeline.apply("fixture.BadDataflow", writer.toByteArray());
            throw new AssertionError("invalid dataflow should be rejected before defineClass");
        } catch (LoaderException error) {
            truth(diagnostics(error).contains("INVALID_BYTECODE"), "invalid stack use has bytecode diagnostic");
        }
    }

    private static byte[] replaceInt(byte[] bytes, int expected, int replacement) {
        ClassReader reader = new ClassReader(bytes); ClassWriter writer = new ClassWriter(0);
        boolean[] changed = {false};
        reader.accept(new ClassVisitor(Opcodes.ASM9, writer) {
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                return new MethodVisitor(Opcodes.ASM9, super.visitMethod(access, name, descriptor, signature, exceptions)) {
                    @Override public void visitIntInsn(int opcode, int operand) {
                        if ((opcode == Opcodes.BIPUSH || opcode == Opcodes.SIPUSH) && operand == expected) {
                            changed[0] = true; super.visitIntInsn(Opcodes.BIPUSH, replacement);
                        } else super.visitIntInsn(opcode, operand);
                    }
                };
            }
        }, 0);
        truth(changed[0], "ASM stage received expected prior bytecode value " + expected);
        return writer.toByteArray();
    }

    private static Path workspace(String name) throws IOException { return Files.createDirectories(artifacts.resolve(name)); }

    private static EventBus captureEvents(List<LifecycleEvent> trace) {
        EventBus bus = new EventBus();
        for (LifecycleEvent event : LifecycleEvent.values()) bus.on(event, 100, trace::add);
        return bus;
    }

    /** Compatibility adapters remain covered through hash-pinned internal test bundles.
     * External user archives always use the production native-only admission path. */
    private record PinnedFixtures(List<BuiltinModSource> sources, URLClassLoader resources) implements AutoCloseable {
        @Override public void close() throws IOException { resources.close(); }
    }

    private static PinnedFixtures pinCompatibilityFixtures(Path game, Path mods) throws Exception {
        Path resources = Files.createDirectories(game.resolve("pinned-fixture-resources"));
        List<String> manifests = new ArrayList<>();
        try (var paths = Files.list(mods)) {
            for (Path jar : paths.filter(path -> path.getFileName().toString().endsWith(".jar")).sorted().toList()) {
                var metadata = MetadataReader.read(jar);
                if (metadata.size() != 1) throw new AssertionError("Test bundle must have exactly one mod");
                var mod = metadata.getFirst();
                if (mod.platform() == dev.n9ezz.loader.metadata.Platform.N9EZZ) continue;
                String resource = jar.getFileName().toString();
                byte[] bytes = Files.readAllBytes(jar);
                String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
                String manifest = resource + ".json";
                Files.move(jar, resources.resolve(resource));
                Files.writeString(resources.resolve(manifest), "{\"resource\":\"" + resource + "\",\"id\":\"" + mod.id()
                        + "\",\"version\":\"" + mod.version() + "\",\"sha256\":\"" + hash + "\",\"size\":" + bytes.length + "}");
                manifests.add(manifest);
            }
        }
        URLClassLoader loader = new URLClassLoader(new java.net.URL[] { resources.toUri().toURL() }, RuntimeTests.class.getClassLoader());
        return new PinnedFixtures(manifests.stream().map(manifest -> BuiltinModSource.resource(loader, manifest)).toList(), loader);
    }

    private static void metadataFailure(Path jar, String context) throws Exception {
        try {
            MetadataReader.read(jar);
            throw new AssertionError("Expected metadata rejection: " + context);
        } catch (dev.n9ezz.loader.metadata.MetadataException failure) {
            truth(failure.getMessage().toLowerCase().contains(context.toLowerCase()), "metadata diagnostic context retained: " + failure);
        }
    }

    private static void pinnedBootstrapFailure(Path game, String context) throws Exception {
        List<LifecycleEvent> events = new ArrayList<>();
        try (PinnedFixtures pinned = pinCompatibilityFixtures(game, game.resolve("mods"))) {
            try {
                RuntimeBootstrap.runBuiltins(game, game.resolve("mods"), List.of(), pinned.sources(), captureEvents(events), false).close();
                throw new AssertionError("Expected internal adapter rejection: " + context);
            } catch (LoaderException error) {
                truth(diagnostics(error).toLowerCase().contains(context.toLowerCase()), "internal adapter diagnostic '" + context + "' present in " + diagnostics(error));
                truth(!events.contains(LifecycleEvent.READY), "invalid adapter cannot become READY");
                truth(events.contains(LifecycleEvent.FAILED), "invalid adapter publishes FAILED");
            }
        }
    }

    private static void bootstrapFailure(Path game, String context) throws Exception {
        List<LifecycleEvent> events = new ArrayList<>();
        try {
            RuntimeBootstrap.run(game, game.resolve("mods"), List.of(), captureEvents(events), false).close();
            throw new AssertionError("Expected runtime rejection: " + context);
        } catch (LoaderException error) {
            truth(!error.diagnostics().isEmpty(), "structured diagnostics are available");
            truth(diagnostics(error).toLowerCase().contains(context.toLowerCase()), "diagnostic context '" + context + "' present in " + diagnostics(error));
            truth(!events.contains(LifecycleEvent.READY), "invalid environment cannot become READY");
            truth(events.contains(LifecycleEvent.FAILED), "invalid environment publishes FAILED");
        }
    }

    private static String diagnostics(LoaderException error) {
        return error.diagnostics().stream().map(Diagnostic::toString).reduce("", (left, right) -> left + "\n" + right);
    }

    private static String nativeMetadata(String id, String entrypoint, String extra) {
        return "{\"schemaVersion\":1,\"id\":\"" + id + "\",\"version\":\"1.0.0\",\"namespace\":\"none\""
            + (entrypoint == null ? "" : ",\"entrypoints\":{\"common\":[\"" + entrypoint + "\"]}") + extra + "}";
    }

    private static String toml(String id, String language, String extra) {
        return "modLoader=\"" + language + "\"\nloaderVersion=\"" + (language.equals("n9ezz") ? ">=0.2.0" : "[1,)")
            + "\"\nlicense=\"MIT\"\n[[mods]]\nmodId=\"" + id + "\"\nversion=\"1.0.0\"\n"
            + "[n9ezz]\nnamespace=\"none\"\n" + extra;
    }

    private static Path jar(Path directory, String name, String metadataPath, String metadata, String... classes) throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put(metadataPath, metadata.getBytes(StandardCharsets.UTF_8));
        for (String className : classes) entries.put(className.replace('.', '/') + ".class", classBytes(className));
        Path output = directory.resolve(name); jarEntries(output, entries); return output;
    }

    private static void jarEntries(Path output, Map<String, byte[]> entries) throws IOException {
        try (JarOutputStream jar = new JarOutputStream(Files.newOutputStream(output))) {
            for (Map.Entry<String, byte[]> entry : entries.entrySet()) {
                JarEntry jarEntry = new JarEntry(entry.getKey()); jarEntry.setTime(0); jar.putNextEntry(jarEntry);
                jar.write(entry.getValue()); jar.closeEntry();
            }
        }
    }

    private static byte[] classBytes(String name) throws IOException {
        String resource = name.replace('.', '/') + ".class";
        try (InputStream input = RuntimeTests.class.getClassLoader().getResourceAsStream(resource)) {
            if (input == null) throw new IOException("Test fixture not compiled: " + resource);
            return input.readAllBytes();
        }
    }

    private static void failure(Check operation, Class<? extends Exception> type, String context) throws Exception {
        try { operation.run(); } catch (Exception expected) {
            if (type.isInstance(expected)) return;
            throw expected;
        }
        throw new AssertionError("Expected rejection: " + context);
    }

    private static void resetProperties() {
        List<String> names = System.getProperties().stringPropertyNames().stream().filter(key -> key.startsWith("n9.test.")).toList();
        for (String name : names) System.clearProperty(name);
    }

    private static void truth(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    private static void equal(Object expected, Object actual, String message) {
        if (!Objects.equals(expected, actual)) throw new AssertionError(message + ": expected=" + expected + " actual=" + actual);
    }
}
