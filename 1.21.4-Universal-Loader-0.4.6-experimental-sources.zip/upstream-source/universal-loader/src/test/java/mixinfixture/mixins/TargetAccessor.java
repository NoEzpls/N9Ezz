package mixinfixture.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(targets = "mixinfixture.Target", remap = false)
public interface TargetAccessor {
    @Accessor("secret") int n9ezz$getSecret();
    @Accessor("secret") void n9ezz$setSecret(int value);
    @Invoker("hidden") int n9ezz$invokeHidden(int value);
}
