package mixinfixture.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "mixinfixture.Target", remap = false)
public abstract class InnerMixin {
    public static class Helper { public static int amount() { return 31; } }
    @Inject(method = "value", at = @At("RETURN"), cancellable = true, require = 1)
    private void n9ezz$inner(CallbackInfoReturnable<Integer> result) { result.setReturnValue(Helper.amount()); }
}
