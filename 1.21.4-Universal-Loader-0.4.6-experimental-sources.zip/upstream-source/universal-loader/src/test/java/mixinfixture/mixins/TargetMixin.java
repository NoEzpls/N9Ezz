package mixinfixture.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "mixinfixture.Target", remap = false)
public abstract class TargetMixin {
    @Inject(method = "value", at = @At("RETURN"), cancellable = true, require = 1)
    private void n9ezz$inject(CallbackInfoReturnable<Integer> result) { result.setReturnValue(result.getReturnValue() + 10); }
    @Redirect(method = "redirected", at = @At(value = "INVOKE", target = "Ljava/lang/Math;abs(I)I"), require = 1)
    private int n9ezz$redirect(int value) { return 7; }
    @ModifyReturnValue(method = "extras", at = @At("RETURN"), require = 1)
    private int n9ezz$extras(int value) { return value * 2; }
}
