package mixinfixture.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "mixinfixture.Target", remap = false)
public abstract class BrokenMixin {
    @Inject(method = "methodThatDoesNotExist", at = @At("HEAD"), require = 1)
    private void n9ezz$broken(CallbackInfo info) { }
}
