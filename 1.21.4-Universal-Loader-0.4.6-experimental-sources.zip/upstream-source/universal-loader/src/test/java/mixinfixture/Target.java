package mixinfixture;

public class Target {
    private int secret = 4;
    private int hidden(int value) { return value * 3; }
    public int value() { return 2; }
    public int redirected() { return Math.abs(-3) + 1; }
    public int extras() { return 5; }
}
