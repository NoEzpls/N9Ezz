package dev.n9ezz.gametest;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Optional;

/**
 * Optional, read-only geometry QA for the exact embedded client and Minecraft
 * 1.21.11 intermediary ABI. This is a local integrated-world observer, not a
 * gameplay module: it never writes entities, settings, camera state or packets.
 */
public final class LocalHitboxProbe {
    private static final String CLIENT_SHA256 = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424";
    private static boolean attempted;
    private static int checks;

    private LocalHitboxProbe() {}

    /** Run once from a genuine END_CLIENT_TICK, after a real local world exists. */
    public static void observe(Object client) throws Exception {
        if (attempted) return;
        Object world = client.getClass().getField("field_1687").get(client);
        Object player = client.getClass().getField("field_1724").get(client);
        Object server = client.getClass().getMethod("method_1576").invoke(client);
        if (world == null || player == null || server == null) return;
        attempted = true;
        try {
            run(client, world, player, server);
        } catch (Exception | LinkageError | AssertionError failure) {
            // A missing symbol, changed payload, or failed assertion remains a
            // real test failure; the observer must never turn it into a PASS.
            System.out.println("N9EZZ_LOCAL_HITBOX_QA status=FAIL checks=" + checks
                + " reason=" + failure.getClass().getName());
            throw failure;
        }
    }

    private static void run(Object client, Object world, Object player, Object server) throws Exception {
        ClassLoader loader = client.getClass().getClassLoader();
        Class<?> geometry = Class.forName("pulse.n9ezz.TargetGeometry", true, loader);
        Class<?> targeting = Class.forName("pulse.n9ezz.d", true, loader);
        Class<?> boundsType = Class.forName("pulse.n9ezz.TargetGeometry$Bounds", true, loader);
        Class<?> pointType = Class.forName("pulse.n9ezz.TargetGeometry$Point", true, loader);
        Class<?> boxType = Class.forName("net.minecraft.class_238", false, loader);
        Class<?> vectorType = Class.forName("net.minecraft.class_243", false, loader);
        Class<?> entityType = Class.forName("net.minecraft.class_1297", false, loader);
        require(loader.getClass().getName().equals("dev.n9ezz.loader.core.UnifiedClassLoader"), "own runtime classloader");
        require(geometry.getClassLoader() == loader && targeting.getClassLoader() == loader
            && world.getClass().getClassLoader() == loader && player.getClass().getClassLoader() == loader
            && server.getClass().getClassLoader() == loader, "game, addon and local server share one classloader");
        Path clientJar = Path.of(geometry.getProtectionDomain().getCodeSource().getLocation().toURI());
        require(Files.isRegularFile(clientJar), "production geometry has a real archive provenance");
        require(sha256(clientJar).equals(CLIENT_SHA256), "exact corrected client archive");
        require(targeting.getProtectionDomain().getCodeSource().getLocation().equals(
            geometry.getProtectionDomain().getCodeSource().getLocation()), "geometry and selection helper come from the same client");

        Constructor<?> boundsConstructor = boundsType.getConstructor(double.class, double.class, double.class,
            double.class, double.class, double.class);
        Constructor<?> pointConstructor = pointType.getConstructor(double.class, double.class, double.class);
        Constructor<?> boxConstructor = boxType.getConstructor(double.class, double.class, double.class,
            double.class, double.class, double.class);
        Constructor<?> vectorConstructor = vectorType.getConstructor(double.class, double.class, double.class);
        Method scale = geometry.getMethod("scale", boundsType, double.class, double.class, double.class);
        Method hit = geometry.getMethod("rayHitDistanceSquared", boundsType, pointType, pointType);
        Method within = geometry.getMethod("withinRange", boundsType, pointType, double.class);
        Method pickable = geometry.getMethod("pickable", double.class, double.class, double.class);
        Method visible = geometry.getMethod("visible", double.class, double.class);
        Method distance = geometry.getMethod("distanceSquared", boundsType, pointType);
        Method raycast = boxType.getMethod("method_992", vectorType, vectorType);

        Object physicalBox = entityType.getMethod("method_5829").invoke(player);
        double[] original = boxValues(physicalBox);
        Object eyeVector = entityType.getMethod("method_33571").invoke(player);
        double[] eye = vectorValues(eyeVector);
        double width = original[3] - original[0], depth = original[5] - original[2];
        require(width > .1 && depth > .1 && original[4] > original[1], "live local player has nonempty physical bounds");
        require(eye[1] > original[1] && eye[1] < original[4], "live eye lies inside the player height");
        Object from = pointConstructor.newInstance(eye[0], eye[1], eye[2]);
        Object to = pointConstructor.newInstance(eye[0], eye[1], eye[2] + 3);
        Object vanillaTo = vectorConstructor.newInstance(eye[0], eye[1], eye[2] + 3);

        // These boxes are numerical fixtures derived from the actual player
        // dimensions and eye position. They are not entities or server targets.
        double[] lateral = {eye[0] + width * 4 / 3 - width / 2, original[1], eye[2] + 2 - depth / 2,
            eye[0] + width * 4 / 3 + width / 2, original[4], eye[2] + 2 + depth / 2};
        Object body = boundsConstructor.newInstance(arguments(lateral));
        Object expanded = scale.invoke(null, body, 5d, 1d, 1d);
        Object vanillaBody = boxConstructor.newInstance(arguments(lateral));
        Object vanillaExpanded = boxConstructor.newInstance(arguments(boundsValues(expanded)));
        double ordinaryHit = (double) hit.invoke(null, body, from, to);
        double expandedHit = (double) hit.invoke(null, expanded, from, to);
        Optional<?> ordinaryRay = (Optional<?>) raycast.invoke(vanillaBody, eyeVector, vanillaTo);
        Optional<?> expandedRay = (Optional<?>) raycast.invoke(vanillaExpanded, eyeVector, vanillaTo);
        require(Double.isInfinite(ordinaryHit) && ordinaryRay.isEmpty(), "ordinary lateral ray misses in both production and vanilla geometry");
        require(Double.isFinite(expandedHit) && expandedRay.isPresent(), "expanded lateral ray hits in both production and vanilla geometry");
        close(expandedHit, squaredDistance(eye, vectorValues(expandedRay.orElseThrow())), "production and actual vanilla raycast agree on first entry distance");
        require((boolean) pickable.invoke(null, expandedHit, 3d, Double.POSITIVE_INFINITY), "expanded visible near-miss can be selected by shared math");
        require(!(boolean) pickable.invoke(null, ordinaryHit, 3d, Double.POSITIVE_INFINITY), "ordinary mode rejects the same near-miss");
        require(!(boolean) pickable.invoke(null, expandedHit, 3d, expandedHit), "block at the same ray distance wins");
        require(!(boolean) pickable.invoke(null, expandedHit, 3d, expandedHit / 2), "earlier block cuts off expanded selection");

        // Invoke the real, remapped Targeting nearest-point bridge as well as
        // independent vanilla Box math; this detects broken client/member links.
        Object selectedNearest = targeting.getMethod("m9", boxType, vectorType).invoke(null, vanillaBody, eyeVector);
        double bodyDistance = (double) distance.invoke(null, body, from);
        close(bodyDistance, squaredDistance(eye, vectorValues(selectedNearest)), "production Targeting nearest point uses shared geometry");
        close(bodyDistance, (double) boxType.getMethod("method_49271", vectorType).invoke(vanillaBody, eyeVector),
            "production closest distance agrees with vanilla Box");
        require(bodyDistance > (double) distance.invoke(null, expanded, from), "physical distance remains separate from virtual distance");
        Object ordinaryReal = targeting.getMethod("m5", entityType, boolean.class).invoke(null, player, false);
        require(physicalBox.equals(ordinaryReal), "ordinary Targeting policy retains the actual physical player box");
        Object identity = scale.invoke(null, body, 1d, 1d, 1d);
        require(body.equals(identity), "identity expansion preserves exact bounds");

        double[] broadMiss = lateral.clone();
        double xShift = width;
        broadMiss[0] += xShift;
        broadMiss[3] += xShift;
        Object broadBody = boundsConstructor.newInstance(arguments(broadMiss));
        Object broadExpanded = scale.invoke(null, broadBody, 5d, 1d, 1d);
        require(broadMiss[0] > eye[0] + 1, "numerical body lies outside vanilla one-block ray broad phase");
        require(Double.isFinite((double) hit.invoke(null, broadExpanded, from, to)), "expanded numerical box still intersects outside that broad phase");

        double[] far = {eye[0] - width / 2, original[1], eye[2] + 3.6 - depth / 2,
            eye[0] + width / 2, original[4], eye[2] + 3.6 + depth / 2};
        Object farBody = boundsConstructor.newInstance(arguments(far));
        Object farExpanded = scale.invoke(null, farBody, 1d, 1d, 4d);
        require(!(boolean) within.invoke(null, farBody, from, 3d), "physical body beyond ordinary reach stays out of range");
        require((boolean) within.invoke(null, farExpanded, from, 3d), "virtual box may enter range without moving the physical body");
        require(!(boolean) visible.invoke(null, bodyDistance, bodyDistance / 2), "physical-body visibility rejects an earlier blocker");
        require((boolean) visible.invoke(null, bodyDistance, Double.POSITIVE_INFINITY), "unblocked physical surface remains visible");
        require(java.util.Arrays.equals(original, boxValues(entityType.getMethod("method_5829").invoke(player))),
            "observer leaves actual entity bounds unchanged");

        System.out.println("N9EZZ_LOCAL_HITBOX_QA status=PASS checks=" + checks + " clientSha256=" + CLIENT_SHA256
            + " loader=" + loader + " world=true player=true integratedServer=true scope=read_only_geometry"
            + " playerWidth=" + width + " playerHeight=" + (original[4] - original[1])
            + " ordinaryMiss=true expandedHit=true vanillaRaycastAgrees=true physicalBoundsUnchanged=true"
            + " attackPacketsTested=false liveRemoteTargetSelectionTested=false");
    }

    private static Object[] arguments(double[] values) {
        Object[] result = new Object[values.length];
        for (int index = 0; index < values.length; index++) result[index] = values[index];
        return result;
    }

    private static double[] boxValues(Object box) throws Exception {
        String[] fields = {"field_1323", "field_1322", "field_1321", "field_1320", "field_1325", "field_1324"};
        double[] result = new double[6];
        for (int index = 0; index < fields.length; index++) result[index] = box.getClass().getField(fields[index]).getDouble(box);
        return result;
    }

    private static double[] boundsValues(Object bounds) throws Exception {
        String[] fields = {"minX", "minY", "minZ", "maxX", "maxY", "maxZ"};
        double[] result = new double[6];
        for (int index = 0; index < fields.length; index++) result[index] = (double) bounds.getClass().getMethod(fields[index]).invoke(bounds);
        return result;
    }

    private static double[] vectorValues(Object vector) throws Exception {
        return new double[]{vector.getClass().getField("field_1352").getDouble(vector),
            vector.getClass().getField("field_1351").getDouble(vector), vector.getClass().getField("field_1350").getDouble(vector)};
    }

    private static double squaredDistance(double[] first, double[] last) {
        double x = first[0] - last[0], y = first[1] - last[1], z = first[2] - last[2];
        return x * x + y * y + z * z;
    }

    private static String sha256(Path source) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = Files.newInputStream(source)) {
            byte[] buffer = new byte[64 * 1024];
            for (int count; (count = input.read(buffer)) >= 0;) if (count > 0) digest.update(buffer, 0, count);
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    private static void close(double actual, double expected, String name) {
        require(Double.isFinite(actual) && Double.isFinite(expected)
            && Math.abs(actual - expected) <= 1e-7 * Math.max(1, Math.abs(expected)), name);
    }

    private static void require(boolean condition, String name) {
        checks++;
        if (!condition) throw new AssertionError("Local hitbox geometry QA: " + name);
    }
}
