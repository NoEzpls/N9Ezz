package dev.n9ezz.gametest;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import dev.n9ezz.loader.core.LifecycleEvent;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicLong;

/** Optional real-game observer; deliberately absent from the installed runtime. */
public final class CrossPlatformMonitor implements N9ModInitializer {
    private static final AtomicLong sequence = new AtomicLong();
    private static final AtomicLong serverStarts = new AtomicLong();
    private static final AtomicLong serverEnds = new AtomicLong();
    private static final AtomicLong serverOrderFailures = new AtomicLong();
    private static long clientStarts;
    private static long clientEnds;
    private static long clientOrderFailures;
    private static long worldCallbacks;
    private static volatile ClassLoader serverLoader;
    private static volatile boolean serverStarted;
    private static boolean joined;
    private static boolean clientStarted;
    private static boolean demoContinued;

    /** Called only by genuine mod constructors/entrypoints and bus callbacks. */
    public static synchronized void phase(String platform, String phase, Object instance) {
        line("kind=phase platform=" + platform + " phase=" + phase + " instance="
            + Integer.toHexString(System.identityHashCode(instance)) + " loader=" + instance.getClass().getClassLoader()
            + " contextLoader=" + Thread.currentThread().getContextClassLoader());
    }

    /** Official API queries are kept separate from successful class construction. */
    public static void api(String platform, boolean identity, boolean paths, boolean sameContainer) {
        line("kind=api platform=" + platform + " identity=" + identity + " paths=" + paths + " sameContainer=" + sameContainer);
    }

    @Override public void onInitialize(ModContext context) throws Exception {
        ClassLoader loader = getClass().getClassLoader();
        for (LifecycleEvent event : LifecycleEvent.values())
            context.events().on(event, Integer.MIN_VALUE, fired -> line("kind=runtime phase=" + fired));
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents", "CLIENT_STARTED", "ClientStarted", args -> {
            clientStarted = true;
            line("kind=milestone event=clientStarted clientLoader=" + args[0].getClass().getClassLoader());
        });
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents", "SERVER_STARTING", "ServerStarting", args -> {
            serverLoader = args[0].getClass().getClassLoader();
            line("kind=milestone event=serverStarting serverLoader=" + serverLoader);
        });
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents", "SERVER_STARTED", "ServerStarted", args -> {
            serverStarted = true;
            line("kind=milestone event=serverStarted serverLoader=" + args[0].getClass().getClassLoader());
        });
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents", "START_SERVER_TICK", "StartTick", args -> {
            if (serverStarts.get() != serverEnds.get()) serverOrderFailures.incrementAndGet();
            serverStarts.incrementAndGet();
        });
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents", "END_SERVER_TICK", "EndTick", args -> {
            long ends = serverEnds.incrementAndGet();
            if (serverStarts.get() != ends) serverOrderFailures.incrementAndGet();
            if (ends == 1 || ends == 100 || ends % 500 == 0)
                line("kind=server serverTicks=" + ends + " serverStarts=" + serverStarts.get()
                    + " serverOrderingFailures=" + serverOrderFailures.get() + " serverLoader=" + args[0].getClass().getClassLoader());
        });
        register(loader, "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents", "INIT", "Init", args ->
            line("kind=milestone event=networkInit handlerLoader=" + args[0].getClass().getClassLoader()));
        register(loader, "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents", "JOIN", "Join", args -> {
            joined = true;
            line("kind=milestone event=networkJoin handlerLoader=" + args[0].getClass().getClassLoader());
        });
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents", "START_CLIENT_TICK", "StartTick", args -> {
            if (clientStarts != clientEnds) clientOrderFailures++;
            clientStarts++;
        });
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents", "END_CLIENT_TICK", "EndTick", args -> {
            clientEnds++;
            if (clientStarts != clientEnds) clientOrderFailures++;
            Object client = args[0];
            Object world = client.getClass().getField("field_1687").get(client);
            Object player = client.getClass().getField("field_1724").get(client);
            Object screen = client.getClass().getField("field_1755").get(client);
            if (world != null && player != null && Boolean.getBoolean("n9ezz.smoke.hitboxGeometry"))
                Class.forName("dev.n9ezz.gametest.LocalHitboxProbe", true, loader)
                    .getMethod("observe", Object.class).invoke(null, client);
            if (Boolean.getBoolean("n9ezz.smoke.continueDemo") && !demoContinued && world != null && player != null
                    && screen != null && screen.getClass().getName().equals("net.minecraft.class_417")) {
                // Minecraft 1.21.11 DemoScreen.method_19810 is the real Continue Playing
                // button handler: setScreen(null), then Mouse.lockCursor(). Invoking it
                // on the ordinary client callback lets vanilla unpause the server;
                // no world/player, pause flags, tick counters or packets are assigned.
                Method continuePlaying = screen.getClass().getDeclaredMethod("method_19810",
                    Class.forName("net.minecraft.class_4185", false, loader));
                continuePlaying.setAccessible(true);
                continuePlaying.invoke(screen, new Object[]{null});
                demoContinued = true;
                line("kind=milestone event=demoContinued mechanism=vanilla_Continue_Playing_handler");
            }
            if (world != null && player != null) worldCallbacks++;
            if (clientEnds == 1 || clientEnds == 100 || clientEnds % 500 == 0 || worldCallbacks == 1 || worldCallbacks % 500 == 0 && worldCallbacks > 0) {
                Class<?> addon = Class.forName("pulse.n9ezz.N9Ezz", false, loader);
                line("kind=sample clientTicks=" + clientEnds + " clientStarts=" + clientStarts
                    + " clientOrderingFailures=" + clientOrderFailures + " clientStarted=" + clientStarted
                    + " world=" + (world != null) + " player=" + (player != null) + " worldCallbacks=" + worldCallbacks
                    + " serverStarted=" + serverStarted + " serverTicks=" + serverEnds.get() + " joined=" + joined
                    + " demoContinued=" + demoContinued + " screen=" + (screen == null ? "none" : screen.getClass().getName())
                    + " clientLoader=" + client.getClass().getClassLoader() + " n9ezzLoader=" + addon.getClassLoader()
                    + " worldLoader=" + (world == null ? "none" : world.getClass().getClassLoader())
                    + " playerLoader=" + (player == null ? "none" : player.getClass().getClassLoader()));
            }
        });
        line("kind=observer registered=true loader=" + loader + " continueDemo=" + Boolean.getBoolean("n9ezz.smoke.continueDemo"));
    }

    @FunctionalInterface private interface Listener { void call(Object[] args) throws Exception; }
    private static void register(ClassLoader loader, String owner, String event, String callback, Listener listener) throws Exception {
        Class<?> api = Class.forName(owner, true, loader);
        Class<?> type = Class.forName(owner + "$" + callback, true, loader);
        Object proxy = Proxy.newProxyInstance(loader, new Class<?>[]{type}, (instance, method, args) -> {
            if (method.getDeclaringClass() == Object.class) return switch (method.getName()) {
                case "toString" -> "N9Ezz cross-platform game observer " + event;
                case "hashCode" -> System.identityHashCode(instance);
                case "equals" -> instance == args[0];
                default -> null;
            };
            listener.call(args);
            return null;
        });
        Class.forName("net.fabricmc.fabric.api.event.Event", false, loader).getMethod("register", Object.class)
            .invoke(api.getField(event).get(null), proxy);
    }

    private static synchronized void line(String text) {
        System.out.println("N9EZZ_CROSS_PLATFORM_PROBE seq=" + sequence.incrementAndGet() + " " + text
            + " thread=" + Thread.currentThread().getName());
    }
}
