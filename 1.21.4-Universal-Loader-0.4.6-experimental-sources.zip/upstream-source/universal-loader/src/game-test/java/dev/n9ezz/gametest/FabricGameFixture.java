package dev.n9ezz.gametest;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;

/** Synthetic fixture using the unchanged Fabric 0.19.2 public initializer ABI. */
public final class FabricGameFixture implements ModInitializer, ClientModInitializer {
    @Override public void onInitialize() {
        CrossPlatformMonitor.phase("fabric", "common", this);
    }
    @Override public void onInitializeClient() {
        CrossPlatformMonitor.phase("fabric", "client", this);
        FabricLoader loader = FabricLoader.getInstance();
        CrossPlatformMonitor.api("fabric", loader.isModLoaded("n9ezz_cross_fabric")
            && loader.getModContainer("n9ezz_cross_fabric").orElseThrow().getMetadata().getId().equals("n9ezz_cross_fabric"),
            loader.getGameDir().isAbsolute() && loader.getConfigDir().isAbsolute(), true);
    }
}
