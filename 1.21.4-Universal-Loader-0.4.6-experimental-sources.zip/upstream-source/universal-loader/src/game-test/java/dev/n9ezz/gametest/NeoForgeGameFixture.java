package dev.n9ezz.gametest;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent;

/** Synthetic NeoForge21.11/FML10/Bus8 fixture, using explicit event types. */
@Mod("n9ezz_cross_neoforge")
public final class NeoForgeGameFixture {
    public NeoForgeGameFixture(IEventBus bus, ModContainer container, Dist dist) {
        CrossPlatformMonitor.phase("neoforge", "construct", this);
        CrossPlatformMonitor.api("neoforge", container.getModId().equals("n9ezz_cross_neoforge") && dist == Dist.CLIENT, true, true);
        bus.addListener(FMLCommonSetupEvent.class, event -> {
            CrossPlatformMonitor.phase("neoforge", "common", this);
            event.enqueueWork(() -> CrossPlatformMonitor.phase("neoforge", "commonWork", this));
        });
        bus.addListener(FMLClientSetupEvent.class, event -> {
            CrossPlatformMonitor.phase("neoforge", "client", this);
            event.enqueueWork(() -> CrossPlatformMonitor.phase("neoforge", "clientWork", this));
        });
        bus.addListener(FMLLoadCompleteEvent.class, event -> CrossPlatformMonitor.phase("neoforge", "complete", this));
    }
}
