package dev.n9ezz.gametest;

import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.loader.api.QuiltLoader;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;

/** Synthetic QSL-signature fixture; it does not advertise a stock QSL release. */
public final class QuiltGameFixture implements ModInitializer, ClientModInitializer {
    private ModContainer commonContainer;
    @Override public void onInitialize(ModContainer container) {
        commonContainer = container;
        CrossPlatformMonitor.phase("quilt", "common", this);
    }
    @Override public void onInitializeClient(ModContainer container) {
        CrossPlatformMonitor.phase("quilt", "client", this);
        CrossPlatformMonitor.api("quilt", QuiltLoader.isModLoaded("n9ezz_cross_quilt")
            && container.metadata().id().equals("n9ezz_cross_quilt")
            && QuiltLoader.getModContainer("n9ezz_cross_quilt").orElseThrow() == container,
            QuiltLoader.getGameDir().isAbsolute() && QuiltLoader.getConfigDir().isAbsolute(), commonContainer == container);
    }
}
