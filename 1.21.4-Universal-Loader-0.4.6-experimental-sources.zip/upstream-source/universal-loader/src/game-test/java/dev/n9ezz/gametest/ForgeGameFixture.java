package dev.n9ezz.gametest;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent;

/** Synthetic Forge61/Bus7 fixture; no Forge engine or game patches are loaded. */
@Mod("n9ezz_cross_forge")
public final class ForgeGameFixture {
    public ForgeGameFixture(FMLJavaModLoadingContext context) {
        CrossPlatformMonitor.phase("forge", "construct", this);
        var group = context.getModBusGroup();
        FMLCommonSetupEvent.getBus(group).addListener(event -> {
            CrossPlatformMonitor.phase("forge", "common", this);
            event.enqueueWork(() -> CrossPlatformMonitor.phase("forge", "commonWork", this));
        });
        FMLClientSetupEvent.getBus(group).addListener(event -> {
            CrossPlatformMonitor.phase("forge", "client", this);
            event.enqueueWork(() -> CrossPlatformMonitor.phase("forge", "clientWork", this));
        });
        FMLLoadCompleteEvent.getBus(group).addListener(event -> CrossPlatformMonitor.phase("forge", "complete", this));
    }
}
