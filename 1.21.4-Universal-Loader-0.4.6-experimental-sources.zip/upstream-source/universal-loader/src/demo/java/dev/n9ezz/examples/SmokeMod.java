package dev.n9ezz.examples;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import dev.n9ezz.loader.core.LifecycleEvent;

/** Native API-only example. Does not depend on Minecraft or another loader. */
public final class SmokeMod implements N9ModInitializer {
    @Override
    public void onInitialize(ModContext context) {
        System.setProperty("n9ezz.smoke.initialized", context.modId());
        context.events().on(LifecycleEvent.READY, 0,
                event -> System.setProperty("n9ezz.smoke.ready", "true"));
        System.out.println("Native smoke mod initialized: " + context.modId());
    }
}
