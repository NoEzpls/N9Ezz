#!/usr/bin/env python3
"""Optional world fixture around gameplay_smoke.py, with an isolated test mod.

The mod observes actual server/network/render events. --demo-world invokes the
vanilla Play Demo button handler after ordinary Pulse initialization. It does not
inject a world/player or call client addon initializers. It needs no account.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile


def build_world_probe(loader, java, output):
    classes = output / "world-probe-classes"
    classes.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).parent / "world-probe/WorldProbe.java"
    subprocess.run([str(java.with_name("javac")), "--release", "21", "-proc:none", "-encoding", "UTF-8",
                    "-cp", str(loader), "-d", str(classes), str(source)], check=True)
    mod = output / "world-probe.jar"
    metadata = {"schemaVersion": 1, "id": "n9ezz_world_probe", "version": "1.0.0",
                "namespace": "none", "environment": "client",
                "entrypoints": {"common": ["dev.n9ezz.smoke.WorldProbe"]},
                "depends": {"java": ">=21", "n9ezz": ">=0.3.0", "pulse": "*"}}
    with zipfile.ZipFile(mod, "w", compression=zipfile.ZIP_DEFLATED) as jar:
        for path in sorted(classes.rglob("*.class")):
            jar.write(path, path.relative_to(classes).as_posix())
        jar.writestr("n9ezz.mod.json", json.dumps(metadata, sort_keys=True))
    return mod


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/minecraft-smoke"))
    parser.add_argument("--loader", type=Path, required=True)
    parser.add_argument("--java", type=Path, default=Path("/workspace/toolchains/jdk-21.0.8+9/bin/java"))
    parser.add_argument("--seconds", type=int, default=180)
    parser.add_argument("--name", default="n9ezz-shared-world")
    parser.add_argument("--demo-world", action="store_true")
    parser.add_argument("--replay", action="store_true", help="Re-evaluate saved logs/base report without launching a game")
    parser.add_argument("--extra-library", action="append", type=Path, default=[])
    args = parser.parse_args()
    if Path(args.name).name != args.name:
        parser.error("--name must be a single path component")
    output = args.root.resolve() / args.name
    loader_sha256 = hashlib.sha256(args.loader.read_bytes()).hexdigest()
    original_exit_code = None
    if args.replay:
        base = json.loads((output / "result.json").read_text())
        if base.get("loader_sha256") != loader_sha256:
            raise SystemExit("Saved gameplay report does not match the supplied loader hash")
        existing = output / "world-result.json"
        if existing.exists():
            previous = json.loads(existing.read_text())
            if previous.get("loader_sha256") != loader_sha256:
                raise SystemExit("Saved world report does not match the supplied loader hash")
            original_exit_code = previous.get("original_gameplay_smoke_exit_code", previous.get("gameplay_smoke_exit_code"))
            archived = output / "world-result-harness-parser-v1.json"
            if not archived.exists():
                archived.write_bytes(existing.read_bytes())
        base_passed = base.get("passed") is True and all(base.get("acceptance", {}).values())
        gameplay_exit_code = 0 if base_passed else 1
    else:
        mods = output / "game/mods"
        mods.mkdir(parents=True, exist_ok=True)
        probe = build_world_probe(args.loader.resolve(), args.java.resolve(), output)
        (mods / "world-probe.jar").write_bytes(probe.read_bytes())
        command = [sys.executable, str(Path(__file__).with_name("gameplay_smoke.py")), "--root", str(args.root),
                   "--loader", str(args.loader), "--java", str(args.java), "--seconds", str(args.seconds), "--name", args.name]
        for library in args.extra_library:
            command.extend(["--extra-library", str(library)])
        env = os.environ.copy()
        if args.demo_world:
            env["JAVA_TOOL_OPTIONS"] = env.get("JAVA_TOOL_OPTIONS", "") + " -Dn9ezz.smoke.demoWorld=true"
        completed = subprocess.run(command, env=env, check=False)
        gameplay_exit_code = completed.returncode
        base_passed = gameplay_exit_code == 0
    lines = (output / "launch.log").read_text(errors="replace").splitlines()
    observed = [line for line in lines if "N9EZZ_WORLD_PROBE" in line]
    result = {"fixture": "optional observer mod", "loader_sha256": loader_sha256,
              "gameplay_smoke_exit_code": gameplay_exit_code,
              "replayed_from_recorded_gameplay_report": args.replay,
              "demo_world_requested": args.demo_world, "probe_lines": observed,
              "world_and_player_observed": any("world=true player=true" in line for line in observed),
              "network_join_observed": any("networkJoin=true" in line for line in observed),
              "server_started_observed": any("serverStarted=true serverLoader=" in line for line in observed),
              "world_render_observed": any("renderFrames=" in line and "renderFrames=0" not in line for line in observed),
              "interpretation": "Only logged callbacks are evidence; module toggles, combat/PvP and arbitrary mod compatibility are not tested."}
    render_failures = [int(value) for line in observed for value in re.findall(r"renderOrderingFailures=(\d+)", line)]
    result["observed_render_ordering_failures"] = max(render_failures, default=None)
    if args.replay:
        result["original_gameplay_smoke_exit_code"] = original_exit_code
        result["gameplay_smoke_exit_code_explanation"] = "Current acceptance replay status; original game harness subprocess status is preserved separately. No second game launch."
    result["acceptance"] = {"base_gameplay_probe_passed": base_passed,
                            "world_and_player": result["world_and_player_observed"],
                            "local_network_join": result["network_join_observed"],
                            "integrated_server_started": result["server_started_observed"],
                            "actual_world_render": result["world_render_observed"],
                            "render_ordering_valid": bool(render_failures) and max(render_failures) == 0}
    result["passed"] = all(result["acceptance"].values())
    (output / "world-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print("WORLD_SMOKE result=" + str(output / "world-result.json"), flush=True)
    for line in observed:
        print(line, flush=True)
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
