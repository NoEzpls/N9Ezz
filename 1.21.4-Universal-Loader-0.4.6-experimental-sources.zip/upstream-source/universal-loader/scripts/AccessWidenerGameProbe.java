import dev.n9ezz.loader.mapping.AccessWidenerSet;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.jar.JarFile;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;

/** Checks the three exact selected Fabric API access wideners against the prepared official game. */
public final class AccessWidenerGameProbe {
    public static void main(String[] arguments) throws Exception {
        Path game = Path.of(arguments[0]);
        List<Path> modules = Arrays.stream(arguments).skip(1).map(Path::of).toList();
        AccessWidenerSet rules = AccessWidenerSet.fromJars(modules, "intermediary");
        if (rules.sources().size() != 3) throw new AssertionError("Expected lifecycle, networking and command AW");
        rules.validateTargets(game);
        System.out.println("PASS exact selected Fabric API target declarations validated: " + rules.sources());
        try (JarFile jar = new JarFile(game.toFile())) {
            classPublic(jar, rules, "net/minecraft/server/MinecraftServer$class_6897");
            classPublic(jar, rules, "net/minecraft/class_631$class_3681");
            ClassNode chunk = transformed(jar, rules, "net/minecraft/class_631$class_3681");
            if (chunk.methods.stream().noneMatch(method -> method.name.equals("method_16034") && method.desc.equals("(II)Z") && (method.access & Opcodes.ACC_PUBLIC) != 0))
                throw new AssertionError("Lifecycle method did not become public");
            System.out.println("PASS lifecycle exact chunk method made public");
            fieldPublic(jar, rules, "net/minecraft/class_8703", "field_45682", "I");
            fieldPublic(jar, rules, "net/minecraft/class_2817", "field_33361", "I");
            fieldPublic(jar, rules, "net/minecraft/class_2658", "field_33326", "I");
            fieldPublic(jar, rules, "net/minecraft/class_2170$class_5364", "field_25423", "Z");
            fieldPublic(jar, rules, "net/minecraft/class_2170$class_5364", "field_25422", "Z");
        }
        System.out.println("PASS exact lifecycle/networking/command access rules applied to actual Minecraft 1.21.11");
    }
    private static ClassNode transformed(JarFile jar, AccessWidenerSet rules, String name) throws Exception {
        byte[] original;
        try (var input = jar.getInputStream(jar.getJarEntry(name + ".class"))) { original = input.readAllBytes(); }
        ClassNode node = new ClassNode();
        new ClassReader(rules.transform(name.replace('/', '.'), original)).accept(node, 0);
        return node;
    }
    private static void classPublic(JarFile jar, AccessWidenerSet rules, String name) throws Exception {
        if ((transformed(jar, rules, name).access & Opcodes.ACC_PUBLIC) == 0) throw new AssertionError("Class not public: " + name);
        System.out.println("PASS class made public: " + name);
    }
    private static void fieldPublic(JarFile jar, AccessWidenerSet rules, String owner, String name, String descriptor) throws Exception {
        if (transformed(jar, rules, owner).fields.stream().noneMatch(field -> field.name.equals(name) && field.desc.equals(descriptor) && (field.access & Opcodes.ACC_PUBLIC) != 0))
            throw new AssertionError("Field not public: " + owner + "." + name);
        System.out.println("PASS field made public: " + owner + "." + name);
    }
}
