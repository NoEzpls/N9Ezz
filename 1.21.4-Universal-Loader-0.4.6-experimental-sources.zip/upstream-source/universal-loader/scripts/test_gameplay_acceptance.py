#!/usr/bin/env python3
"""Regression checks for observed game acceptance, without launching or fabricating a game."""
from gameplay_smoke import evaluate_acceptance

line = ("[Render thread/INFO]: N9EZZ_GAMEPLAY_PROBE ticks=4000 starts=4000 orderingFailures=0 "
        "clientStarted=true initialized=true pulseInit=true registeredAura=true registeredTrigger=true "
        "registeredHitboxes=true registryCount=113 "
        "clientLoader=dev.n9ezz.loader.core.UnifiedClassLoader@123 "
        "n9ezzLoader=dev.n9ezz.loader.core.UnifiedClassLoader@123")

def passed(lines, alive=True):
    return all(evaluate_acceptance(lines, alive).values())

assert passed([line]), "The digit in n9ezzLoader must retain the exact shared-loader observation"
assert not passed([line.replace("n9ezzLoader=dev.n9ezz.loader.core.UnifiedClassLoader@123", "n9ezzLoader=dev.n9ezz.loader.core.UnifiedClassLoader@456")])
assert not passed([line.replace("starts=4000", "starts=3999")])
assert not passed([line.replace("registeredHitboxes=true", "registeredHitboxes=false")])
assert not passed([line.replace("registryCount=113", "registryCount=83")])
assert not passed([line, "Exception in thread Render thread: game crashed"])
assert not passed([line], False)
assert not passed([line.replace("dev.n9ezz.loader.core.UnifiedClassLoader@123", "net.fabricmc.loader.impl.launch.knot.KnotClassLoader@123")])
assert not passed(["Only a PID and a screenshot exist"])
print("PASS 9 gameplay report acceptance checks")
