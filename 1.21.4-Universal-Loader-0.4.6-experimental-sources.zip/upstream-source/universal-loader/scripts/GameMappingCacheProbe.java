import com.google.gson.Gson;
import com.google.gson.JsonObject;
import dev.n9ezz.loader.core.LoaderException;
import dev.n9ezz.loader.mapping.GameMappings;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

/** Exercises integrity repair and safe cache paths with the checksum-verified real game. */
public final class GameMappingCacheProbe {
    public static void main(String[] arguments) throws Exception {
        JsonObject inputs = new Gson().fromJson(Files.readString(Path.of(arguments[0])), JsonObject.class);
        Path original = Path.of(inputs.getAsJsonObject("client").get("path").getAsString());
        ArrayList<Path> libraries = new ArrayList<>();
        for (var item : inputs.getAsJsonArray("libraries")) libraries.add(Path.of(item.getAsString()));
        Path root = Path.of(arguments[1]);
        Path mapped = GameMappings.prepare(original, root, libraries);
        String expectedHash = GameMappings.sha256(mapped);
        Files.write(mapped, new byte[]{1}, StandardOpenOption.APPEND);
        Path repaired = GameMappings.prepare(original, root, libraries);
        if (!expectedHash.equals(GameMappings.sha256(repaired))) throw new AssertionError("Corrupt cache not deterministically repaired");
        System.out.println("PASS corrupted real-game cache rebuilt to identical output SHA256 " + expectedHash);
        Path symlinkGame = Files.createTempDirectory(root, "symlink-root-");
        Path outside = Files.createTempDirectory(root, "symlink-outside-");
        Files.createSymbolicLink(symlinkGame.resolve(".n9ezz"), outside);
        try {
            GameMappings.prepare(original, symlinkGame, libraries);
            throw new AssertionError("Symlink cache root accepted");
        } catch (IOException expected) {
            if (!expected.getMessage().contains("symbolic link")) throw expected;
            if (Files.exists(outside.resolve("cache"))) throw new AssertionError("Wrote through symlink");
            System.out.println("PASS cache root symbolic link rejected before external writes");
        }
        Path symlinkOutputGame = Files.createTempDirectory(root, "symlink-output-");
        Path linkedCache = symlinkOutputGame.resolve(".n9ezz/cache/game").resolve(mapped.getParent().getFileName());
        Files.createDirectories(linkedCache);
        Files.createSymbolicLink(linkedCache.resolve(mapped.getFileName()), mapped);
        try {
            GameMappings.prepare(original, symlinkOutputGame, libraries);
            throw new AssertionError("Symlink cache output accepted");
        } catch (IOException expected) {
            if (!expected.getMessage().contains("symbolic link")) throw expected;
            if (!expectedHash.equals(GameMappings.sha256(mapped))) throw new AssertionError("Symlink target modified");
            System.out.println("PASS cache output symbolic link rejected without changing target");
        }
        Path fake = root.resolve("unverified-client-fixture.jar");
        Files.writeString(fake, "unverified fixture");
        try {
            GameMappings.prepare(fake, root.resolve("unverified-game"), libraries);
            throw new AssertionError("Unknown original game accepted");
        } catch (LoaderException expected) {
            if (!expected.diagnostics().getFirst().code().equals("GAME_HASH_MISMATCH")) throw expected;
            if (Files.exists(root.resolve("unverified-game"))) throw new AssertionError("Created cache for unknown game");
            System.out.println("PASS unknown original game hash rejected before cache creation");
        } finally { Files.deleteIfExists(fake); }
    }
}
