package dev.n9ezz.smoke;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicLong;

/** Optional diagnostic mod. It observes vanilla/Fabric events; no Pulse init calls. */
public final class WorldProbe implements N9ModInitializer {
    private final AtomicLong serverTicks = new AtomicLong();
    private final AtomicLong renderStarts = new AtomicLong();
    private final AtomicLong renderEnds = new AtomicLong();
    private final AtomicLong renderOrderingFailures = new AtomicLong();
    private volatile boolean serverStarted;
    private volatile boolean joined;
    private long clientTicks;
    private long worldTicks;
    private boolean demoRequested;
    private boolean worldObserved;

    @Override public void onInitialize(ModContext context) throws Exception {
        ClassLoader loader = getClass().getClassLoader();
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents", "SERVER_STARTING", "ServerStarting",
            args -> log("serverStarting=true serverLoader=" + args[0].getClass().getClassLoader()));
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents", "SERVER_STARTED", "ServerStarted",
            args -> { serverStarted = true; log("serverStarted=true serverLoader=" + args[0].getClass().getClassLoader()); });
        register(loader, "net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents", "END_SERVER_TICK", "EndTick",
            args -> { long tick = serverTicks.incrementAndGet(); if (tick == 1 || tick == 20 || tick == 100) log("serverTicks=" + tick); });
        register(loader, "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents", "INIT", "Init",
            args -> log("networkInit=true handlerLoader=" + args[0].getClass().getClassLoader()));
        register(loader, "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents", "JOIN", "Join",
            args -> { joined = true; log("networkJoin=true handlerLoader=" + args[0].getClass().getClassLoader()); });
        register(loader, "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents", "DISCONNECT", "Disconnect",
            args -> log("networkDisconnect=true"));
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientWorldEvents", "AFTER_CLIENT_WORLD_CHANGE", "AfterClientWorldChange",
            args -> log("clientWorldChange=true worldLoader=" + args[1].getClass().getClassLoader()));
        String renderApi = "net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents";
        register(loader, renderApi, "START_MAIN", "StartMain", args -> {
            if (renderStarts.get() != renderEnds.get()) renderOrderingFailures.incrementAndGet();
            renderStarts.incrementAndGet();
        });
        register(loader, renderApi, "END_MAIN", "EndMain", args -> {
            long frames = renderEnds.incrementAndGet();
            if (renderStarts.get() != frames) renderOrderingFailures.incrementAndGet();
            if (frames == 1 || frames == 20 || frames == 100) log("renderFrames=" + frames + " renderStarts="
                + renderStarts.get() + " renderOrderingFailures=" + renderOrderingFailures.get());
        });
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents", "END_CLIENT_TICK", "EndTick", args -> {
            Object client = args[0];
            clientTicks++;
            Object world = client.getClass().getField("field_1687").get(client);
            Object player = client.getClass().getField("field_1724").get(client);
            if (world != null && player != null) {
                worldTicks++;
                if (!worldObserved || worldTicks == 20 || worldTicks == 100 || worldTicks % 500 == 0) {
                    worldObserved = true;
                    log("world=true player=true worldTicks=" + worldTicks + " clientTicks=" + clientTicks
                        + " serverStarted=" + serverStarted + " serverTicks=" + serverTicks.get()
                        + " joined=" + joined + " renderFrames=" + renderEnds.get()
                        + " renderOrderingFailures=" + renderOrderingFailures.get()
                        + " worldLoader=" + world.getClass().getClassLoader() + " playerLoader=" + player.getClass().getClassLoader());
                }
            }
            if (!demoRequested && Boolean.getBoolean("n9ezz.smoke.demoWorld") && clientTicks >= 100 && world == null) {
                Object screen = client.getClass().getField("field_1755").get(client);
                if (screen != null && screen.getClass().getName().equals("pulse.gui.menu.PulseMainMenuScreen")) {
                    demoRequested = true;
                    launchDemo(loader, client);
                }
            }
        });
        log("registered=true demoWorldAutomation=" + Boolean.getBoolean("n9ezz.smoke.demoWorld") + " loader=" + loader);
    }

    private static void launchDemo(ClassLoader loader, Object client) throws Exception {
        // Invoke the exact 1.21.11 vanilla Play Demo button handler. This drives
        // IntegratedWorldLoader normally, including worldgen/server/networking.
        // Neither world/player nor client addon initialization flags are assigned.
        Class<?> titleType = Class.forName("net.minecraft.class_442", true, loader);
        Object title = titleType.getConstructor().newInstance();
        Class<?> screenType = Class.forName("net.minecraft.class_437", false, loader);
        Field minecraft = screenType.getDeclaredField("field_22787");
        minecraft.setAccessible(true);
        minecraft.set(title, client);
        Method hasWorld = titleType.getDeclaredMethod("method_31129");
        hasWorld.setAccessible(true);
        boolean existing = (boolean) hasWorld.invoke(title);
        Method play = titleType.getDeclaredMethod("method_19858", boolean.class, Class.forName("net.minecraft.class_4185", false, loader));
        play.setAccessible(true);
        log("demoWorldRequested=true existing=" + existing + " mechanism=vanilla_Play_Demo_handler");
        play.invoke(title, existing, null);
    }

    @FunctionalInterface private interface Listener { void call(Object[] args) throws Exception; }
    private static void register(ClassLoader loader, String owner, String eventName, String callbackName, Listener callback) throws Exception {
        Class<?> api = Class.forName(owner, true, loader);
        Class<?> callbackType = Class.forName(owner + "$" + callbackName, true, loader);
        Object event = api.getField(eventName).get(null);
        Object proxy = Proxy.newProxyInstance(loader, new Class<?>[]{callbackType}, (instance, method, args) -> {
            if (method.getDeclaringClass() == Object.class) return switch (method.getName()) {
                case "toString" -> "N9Ezz world smoke listener " + eventName;
                case "hashCode" -> System.identityHashCode(instance);
                case "equals" -> instance == args[0];
                default -> null;
            };
            callback.call(args);
            return null;
        });
        Class.forName("net.fabricmc.fabric.api.event.Event", false, loader).getMethod("register", Object.class).invoke(event, proxy);
    }
    private static void log(String text) {
        System.out.println("N9EZZ_WORLD_PROBE " + text + " thread=" + Thread.currentThread().getName());
    }
}
