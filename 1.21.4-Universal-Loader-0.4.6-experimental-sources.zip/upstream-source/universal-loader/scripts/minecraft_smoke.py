#!/usr/bin/env python3
"""Fetch checksum-verified official Minecraft 1.21.11 inputs and run local demo smoke.

No account is authenticated. The token 0 is an explicitly offline/demo placeholder.
Rendering prerequisites such as Xvfb are supplied by the host, not installed here.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import urllib.request
import zipfile

VERSION = "1.21.11"
VERSION_SHA1 = "6827f8e998ee6add1b3acff9286b6c95ebeebdc1"
VERSION_URL = f"https://piston-meta.mojang.com/v1/packages/{VERSION_SHA1}/{VERSION}.json"
MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"


def digest(path, algorithm="sha1"):
    result = hashlib.new(algorithm)
    with path.open("rb") as source:
        for data in iter(lambda: source.read(131072), b""):
            result.update(data)
    return result.hexdigest()


def fetch(url, output, expected=None, size=None):
    output.parent.mkdir(parents=True, exist_ok=True)
    if expected and output.is_file() and (size is None or output.stat().st_size == size) and digest(output) == expected:
        return output
    temporary = output.with_name(output.name + ".download")
    checksum = hashlib.sha1()
    received = 0
    try:
        # Standard urllib preserves inherited managed proxy and verified CA trust.
        with urllib.request.urlopen(url, timeout=60) as response, temporary.open("wb") as target:
            for data in iter(lambda: response.read(131072), b""):
                received += len(data)
                if received > (size if size is not None else 16 * 1024 * 1024):
                    raise RuntimeError("Download exceeds declared limit: " + url)
                checksum.update(data)
                target.write(data)
        if size is not None and received != size:
            raise RuntimeError("Download size mismatch: " + url)
        if expected and checksum.hexdigest() != expected:
            raise RuntimeError("Official SHA-1 mismatch: " + url)
        temporary.replace(output)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return output


def linux_library(library):
    rules = library.get("rules")
    if not rules:
        return True
    permitted = False
    for rule in rules:
        os_rule = rule.get("os", {})
        matches = os_rule.get("name", "linux") == "linux"
        if "arch" in os_rule:
            matches = matches and os_rule["arch"] in (platform.machine(), "amd64")
        if "version" in os_rule or rule.get("features"):
            raise RuntimeError("Unsupported launcher rule; review explicitly: " + str(rule))
        if matches:
            permitted = rule["action"] == "allow"
    return permitted


def prepare(root, workers):
    root.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(fetch(MANIFEST_URL, root / "version_manifest_v2.json").read_text())
    selected = next(item for item in manifest["versions"] if item["id"] == VERSION)
    if selected["sha1"] != VERSION_SHA1 or selected["url"] != VERSION_URL:
        raise RuntimeError("Published metadata changed from pinned smoke version; review before updating pin")
    version = json.loads(fetch(VERSION_URL, root / f"{VERSION}.json", VERSION_SHA1).read_text())
    if version["javaVersion"]["majorVersion"] != 21:
        raise RuntimeError("Pinned Minecraft metadata does not require Java 21")
    client = version["downloads"]["client"]
    client_path = fetch(client["url"], root / "client.jar", client["sha1"], client["size"])
    libraries = []
    tasks = []
    for library in version["libraries"]:
        if not linux_library(library):
            continue
        artifact = library["downloads"]["artifact"]
        path = root / "libraries" / artifact["path"]
        libraries.append(path)
        tasks.append((artifact["url"], path, artifact["sha1"], artifact["size"]))
    asset = version["assetIndex"]
    asset_path = fetch(asset["url"], root / "assets" / "indexes" / (asset["id"] + ".json"), asset["sha1"], asset["size"])
    objects = json.loads(asset_path.read_text())["objects"]
    unique = {record["hash"]: record["size"] for record in objects.values()}
    for checksum, size in unique.items():
        tasks.append((f"https://resources.download.minecraft.net/{checksum[:2]}/{checksum}",
                      root / "assets" / "objects" / checksum[:2] / checksum, checksum, size))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        pending = [pool.submit(fetch, *task) for task in tasks]
        completed = 0
        for future in as_completed(pending):
            future.result()
            completed += 1
            if completed % 250 == 0 or completed == len(tasks):
                print(f"VERIFIED {completed}/{len(tasks)} official artifacts", flush=True)
    natives = root / "natives"
    natives.mkdir(exist_ok=True)
    for library in libraries:
        if "natives-linux" not in library.name:
            continue
        with zipfile.ZipFile(library) as jar:
            for name in jar.namelist():
                if not name.endswith(".so"):
                    continue
                output = natives / Path(name).name
                data = jar.read(name)
                if output.exists() and output.read_bytes() != data:
                    raise RuntimeError("Conflicting native library basename: " + output.name)
                output.write_bytes(data)
    state = {"version": VERSION, "version_json_sha1": VERSION_SHA1,
             "client": {**client, "path": str(client_path)}, "asset_index": asset,
             "asset_objects": len(unique), "asset_bytes": sum(unique.values()),
             "libraries": [str(path) for path in libraries], "natives": str(natives),
             "verification": "TLS verified; official metadata SHA-1 and size verified for every artifact"}
    (root / "prepared.json").write_text(json.dumps(state, indent=2) + "\n")
    print("PREPARED", root, flush=True)
    return state


def command(root, loader, java, state):
    game = root / "game"
    (game / "mods").mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(loader) as jar:
        demo = jar.read("examples/native-smoke-mod.jar")
    (game / "mods" / "n9ezz-smoke.jar").write_bytes(demo)
    classpath = os.pathsep.join([str(loader), *state["libraries"], state["client"]["path"]])
    natives = state["natives"]
    return [str(java), "-Xms512m", "-Xmx3g",
            # Deny game HTTP authentication/telemetry locally for offline smoke.
            "-Dhttp.proxyHost=127.0.0.1", "-Dhttp.proxyPort=9", "-Dhttps.proxyHost=127.0.0.1", "-Dhttps.proxyPort=9",
            "-Djava.library.path=" + natives,
            "-Djna.tmpdir=" + natives, "-Dorg.lwjgl.system.SharedLibraryExtractPath=" + natives,
            "-Dio.netty.native.workdir=" + natives, "-Dminecraft.launcher.brand=N9Ezz-dev-smoke",
            "-Dminecraft.launcher.version=0.2.0-experimental", "-cp", classpath,
            "dev.n9ezz.loader.launch.GameBootstrap", "--username", "N9EzzDevSmoke", "--version", VERSION,
            "--gameDir", str(game), "--assetsDir", str(root / "assets"), "--assetIndex", state["asset_index"]["id"],
            "--uuid", "00000000-0000-0000-0000-000000000000", "--accessToken", "0", "--userType", "legacy",
            "--versionType", "release", "--demo", "--width", "1280", "--height", "720"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["prepare", "launch", "command"])
    parser.add_argument("--root", type=Path, default=Path("/workspace/minecraft-smoke"))
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--loader", type=Path, default=Path(__file__).resolve().parents[1] / "dist/N9Ezz-Universal-Loader-0.2.0-experimental.jar")
    parser.add_argument("--java", type=Path, default=Path("/workspace/toolchains/jdk-21.0.8+9/bin/java"))
    args = parser.parse_args()
    if args.operation == "prepare":
        prepare(args.root, args.workers)
        return
    state = json.loads((args.root / "prepared.json").read_text())
    argv = command(args.root, args.loader.resolve(), args.java, state)
    (args.root / "launch-command.json").write_text(json.dumps(argv, indent=2) + "\n")
    if args.operation == "command":
        print(json.dumps(argv, indent=2))
        return
    # stdout/stderr are retained by the caller; no login/account setup occurs.
    print("OFFLINE_DEMO_SMOKE no account authentication; accessToken=0 placeholder", flush=True)
    raise SystemExit(subprocess.call(argv, cwd=args.root / "game"))


if __name__ == "__main__":
    main()
