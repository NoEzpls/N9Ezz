#!/usr/bin/env python3
"""Probe a real installed profile; today's bundled client must fail before game main."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--installer", type=Path, required=True)
    parser.add_argument("--prepared-game", type=Path, required=True,
                        help="Verified smoke directory containing prepared.json and 1.21.11.json")
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    installer = args.installer.resolve()
    prepared = json.loads((args.prepared_game / "prepared.json").read_text())
    assert prepared["version"] == "1.21.11"
    gamejar = Path(prepared["client"]["path"])
    assert hashlib.sha1(gamejar.read_bytes()).hexdigest() == prepared["client"]["sha1"]
    with tempfile.TemporaryDirectory(prefix="n9ezz-installed-profile-") as temporary:
        home = Path(temporary)
        vanilla = home / "versions/1.21.11"
        vanilla.mkdir(parents=True)
        shutil.copyfile(args.prepared_game / "1.21.11.json", vanilla / "1.21.11.json")
        shutil.copyfile(gamejar, vanilla / "1.21.11.jar")
        installed = subprocess.run(["java", "-jar", str(installer), "--install", "--game-dir", str(home)],
                                   capture_output=True, text=True, timeout=30)
        assert installed.returncode == 0, installed.stderr
        report = json.loads(installed.stdout)
        profile = json.loads((home / "versions/N9Ezz-Universal-1.21.11/N9Ezz-Universal-1.21.11.json").read_text())
        assert profile["mainClass"] == "dev.n9ezz.loader.launch.GameBootstrap"
        assert report["clientBundled"] and not report["clientRunnableInUniversalCore"]
        library = home / "libraries/dev/n9ezz/universal-loader/0.2.0-experimental/universal-loader-0.2.0-experimental.jar"
        assert hashlib.sha256(library.read_bytes()).hexdigest() == hashlib.sha256(installer.read_bytes()).hexdigest()
        classpath = os.pathsep.join(map(str, [library, vanilla / "1.21.11.jar", *map(Path, prepared["libraries"])]))
        launched = subprocess.run(["java", "-cp", classpath, profile["mainClass"], "--gameDir", report["instance"]],
                                  capture_output=True, text=True, timeout=30)
        evidence = installed.stdout + "\nPROFILE BOOTSTRAP\n" + launched.stdout + launched.stderr
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(evidence)
        assert launched.returncode == 1 and "METADATA_UNSUPPORTED" in launched.stderr, evidence
        assert "builtin-discovery" in launched.stderr and "pulse" in launched.stderr, evidence
        assert list((Path(report["instance"]) / "mods").iterdir()) == []
        print("PASS: official Minecraft 1.21.11 installed profile selects the embedded client")
        print("EXPECTED_FAILURE: unsupported nested JARs rejected before entrypoints/game main; no N9Ezz gameplay claim")
        print("Evidence:", args.report)


if __name__ == "__main__":
    main()
