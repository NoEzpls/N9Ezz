import com.google.gson.Gson;
import com.google.gson.JsonObject;
import dev.n9ezz.loader.core.TransformationPipeline;
import dev.n9ezz.loader.core.UnifiedClassLoader;
import dev.n9ezz.loader.mapping.GameMappings;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/** Verifies the real official game binary; creates no Minecraft redistribution artifact. */
public final class GameMappingProbe {
    public static void main(String[] arguments) throws Exception {
        Path preparation = Path.of(arguments[0]);
        JsonObject inputs = new Gson().fromJson(Files.readString(preparation), JsonObject.class);
        Path original = Path.of(inputs.getAsJsonObject("client").get("path").getAsString());
        ArrayList<Path> libraries = new ArrayList<>();
        for (var element : inputs.getAsJsonArray("libraries")) libraries.add(Path.of(element.getAsString()));
        Path gameDir = Path.of(arguments[1]);
        long started = System.nanoTime();
        Path mapped = GameMappings.prepare(original, gameDir, libraries);
        System.out.println("PASS real game remap: " + mapped);
        System.out.println("OUTPUT_SHA256 " + GameMappings.sha256(mapped));
        var timestamp = Files.getLastModifiedTime(mapped);
        Path reused = GameMappings.prepare(original, gameDir, libraries);
        if (!mapped.equals(reused) || !timestamp.equals(Files.getLastModifiedTime(mapped))) throw new AssertionError("Cache was rewritten");
        System.out.println("PASS validated cache reused without rewrite");
        URL[] urls = new URL[libraries.size()];
        for (int i = 0; i < urls.length; i++) urls[i] = libraries.get(i).toUri().toURL();
        TransformationPipeline pipeline = new TransformationPipeline(); pipeline.freeze();
        try (URLClassLoader dependencies = new URLClassLoader(urls, GameMappingProbe.class.getClassLoader());
                UnifiedClassLoader unified = new UnifiedClassLoader(java.util.List.of(), mapped, dependencies, pipeline)) {
            Class<?> client = Class.forName("net.minecraft.class_310", false, unified);
            Class<?> player = client.getDeclaredField("field_1724").getType();
            if (!player.getName().equals("net.minecraft.class_746") || player.getClassLoader() != unified) throw new AssertionError("Player type/loader mismatch");
            if (client.getDeclaredMethod("method_1551").getReturnType() != client) throw new AssertionError("Singleton return descriptor mismatch");
            Class<?> main = Class.forName("net.minecraft.client.main.Main", false, unified);
            main.getDeclaredMethod("main", String[].class);
            if (main.getClassLoader() != unified || client.getClassLoader() != unified) throw new AssertionError("Common loader ownership mismatch");
            System.out.println("PASS actual MinecraftClient class, player field, singleton method and Main defined by one UnifiedClassLoader");
        }
        System.out.println("ELAPSED_MS " + ((System.nanoTime() - started) / 1_000_000));
    }
}
