package dev.n9ezz.smoke;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import dev.n9ezz.loader.core.LifecycleEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

/** Diagnostic mod used only by the offline game smoke; never calls client init. */
public final class GameplayProbe implements N9ModInitializer {
    private final List<String> lifecycle = new ArrayList<>();
    private long starts;
    private long ends;
    private long orderingFailures;
    private boolean clientStarted;

    @Override public void onInitialize(ModContext context) throws Exception {
        ClassLoader loader = getClass().getClassLoader();
        for (LifecycleEvent event : LifecycleEvent.values()) {
            context.events().on(event, Integer.MIN_VALUE, fired -> {
                lifecycle.add(fired.name());
                System.out.println("N9EZZ_GAMEPLAY_PROBE lifecycle=" + fired + " thread=" + Thread.currentThread().getName());
            });
        }
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents",
            "CLIENT_STARTED", "ClientStarted", args -> {
                clientStarted = true;
                System.out.println("N9EZZ_GAMEPLAY_PROBE clientStarted=true clientLoader=" + args[0].getClass().getClassLoader());
            });
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents",
            "START_CLIENT_TICK", "StartTick", args -> {
                if (starts != ends) orderingFailures++;
                starts++;
            });
        register(loader, "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents",
            "END_CLIENT_TICK", "EndTick", args -> {
                ends++;
                if (starts != ends) orderingFailures++;
                if (ends == 1 || ends == 20 || ends == 100 || ends % 1000 == 0) inspect(loader, args[0]);
            });
        System.out.println("N9EZZ_GAMEPLAY_PROBE registered=true loader=" + loader);
    }

    @FunctionalInterface private interface Listener { void call(Object[] args) throws Exception; }

    private static void register(ClassLoader loader, String owner, String eventName, String callbackName, Listener callback) throws Exception {
        Class<?> api = Class.forName(owner, true, loader);
        Class<?> callbackType = Class.forName(owner + "$" + callbackName, true, loader);
        Object event = api.getField(eventName).get(null);
        Object proxy = Proxy.newProxyInstance(loader, new Class<?>[]{callbackType}, (instance, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                return switch (method.getName()) {
                    case "toString" -> "N9Ezz gameplay smoke listener " + eventName;
                    case "hashCode" -> System.identityHashCode(instance);
                    case "equals" -> instance == args[0];
                    default -> null;
                };
            }
            callback.call(args);
            return null;
        });
        Class.forName("net.fabricmc.fabric.api.event.Event", false, loader).getMethod("register", Object.class).invoke(event, proxy);
    }

    private void inspect(ClassLoader loader, Object client) throws Exception {
        Class<?> n9ezz = Class.forName("pulse.n9ezz.N9Ezz", false, loader);
        // The pinned compiled addon renames this private source field to f0.
        // Observe it directly; never call modules() to manufacture initialization.
        Field initialized = n9ezz.getDeclaredField("f0");
        initialized.setAccessible(true);
        int modules = 0;
        for (Field field : n9ezz.getDeclaredFields()) {
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())
                && field.getType().getName().startsWith("pulse.n9ezz.") && field.get(null) != null) modules++;
        }
        Object aura = n9ezz.getField("AURA").get(null);
        Object trigger = n9ezz.getField("TRIGGER").get(null);
        Object hitboxes = n9ezz.getField("HITBOXES").get(null);
        Class<?> pulse = Class.forName("ru.pulse.Pulse", false, loader);
        Object instance = pulse.getMethod("getInstance").invoke(null);
        Field pulseInit = pulse.getDeclaredField("init");
        pulseInit.setAccessible(true);
        boolean pulseInitialized = pulseInit.getBoolean(instance);
        int registryCount = -1;
        boolean registryContainsAura = false;
        boolean registryContainsTrigger = false;
        boolean registryContainsHitboxes = false;
        if (pulseInitialized) {
            // Pulse.init() already ran ModuleRegistry.init(); observe its list now.
            Class<?> registry = Class.forName("pulse.module.ModuleRegistry", false, loader);
            Field registered = registry.getDeclaredField("MODULES");
            registered.setAccessible(true);
            List<?> entries = (List<?>) registered.get(null);
            registryCount = entries.size();
            registryContainsAura = aura != null && entries.contains(aura);
            registryContainsTrigger = trigger != null && entries.contains(trigger);
            registryContainsHitboxes = hitboxes != null && entries.contains(hitboxes);
        }
        System.out.println("N9EZZ_GAMEPLAY_PROBE ticks=" + ends + " starts=" + starts
            + " orderingFailures=" + orderingFailures + " clientStarted=" + clientStarted
            + " initialized=" + initialized.getBoolean(null) + " pulseInit=" + pulseInitialized
            + " moduleFields=" + modules + " aura=" + (aura != null) + " trigger=" + (trigger != null)
            + " hitboxes=" + (hitboxes != null) + " registryCount=" + registryCount
            + " registeredAura=" + registryContainsAura + " registeredTrigger=" + registryContainsTrigger
            + " registeredHitboxes=" + registryContainsHitboxes
            + " world=" + (client.getClass().getField("field_1687").get(client) != null)
            + " player=" + (client.getClass().getField("field_1724").get(client) != null)
            + " screen=" + screenName(client) + " clientLoader=" + client.getClass().getClassLoader()
            + " n9ezzLoader=" + n9ezz.getClassLoader() + " thread=" + Thread.currentThread().getName());
    }

    private static String screenName(Object client) throws Exception {
        Object screen = client.getClass().getField("field_1755").get(client);
        return screen == null ? "none" : screen.getClass().getName();
    }
}
