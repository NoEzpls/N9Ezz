#!/usr/bin/env python3
"""Send one real mouse click or key press to the isolated Xvfb smoke display."""
import argparse
import ctypes as c
import ctypes.util
import os
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--display", default=":99")
    parser.add_argument("--xauthority", default="/workspace/minecraft-smoke/host/Xauthority")
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument("--click", nargs=2, type=int, metavar=("X", "Y"))
    actions.add_argument("--key", help="X11 keysym such as Return, Escape, or space")
    args = parser.parse_args()
    os.environ["XAUTHORITY"] = args.xauthority
    x11 = c.CDLL(ctypes.util.find_library("X11"))
    xtst = c.CDLL(ctypes.util.find_library("Xtst"))
    x11.XOpenDisplay.argtypes, x11.XOpenDisplay.restype = [c.c_char_p], c.c_void_p
    x11.XFlush.argtypes = [c.c_void_p]
    x11.XCloseDisplay.argtypes = [c.c_void_p]
    x11.XStringToKeysym.argtypes, x11.XStringToKeysym.restype = [c.c_char_p], c.c_ulong
    x11.XKeysymToKeycode.argtypes, x11.XKeysymToKeycode.restype = [c.c_void_p, c.c_ulong], c.c_uint
    xtst.XTestFakeMotionEvent.argtypes = [c.c_void_p, c.c_int, c.c_int, c.c_int, c.c_ulong]
    xtst.XTestFakeButtonEvent.argtypes = [c.c_void_p, c.c_uint, c.c_int, c.c_ulong]
    xtst.XTestFakeKeyEvent.argtypes = [c.c_void_p, c.c_uint, c.c_int, c.c_ulong]
    display = x11.XOpenDisplay(args.display.encode())
    if not display:
        raise SystemExit("Cannot open smoke display " + args.display)
    try:
        if args.click:
            x, y = args.click
            xtst.XTestFakeMotionEvent(display, -1, x, y, 0)
            x11.XFlush(display)
            time.sleep(0.08)
            xtst.XTestFakeButtonEvent(display, 1, 1, 0)
            x11.XFlush(display)
            time.sleep(0.08)
            xtst.XTestFakeButtonEvent(display, 1, 0, 0)
        else:
            keysym = x11.XStringToKeysym(args.key.encode())
            keycode = x11.XKeysymToKeycode(display, keysym)
            if not keycode:
                raise SystemExit("Unknown or unmapped X11 key " + args.key)
            xtst.XTestFakeKeyEvent(display, keycode, 1, 0)
            x11.XFlush(display)
            time.sleep(0.08)
            xtst.XTestFakeKeyEvent(display, keycode, 0, 0)
        x11.XFlush(display)
    finally:
        x11.XCloseDisplay(display)
    print("X11_INPUT sent=" + ("click " + " ".join(map(str, args.click)) if args.click else "key " + args.key))


if __name__ == "__main__":
    main()
