#!/usr/bin/env python3
"""Disposable launcher metadata tests; these do not launch Minecraft."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile

JAR = Path(sys.argv[1]).resolve()
with zipfile.ZipFile(JAR) as packaged:
    main_manifest = packaged.read("META-INF/MANIFEST.MF").decode("utf-8").replace("\r\n", "\n").split("\n\n", 1)[0]
    manifest_attributes = dict(line.split(": ", 1) for line in main_manifest.splitlines() if ": " in line)
    RELEASE_VERSION = manifest_attributes["Implementation-Version"]
PROFILE = "N9Ezz-Universal-1.21.11"
CLIENT_SHA256 = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424"
CLIENT_SIZE = 41_062_124
CLIENT_RESOURCE = "embedded/n9ezz-client-1.5.3.jar"
passed = 0


def invoke(home, success):
    result = subprocess.run(["java", "-jar", str(JAR), "--install", "--game-dir", str(home)],
                            capture_output=True, text=True)
    if (result.returncode == 0) != success:
        raise AssertionError(result.stdout + result.stderr)
    return result


def case(name):
    global passed
    passed += 1
    print("PASS", name)


def base(home):
    home.mkdir()
    version = home / "versions/1.21.11"
    version.mkdir(parents=True)
    (version / "1.21.11.json").write_text(json.dumps({
        "id": "1.21.11", "javaVersion": {"majorVersion": 21, "component": "java-runtime-delta"}}))
    with zipfile.ZipFile(version / "1.21.11.jar", "w") as archive:
        archive.writestr("INSTALLER_TEST_ONLY.txt", "No Minecraft code. Metadata fixture only.")


with tempfile.TemporaryDirectory(prefix="n9ezz-installer-tests-") as temporary:
    root = Path(temporary)
    missing = root / "missing"
    missing.mkdir()
    failure = invoke(missing, False)
    assert "BASE_VERSION_MISSING" in failure.stderr and list(missing.iterdir()) == []
    case("missing vanilla version fails without modifying files")

    home = root / "minecraft"
    base(home)
    original_profile = {"name": "N9Ezz 0.1.0", "lastVersionId": "n9ezz-fabric-1.21.11-0.1.0", "custom": 17}
    original = {"profiles": {"old-working": original_profile}, "settings": {"keep": True}, "custom": [1, 2]}
    profiles_path = home / "launcher_profiles.json"
    profiles_bytes = json.dumps(original).encode()
    profiles_path.write_bytes(profiles_bytes)
    old_jar = home / "versions/old-working/old.jar"
    old_jar.parent.mkdir()
    old_jar.write_bytes(b"untouched previous working installation")
    first = invoke(home, True)
    report = json.loads(first.stdout)
    assert report["profile"] == PROFILE and report["clientBundled"] is True
    assert report["clientSha256"] == CLIENT_SHA256
    assert report["clientSize"] == CLIENT_SIZE
    assert report["clientRunnableInUniversalCore"] is True
    assert report["clientExecutionStatus"].startswith("pinned-client:")
    assert report["realMinecraftLaunchVerified"] is False
    assert "validated separately" in report["verificationScope"]
    with zipfile.ZipFile(JAR) as installer:
        embedded = installer.read(CLIENT_RESOURCE)
        embedded_manifest = json.loads(installer.read("META-INF/n9ezz/embedded-client.json"))
    assert hashlib.sha256(embedded).hexdigest() == CLIENT_SHA256
    assert embedded_manifest["sha256"] == CLIENT_SHA256 and embedded_manifest["size"] == len(embedded)
    assert embedded_manifest["version"] == "1.5.3-n9ezz"
    assert embedded_manifest["baseSha256"] == "2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb"
    assert embedded_manifest["overlaySha256"] == "80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206"
    installed_client = home / "n9ezz-universal/.n9ezz/builtin" / (CLIENT_SHA256 + ".jar")
    assert installed_client.is_file() and hashlib.sha256(installed_client.read_bytes()).hexdigest() == CLIENT_SHA256
    assert report["clientPath"] == str(installed_client)
    assert report["clientSource"] == "built-in runtime module; no separate mod installation"
    assert list((home / "n9ezz-universal/mods").iterdir()) == []
    profiles = json.loads(profiles_path.read_text())
    assert profiles["profiles"]["old-working"] == original_profile
    assert profiles["settings"] == original["settings"] and profiles["custom"] == original["custom"]
    assert len(profiles["profiles"]) == 2
    assert old_jar.read_bytes() == b"untouched previous working installation"
    case("one experimental profile installed and old profile/files preserved")
    installed = home / f"libraries/dev/n9ezz/universal-loader/{RELEASE_VERSION}/universal-loader-{RELEASE_VERSION}.jar"
    assert hashlib.sha256(installed.read_bytes()).digest() == hashlib.sha256(JAR.read_bytes()).digest()
    version = json.loads((home / f"versions/{PROFILE}/{PROFILE}.json").read_text())
    assert version["mainClass"] == "dev.n9ezz.loader.launch.GameBootstrap"
    assert version["inheritsFrom"] == "1.21.11" and version["javaVersion"]["majorVersion"] == 21
    assert len(version["libraries"]) == 1 and "fabric" not in json.dumps(version).lower()
    assert version["libraries"][0]["name"] == f"dev.n9ezz:universal-loader:{RELEASE_VERSION}"
    assert "neoforge" not in json.dumps(version).lower() and "forge" not in json.dumps(version).lower()
    case("installed library checksum and one-core profile verified")
    backups = list((home / ".n9ezz-backups").rglob("launcher_profiles.json"))
    assert len(backups) == 1 and backups[0].read_bytes() == profiles_bytes
    case("exact previous launcher metadata backed up")
    before = {p.relative_to(home).as_posix(): p.read_bytes() for p in home.rglob("*") if p.is_file()}
    second = json.loads(invoke(home, True).stdout)
    assert second["clientInstallStatus"] == "already-present"
    after = {p.relative_to(home).as_posix(): p.read_bytes() for p in home.rglob("*") if p.is_file()}
    assert before == after
    case("repeat installation leaves all file bytes unchanged")
    profiles_path.write_bytes(b"{not json}")
    library_before = installed.read_bytes()
    invoke(home, False)
    assert profiles_path.read_bytes() == b"{not json}" and installed.read_bytes() == library_before
    case("malformed launcher metadata preserved and installation rejected")

    collision = root / "client-collision"
    base(collision)
    collision_cache = collision / "n9ezz-universal/.n9ezz/builtin"
    collision_cache.mkdir(parents=True)
    unmanaged_client = collision_cache / (CLIENT_SHA256 + ".jar")
    unmanaged_client.write_bytes(b"modified cache that must be preserved")
    collision_result = invoke(collision, False)
    assert "BUILTIN_CACHE_MISMATCH" in collision_result.stderr
    assert unmanaged_client.read_bytes() == b"modified cache that must be preserved"
    assert not (collision / "launcher_profiles.json").exists()
    assert not (collision / "libraries").exists()
    case("altered builtin client cache is preserved and rejected before launcher changes")

    fresh = root / "fresh"
    base(fresh)
    invoke(fresh, True)
    assert len(json.loads((fresh / "launcher_profiles.json").read_text())["profiles"]) == 1
    case("missing launcher metadata creates exactly one profile")

    foreign_profile = root / "foreign-profile"
    base(foreign_profile)
    foreign = json.dumps({"profiles": {PROFILE: {"name": "User profile"}}}).encode()
    (foreign_profile / "launcher_profiles.json").write_bytes(foreign)
    invoke(foreign_profile, False)
    assert (foreign_profile / "launcher_profiles.json").read_bytes() == foreign
    assert not (foreign_profile / "libraries").exists()
    case("foreign profile with same id is preserved")

    symlink = root / "symlink"
    base(symlink)
    outside = root / "external.json"
    outside.write_bytes(b"{\"profiles\":{}}")
    (symlink / "launcher_profiles.json").symlink_to(outside)
    invoke(symlink, False)
    assert outside.read_bytes() == b"{\"profiles\":{}}"
    case("symlink target preserved on rejected install")

    verification = subprocess.run(["java", "-jar", str(JAR), "--verify-bundled", "--game-dir", str(root / "bundled-check")],
                                  capture_output=True, text=True)
    assert verification.returncode != 0 and "METADATA_UNSUPPORTED" in verification.stderr
    assert "builtin-discovery" in verification.stderr and "pulse" in verification.stderr
    assert "Native smoke mod initialized" not in verification.stdout
    assert list((root / "bundled-check/mods").iterdir()) == []
    case("builtin N9Ezz is discovered without mods and honestly rejected before entrypoints")

print(f"Installer metadata tests: {passed} passed, 0 failed. Real Minecraft launch: UNRUN.")
