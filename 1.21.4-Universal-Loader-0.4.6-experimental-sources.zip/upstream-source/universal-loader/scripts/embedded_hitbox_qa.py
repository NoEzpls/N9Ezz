#!/usr/bin/env python3
"""Run existing geometry assertions against the exact embedded client bytecode.

This Java 21 computation suite does not launch Minecraft or invoke client
initializers/modules. Real-game wiring is tested separately by LocalHitboxProbe.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile


CLIENT_SHA256 = "2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424"
CLIENT_ENTRY = "embedded/n9ezz-client-1.5.3.jar"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--loader", type=Path, required=True)
    parser.add_argument("--java", type=Path, default=Path(shutil.which("java") or "java"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[2]
    output = (args.output or project / "universal-loader/build/embedded-hitbox-qa").resolve()
    output.mkdir(parents=True, exist_ok=True)
    java = args.java.resolve()
    javac = java.with_name("javac")
    if not java.is_file() or not javac.is_file():
        parser.error("--java must name the java executable inside a Java 21 JDK containing javac")
    with zipfile.ZipFile(args.loader.resolve()) as loader:
        if loader.getinfo(CLIENT_ENTRY).file_size > 64 * 1024 * 1024:
            raise ValueError("Embedded client exceeds expected size limit")
        client_bytes = loader.read(CLIENT_ENTRY)
    actual = hashlib.sha256(client_bytes).hexdigest()
    if actual != CLIENT_SHA256:
        raise ValueError("Geometry suite is pinned to the corrected client SHA256; got " + actual)
    client = output / "verified-client.jar"
    client.write_bytes(client_bytes)
    classes = output / "test-classes"
    classes.mkdir(parents=True, exist_ok=True)
    test = project / "client/src/test/java/pulse/n9ezz/TargetGeometryTest.java"
    subprocess.run([str(javac), "--release", "21", "-proc:none", "-encoding", "UTF-8",
                    "-cp", str(client), "-d", str(classes), str(test)], check=True)
    run = subprocess.run([str(java), "-ea", "-cp", os.pathsep.join([str(client), str(classes)]),
                          "pulse.n9ezz.TargetGeometryTest"], text=True, capture_output=True, check=False)
    (output / "geometry-test.log").write_text(run.stdout + run.stderr)
    passed = run.returncode == 0 and "PASS: 3036 shared targeting geometry checks" in run.stdout
    report = {"passed": passed, "java_exit_code": run.returncode, "expected_checks": 3036,
              "loader_sha256": hashlib.sha256(args.loader.read_bytes()).hexdigest(),
              "client_sha256": actual,
              "test_source_sha256": hashlib.sha256(test.read_bytes()).hexdigest(),
              "production_geometry_recompiled": False, "client_initializers_called": False,
              "minecraft_launched": False, "network_packets_tested": False,
              "scope": "Existing geometry assertions run against pinned embedded TargetGeometry.class bytecode"}
    (output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(run.stdout, end="")
    if run.stderr:
        print(run.stderr, end="")
    print("EMBEDDED_HITBOX_QA result=" + str(output / "result.json"))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
