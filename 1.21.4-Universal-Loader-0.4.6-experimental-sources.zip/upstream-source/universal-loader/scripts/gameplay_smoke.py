#!/usr/bin/env python3
"""Bounded offline N9Ezz game probe against previously verified Mojang inputs.

The probe observes initialization and real START/END_CLIENT_TICK callbacks; it
never calls Pulse.init()/N9Ezz.modules(). This is a development acceptance tool,
not an installer component. Authentication remains the explicit demo token 0.
"""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import time
import zipfile


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evaluate_acceptance(lines, timed_out):
    probe_lines = [line for line in lines if "N9EZZ_GAMEPLAY_PROBE" in line]
    observations = [dict(re.findall(r"\b([A-Za-z][A-Za-z0-9_]*)=([^ ]+)", line))
                    for line in probe_lines if " ticks=" in line]
    healthy = [state for state in observations
               if int(state.get("ticks", "0")) >= 100
               and state.get("starts") == state.get("ticks")
               and state.get("orderingFailures") == "0"
               and all(state.get(key) == "true" for key in ("clientStarted", "initialized", "pulseInit",
                    "registeredAura", "registeredTrigger", "registeredHitboxes"))
               and state.get("registryCount") == "113"
               and state.get("clientLoader", "").startswith("dev.n9ezz.loader.core.UnifiedClassLoader@")
               and state.get("clientLoader") == state.get("n9ezzLoader")]
    fatal = any("Exception in thread" in line or "Unreported exception thrown!" in line for line in lines)
    return {"client_started": any("clientStarted=true" in line for line in probe_lines),
            "balanced_100_ticks_and_initialized_modules": bool(healthy),
            "no_fatal_exception": not fatal, "alive_at_deadline": timed_out}


def build_probe(loader, java, output):
    source = Path(__file__).parent / "gameplay-probe/GameplayProbe.java"
    classes = output / "probe-classes"
    classes.mkdir(parents=True, exist_ok=True)
    subprocess.run([str(java.with_name("javac")), "--release", "21", "-proc:none", "-encoding", "UTF-8",
                    "-cp", str(loader), "-d", str(classes), str(source)], check=True)
    mod = output / "gameplay-probe.jar"
    metadata = {"schemaVersion": 1, "id": "n9ezz_gameplay_probe", "version": "1.0.0",
                "namespace": "none", "environment": "client",
                "entrypoints": {"common": ["dev.n9ezz.smoke.GameplayProbe"]},
                "depends": {"java": ">=21", "n9ezz": ">=0.2.0", "pulse": "*"}}
    with zipfile.ZipFile(mod, "w", compression=zipfile.ZIP_DEFLATED) as jar:
        for path in sorted(classes.rglob("*.class")):
            jar.write(path, path.relative_to(classes).as_posix())
        jar.writestr("n9ezz.mod.json", json.dumps(metadata, sort_keys=True))
    return mod


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/minecraft-smoke"))
    parser.add_argument("--loader", type=Path, required=True)
    parser.add_argument("--java", type=Path, default=Path("/workspace/toolchains/jdk-21.0.8+9/bin/java"))
    parser.add_argument("--seconds", type=int, default=90)
    parser.add_argument("--name", default="n9ezz-shared-runtime")
    parser.add_argument("--extra-library", action="append", type=Path, default=[])
    args = parser.parse_args()
    if not 5 <= args.seconds <= 600:
        parser.error("--seconds must be between 5 and 600")
    if Path(args.name).name != args.name:
        parser.error("--name must be a single path component")
    root, loader = args.root.resolve(), args.loader.resolve()
    state = json.loads((root / "prepared.json").read_text())
    output = root / args.name
    output.mkdir(parents=True, exist_ok=True)
    game = output / "game"
    (game / "mods").mkdir(parents=True, exist_ok=True)
    options = game / "options.txt"
    if not options.exists():
        # Fresh smoke directories skip the accessibility onboarding modal only.
        options.write_text("onboardAccessibility:false\nguiScale:2\nrenderDistance:2\nsimulationDistance:5\nnarrator:0\n", encoding="utf-8")
    probe = build_probe(loader, args.java, output)
    (game / "mods/gameplay-probe.jar").write_bytes(probe.read_bytes())
    # Local null audio is sufficient to prove lifecycle without an ALSA device.
    env = os.environ.copy()
    env.update(DISPLAY=":99", XAUTHORITY=str(root / "host/Xauthority"),
               LIBGL_ALWAYS_SOFTWARE="1", MESA_SHADER_CACHE_DIR=str(root / "host/mesa-cache"),
               XCURSOR_THEME="breeze_cursors", ALSOFT_DRIVERS="null", XDG_CACHE_HOME=str(root / "host/xdg-cache"))
    Path(env["XDG_CACHE_HOME"]).mkdir(parents=True, exist_ok=True)
    subprocess.run(["xdpyinfo"], env=env, stdout=subprocess.DEVNULL, check=True)
    classpath = os.pathsep.join(map(str, [loader, *args.extra_library, *state["libraries"], state["client"]["path"]]))
    argv = [str(args.java), "-Xms512m", "-Xmx3g",
            "-Dhttp.proxyHost=127.0.0.1", "-Dhttp.proxyPort=9", "-Dhttps.proxyHost=127.0.0.1", "-Dhttps.proxyPort=9",
            "-Djava.library.path=" + state["natives"], "-Djna.tmpdir=" + state["natives"],
            "-Dorg.lwjgl.system.SharedLibraryExtractPath=" + state["natives"],
            "-Dio.netty.native.workdir=" + state["natives"],
            "-Dminecraft.launcher.brand=N9Ezz-offline-gameplay-smoke", "-cp", classpath,
            "dev.n9ezz.loader.launch.GameBootstrap", "--username", "N9EzzDevSmoke", "--version", "1.21.11",
            "--gameDir", str(game), "--assetsDir", str(root / "assets"), "--assetIndex", state["asset_index"]["id"],
            "--uuid", "00000000-0000-0000-0000-000000000000", "--accessToken", "0", "--userType", "legacy",
            "--versionType", "release", "--demo", "--width", "1280", "--height", "720"]
    (output / "command.json").write_text(json.dumps(argv, indent=2) + "\n")
    started = time.monotonic()
    screenshots = []
    with (output / "launch.log").open("wb") as log:
        process = subprocess.Popen(argv, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT)
        (output / "pid").write_text(str(process.pid) + "\n")
        print("OFFLINE_DEMO_SMOKE no account authentication; accessToken=0 placeholder", flush=True)
        print("GAMEPLAY_SMOKE pid=" + str(process.pid) + " output=" + str(output), flush=True)
        next_capture = 15
        while process.poll() is None and time.monotonic() - started < args.seconds:
            elapsed = time.monotonic() - started
            if elapsed >= next_capture:
                shot = output / ("display-%03d.png" % next_capture)
                capture = subprocess.run(["import", "-window", "root", str(shot)], env=env, capture_output=True)
                if capture.returncode == 0:
                    screenshots.append(shot.name)
                    print("SCREENSHOT " + str(shot), flush=True)
                next_capture += 15
            time.sleep(0.5)
        timed_out = process.poll() is None
        if timed_out:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
    lines = (output / "launch.log").read_text(errors="replace").splitlines()
    probe_lines = [line for line in lines if "N9EZZ_GAMEPLAY_PROBE" in line]
    acceptance = evaluate_acceptance(lines, timed_out)
    config = game / "config/pulse/pulse.cfg"
    config_evidence = None
    if config.is_file():
        try:
            modules = json.loads(config.read_text())["modules"]
            config_evidence = {"path": str(config), "sha256": sha256(config), "module_count": len(modules),
                               "combat_entries": {key: key in modules for key in ("Kill Aura", "Triggerbot", "Hitboxes")}}
        except (UnicodeError, json.JSONDecodeError, KeyError, TypeError) as error:
            config_evidence = {"path": str(config), "read_error": str(error)}
    result = {"loader": str(loader), "loader_sha256": sha256(loader), "java": str(args.java),
              "official_client_sha1": state["client"]["sha1"], "demo_authentication": "offline placeholder 0",
              "duration_seconds": round(time.monotonic() - started, 1), "exit_code": process.returncode,
              "terminated_at_deadline": timed_out, "screenshots": screenshots,
              "probe_lines": probe_lines, "probe_registers_callbacks_only": True, "generated_config": config_evidence,
              "acceptance": acceptance, "passed": all(acceptance.values()),
              "interpretation": "Inspect logs/screenshots; PID/screenshot existence alone does not prove N9Ezz gameplay."}
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print("GAMEPLAY_SMOKE result=" + str(output / "result.json"), flush=True)
    for line in probe_lines:
        print(line, flush=True)
    if not all(acceptance.values()):
        raise SystemExit("GAMEPLAY_SMOKE_FAILED " + json.dumps(acceptance, sort_keys=True))


if __name__ == "__main__":
    main()
