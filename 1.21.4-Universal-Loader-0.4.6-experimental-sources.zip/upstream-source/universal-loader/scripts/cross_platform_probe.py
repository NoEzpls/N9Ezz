#!/usr/bin/env python3
"""Opt-in, bounded real-game test of four declared lifecycle compatibility contracts.

Five synthetic mod fixtures enter the ordinary discovery/dependency/classloader
path. They never start a platform loader or manufacture a Minecraft world/player.
Use --build-only to package fixtures without launching, or --replay to inspect
recorded evidence without a second game run. Official ABI archives, when supplied,
precede the own facade on javac's classpath and are hash-recorded in the report.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

MARKER = "N9EZZ_CROSS_PLATFORM_PROBE"
PLATFORMS = ("fabric", "quilt", "forge", "neoforge")
STAMP = (1980, 1, 1, 0, 0, 0)
SOURCE = Path(__file__).resolve().parents[1] / "src/game-test/java/dev/n9ezz/gametest"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(lines):
    return [dict(re.findall(r"\b([A-Za-z][A-Za-z0-9_]*)=([^ ]+)", line))
            for line in lines if MARKER in line]


def evaluate_acceptance(lines, base_passed, min_world_callbacks=1000, min_server_ticks=1000):
    """Strictly evaluate observations; synthetic parser tests cannot prove a game run."""
    observed = records(lines)
    phases = [row for row in observed if row.get("kind") == "phase"]
    samples = [row for row in observed if row.get("kind") == "sample"]
    servers = [row for row in observed if row.get("kind") == "server"]
    milestones = [row for row in observed if row.get("kind") == "milestone"]
    apis = [row for row in observed if row.get("kind") == "api"]
    runtime = [row for row in observed if row.get("kind") == "runtime"]

    def integer(row, key):
        try:
            return int(row.get(key, "-1"))
        except (ValueError, TypeError):
            return -1

    def phase(platform, name):
        return [row for row in phases if row.get("platform") == platform and row.get("phase") == name]

    def before(left, right):
        return len(left) == len(right) == 1 and integer(left[0], "seq") < integer(right[0], "seq")

    complete = all(len(phase(platform, name)) == 1 for platform in PLATFORMS for name in ("common", "client"))
    ordered = complete and all(before(phase(platform, "common"), phase(platform, "client")) for platform in PLATFORMS)
    ordered = ordered and max((integer(row, "seq") for row in phases if row.get("phase") == "common"), default=-1) < min(
        (integer(row, "seq") for row in phases if row.get("phase") == "client"), default=-1)
    singleton = complete and all(bool(phase(platform, "common")[0].get("instance"))
                                and phase(platform, "common")[0].get("instance") == phase(platform, "client")[0].get("instance")
                                for platform in PLATFORMS)
    fml_stages = all(len(phase(platform, name)) == 1 for platform in ("forge", "neoforge")
                     for name in ("construct", "common", "commonWork", "client", "clientWork", "complete"))
    if fml_stages:
        boundaries = [("construct", "common"), ("common", "commonWork"), ("commonWork", "client"),
                      ("client", "clientWork"), ("clientWork", "complete")]
        fml_stages = all(max(integer(phase(platform, a)[0], "seq") for platform in ("forge", "neoforge"))
                         < min(integer(phase(platform, b)[0], "seq") for platform in ("forge", "neoforge"))
                         for a, b in boundaries)
    loaders = {row.get("loader") for row in phases}
    same_loader = len(loaders) == 1 and isinstance(next(iter(loaders), None), str) and next(iter(loaders), "").startswith("dev.n9ezz.loader.core.UnifiedClassLoader@")
    shared = next(iter(loaders), "") if same_loader else ""
    same_loader = same_loader and all(row.get("contextLoader") == shared for row in phases)
    same_loader = same_loader and any(row.get("clientLoader") == shared and row.get("n9ezzLoader") == shared
                                      and row.get("worldLoader") == shared and row.get("playerLoader") == shared for row in samples)
    same_loader = same_loader and any(row.get("serverLoader") == shared for row in servers)
    valid_apis = all(any(row.get("platform") == platform and row.get("identity") == "true"
                        and row.get("paths") == "true" and row.get("sameContainer") == "true" for row in apis)
                     for platform in ("fabric", "quilt", "neoforge"))
    healthy_client = any(integer(row, "clientTicks") >= 100 and row.get("clientTicks") == row.get("clientStarts")
                         and row.get("clientOrderingFailures") == "0" and row.get("clientStarted") == "true" for row in samples)
    healthy_world = any(row.get("world") == row.get("player") == row.get("joined") == row.get("serverStarted") == "true"
                        and integer(row, "worldCallbacks") >= min_world_callbacks for row in samples)
    healthy_server = any(integer(row, "serverTicks") >= min_server_ticks and row.get("serverTicks") == row.get("serverStarts")
                         and row.get("serverOrderingFailures") == "0" for row in servers)
    client_failures = any(integer(row, "clientOrderingFailures") != 0 for row in samples)
    server_failures = any(integer(row, "serverOrderingFailures") != 0 for row in servers)
    event = lambda name: [row for row in milestones if row.get("event") == name]
    lifecycle = before(event("serverStarting"), event("serverStarted")) and before(event("networkInit"), event("networkJoin"))
    lifecycle = lifecycle and before(event("clientStarted"), event("networkJoin"))
    ready = [row for row in runtime if row.get("phase") == "READY"]
    lifecycle = lifecycle and len(ready) == 1 and all(integer(row, "seq") < integer(ready[0], "seq") for row in phases)
    sequence = [integer(row, "seq") for row in observed]
    sequence_valid = bool(sequence) and all(a < b for a, b in zip(sequence, sequence[1:])) and sequence[0] > 0
    continued = len(event("demoContinued")) == 1 and event("demoContinued")[0].get("mechanism") == "vanilla_Continue_Playing_handler"
    fatal = any("Exception in thread" in line or "Unreported exception thrown!" in line for line in lines)
    return {"base_real_game_probe_passed": base_passed is True, "four_platform_common_client": complete,
            "common_before_client": ordered, "entrypoint_singletons": singleton, "fml_deferred_stage_order": fml_stages,
            "shared_mod_game_n9ezz_classloader": same_loader, "supported_loader_queries": valid_apis,
            "client_ticks_balanced": healthy_client and not client_failures,
            "real_world_player_callbacks": healthy_world, "unpaused_server_ticks_balanced": healthy_server and not server_failures,
            "actual_game_lifecycle_order": lifecycle, "vanilla_demo_continue": continued,
            "monotonic_trace_sequence": sequence_valid, "no_fatal_exception": not fatal}


def write_jar(path, classes, class_names, descriptor, metadata):
    entries = {file.relative_to(classes).as_posix(): file.read_bytes()
               for class_name in class_names for file in classes.rglob(class_name + "*.class")}
    if not entries:
        raise RuntimeError("No compiled fixture classes for " + str(class_names))
    entries[descriptor] = metadata.encode("utf-8")
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as jar:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            jar.writestr(info, data, compresslevel=9)


def metadata(platform):
    mod_id = "n9ezz_cross_" + platform
    entry = "dev.n9ezz.gametest." + {"probe": "CrossPlatformMonitor", "fabric": "FabricGameFixture",
        "quilt": "QuiltGameFixture", "forge": "ForgeGameFixture", "neoforge": "NeoForgeGameFixture"}[platform]
    if platform == "probe":
        return "n9ezz.mod.json", json.dumps({"schemaVersion": 1, "id": mod_id, "version": "1.0.0", "namespace": "none",
            "environment": "client", "entrypoints": {"common": [entry]},
            "depends": {"java": ">=21", "n9ezz": ">=0.3.1", "pulse": "*"}}, sort_keys=True)
    if platform == "fabric":
        return "fabric.mod.json", json.dumps({"schemaVersion": 1, "id": mod_id, "version": "1.0.0", "environment": "client",
            "entrypoints": {"main": [entry], "client": [entry]}, "n9ezz": {"namespace": "none"},
            "depends": {"fabricloader": "=0.19.2", "minecraft": "=1.21.11", "n9ezz_cross_probe": "=1.0.0"}}, sort_keys=True)
    if platform == "quilt":
        return "quilt.mod.json", json.dumps({"schema_version": 1, "quilt_loader": {"group": "dev.n9ezz.gametest", "id": mod_id,
            "version": "1.0.0", "intermediate_mappings": "net.fabricmc:intermediary", "metadata": {"name": "Quilt lifecycle fixture"},
            "entrypoints": {"init": [entry], "client_init": [entry]},
            "depends": [{"id": "quilt_loader", "versions": "=0.30.1"}, {"id": "minecraft", "versions": "=1.21.11"},
                        {"id": "n9ezz_cross_probe", "versions": "=1.0.0"}]}, "minecraft": {"environment": "client"},
            "n9ezz": {"namespace": "none", "compatibility": "quilt-lifecycle-v1"}}, sort_keys=True)
    neo = platform == "neoforge"
    descriptor = "META-INF/neoforge.mods.toml" if neo else "META-INF/mods.toml"
    version = "10" if neo else "61"
    required = 'type="required"' if neo else 'mandatory=true'
    return descriptor, ('modLoader="javafml"\nloaderVersion="[' + version + ',)"\nlicense="MIT"\n'
        '[n9ezz]\nnamespace="none"\ncompatibility="fml-lifecycle-v1"\n'
        '[[mods]]\nmodId="' + mod_id + '"\nversion="1.0.0"\ndisplayName="Synthetic ' + platform + ' lifecycle fixture"\n'
        '[[dependencies.' + mod_id + ']]\nmodId="n9ezz_cross_probe"\n' + required + '\nversionRange="[1.0.0]"\nordering="NONE"\nside="CLIENT"\n'
        '[[dependencies.' + mod_id + ']]\nmodId="minecraft"\n' + required + '\nversionRange="[1.21.11]"\nordering="NONE"\nside="CLIENT"\n')


def build_fixtures(loader, java, output, abi, hitbox_geometry=False):
    fixtures = output / "cross-platform-fixtures"
    fixtures.mkdir(parents=True, exist_ok=True)
    built = []
    monitor_classes = None
    for platform in ("probe", *PLATFORMS):
        class_name = {"probe": "CrossPlatformMonitor", "fabric": "FabricGameFixture", "quilt": "QuiltGameFixture",
                      "forge": "ForgeGameFixture", "neoforge": "NeoForgeGameFixture"}[platform]
        classes = fixtures / (platform + "-classes")
        classes.mkdir(parents=True, exist_ok=True)
        official = [path.resolve() for path in abi.get(platform, [])]
        classpath = [*official, *([monitor_classes] if monitor_classes else []), loader]
        sources = [SOURCE / (class_name + ".java")]
        class_names = [class_name]
        if platform == "probe" and hitbox_geometry:
            helper = SOURCE / "LocalHitboxProbe.java"
            if not helper.is_file():
                raise RuntimeError("Optional local geometry fixture source is missing")
            sources.append(helper)
            class_names.append("LocalHitboxProbe")
        command = [str(java.with_name("javac")), "--release", "21", "-proc:none", "-encoding", "UTF-8", "-Xlint:all",
                   "-cp", os.pathsep.join(map(str, classpath)), "-d", str(classes), *map(str, sources)]
        subprocess.run(command, check=True)
        if platform == "probe":
            monitor_classes = classes
        jar = fixtures / ("n9ezz-cross-" + platform + ".jar")
        descriptor, text = metadata(platform)
        write_jar(jar, classes, class_names, descriptor, text)
        built.append({"platform": platform, "path": str(jar), "sha256": sha256(jar), "metadata": descriptor,
                      "sources": [{"path": str(source), "sha256": sha256(source)} for source in sources], "javac": command,
                      "official_abi_inputs": [{"path": str(path), "sha256": sha256(path)} for path in official],
                      "abi_interpretation": "Synthetic fixture; supplied official archives precede own compatibility classes."
                        if official else "Synthetic fixture compiled against the own compatibility facade; source-signature check only, no independent binary ABI proof."})
    report = {"loader_sha256": sha256(loader), "fixtures": built, "packets_or_client_modules_modified": False,
              "scope": "Opt-in synthetic lifecycle fixtures and actual Minecraft observations; arbitrary mods/game patches/stock QSL unverified."}
    (output / "cross-platform-fixtures.json").write_text(json.dumps(report, indent=2) + "\n")
    return built


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/workspace/minecraft-smoke"))
    parser.add_argument("--loader", type=Path, required=True)
    parser.add_argument("--java", type=Path, default=Path("/workspace/toolchains/jdk-21.0.8+9/bin/java"))
    parser.add_argument("--seconds", type=int, default=240)
    parser.add_argument("--name", default="n9ezz-four-platform-lifecycle")
    parser.add_argument("--build-only", action="store_true")
    parser.add_argument("--replay", action="store_true")
    parser.add_argument("--min-world-callbacks", type=int, default=1000)
    parser.add_argument("--min-server-ticks", type=int, default=1000)
    parser.add_argument("--hitbox-geometry", action="store_true", help="Opt-in read-only local Box/TargetGeometry diagnostic helper")
    for platform in PLATFORMS:
        parser.add_argument("--" + platform + "-abi", action="append", type=Path, default=[])
    parser.add_argument("--extra-library", action="append", type=Path, default=[])
    args = parser.parse_args()
    if Path(args.name).name != args.name or not args.name:
        parser.error("--name must be a single nonempty path component")
    if args.build_only and args.replay:
        parser.error("--build-only and --replay are mutually exclusive")
    if not 5 <= args.seconds <= 600 or args.min_world_callbacks < 1 or args.min_server_ticks < 1:
        parser.error("Require 5..600 seconds and positive callback/tick thresholds")
    output = args.root.resolve() / args.name
    output.mkdir(parents=True, exist_ok=True)
    loader = args.loader.resolve()
    loader_hash = sha256(loader)
    if not args.replay:
        if not args.build_only and (output / "launch.log").exists():
            raise SystemExit("Previous launch evidence exists; use a new --name or --replay")
        built = build_fixtures(loader, args.java.resolve(), output, {platform: getattr(args, platform + "_abi") for platform in PLATFORMS}, args.hitbox_geometry)
        if args.build_only:
            print("CROSS_PLATFORM_FIXTURES result=" + str(output / "cross-platform-fixtures.json"), flush=True)
            return
        mods = output / "game/mods"
        mods.mkdir(parents=True, exist_ok=True)
        for fixture in built:
            path = Path(fixture["path"])
            (mods / path.name).write_bytes(path.read_bytes())
        command = [sys.executable, str(Path(__file__).with_name("world_probe.py")), "--root", str(args.root), "--loader", str(loader),
                   "--java", str(args.java), "--seconds", str(args.seconds), "--name", args.name, "--demo-world"]
        for path in args.extra_library:
            command.extend(["--extra-library", str(path)])
        env = os.environ.copy()
        env["JAVA_TOOL_OPTIONS"] = env.get("JAVA_TOOL_OPTIONS", "") + " -Dn9ezz.smoke.continueDemo=true"
        if args.hitbox_geometry:
            env["JAVA_TOOL_OPTIONS"] += " -Dn9ezz.smoke.hitboxGeometry=true"
        completed = subprocess.run(command, env=env, check=False)
        harness_status = completed.returncode
    else:
        harness_status = None
    base = json.loads((output / "result.json").read_text())
    world = json.loads((output / "world-result.json").read_text())
    fixtures = json.loads((output / "cross-platform-fixtures.json").read_text())
    for report in (base, world, fixtures):
        if report.get("loader_sha256") != loader_hash:
            raise SystemExit("Recorded evidence does not match the supplied loader hash")
    lines = (output / "launch.log").read_text(errors="replace").splitlines()
    base_passed = all(report.get("passed") is True and all(report.get("acceptance", {}).values()) for report in (base, world))
    acceptance = evaluate_acceptance(lines, base_passed, args.min_world_callbacks, args.min_server_ticks)
    local_geometry = [dict(re.findall(r"\b([A-Za-z][A-Za-z0-9_]*)=([^ ]+)", line))
                      for line in lines if "N9EZZ_LOCAL_HITBOX_QA" in line]
    if args.hitbox_geometry:
        shared_loaders = {row.get("loader") for row in records(lines) if row.get("kind") == "phase"}
        acceptance["optional_read_only_local_hitbox_geometry"] = bool(local_geometry) and len(shared_loaders) == 1 and all(
            row.get("status") == "PASS" and row.get("loader") in shared_loaders and int(row.get("checks", "0")) > 0 for row in local_geometry)
    result = {"loader_sha256": loader_hash, "harness_exit_code": harness_status, "replayed": args.replay,
              "acceptance": acceptance, "passed": all(acceptance.values()), "thresholds": {
                  "world_callbacks": args.min_world_callbacks, "server_ticks": args.min_server_ticks},
              "probe_lines": [line for line in lines if MARKER in line], "fixtures": fixtures["fixtures"],
              "optional_local_geometry_lines": [line for line in lines if "N9EZZ_LOCAL_HITBOX_QA" in line],
              "scope": "Four synthetic official-metadata mods with explicitly opted-in lifecycle contracts. Actual client/server/world observations; no arbitrary mod, game patch or PvP claim."}
    (output / "cross-platform-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print("CROSS_PLATFORM_SMOKE result=" + str(output / "cross-platform-result.json"), flush=True)
    if not result["passed"]:
        raise SystemExit("CROSS_PLATFORM_SMOKE_FAILED " + json.dumps(acceptance, sort_keys=True))


if __name__ == "__main__":
    main()
