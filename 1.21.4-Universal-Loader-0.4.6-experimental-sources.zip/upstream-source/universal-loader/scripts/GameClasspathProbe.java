import dev.n9ezz.loader.core.EventBus;
import dev.n9ezz.loader.core.RuntimeBootstrap;
import java.nio.file.Path;

/** Real official client class ownership probe; does not invoke Minecraft or authenticate. */
public final class GameClasspathProbe {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("game-dir client-jar");
        Path game = Path.of(args[0]); Path jar = Path.of(args[1]).toRealPath();
        try (var session = RuntimeBootstrap.runGame(game, game.resolve("mods"), jar, new EventBus(), false)) {
            Class<?> main = Class.forName("net.minecraft.client.main.Main", false, session.classLoader());
            Class<?> mod = Class.forName("dev.n9ezz.examples.SmokeMod", false, session.classLoader());
            if (main.getClassLoader() != session.classLoader() || mod.getClassLoader() != session.classLoader())
                throw new AssertionError("game/mod classloader ownership differs");
            if (!Path.of(main.getProtectionDomain().getCodeSource().getLocation().toURI()).equals(jar))
                throw new AssertionError("game class source differs from verified official client");
            if (!"n9ezz_smoke".equals(System.getProperty("n9ezz.smoke.initialized"))
                    || !"true".equals(System.getProperty("n9ezz.smoke.ready")))
                throw new AssertionError("native fixture did not initialize and reach READY");
            main.getMethod("main", String[].class); // Also resolve the actual entrypoint signature.
            System.out.println("OFFICIAL_CLIENT_CLASS_LOAD_PASS " + main.getName());
            System.out.println("GAME_SOURCE " + main.getProtectionDomain().getCodeSource().getLocation());
            System.out.println("SHARED_LOADER " + session.classLoader().getClass().getName()
                + "@" + Integer.toHexString(System.identityHashCode(session.classLoader())));
            System.out.println("MOD_SOURCE " + mod.getProtectionDomain().getCodeSource().getLocation());
            System.out.println("MOD_READY " + System.getProperty("n9ezz.smoke.ready"));
            System.out.println("LIFECYCLE " + session.lifecycleTrace());
            System.out.println("This probe did not invoke Minecraft.main or verify a rendered menu.");
        }
    }
}
