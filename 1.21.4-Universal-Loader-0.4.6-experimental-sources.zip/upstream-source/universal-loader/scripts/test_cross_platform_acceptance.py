#!/usr/bin/env python3
"""Negative parser checks with synthetic lines, never evidence of a game launch."""
from cross_platform_probe import MARKER, PLATFORMS, evaluate_acceptance

LOADER = "dev.n9ezz.loader.core.UnifiedClassLoader@123"


def fixture_lines():
    lines = []
    def add(text):
        lines.append(MARKER + " seq=" + str(len(lines) + 1) + " " + text)
    def phase(platform, name):
        add("kind=phase platform=" + platform + " phase=" + name + " instance=" + platform
            + " loader=" + LOADER + " contextLoader=" + LOADER)
    for platform in ("forge", "neoforge"):
        phase(platform, "construct")
    for platform in PLATFORMS:
        phase(platform, "common")
    for platform in ("forge", "neoforge"):
        phase(platform, "commonWork")
    for platform in PLATFORMS:
        phase(platform, "client")
    for platform in ("forge", "neoforge"):
        phase(platform, "clientWork")
    for platform in ("forge", "neoforge"):
        phase(platform, "complete")
    for platform in ("fabric", "quilt", "neoforge"):
        add("kind=api platform=" + platform + " identity=true paths=true sameContainer=true")
    add("kind=runtime phase=READY")
    for event in ("clientStarted", "serverStarting", "serverStarted", "networkInit", "networkJoin", "demoContinued"):
        add("kind=milestone event=" + event + " mechanism=vanilla_Continue_Playing_handler")
    add("kind=server serverTicks=1000 serverStarts=1000 serverOrderingFailures=0 serverLoader=" + LOADER)
    add("kind=sample clientTicks=1500 clientStarts=1500 clientOrderingFailures=0 clientStarted=true "
        "world=true player=true joined=true serverStarted=true worldCallbacks=1000 clientLoader=" + LOADER
        + " n9ezzLoader=" + LOADER + " worldLoader=" + LOADER + " playerLoader=" + LOADER)
    return lines


def passed(lines, base=True):
    return all(evaluate_acceptance(lines, base).values())


lines = fixture_lines()
checks = 0


def check(value, message):
    global checks
    assert value, message
    checks += 1


check(passed(lines), "Complete synthetic trace must parse; this is not a real-game test")
check(not passed(lines, False), "Cannot override failed base game evidence")
for platform in PLATFORMS:
    check(not passed([line for line in lines if "platform=" + platform + " " not in line]), "Missing " + platform + " must fail")
check(not passed([line.replace("platform=quilt phase=client", "platform=quilt phase=common") for line in lines]), "Missing client / duplicate common fails")
check(not passed([line.replace("phase=commonWork", "phase=common") for line in lines]), "Deferred work cannot be conflated with common callbacks")
check(not passed([line.replace("instance=quilt", "instance=second") if "platform=quilt phase=client" in line else line for line in lines]), "Common/client singleton must match")
check(not passed([line.replace("instance=quilt ", "") for line in lines]), "Missing singleton identities cannot compare as null")
check(not passed([line.replace("loader=" + LOADER + " ", "") for line in lines]), "Missing classloaders must reject instead of crashing")
check(not passed([line.replace("loader=" + LOADER, "loader=net.fabricmc.loader.impl.launch.knot.KnotClassLoader@abc")
                  if "platform=forge phase=common" in line else line for line in lines]), "Separate platform classloader fails")
check(not passed([line.replace("contextLoader=" + LOADER, "contextLoader=jdk.internal.loader.ClassLoaders$AppClassLoader@a")
                  if "platform=forge phase=common" in line else line for line in lines]), "Mod callback TCCL must be shared")
check(not passed([line.replace("n9ezzLoader=" + LOADER, "n9ezzLoader=" + LOADER + "other") for line in lines]), "N9Ezz must share game/mod classloader")
check(not passed([line.replace("serverStarts=1000", "serverStarts=999") for line in lines]), "Unbalanced server tick pair fails")
check(not passed([line.replace("clientStarts=1500", "clientStarts=1499") for line in lines]), "Unbalanced client tick pair fails")
check(not passed([line.replace("worldCallbacks=1000", "worldCallbacks=999") for line in lines]), "Insufficient real world callbacks fail")
check(not passed([line.replace("serverTicks=1000", "serverTicks=101") for line in lines]), "Paused/demo server cannot pass sustained ticks")
check(not passed([line.replace("sameContainer=true", "sameContainer=false") for line in lines]), "Quilt container identity must survive common/client")
check(not passed([line for line in lines if "event=networkJoin" not in line]), "World without real network join is incomplete")
check(not passed([line for line in lines if "event=demoContinued" not in line]), "Must use disclosed vanilla Continue Playing handler")
check(not passed(list(reversed(lines))), "Out-of-order log sequence fails")
check(not passed([*lines, "Exception in thread Render thread: failed"]), "Fatal game exception fails")
check(not passed(["A PID, screenshot and ready text exist"]), "Text/PID/screenshot alone are not game evidence")
print("PASS " + str(checks) + " synthetic cross-platform report parser checks (no game launch)")
