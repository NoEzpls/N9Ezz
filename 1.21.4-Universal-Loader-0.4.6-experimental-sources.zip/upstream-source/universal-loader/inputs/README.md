# Pinned client update inputs

`base-client-1.5.3.jar` is the byte-identical client from the user's supplied
original installer. It is already patched N9Ezz, not a clean Pulse base.
`hitbox-overlay-1.5.3.jar` is the compiled/remapped addon from this release's
`client/` Java sources. Exact hashes and provenance are in
`client-bundle-inputs.json`.

The Java updater replaces only the N9Ezz subsystem after verifying input hashes,
host ABI, existing Mixin contracts and bytecode. It never reapplies host hooks.
These inputs are included in the source archive so its installer JAR can be
reproduced with JDK 21 and the locked dependencies. They retain their existing
licenses; the new core's MIT license does not relicense the Pulse host.

The addon source can be compiled separately using the command in
`docs/n9ezz-integration-audit.md`. This release's exact installer reproduction
uses the pinned compiled addon, not an unverified replacement from another build.
