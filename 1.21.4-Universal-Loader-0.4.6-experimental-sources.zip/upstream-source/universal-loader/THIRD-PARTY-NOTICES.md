# Third-party components

N9Ezz Universal Loader contains original Java runtime code, independently
implemented interoperability services and the reusable components below.
It does not contain or launch Fabric Loader, Quilt Loader, Forge, NeoForge,
ModLauncher or FML engines. The ratio of original and reused code is not
measured or claimed. New N9Ezz code is MIT; that license does not relicense
upstream libraries, mappings, the embedded client or its dependencies.

| Bundled component | Version | License | Source |
| --- | --- | --- | --- |
| ASM core, util, tree, analysis, commons | 9.9.1 | BSD-3-Clause | https://asm.ow2.io/ |
| Gson | 2.13.2 | Apache-2.0 | https://github.com/google/gson |
| tomlj | 1.1.1 | Apache-2.0 | https://github.com/tomlj/tomlj |
| ANTLR runtime | 4.11.1 | BSD-3-Clause | https://github.com/antlr/antlr4 |
| Checker Qual | 3.21.2 | MIT | https://github.com/typetools/checker-framework |
| Fabric's Sponge Mixin distribution | 0.17.2+mixin.0.8.7 | MIT | https://github.com/FabricMC/Mixin and https://github.com/SpongePowered/Mixin |
| MixinExtras | 0.5.4 | MIT | https://github.com/LlamaLad7/MixinExtras |
| TinyRemapper | 0.13.0 | LGPL-3.0-or-later | https://github.com/FabricMC/tiny-remapper/tree/0.13.0 |
| Class Tweaker | 0.3.0-beta.2 | Apache-2.0 | https://github.com/FabricMC/class-tweaker |
| Intermediary Minecraft mappings | 1.21.11 | CC0-1.0 | https://github.com/FabricMC/intermediary |
| Selected Fabric API components | From 0.141.3+1.21.11; exact modules below | Apache-2.0 | https://github.com/FabricMC/fabric |
| Modified Fabric Loader public interface descriptors | Verified ABI baseline 0.19.2 | Apache-2.0 | https://github.com/FabricMC/fabric-loader/tree/0.19.2 |
| Modified Quilt Loader public interface descriptors | Verified ABI baseline 0.30.1 | Apache-2.0 | https://github.com/QuiltMC/quilt-loader/tree/0.30.1 |
| QSL common/client initializer public descriptors | Source ABI from 1.21.5, commit fef35afe5fb046e6339a3dfc8478a65b5bfce3bc | Apache-2.0 | https://github.com/QuiltMC/quilt-standard-libraries |

Original dependency JARs, including their metadata and embedded notices,
remain under `META-INF/n9ezz/dependencies/`. Complete license texts are under
`META-INF/n9ezz/licenses/` and `universal-loader/licenses/` in the source
distribution. Exact binary URLs and SHA-256 pins are in `deps-lock.json`.
The build expands runtime classes, excludes upstream manifests/signatures
and module descriptors from the combined outer JAR, and merges service
registrations deterministically. Original dependency bytecode is retained.
The complete original archives preserve their original packaging metadata.

Gson/tomlj/ANTLR notices were retrieved from matching official source tags;
ASM notices are the headers from matching Maven source archives; Checker
Qual's notice is from its original JAR. Mixin/MixinExtras licenses and the
Class Tweaker/TinyRemapper licenses are preserved in the named license files.
Mixin is developed by the SpongePowered contributors; the Fabric distribution
is maintained by FabricMC. MixinExtras is Copyright 2022-present LlamaLad7.
TinyRemapper is Copyright 2016, 2018 Player and asie, and FabricMC contributors.
Intermediary mapping data retains its CC0 dedication.

## TinyRemapper corresponding source and replacement

TinyRemapper is used unmodified through its mapping interfaces. Its LGPLv3
notice and the GPLv3 text incorporated by LGPLv3 are both included:
`licenses/TINY-REMAPPER-0.13.0-LICENSE.txt` and
`licenses/TINY-REMAPPER-GPL-3.txt`.

The source distribution contains the matching official 0.13.0 repository,
including its Gradle build files, wrapper and source headers, at
`universal-loader/third-party-sources/tiny-remapper-0.13.0-sources.zip`.
The installer also includes it under
`META-INF/n9ezz/sources/tiny-remapper-0.13.0-sources.zip`.
Its SHA-256 is
`9a1cd6f975f79aa929aa063d32deb61e49d6714bdb4b14dda09a27a0f41d230b`.
The N9Ezz source distribution also contains the corresponding Java application
sources and reproducible packaging script needed to rebuild the combined JAR.

To use a modified compatible TinyRemapper, build the library from those
sources, place the resulting JAR into `universal-loader/.cache/deps/`, update
its entry in `deps-lock.json` to the new binary and SHA-256. Rebuild the
application with JDK 21 and `python3 build.py --offline`. If changing the
library API, adjust the supplied Java adapter sources as needed. The changed
binary fingerprint automatically selects a different remap cache, even when
the library retains the same version label. The runtime fingerprints the
actual library selected by the JVM; a preserved archive is used only when
its library classes match the running shaded classes. These checks are editable
source configuration, not a restriction on library replacement. Modification
for personal use and reverse engineering for debugging those modifications
are permitted as required by LGPLv3. Preserve the upstream license and notices
when distributing a modified build.

## Selected Fabric API and Fabric Loader public ABI

The embedded official Fabric API archive has SHA-256
`86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5`.
`SelectedFabricApi` creates a deterministic outer container containing these
six selected original nested modules:

| Module | Version |
| --- | --- |
| fabric-api-base | 1.0.5+4ebb5c083e |
| fabric-command-api-v2 | 2.4.7+6b42a6003e |
| fabric-key-binding-api-v1 | 1.1.7+4fc5413f3e |
| fabric-lifecycle-events-v1 | 2.6.15+4ebb5c083e |
| fabric-networking-api-v1 | 5.1.5+ae1e07683e |
| fabric-rendering-v1 | 16.2.10+0290ad933e |

Their bytes, metadata and Apache-2.0 licenses remain unchanged. Only the
outer metadata's module selection is changed. Invalidated outer signatures
and manifest digest sections are removed; modification provenance is retained
in `META-INF/n9ezz/fabric-api-selection.json`. The original official umbrella
is also retained under `embedded/`. Exact module hashes and contracts are in
`docs/fabric-runtime-contract.md`. The `fabric` alias represents this bounded
subset, not a complete Fabric API implementation.

Public interface descriptors in `net.fabricmc.loader.api` derive from Fabric
Loader 0.19.2, Copyright 2016 FabricMC, Apache License 2.0. They are modified
to expose the documented read-only subset, with new implementations backed
by N9Ezz runtime services. Original attribution headers are retained. No
Fabric Loader implementation or engine classes are bundled. Fabric-named
Mixin and MixinExtras artifacts are reusable transformation libraries;
N9Ezz invokes their platform-independent bootstrap through its own service.

Quilt public interface descriptors retain Copyright 2016 FabricMC and
2022–2023 QuiltMC, Apache License 2.0. The adapted QSL initializer descriptors
retain Copyright 2022 The Quilt Project, Apache License 2.0. Their implementations
are backed by original N9Ezz services. The QSL source ABI is from Minecraft 1.21.5:
it is not an embedded or verified stock QSL distribution for Minecraft 1.21.11.
The full Apache text is preserved in `licenses/QUILT-QSL-API-APACHE-2.0.txt`.

Forge and NeoForge compatibility classes implement the explicitly documented
public signatures using original N9Ezz code; upstream FML/EventBus engines and
their implementations are not bundled. Reviewed Forge/FML public sources are
LGPL-2.1-only and their EventBus projects retain their original licenses.
The runtime uses its own per-mod buses, constructor contexts, phase barriers
and deferred queues. These are bounded lifecycle contracts, not upstream
Minecraft patches or registry implementations. Exact contracts are in
`docs/fml-game-contract.md` and `docs/quilt-game-contract.md`; full source audits
preserve the original projects' license information.

## Embedded user client

Minecraft binaries and assets, the user's original installer and the uploaded
reference JAR are not included in the installer JAR. The installer includes
the N9Ezz 1.5.3 client extracted from the user's original installer with the
user's Java addon fixes applied by the verified `MergeBundledClient` updater.
Its complete `embedded/n9ezz-client-1.5.3.jar` archive preserves existing host
hooks, metadata, refmap, notices and nested libraries. Its inputs and output
hashes are recorded in `META-INF/n9ezz/embedded-client.json` and
`inputs/client-bundle-inputs.json`.

The client preserves its existing generated nested archives for JSON 20250517,
Kotlin stdlib 1.9.22, OkHttp/OkHttp SSE 4.12.0, Okio JVM 3.6.0 and
Zero-Allocation Hashing 0.16. Their existing bytes and notices are retained
without changing their licenses. The new core's MIT license does not relicense
the client, its Pulse base, fonts/resources or those components. Base Pulse
sources are not present in the supplied project. Client bundling does not
establish arbitrary platform or mod compatibility; see the runtime report.
