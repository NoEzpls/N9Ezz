# Границы завершения совместимости четырёх платформ

Проверка исходников и официальной доступности: **8 октября 2026, 15:02–15:12 UTC**.
Исходная точка этого аудита — выпущенный N9Ezz `0.3.1-experimental`.
Новые слои совместимости команда реализует отдельно; их результат устанавливается
тестами конкретного выпуска, а не этой таблицей требований.

## Что уже доказывает сборка 0.3.1

Собственный bootstrap, один `UnifiedClassLoader`, поиск модов, общий resolver,
контроль дубликатов, mapping/access/core/Mixin/post pipeline и реальные Fabric
client/world hooks работают в общей среде. Встроенный N9Ezz и выбранные шесть
модулей Fabric API `0.141.3+1.21.11` запускались в Minecraft `1.21.11` на Java 21.
См. [отчёт 0.3.1](release-test-report-0.3.1.md). Проверка метаданных Quilt/TOML
и конструкторов `@Mod` в CLI остаётся отдельным доказательством; она не
подтверждает игровые контракты QSL или JavaFML.

## Повторная проверка доступности

Все запросы выполнены по официальным HTTPS URLs через унаследованный proxy,
с обычной TLS-проверкой. Ни прямое соединение, ни другой mirror, ни исполнение
upstream installer не использовались. Статус среды был `running`,
`observations_current=true`; состояние желаемой HTTP policy — `unknown`, поэтому
вывод ниже относится к фактическим HTTP-ответам, а не к гарантии политики.

| Официальный запрос | Время UTC | Фактический результат |
| --- | --- | --- |
| [Forge Maven metadata](https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml) | 15:02:34 | HTTP 200, 211 875 bytes, SHA-256 `b9e6515eefd5573f9f92ff9f4b2ee85e9ee05d570300d1a08e927ae1d601fc64`; 31 версия `1.21.11-*` |
| [Forge download index 1.21.11](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.21.11.html) | 15:02:34 | HTTP 200, 190 722 bytes, SHA-256 `20ba608395be8963fd12f9580643ded4acc93c57e4fbded5c9f1e959023db586` |
| [Forge promotions](https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json) | 15:02:34 | HTTP 200, 4 111 bytes, SHA-256 `9d3a9dd674c0dd264d82b1f39a204581eaee32d75e3b315f9767d9e07ade01d0`; latest `61.2.1`, recommended `61.2.0` |
| Forge `1.21.11-61.2.1` installer, universal, sources, POM | 15:03:41–15:03:42 | HTTP 403, тело `error code: 1010`; bytes артефактов не получены |
| Forge `61.2.1` installer/universal/sources `.sha256` и `.sha1` | 15:03–15:04 | HTTP 403; publisher checksum нельзя сопоставить с скачанным JAR |
| Forge recommended `1.21.11-61.2.0` universal и POM; EventBus `7.0.5` JAR | 15:05:03 | HTTP 403, тело `error code: 1010` |
| [QSL aggregate Maven metadata](https://maven.quiltmc.org/repository/release/org/quiltmc/qsl/maven-metadata.xml) | 15:03:42 | HTTP 200, 6 870 bytes, SHA-256 `5b00d07b12b4ebaaf49de34b5fbafe60df917ccbba29af50a5b35fef44bc06df`; 144 версии, ни одной `+1.21.11` |
| [QSL official source heads](https://github.com/QuiltMC/quilt-standard-libraries) | 15:02–15:03 | Среди объявленных heads нет `1.21.11`; последняя ветка по версии Minecraft — `1.21.5`, commit `fef35afe5fb046e6339a3dfc8478a65b5bfce3bc` |
| [Neo FML `10.0.36` JAR](https://maven.neoforged.net/releases/net/neoforged/fancymodloader/loader/10.0.36/loader-10.0.36.jar) и `.sha256` | 15:10:06 | Оба HTTP 200; 660 602 bytes, publisher SHA-256 `5711bb95b45b421ada6e5f0f4600ac441c3509446178da5de927135f8bd6b0c9` совпал; manifest `Git-Commit: 805fe3e7`, `Build-Number: 10.0.36` |
| [Neo EventBus `8.0.5` JAR](https://maven.neoforged.net/releases/net/neoforged/bus/8.0.5/bus-8.0.5.jar) и `.sha256` | 15:10:06 | Оба HTTP 200; 30 340 bytes, publisher SHA-256 `705e24f37752809499a5cd0c7dd31eaabf3d933c5d3b2060168e94e9ef62593a` совпал; manifest `8.0.5+main.b0584b4c` |
| [Neo MergeTool `2.0.0:api` JAR](https://maven.neoforged.net/releases/net/neoforged/mergetool/2.0.0/mergetool-2.0.0-api.jar) и `.sha256` | 15:11:52 | Оба HTTP 200; 2 550 bytes, publisher SHA-256 `0260881294d8b218afe3d673f084d3745a55c28b35205d07d5e62d7f22202a00` совпал; предоставляет используемый constructor API `net.neoforged.api.distmarker.Dist` |

Эта проверка **заменяет прежний вывод о недоступности Forge metadata/index**.
Конкретные бинарные пути Forge по-прежнему недоступны. Download index публикует
SHA-1 installer `61.2.1`: `3740bbf893e38c90990f01d6a49eac398e6d87b8`;
checksum из страницы без полученных bytes не доказывает целостность артефакта.
Официальный source tag `61.2` указывает на commit
`3b981f47252a0719037c81ed35776f4bd9b30049`; точное соответствие бинарного
`61.2.1` исследованной source branch без manifest не подтверждено.

Правильный aggregate coordinate QSL — `org.quiltmc:qsl`. Предварительный
запрос несуществующего `org.quiltmc.qsl:quilt-standard-libraries` вернул 404 и
не используется как доказательство отсутствия QSL. В правильном metadata
среди `1.21`-серии опубликованы `10.0.0-alpha.1+1.21` и
`10.0.0-alpha.2/.3/.5+1.21.1`. Исследованная source branch `1.21.5` объявляет
`QSL_VERSION=10.0.0-alpha.4`, `COMPATIBLE_VERSIONS=[1.21.5]`.
Это отсутствие подходящего aggregate release и source branch в проверенных
официальных ответах; не утверждение об отсутствии любых отдельных модулей.

NeoForge `21.11.45` и FML `10.0.36` уже получены и сверены с publisher SHA-256;
точные fingerprints находятся в [platform-availability.md](platform-availability.md).
Quilt Loader `0.30.1` доступен, но расхождение Meta/Maven checksum остаётся
неразрешённым. Оно не мешает исследовать API source, но препятствует заявлению
о согласованности двух официальных источников.

## Бинарные контракты, которые нельзя смешивать

| Поверхность | Подтверждённое поведение upstream | Требование к собственному слою |
| --- | --- | --- |
| Forge JavaFML construction | [Pinned FMLModContainer](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/javafmllanguage/src/main/java/net/minecraftforge/fml/javafmlmod/FMLModContainer.java) сначала ищет constructor `(FMLJavaModLoadingContext)`, затем no-arg; automatic subscribers подключаются после успешной конструкции | Один экземпляр, правильный context, origin/code-source check, исходная cause при ошибке; dependent phases не запускаются после failure |
| Forge context | `FMLJavaModLoadingContext.getModBusGroup(): net.minecraftforge.eventbus.api.bus.BusGroup`; covariant `getContainer(): FMLModContainer` | Нельзя заменить возвращаемый descriptor старым `IEventBus` или более общим container без bridge method |
| Forge EventBus 7 | Source candidate `588a6c7a2fb3d936aefc3c1bd89435c42f5a92d8`; `BusGroup` и `EventBus<T>` — interfaces; `internal.Event` — sealed interface; `IModBusEvent` extends `InheritableEvent`; `ModLifecycleEvent` — abstract class implements `IModBusEvent` | Собственная реализация должна сохранить interface/class shapes и точные erased descriptors поддержанных методов |
| Forge typed listeners | `EventBus.addListener(Consumer): api.listener.EventListener`; `addListener(byte, Consumer)`; `post(internal.Event): boolean`; `fire(internal.Event): internal.Event`; `FMLClientSetupEvent.getBus(BusGroup): EventBus` | Return types, listener identity и порядок priorities являются контрактом; прежний Forge 6 API не описывает Forge 61.x |
| NeoForge FML 10 construction | [Exact source](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/javafmlmod/FMLModContainer.java): ровно один public constructor; допустимы `IEventBus`, `ModContainer`, `FMLModContainer`, `Dist`; повтор типа параметра отклоняется | Отдельный constructor adapter, без подмены Forge context; нельзя произвольно выбрать один из нескольких public constructors |
| NeoForge `@Mod` | `dist(): Dist[]` по умолчанию CLIENT + DEDICATED_SERVER; `depends(): String[]`; несколько entrypoints одного mod | Неподдержанные attributes/ordering отклонять явно; value-only shape не является полным `@Mod` API |
| NeoForge EventBus 8 | Published `21.11.45` pin `8.0.5`; `net.neoforged.bus.api.IEventBus` — interface, `Event` — abstract class. Exact JAR `javap`: `addListener(Consumer): void`, `post(Event): Event`; explicit `Class<T>` listener overloads и per-priority post | Не применять Forge typed-bus ABI к NeoForge; ограничения списка событий объявлять отдельно |
| Deferred work | В обеих FML-платформах `enqueueWork(Runnable): CompletableFuture<Void>` и `enqueueWork(Supplier<T>): CompletableFuture<T>`; работа выполняется после соответствующего event barrier | Futures завершаются только после работы; exceptions остаются failures; очередь исполняется на нужном игровом потоке, без синхронного исполнения внутри listener вместо очереди |
| QSL common initializer | [RegistriesMixin 1.21.5](https://github.com/QuiltMC/quilt-standard-libraries/blob/fef35afe5fb046e6339a3dfc8478a65b5bfce3bc/library/core/qsl_base/src/main/java/org/quiltmc/qsl/base/mixin/RegistriesMixin.java): `init` перед `Registries.freeze()` в `Registries.bootstrap()`; `onInitialize(ModContainer): void` | Отдельный registry boundary. Вызов в обычном Fabric client common phase перед GameOptions слишком поздний для исходного registry contract |
| QSL client initializer | [MinecraftClientMixin](https://github.com/QuiltMC/quilt-standard-libraries/blob/fef35afe5fb046e6339a3dfc8478a65b5bfce3bc/library/core/qsl_base/src/main/java/org/quiltmc/qsl/base/mixin/client/MinecraftClientMixin.java): `client_init` перед GameOptions constructor; `onInitializeClient(ModContainer): void` | Отдельный typed callback в реальном Minecraft constructor; один callback и правильный container |

Рассмотренные Forge/FML API имеют LGPL-2.1-only, QSL — Apache-2.0.
API shapes и адаптеры требуют сохранённых лицензий/attribution; чужие bootstrap,
Knot, ModLauncher и FML runtime не должны становиться вторым ядром.

FML/Neo EventBus descriptors независимо прочитаны через `javap -public -s` из
publisher-verified JAR; код этих JAR не исполнялся. Эти bytes доступны для
компиляции тестового мода против upstream ABI, а не против собственного shim.
Совпадение descriptor подтверждает бинарную форму; lifecycle/thread behavior
подтверждается отдельной игровой проверкой.

## Проверяемое завершение ограниченного выпуска

Общее ядро может принять четыре **явно ограниченных** game fixtures без запуска
четырёх engines. Для такого выпуска нужны:

1. Явный контракт архива с поддержанным API inventory и namespace. Для JavaFML
   language provider версия выбирается по origin: Forge `61.x`, NeoForge FML
   `10.x`. Одна глобальная версия `javafml` неверно разрешит один из форматов.
2. QSL registry/client boundaries и FML construction/setup/deferred barriers
   вызываются из реальной игры. Фиксируются once-only, dependency order,
   поток выполнения, failure propagation и отсутствие listener bleed между mods.
3. Четыре одновременно установленных fixtures получают тот же classloader, что
   Minecraft и встроенный N9Ezz. Проверяются duplicate classes, reserved API,
   несовместимая зависимость, недоступный API и ожидаемый отказ без READY.
4. Реальный запуск мира фиксирует экземпляр клиента/игрока/мира, события и
   завершённые tick/render пары. Если меню ставит сервер на паузу, это остаётся
   доказательством загрузки мира, без заявления о длительной игре.
5. Установочный JAR и архив исходников воспроизводятся побайтно; старые JAR
   остаются доступными. Reports привязаны к SHA-256 именно проверенного JAR.

Fixture, использующий только constructor, setup event и вывод диагностики,
может доказать этот ограниченный контракт. Он не проверяет регистрацию блока,
network payload или capabilities и не должен служить основанием для их поддержки.

## Части, которые такой выпуск не завершает

| Требование более широкого mod API | Конкретная отсутствующая работа / внешнее доказательство |
| --- | --- |
| Stock Quilt QSL для `1.21.11` | В проверенных официальных aggregate/source ответах нет такой версии. Собственная реализация трёх известных initializer shapes остаётся своим ограниченным API, а не проверенным QSL release |
| Exact Forge binary compatibility | Canonical artifact paths для `61.2.1` и recommended `61.2.0` возвращают 403. Source shape fixtures возможны, publisher-verified binary ABI пока не проверен |
| Ссылки обычного Forge/NeoForge мода на Minecraft | Mojang-name references, descriptors, inheritance, refmaps и AT должны перейти в один intermediary namespace; текущие game mappings сами по себе не remap произвольный mod JAR |
| Registry/events/game extensions Forge и NeoForge | В vanilla отсутствуют добавленные upstream members и hooks. Нужна собственная реализация конкретных registration/freeze, resources, network, capabilities/attachments APIs и конфликтующих Minecraft patches |
| Transformer и loader SPI | ModLauncher voting, FML processor graph, JarJar selection, coremods, runtime enum extension, JPMS opens/exports и полный SAT semantics требуют самостоятельных контрактов; поддержка TOML не предоставляет их |
| Произвольные API-модули | Quilt QSL/QFAPI и непроверенные Fabric API modules имеют дополнительные mixins, registry/resource/network зависимости. Список выбранных шести Fabric modules нельзя расширять только по совпадению имени platform |
| Полная пересборка Pulse host из исходников | Сохранённый pinned base JAR плюс собственный overlay воспроизводимы, но исходники всего базового Pulse host отсутствуют. Это отдельная граница поставленного исходного материала |

Запрос «завершить всё» не превращает непроверенные API в поддержанные.
Завершённость выпуска относится к указанным и реально проверенным контрактам;
открытые части сохраняются в отчёте с точным основанием.
