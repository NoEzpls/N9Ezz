# Opt-in real-game compatibility probe

`universal-loader/scripts/cross_platform_probe.py` packages five development-only
synthetic fixtures. They enter ordinary mod discovery, metadata parsing,
dependency resolution and the one `UnifiedClassLoader`; they are not embedded in
the installed client and never launch upstream loader engines.

| Fixture | Metadata | Contract exercised |
| --- | --- | --- |
| Native observer | `n9ezz.mod.json` | Actual Fabric client/server ticks, lifecycle, local connection and world/player observations |
| Fabric | `fabric.mod.json` | Fabric Loader 0.19.2 common/client initializer and selected loader queries |
| Quilt | `quilt.mod.json` | Quilt Loader 0.30.1 container/query subset, QSL-shaped common/client initializer signatures; explicit `quilt-lifecycle-v1` opt-in |
| Forge | `META-INF/mods.toml` | Forge 61 JavaFML constructor, Bus7 typed lifecycle buses and deferred work; explicit `fml-lifecycle-v1` opt-in |
| NeoForge | `META-INF/neoforge.mods.toml` | FML 10 / NeoForge 21.11 constructor injection, Bus8 explicit-type lifecycle listeners and deferred work; explicit `fml-lifecycle-v1` opt-in |

Forge and NeoForge fixtures declare platform-specific `javafml` versions rather
than a global platform dependency. The selected contract does not implement the
complete Forge/NeoForge platform, so neither fixture requires a fake global
`forge`/`neoforge` provider. The Quilt fixture does not require a stock QSL release.

The fixture packaging report records each source/JAR hash, full javac command,
loader hash and optional official ABI inputs. `--fabric-abi`, `--quilt-abi`,
`--forge-abi` and `--neoforge-abi` accept repeated archives and put those inputs
before the own facade on javac's classpath. Without official binary inputs,
successful compilation only checks the own facade signatures; it is not
independent upstream binary compatibility evidence.

```bash
source /workspace/toolchains/activate-temurin21.sh
python3 universal-loader/scripts/cross_platform_probe.py \
  --loader /absolute/path/to/candidate.jar \
  --name unique-four-platform-run --seconds 240 \
  --fabric-abi /workspace/research/fabric-loader-0.19.2.jar \
  --quilt-abi /workspace/research/quilt-loader-0.30.1.jar
```

The script wraps the existing `world_probe.py`, which wraps
`gameplay_smoke.py`. Their reports must pass and match the exact candidate hash.
An additional observer dismisses the demo modal on the ordinary client callback
by invoking the version-pinned vanilla `DemoScreen` Continue Playing button
handler. Bytecode inspection of Minecraft 1.21.11 intermediary `class_417` shows
`method_19810(class_4185)` performs `MinecraftClient.setScreen(null)` followed by
`Mouse.lockCursor()`. No game state, world/player reference, pause flag, tick
counter, packet or module setting is assigned by this automation. The world is
created through the existing vanilla Play Demo handler, including normal world
generation, integrated server startup and local connection.

Acceptance requires all four common/client phases exactly once, retained mod
instances, a common-before-client boundary, the Forge/NeoForge constructor/common/
deferred-common/client/deferred-client/load-complete boundaries, actual game
lifecycle ordering, one shared mod/game/N9Ezz classloader, a matching context
classloader, and successful selected public loader queries. Defaults additionally
require at least 1000 real world/player callbacks and 1000 balanced integrated
server START/END tick pairs. This catches the previously observed paused demo
modal, which continued client callbacks while server ticks stopped near 101.

`--build-only` packages fixtures without launching a game. `--replay` evaluates
saved logs without launching a second process. The parser test uses explicitly
synthetic text and checks failures for a missing platform, a separate loader,
incorrect context loader, mismatched instances, missing phases, bad ordering,
insufficient/unbalanced ticks, missing JOIN and fatal exceptions. Passing parser
tests does not establish game compatibility.

`--hitbox-geometry` additionally packages the opt-in `LocalHitboxProbe` helper
and requests its read-only comparison of the actual local player's bounds/eye
with vanilla `Box` and the embedded client's `TargetGeometry`. Its translated
numerical cases are explicitly fixtures, not inserted entities or live targets.
The extra acceptance entry requires a PASS record from the shared classloader.
This checks local geometry only and does not toggle combat modules, send attacks
or establish PvP behavior.

The measured reports produced by a real run are `cross-platform-fixtures.json`
and `cross-platform-result.json` in the selected smoke directory. They document
the exact scope: these five fixtures and supported lifecycle APIs. Arbitrary
mods, complete platform game patches/registries, stock QSL, PvP and remote
multiplayer are outside the test.
