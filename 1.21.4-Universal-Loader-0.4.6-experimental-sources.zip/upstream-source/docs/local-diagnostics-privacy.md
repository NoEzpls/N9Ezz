# Локальная диагностика 0.3.1: контракт privacy

Версия 0.3.1 скрывает распознанные секреты в локальных сообщениях самого
загрузчика, сохраняя информацию для разбора ошибок. Это изменение находится
в `Diagnostic`, `LocalDiagnostics`, CLI `Main`, game `GameBootstrap` и
окне installer. `LocalDiagnostics` не отправляет отчёты по сети.

| Вывод | Поведение |
| --- | --- |
| Structured Diagnostic | Текст сообщения и строковое представление очищаются; diagnostic code, mod ID, phase и source остаются доступны для диагностики |
| CLI failure | Очищаются summary и полный exception trace; ошибка остаётся ошибкой с exit 1 |
| Game bootstrap fatal boundary | Очищается полный trace, включая nested causes и suppressed exceptions; raw exception повторно не выбрасывается в JVM handler |
| Installer error | Swing log получает очищенный exception trace |

Распознаются именованные credential-поля/CLI flags, например access token,
refresh token, client token, id_token, client secret, API key и password.
Обработаны Authorization Bearer/Basic/ApiKey, отдельный Bearer и raw
single-token Authorization. Значения заменяются на `[REDACTED]`.
Обнаруженные credential arguments также используются для удаления их
значений из последующих сообщений. Аргументы, передаваемые Minecraft,
остаются исходными.

Реализация собирает явные spans значений из исходного текста, а не заменяет
regex на уже изменённом сообщении. Это сохраняет credential values с
пробелами/metacharacters, escaped quotes и распознанные unclosed quoted
values. Неполное quoted value ограничивается текущей строкой ошибки, чтобы
не удалить последующие stack frames. Marker `[REDACTED]` защищён от повторной
очистки, включая совпадения частей marker с observed credential. Повторное
применение остаётся идемпотентным; совпадение credential с именем поля также
проверено.

Для глобальной literal replacement запоминаются до 64 обнаруженных
credential values длиной от 8 до 4096 символов. Короткий offline token `0`
не удаляется как подстрока из счётчиков и IDs; явно именованное
credential-поле всё равно маскируется. Это ограничение защищает читаемость
обычной диагностики и не является гарантией очистки произвольного
короткого секрета, записанного без имени.

Пример с вымышленным значением:

```text
ENTRYPOINT_FAILED [mod=pulse] [phase=common]: accessToken=[REDACTED]
java.lang.IllegalStateException: initialization failed
    at example.Mod.onInitialize(Mod.java:12)
Caused by: java.lang.IllegalArgumentException: password=[REDACTED]
```

Types, frames, causes, suppressed failures и circular-reference markers
сохраняются. Обычные пути, endpoints без credential-полей, mod IDs,
порядок lifecycle и tick counters остаются видимыми: они нужны для поиска
неисправности. Trace не сокращается до сообщения «ошибка».

Граница очистки ограничена выводом загрузчика. Независимые Minecraft,
Log4j, Sponge Mixin, Pulse и сторонние logger implementations, stdout/stderr
модов, JVM crash dumps, system process arguments и логи внешних программ
не проходят через `LocalDiagnostics` автоматически. Не обещается
распознавание всех authorization schemes, multiline secrets, любых свободно
записанных секретов, unknown encoded форм или
произвольных payload secrets. Raw exception object остаётся у runtime для
обработки причин; privacy применяется к текстовому выводу на перечисленных
границах.

Клиентский JAR, 144 файла архивируемого дерева `client/`, module logic и
сетевые пакеты не менялись. Локальная очистка не устанавливает поддержку
новых mods, API, Quilt/Forge/NeoForge gameplay layers или боевых функций.

Финальная реализация прошла 71 targeted privacy check: 33 предыдущих и 38
дополнительных. Проверены credential-поля и CLI forms, сохранность аргументов,
overlap/short placeholders, полный trace с causes/suppressed/cycles, output
stream, Diagnostic и CLI fatal subprocess. Дополнительные cases проверяют
multiword/metacharacter values, escaped JSON/single quotes, bounded malformed
quotes, marker и field-name collisions, clientToken/id_token, Bearer и
ApiKey/raw Authorization; scheme names и последующие endpoints остаются
читаемыми. Unobserved unquoted values ограничиваются whitespace/query/log
punctuation delimiters; произвольные formats не гарантируются.

Финальный прогон всех suites прошёл, включая 71 privacy check и 9 проверок
acceptance parser. Финальный immutable installer прошёл 180-секундный
real-game smoke; его точный хеш, scope и отдельный reproducibility receipt
фиксируются в
[release-test-report-0.3.1.md](release-test-report-0.3.1.md).
