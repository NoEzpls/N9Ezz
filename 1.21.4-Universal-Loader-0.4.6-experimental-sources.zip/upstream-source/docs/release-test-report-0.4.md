# N9Ezz 0.4.0 experimental: проверки выпуска

Цель: Minecraft 1.21.11, Java 21. Эта итерация добавляет явные Quilt/FML
lifecycle contracts в существующий собственный runtime. Полная сборка 0.4.0
прошла. Проверяемый установочный JAR содержит 53 559 261 bytes, SHA-256
`d5f2417ea56c6a297e543bd92e1d1e850f69479ccb97809e80e501c48926dbd6`.
Реальный совместный запуск именно этого JAR прошёл; результаты предыдущих
версий сохраняются отдельно.

## Что меняется

| Слой | Контракт и граница |
| --- | --- |
| Fabric | Сохранён shared Mixin и шесть pinned Fabric API modules 0.141.3+1.21.11, loader ABI baseline 0.19.2 |
| Quilt | quilt-lifecycle-v1; Quilt 0.30.1 services; QSL-shaped init/client_init descriptors из официальных sources 1.21.5; поздний registry-independent callback перед GameOptions |
| Forge | fml-lifecycle-v1; JavaFML 61.0-source ABI, Forge EventBus 7 typed mod buses, context/no-arg construction, common/client/load-complete events |
| NeoForge | fml-lifecycle-v1; NeoForge 21.11.45, FML 10.0.36, Bus 8.0.5; supported constructor injection и отдельный per-mod lifecycle bus |

GameCompatibilityPolicy требует opt-in в metadata и отдельно проверяет
namespace и scoped language identity. javafml 61.0 относится к Forge mod,
javafml 10.0.36 — к NeoForge mod; глобальных forge/neoforge providers нет.
Поздний lifecycle используется только для авторов, принявших этот ограниченный
контракт. Регистрация игровых объектов до upstream registry freeze, полные
FML patches и stock QSL не реализованы.

Deferred work выполняется на общем game thread после всех listeners текущей
фазы, с context своего mod, до следующей фазы. Ошибка прекращает последующие
этапы и READY. Отмена или явное завершение future до исполнения не запускает
его supplier. Это собственный порядок исполнения, а не создание отдельных
upstream executors или движков. Hard dependency native/Fabric/Quilt initializer
на FML mod или alias отклоняется до любого mod code с
`UNSUPPORTED_CROSS_PHASE_DEPENDENCY`: такой граф противоречит общему FML
barrier. Обратная зависимость FML от native/Fabric допустима.

## Исполняемые проверки и игровой запуск

Полная Java 21 сборка завершилась с кодом 0. Сводка отдельных наборов:

| Проверка | Результат |
| --- | --- |
| Core/resolver/events/transforms | 54 PASS |
| Mapping index/remapping; fingerprint/cache | 26 и 17 PASS |
| Access wideners; nested discovery | 18 и 40 PASS |
| Настоящий Mixin host | 11 PASS |
| Fabric services; entrypoint dispatch; dependencies | 9, 9 и 77 PASS |
| Game integration; universal game policy | 20 и 23 PASS |
| Quilt services/callbacks/preflight/cleanup | 34 PASS |
| FML constructors/buses/barriers/futures/preflight | 33 PASS |
| Local diagnostic redaction | 71 PASS |
| Builtin render provenance; resource bridge; client updater | 21, 29 и 8 PASS |
| Готовый встроенный TargetGeometry.class, без перекомпиляции production класса | 3036 PASS |
| Packaged native mod bootstrap | PASS |
| Старый gameplay parser; cross-platform parser | 9 и 24 PASS, synthetic inputs |
| Installer metadata и сохранность старой установки | 11 PASS |

3036 geometry assertions из существующего TargetGeometryTest исполнены на
готовом `TargetGeometry.class` внутри указанного установщика. Receipt фиксирует
`production_geometry_recompiled=false`, `minecraft_launched=false` и
`network_packets_tested=false`; это проверка встроенного bytecode, не игры.
Результат находится в `embedded-hitbox-test-report.txt` и отдельном JSON receipt.

## Реальный запуск Minecraft

8 октября 2026 года выполнен настоящий запуск
`cross_platform_probe.py --seconds 300 --hitbox-geometry` с неизменяемой
копией указанного JAR. Использовались Java 21, официальный Minecraft 1.21.11,
Mesa/Xvfb и локальная demo-сессия. Запущены обычные discovery/resolver/loader
для пяти development-only fixtures: native observer и четыре platform mod.
Наблюдатели не входят в установочный клиент. Отчёты base/game, world и
cross-platform получили PASS, без replay ранее сохранённого log.

| Зафиксированное поведение | Результат |
| --- | --- |
| Жизнь процесса | 302.5 секунды, жив до заданного deadline; штатная остановка проверкой с exit 143, harness exit 0 |
| Fabric/Quilt/Forge/NeoForge common и client | Каждый callback один раз, тот же экземпляр между фазами |
| Общий порядок | Все common завершены до client; FML listeners до phase-wide deferred work; load-complete до READY |
| Classloader/TCCL | Один `UnifiedClassLoader@84135aa` у mod fixtures, N9Ezz, клиента, мира, игрока, сервера и network handler |
| Клиентские START/END тики | 3698 сбалансированных пар, ordering failures 0 |
| World/player callbacks | 3500 с настоящими миром и локальным игроком |
| Серверные START/END тики | 3500 сбалансированных пар, ordering failures 0; последний world sample дополнительно показывает server counter 3580 |
| World rendering | 1669 завершённых кадров в последнем sample, reported ordering failures 0 |
| Реальные игровые события | CLIENT_STARTED, SERVER_STARTING/STARTED, network INIT/JOIN и смена мира |
| Demo pause | Обычный vanilla Continue Playing handler вызван в 20:47:59 UTC; далее `screen=none`, сервер продолжает тики |
| Встроенный N9Ezz | Инициализация завершена, 113 модулей в registry; Aura, Triggerbot и Hitboxes зарегистрированы |
| Read-only LocalHitboxProbe | 26 PASS, production geometry согласуется с vanilla Box, физические bounds игрока не изменены |

Числа — реально записанные контрольные точки, не оценка по длительности
процесса. Прохождение parser tests не использовалось вместо игрового запуска.
Наблюдение advancing server ticks показывает отсутствие прежней остановки на
demo modal; короткий прогон не считается длительным игровым тестированием.

Геометрический наблюдатель использует настоящие размеры/глаза локального
игрока и вычисляемые числовые коробки. Он не добавляет сущности, не вызывает
Aura/Triggerbot и не атакует другого игрока. В log сохранены
`attackPacketsTested=false`, `liveRemoteTargetSelectionTested=false`.

Raw evidence: `game-0.4.0-result.json`, `world-0.4.0-result.json`,
`cross-platform-0.4.0-result.json`, `cross-platform-0.4.0-fixtures.json`,
`game-0.4.0-launch.log` и `embedded-hitbox-0.4.0-result.json` в `docs/`.

`cross-platform-fixtures.json` сохраняет source/JAR hashes и команды javac.
Fabric fixture скомпилирован с официальным Loader 0.19.2, Quilt — с Loader
0.30.1; NeoForge — с официальными FML 10.0.36, Bus 8.0.5 и MergeTool API 2.0.0
перед собственным API в classpath. Quilt QSL callback shapes предоставлены
собственным ограниченным API, поскольку QSL 1.21.11 не подтверждён. Forge
fixture скомпилирован против собственного source-derived facade; отдельного
подтверждения upstream Forge binary ABI это не даёт.

Исходники и установщик отдельно собираются из распакованного архива.
Фактический результат побайтного сравнения JAR и source ZIP записывается во
внешние `RELEASE-MANIFEST.md` и `dist/tests-0.4.0/reproduction.json` после
фиксации исходников. Архив исходников не содержит собственного checksum.

Полный встроенный клиент остаётся SHA-256
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
Новые слои не изменяют production module/packet logic или base client.
Чистых Pulse sources нет: host остаётся pinned binary input, а не полностью
пересобираемый из supplied sources компонент.

## Официальная доступность и ограничения

Forge official metadata/index сейчас HTTP 200: latest 61.2.1, recommended
61.2.0. Конкретные installer/universal/sources/POM paths остаются HTTP 403;
изученный source API не является полученным Forge runtime binary. Правильный
QSL aggregate metadata содержит 144 версии и не содержит +1.21.11. Это
не отсутствие любых отдельных модулей; stock aggregate/QSL1.21.11 здесь
не подтверждён. Neo FML/Bus official binary pins проверены отдельно.
Точные ответы и времена — в [completion-blockers.md](completion-blockers.md).

Остаются unsupported: stock QSL/ранние registries, Forge/NeoForge game
patches и полный registry/global-event surface, JavaFML/module/AT/JarJar
semantics вне subset, general official/SRG/named mod remapping, dedicated
server bootstrap и arbitrary third-party mods. Моды с отсутствующими API
должны получить диагностику, а не фиктивную platform compatibility.
Local geometry не доказывает target acquisition против другого игрока,
attack packet, damage, PvP, authenticated remote multiplayer или direct
command dispatch. Маскирование сетевых packets не реализуется.

Контракты:
[compatibility.md](compatibility.md),
[quilt-game-contract.md](quilt-game-contract.md),
[fml-game-contract.md](fml-game-contract.md),
[cross-platform-probe.md](cross-platform-probe.md),
[client-hitbox-local-qa.md](client-hitbox-local-qa.md).
Сохранённые [0.3.1 results](release-test-report-0.3.1.md) и
[0.3.0 world report](world-probe-results.md) остаются историческими.
