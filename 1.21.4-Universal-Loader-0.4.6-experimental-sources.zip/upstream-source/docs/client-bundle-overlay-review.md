# Проверенный class overlay для встроенного N9Ezz 1.5.3

Проверено 7 октября 2026 года в Java 21. Это обновление полной сохранённой
клиентской сборки, включающее исправления Hitboxes/Triggerbot/KillAura из `client/`.
Оно выполняется отдельным `universal-loader/tools/MergeBundledClient.java`.
`MergeClient` повторно не выполнялся. Исходный полный JAR сохранён без изменений.

## Входы и результат

| Файл | SHA256 | Размер |
| --- | --- | ---: |
| Сохранённый полный `1.5.3-n9ezz` | `2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb` | 41069456 |
| Remapped addon из исправленных исходников | `80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206` | 171746 |
| Обновлённый полный клиент | `2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424` | 41062124 |

Входы закреплены в коде updater по SHA256; любой другой host или overlay отвергается.
Сборка Universal Loader включает снимки этих входов в `universal-loader/inputs/`,
чтобы повторение updater не зависело от отсутствующей чистой Pulse-базы.
`fabric.mod.json` сохраняет id `pulse`, version `1.5.3-n9ezz`, Minecraft `1.21.11`,
Java `>=21` и существующий `All-Rights-Reserved`. Метаданные overlay
`n9ezz_overlay` не переносятся в полный клиент.

## Почему обычное копирование небезопасно

Host содержит `Targeting=d`, `Attacks=e`, `KillAura=u0`, `Triggerbot=u1`,
`Hitboxes=u3`, а addon содержит исходные имена. Кроме того, старый
`ObfuscateClient` переименовал private fields в `fN`, private methods и helper
methods в `mN`. Копирование исходного `KillAura.class` не заменяет реально
зарегистрированный `u0`; частичная замена `N9Ezz.class` оставляет несовместимые
типы и ссылки на старые методы.

Updater заменяет **весь существующий `pulse/n9ezz` subsystem** за одну операцию:
79 существующих class entries и только три новых `TargetGeometry` class entries.
Он использует фиксированные class aliases из исходного `ObfuscateClient` и
его правило member remapping. Все internal callers, включая lambda/method
handles и nest classes, переписываются ASM `ClassRemapper` совместно с callees.
Private/member mappings приведены полностью в
`docs/client-bundle-overlay-symbols-report.txt`.

Старые номера helper methods `d.mN`/`e.mN` зависят от порядка methods в classfile;
после добавления новых methods номер может измениться. Сохранённый host не
содержит внешних calls к этим helper methods. Их internal callers заменены
совместно. Это не сохраняет сторонний неофициальный ABI модов, которые напрямую
вызывают private/helper implementation. Public module settings и существующие
host hooks сохраняют имена и descriptors.

Новые строковые constants не упаковываются повторно. Старый host использует
`StringCodec.decode`, который принимает и упакованные старые, и обычные новые
strings. Исходный source не использует reflection по переименованным N9Ezz
members. Reflection в `FriendSupport`/`ConfigSnapshots` обращается к неизменным
Pulse host members (`FriendsPanel.s/e`, `LocalConfigManager.applying`, и т. п.).
Это проверено чтением source/bytecode, без исполнения клиентских классов.

## Что сохраняется и что проверено

- Все **988 entries вне `pulse/n9ezz`** byte-identical: `fabric.mod.json`,
  `pulse.mixins.json`, `n9ezz.mixins.json`, `Minecraft-refmap.json`, manifest,
  шесть nested dependency JAR, assets и классы Pulse. Из всех старых entries
  997 byte-identical; 70 subsystem class bytes изменились, девять replacements
  получились одинаковыми.
- 35 host calls к N9Ezz сохранили exact owner/name/descriptor и public/static
  access contract. Это `ModuleRegistry -> N9Ezz.modules`, hooks Stars,
  InterfaceMode, FriendSupport и StringCodec. Host class bytes не меняются,
  поэтому новых hook calls и повторной регистрации в host нет.
- Все 2593 references к N9Ezz members в результирующем archive разрешаются.
  Включены `invokedynamic` bootstrap handles и постоянные method handles.
- Все десять существующих Mixin classes сохранили exact `@Mixin`, injection,
  accessor targets и method annotations. Список Mixin и refmap не меняются;
  новые Mixin declarations не добавлены. Method bodies используют обновлённую
  согласованную геометрию.
- Все 82 replacement/addition classes прошли `CheckClassAdapter` и ASM
  `Analyzer<BasicValue>(BasicVerifier)`. Class version не превышает Java 21.
- ZIP entry duplicates, class identity/path mismatch, неизвестные новые classes,
  пропущенный старый class, изменённые injection contracts, подпись host,
  неверные SHA256 и запись поверх существующих output/report отвергаются.
- Два независимых merges дали одинаковый output SHA256. Black-box suite
  `tools/test_client_bundle.py` прошёл **8 checks**: pins, exact entry set,
  host bytes, metadata/Mixin count, повторяемость, отказ overwrite, отказ
  изменённому addon до создания output и сохранность обоих входов.

Без Minecraft на tool classpath updater допускает лишь baseline-proven,
неизменные inherited references двух полей `CombatInputMixin` из Minecraft
`Input`: `field_55868` и `field_54155`, с тем же superclass и descriptor.
Отдельная повторная проверка с cached Minecraft 1.21.11 intermediary JAR
разрешила оба symbols: `baselineInheritedGameMembers=0`. Итоговый клиентский
SHA256 при этом совпал. Это symbol verification; код клиента не запускался.

## Воспроизведение

Основная команда из корня проекта:

```sh
python3 universal-loader/build.py --offline
```

Сборка компилирует updater с `javac --release 21`, использует locked ASM
core/tree/analysis/util/commons 9.9.1 и Gson 2.13.2, затем вызывает
`MergeBundledClient <pinned-host.jar> <pinned-overlay.jar> <new-output.jar>`.
Gson нужен только для чтения superclass `TypeToken` в symbol verifier.
Updater читает class bytes и JDK/dependency resources; mod entrypoints,
`<clinit>` и клиентские methods не выполняются.

## Проверенные пределы

Получен **полный обновлённый Fabric-клиент**, пригодный для включения в один
установочный JAR. Это устраняет прежний packaging gap, когда выдавался только
addon overlay. Исходная рабочая сборка не заменяется.

Согласованная targeting geometry проверена ранее 3036 geometry checks;
общие source suites дали 34614 checks и addon compile/remap прошёл. Реальное
исполнение новых PvP fixtures в игровом мире и packet capture не проводились.
Мы не заявляем, что gameplay поведение уже проверено на сервере.

Включение полного клиента в Universal Loader **не подтверждает исполнение
клиента в собственном ядре**. Client требует Fabric API, intermediary mappings,
Mixin и nested dependency support; ядро пока отвергает его до entrypoints.
Four-platform runtime compatibility, N9Ezz gameplay и server acceptance остаются
незавершёнными отдельными задачами. Упаковка не скрывает этот статус.

## Точный class alias map

```text
pulse/n9ezz/AimBot -> pulse/n9ezz/u2
pulse/n9ezz/AntiBot -> pulse/n9ezz/u25
pulse/n9ezz/AntiWeb -> pulse/n9ezz/u24
pulse/n9ezz/AttackClock -> pulse/n9ezz/c
pulse/n9ezz/Attacks -> pulse/n9ezz/e
pulse/n9ezz/AutoArmor -> pulse/n9ezz/u13
pulse/n9ezz/AutoGapple -> pulse/n9ezz/u11
pulse/n9ezz/AutoHeal -> pulse/n9ezz/u12
pulse/n9ezz/AutoMace -> pulse/n9ezz/u15
pulse/n9ezz/AutoRefill -> pulse/n9ezz/u14
pulse/n9ezz/AutoShield -> pulse/n9ezz/u10
pulse/n9ezz/AutoTotem -> pulse/n9ezz/u4
pulse/n9ezz/AutoWeapon -> pulse/n9ezz/u9
pulse/n9ezz/BowRelease -> pulse/n9ezz/u16
pulse/n9ezz/CombatMath -> pulse/n9ezz/a
pulse/n9ezz/Criticals -> pulse/n9ezz/u7
pulse/n9ezz/CrystalAura -> pulse/n9ezz/u28
pulse/n9ezz/Friends -> pulse/n9ezz/u6
pulse/n9ezz/Hitboxes -> pulse/n9ezz/u3
pulse/n9ezz/IncreasedDamage -> pulse/n9ezz/u5
pulse/n9ezz/KillAura -> pulse/n9ezz/u0
pulse/n9ezz/MissSequence -> pulse/n9ezz/b
pulse/n9ezz/NoPush -> pulse/n9ezz/u22
pulse/n9ezz/NoSlow -> pulse/n9ezz/u23
pulse/n9ezz/PearlThrow -> pulse/n9ezz/u18
pulse/n9ezz/ProjectileAim -> pulse/n9ezz/u17
pulse/n9ezz/Reach -> pulse/n9ezz/u27
pulse/n9ezz/SectionTransition -> pulse/n9ezz/f
pulse/n9ezz/ShieldBreaker -> pulse/n9ezz/u8
pulse/n9ezz/TargetStrafe -> pulse/n9ezz/u20
pulse/n9ezz/Targeting -> pulse/n9ezz/d
pulse/n9ezz/TeamCheck -> pulse/n9ezz/u26
pulse/n9ezz/Triggerbot -> pulse/n9ezz/u1
pulse/n9ezz/Velocity -> pulse/n9ezz/u21
pulse/n9ezz/WTap -> pulse/n9ezz/u19
pulse/n9ezz/WebTrap -> pulse/n9ezz/u29
```

## Точный список replacements/additions

Только `TargetGeometry`, `TargetGeometry$Bounds`, `TargetGeometry$Point` новые;
остальные 79 entries заменяют существующие classes.

```text
pulse/n9ezz/AimSmoothing$Turn.class
pulse/n9ezz/AimSmoothing.class
pulse/n9ezz/Attacks$Options.class
pulse/n9ezz/Attacks$Pending.class
pulse/n9ezz/CheatModule.class
pulse/n9ezz/CombatDispatch.class
pulse/n9ezz/CombatInventory.class
pulse/n9ezz/CombatItems$1.class
pulse/n9ezz/CombatItems.class
pulse/n9ezz/CombatRules$CriticalDecision.class
pulse/n9ezz/CombatRules.class
pulse/n9ezz/CombatTargets.class
pulse/n9ezz/ConfigCommands.class
pulse/n9ezz/ConfigSnapshots$1.class
pulse/n9ezz/ConfigSnapshots.class
pulse/n9ezz/ConsumableUse.class
pulse/n9ezz/FriendSupport.class
pulse/n9ezz/HitboxVisuals.class
pulse/n9ezz/InterfaceMode.class
pulse/n9ezz/LegacyConfigs.class
pulse/n9ezz/N9Ezz.class
pulse/n9ezz/NetworkPreset.class
pulse/n9ezz/PowerCurve$Level.class
pulse/n9ezz/PowerCurve.class
pulse/n9ezz/PowerModes.class
pulse/n9ezz/PowerProfiles$Profile.class
pulse/n9ezz/PowerProfiles.class
pulse/n9ezz/PvPMath.class
pulse/n9ezz/PvPModule.class
pulse/n9ezz/SlotOwnership.class
pulse/n9ezz/Stars.class
pulse/n9ezz/StringCodec.class
pulse/n9ezz/TargetGeometry$Bounds.class
pulse/n9ezz/TargetGeometry$Point.class
pulse/n9ezz/TargetGeometry.class
pulse/n9ezz/ViewMotion.class
pulse/n9ezz/a.class
pulse/n9ezz/b.class
pulse/n9ezz/c.class
pulse/n9ezz/d.class
pulse/n9ezz/e.class
pulse/n9ezz/f.class
pulse/n9ezz/mixin/AimFrameMixin.class
pulse/n9ezz/mixin/AttackCallbackMixin.class
pulse/n9ezz/mixin/CombatEntityMixin.class
pulse/n9ezz/mixin/CombatInputMixin.class
pulse/n9ezz/mixin/CombatTickMixin.class
pulse/n9ezz/mixin/NoSlowMixin.class
pulse/n9ezz/mixin/PlayerDamageMixin.class
pulse/n9ezz/mixin/ProjectileTargetMixin.class
pulse/n9ezz/mixin/ReachMixin.class
pulse/n9ezz/mixin/SlotSyncAccessor.class
pulse/n9ezz/u0.class
pulse/n9ezz/u1.class
pulse/n9ezz/u10.class
pulse/n9ezz/u11.class
pulse/n9ezz/u12.class
pulse/n9ezz/u13.class
pulse/n9ezz/u14.class
pulse/n9ezz/u15.class
pulse/n9ezz/u16.class
pulse/n9ezz/u17.class
pulse/n9ezz/u18.class
pulse/n9ezz/u19.class
pulse/n9ezz/u2.class
pulse/n9ezz/u20.class
pulse/n9ezz/u21.class
pulse/n9ezz/u22.class
pulse/n9ezz/u23.class
pulse/n9ezz/u24.class
pulse/n9ezz/u25.class
pulse/n9ezz/u26.class
pulse/n9ezz/u27.class
pulse/n9ezz/u28.class
pulse/n9ezz/u29.class
pulse/n9ezz/u3.class
pulse/n9ezz/u4.class
pulse/n9ezz/u5.class
pulse/n9ezz/u6.class
pulse/n9ezz/u7.class
pulse/n9ezz/u8.class
pulse/n9ezz/u9.class
```
