# Облачная среда N9Ezz

Подготовлены полный Temurin JDK 21.0.8+9, locked зависимости ядра и клиентские
input JAR. Сборка и перечисленные проверки выполнены в текущей машине.
Для работы с ядром постоянно запущенные сервисы не требуются.

```sh
source /workspace/toolchains/activate-temurin21.sh
cd /workspace/N9Ezz
python3 universal-loader/build.py --offline
```

В черновик конфигурации среды сохранены `install_script` и `start_skill` через
`cloud-environment-onboarding:setup`. Скрипт активирует Java 21, проверяет
`ct.sym` и выполняет сборку с pinned inputs/dependencies. Startup-инструкции
фиксируют working directory, обязательные проверки, сохранение baseline и
ограничения общего runtime. Настройки сети и репозиториев этим обновлением
не заменялись; секреты не требуются для core/test workflow.

Сохранение черновика подтверждено инструментом (`status: saved`). Оно само
не выполняет скрипт и не публикует среду. Для применения в новых задачах
пользователю нужно сохранить изменения в настройках среды и опубликовать её.
Восстановление в новой задаче отдельно не проверялось.

Startup-инструкции обновлены 9 октября 2026 года для 0.4.1:
`status: saved`, `requires_publish: true`. Новый внешний контракт требует
n9ezz.mod.json; прежний cross-platform runner относится к 0.4.0 и не
используется для нового JAR. Текущий проверенный runner:

```sh
python3 universal-loader/scripts/world_probe.py --loader universal-loader/dist/N9Ezz-Universal-Loader-0.4.1-experimental.jar --seconds 180 --name n9ezz-validation --demo-world
```

Он использует два собственных native observer mod и обычный Play Demo handler.
Нужно проверять оба result/world-result JSON и учитывать паузу demo modal.
Основной install_script сохраняет проверенную полную offline-сборку.
Сохранение черновика не означает публикацию или проверку новой машины.

Опциональный Xvfb/OpenGL smoke использует `/workspace/minecraft-smoke/host`.
Его процессы нужно запускать заново после восстановления среды по
`host/README.md`; живой процесс не считается частью сохраняемого snapshot.
Для smoke нужны реальные vanilla client/libraries/assets, Xvfb, software
OpenGL, `XCURSOR_THEME=breeze_cursors` и `ALSOFT_DRIVERS=null`.
Новая общая среда уже запустила встроенный N9Ezz, загрузила его native resource
pack, дошла до меню и demo world, зарегистрировала 30 addon modules и
подтвердила порядок client/server/network/render callbacks. Эти результаты
принадлежат конкретным проверенным бинарникам; подробности и оставшиеся
gameplay-ограничения находятся в [latest-runtime-status.md](latest-runtime-status.md)
и [release-test-report-0.4.1.md](release-test-report-0.4.1.md). Живые игровые процессы,
offline demo session и downloaded game cache не являются доказательством
восстановимости нового cloud snapshot.
