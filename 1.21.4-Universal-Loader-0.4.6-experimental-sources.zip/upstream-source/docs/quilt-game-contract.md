# Ограниченный игровой слой Quilt в общей среде N9Ezz

Слой реализован собственным Java-кодом N9Ezz поверх общей среды, общей таблицы
`official → intermediary` и одного `UnifiedClassLoader`. Он не запускает Quilt
Loader, Quilt plugins, Knot или отдельный движок. Базовый публичный ABI проверен
по Quilt Loader `0.30.1`, commit
`b33861b30a815f327652015018d2d1262f12b63a`.

## Явный контракт мода

Для игрового запуска требуется `quilt.mod.json` schema 1 с обычными Quilt
метаданными и собственным расширением в корне:

```json
{
  "schema_version": 1,
  "quilt_loader": {
    "group": "example",
    "id": "example_quilt",
    "version": "1.0.0",
    "intermediate_mappings": "net.fabricmc:intermediary",
    "entrypoints": {
      "init": ["example.QuiltClient"],
      "client_init": ["example.QuiltClient"]
    },
    "depends": [
      {"id": "quilt_loader", "versions": "=0.30.1"},
      {"id": "minecraft", "versions": "=1.21.11"}
    ]
  },
  "n9ezz": {"compatibility": "quilt-lifecycle-v1"}
}
```

Поле `n9ezz.compatibility` означает явное согласие автора мода с ограниченным
порядком инициализации. Оба callback выполняются на клиентском потоке в
подтверждённой точке конструктора Minecraft перед созданием GameOptions:
сначала все `common`, затем все `client`, затем общий `READY`. Один класс,
указанный в обеих фазах, получает один экземпляр; передаваемый `ModContainer`
также является одним каноническим объектом. Ресурсы и классы остаются в общей
среде с другими форматами модов.

Это сознательно более узкий lifecycle, чем QSL. Исследованный QSL вызывает
`init` в `Bootstrap.bootstrap()` перед замораживанием встроенных registries.
N9Ezz не заявляет эту раннюю точку как реализованную. Контракт
`quilt-lifecycle-v1` предназначен для **инициализаторов, не зависящих от ранней
регистрации игровых объектов**. API регистрации/QSL registry отсутствуют;
прямые ссылки на них отклоняются до инициализации модов. Учитывать такой мод
как совместимый со штатным QSL на основании совпадения двух интерфейсов нельзя.

Допускаются namespaces `intermediary` и `none`; `named`, Quilt named mappings,
hashed intermediary и remapping refmap из другого namespace не поддержаны.
Требуется обязательная зависимость `quilt_loader`, допускающая проверенный ABI
`0.30.1`; общая система зависимостей проверяет Minecraft и остальные требования.
Нестандартные language adapters и другие entrypoint фазы отклоняются. Stock QSL
dependency provider не добавляется: `qsl`/`quilt_base` не являются builtin-модами.

## Поддержанные публичные сигнатуры

| Тип | Поддержанный API |
| --- | --- |
| `org.quiltmc.loader.api.QuiltLoader` | Статические `getModContainer(String)`, `getModContainer(Class<?>)`, `getAllMods()`, `isModLoaded(String)`, `getGameDir()`, `getConfigDir()`, `getCacheDir()`, `getRawGameVersion()`, `getNormalizedGameVersion()`, `isDevelopmentEnvironment()`, `getGameInstance()`, `getMappingResolver()` |
| `ModContainer` | `metadata()`, `rootPath()`, `getPath(String)`, `getSourcePaths()`, `getSourceType()`, `getClassLoader()` |
| `ModContainer.BasicSourceType` | `NORMAL_QUILT`, `NORMAL_FABRIC`, `BUILTIN`, `OTHER` и стандартные методы enum |
| `ModMetadata` | `id()`, `group()`, `version()`, `name()`, `description()` |
| `Version` | Только `raw()`; semantic parsing/comparison и вложенные semantic типы не предоставляются |
| `MappingResolver` | Шесть штатных методов: `getNamespaces`, `getCurrentRuntimeNamespace`, `mapClassName`, `unmapClassName`, `mapFieldName`, `mapMethodName` |
| `org.quiltmc.qsl.base.api.entrypoint.ModInitializer` | `ENTRYPOINT_KEY="init"`, `void onInitialize(ModContainer)` |
| `org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer` | `ENTRYPOINT_KEY="client_init"`, `void onInitializeClient(ModContainer)` |

Quilt-сервисы публикуют контейнеры общей разрешённой коллекции модов, включая
Fabric/N9Ezz/Forge/NeoForge, если соответствующие игровые контракты включены.
Для Quilt group/name/description читаются из оригинального metadata. Другие
форматы не получают выдуманного Quilt group. Builtin `quilt_loader` обозначает
публичный ABI N9Ezz, а не присутствие штатного Quilt engine. Builtin-контейнеры
не имеют архивного root и собственного classloader.

`getModContainer(Class<?>)` подтверждает classloader и реальный CodeSource.
Класс из другой среды с тем же именем/архивом не считается принадлежащим этому
runtime. При нескольких mod ID в одном архиве однозначного владельца класса
нет, и возвращается пустой результат. Для извлечённых nested JAR
`getSourcePaths()` отражает фактический используемый архив, без выдуманной цепи
исходных контейнеров. `getPath()` принимает безопасный относительный путь;
абсолютные пути, обратные слеши, `.`/`..` и пустые сегменты отклоняются.

Коллекции контейнеров, aliases и source paths неизменяемы. Архивные NIO
filesystems закрываются вместе с сессией; до установки и после закрытия доступ
к QuiltLoader прекращается. Game instance привязывается один раз перед
callback и должен использовать тот же classloader. Повторная параллельная
установка сервиса не заменяет действующий runtime.

## Предварительные проверки

`QuiltGameContract.validate` обходит **все классы** Quilt JAR до выполнения
пользовательских initializer. Проверяется белый список классов, методов и
полей `org.quiltmc` с точными JVM descriptors, включая аннотации, generic
сигнатуры, method handles, invokedynamic и constant-dynamic arguments.
Неизвестные QSL API, Quilt implementation classes, неверная сигнатура знакомого
метода, неподдержанный namespace/ABI и отсутствие opt-in дают структурированную
ошибку с mod ID, архивом и фазой `quilt-preflight`. Multi-release Quilt моды
отклоняются. Пределы: 20 000 классов, 16 MiB на класс, 1 MiB metadata.

Произвольные ссылки, построенные через reflection из runtime-строк, невозможно
доказать статическим анализом. Они не получают отсутствующие API и завершатся
обычной диагностикой linkage/initializer. Проверка известного subset не является
обещанием совместимости произвольных Quilt-модов.

## QSL, доказательства и лицензия

Публичные callback descriptors взяты из официальных исходников QSL commit
`fef35afe5fb046e6339a3dfc8478a65b5bfce3bc`, ветка `1.21.5`. В её
`Versions.java`: QSL `10.0.0-alpha.4`, Minecraft `1.21.5`, Java 21.
Изученный source audit не обнаружил ref для `1.21.11`; опубликованный штатный
QSL JAR для `1.21.11` здесь не скачан и не проверен. Перенос двух ABI интерфейсов
на новую общую среду не превращает старую библиотеку в проверенный QSL1.21.11.
Полные QSL/QFAPI, registry/resource/lifecycle/networking modules отсутствуют.

`QuiltCompatibilityTests` проверяет opt-in и ограничения, реальные NIO archive
views, metadata/aliases, provenance, lifecycle binding, конкурирующие установки,
cleanup и скрытые в не-entrypoint классах неподдержанные API. Игровые результаты
совместной загрузки Quilt fixture с другими форматами публикуются в отдельном
отчёте конкретного запуска; unit fixtures сами по себе этот запуск не доказывают.

API descriptors адаптированы по Apache-2.0: Quilt Loader сохраняет Copyright
2016 FabricMC и Copyright 2022-2023 QuiltMC; QSL callbacks — Copyright 2022 The
Quilt Project. В исходниках отмечены изменения и авторство API; полный текст
Apache-2.0 уже включён в `universal-loader/licenses`. `QuiltRuntime` и
`QuiltGameContract` — собственные реализации N9Ezz; upstream engine implementation
не переносился. См. также [аудит исходников](fabric-quilt-audit.md).
