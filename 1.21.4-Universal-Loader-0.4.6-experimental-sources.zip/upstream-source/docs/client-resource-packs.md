# Built-in client resources in the shared runtime

The original corrected client JAR stays byte-identical. Its `assets/` files were available through the Java classloader but were absent from Minecraft's `ResourceManager`; classpath availability alone does not register a resource pack. The supplied client contains 398 assets (47,203,943 uncompressed bytes) in `pulse` and `minecraft` namespaces, including `pulse:textures/splash_logo.png`.

`ModResourcePacks` supplies one native Minecraft resource-pack provider inside the shared runtime. It does not launch Fabric Loader or add Fabric resource-loader modules. Java 21 compiles the adapter without a game JAR dependency. Runtime reflection calls the pinned Minecraft 1.21.11 intermediary API:

| Mechanism | Exact boundary |
| --- | --- |
| Injection | `class_310.<init>(class_542)` before its only `class_3283.<init>(class_3285[])` invocation |
| Provider | A proxy implementing native `class_3285.method_14453(Consumer)` |
| Factory | Native `class_3258$class_8615(Path)` (`ZipResourcePack.ZipBackedFactory`) |
| Metadata/profile | `class_9224`, `class_9225`, `class_3288.method_45275` |
| Activation | Required, pinned, `BOTTOM`; normal vanilla manager activation and normal user pack priority |
| Resource type | Client assets (`class_3264.field_14188`) only |

The CORE transform checks one exact client constructor, one provider array, and one manager constructor invocation. A changed shape or repeated installation fails with a diagnostic. The server resource and data-pack manager constructors are untouched.

Only the verified built-in archive can acquire this role: SHA-256 `2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`, size 41,062,124. An external mod with the same ID is insufficient. `prepare(gameDir, orderedMods)` verifies the whole source archive before and after export. The adapter writes a deterministic resources-only ZIP in `.n9ezz/cache/resources`, with sorted, stored entries and fixed timestamps. It exports all original asset bytes and generates `pack.mcmeta` for resource version 75.0 from official Minecraft 1.21.11 `version.json`. No classes, nested mod JARs, or `data/` entries enter this ZIP. Source metadata is replaced only in the generated cache ZIP; no source/client modification occurs.

Export is bounded to 8,192 files, 16 MiB per asset, 128 MiB total, and 1,024 characters per path. Duplicate entries, unsafe paths, invalid namespaces, cache path traversal, and symlink cache directories fail. The game directory itself is resolved to its canonical path first, so a legitimate launcher game-directory alias works. Cache reuse compares size and full hash against freshly generated deterministic bytes; corrupt cache files regenerate from the original archive. Hash reads also have a total bound. Profile creation checks the cached resource ZIP hash. Native Minecraft code owns and closes the opened packs.

`ResourcePackTests` covers export identity and determinism, cache corruption, hostile paths/limits, hook shape and duplicate guards, non-target class behavior, runtime lifecycle and the built-in archive trust boundary. The standalone fixture suite passed 27 checks; the release build passed 29 with the actual corrected client, and a separate run with mapped 1.21.11 game bytes passed 30. These include all 398 assets and the splash resource. `NativeResourcePackProbe` additionally passed three real Minecraft checks (process exit 0): metadata accepted as compatible/required/pinned, native manager automatically enabled `n9ezz/builtin/pulse`, and native ZipResourcePack returned the exact 3,127 original splash PNG bytes. These native tests are separate from the full shared-runtime launch.

The final immutable installer (SHA-256 `b52e9c071753fd453f633e65e11fb979179f8674309f730dbd41c97471b847b9`) also passed a real 300-second demo-world run. ResourceManager reloaded `n9ezz/builtin/pulse, vanilla`, and inspected menu/world screenshots show correct assets without the earlier missing-texture pattern. The same runtime recorded 2042 balanced world-render frame pairs with zero ordering failures. See [world-probe-results.md](world-probe-results.md) for raw evidence, the preserved initial harness false negative, and the corrected analysis of the unchanged game log.

The design was compared against official Fabric resource-loader-v1 `1.0.10+78c8b4663e`, in particular `ModResourcePackCreator` and `ModPackResourcesUtil`. Source JAR SHA-256: `5f88ee33c6afacb050cc44b4f13635cd70dc19051dfc2084f8226d9ef40dba1f`. No upstream implementation code was copied into this adapter. Resource assets remain supplied by the existing client and retain their existing license conditions.

Limitations: this is an exact built-in client asset bridge. It does not implement Fabric resource-loader-v0/v1 APIs, arbitrary external mod resource packs, resource reload dependency APIs, `fabric:resource_load_order`, optional built-in packs, world data packs, known-pack networking, or resource format conversion. The required pack is visible to Minecraft's normal resource-pack UI. The successful bounded demo run does not establish arbitrary external resource compatibility or combat/PvP behavior.
