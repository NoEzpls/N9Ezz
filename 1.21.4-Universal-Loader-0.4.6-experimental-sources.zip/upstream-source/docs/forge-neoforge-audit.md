# Аудит Forge и NeoForge для N9Ezz Universal Loader

Дата проверки: 2026-10-07. Проверялись официальные исходники, а не совместимость готовых модов. Ни Forge, ни NeoForge не запускались внутри N9Ezz в рамках этого аудита.

## Наличие версии 1.21.11 и фиксированные исходники

| Компонент | Официальный источник и проверенный commit | Что подтверждено |
| --- | --- | --- |
| Forge | [MinecraftForge/MinecraftForge](https://github.com/MinecraftForge/MinecraftForge/tree/1dab50ca003abc59e4115a329bcb46f76c105e15), branch `1.21.11` | `minecraft.versions.toml`: Minecraft `1.21.11`, Java `21`, official mappings `1.21.11`, MCP `20251223.124241`. Git содержит tags `61.0`, `61.1`, `61.2`; это исходные опорные tags, а не подтверждение конкретного доступного installer JAR. |
| Forge ModLauncher | [MinecraftForge/ModLauncher](https://github.com/MinecraftForge/ModLauncher/tree/b5f35aa3d7a6369e13053b1fbb165796ab8b8bb1) | Forge `settings.gradle` закрепляет `10.2.6`. У этого commit ровно шесть commits после tag `10.2`; метаданные опубликованного Maven артефакта не получены. |
| NeoForge | [neoforged/NeoForge](https://github.com/neoforged/NeoForge/tree/bef35d56255d4cb4a3aa58e1f4c27b41c61d3000), branch `1.21.11` | `gradle.properties`: Minecraft `1.21.11`, Java `21`, NeoForm `20251209.172050`, FancyModLoader `10.0.36`. Git содержит tag `21.11` → `28c765fc63a63336042b8c2ac40ece046a36bc78` и `21.11-stable` → `d877fabef010befbe4d5babb0adfe3c0eca78530`. Наличие stable tag не заменяет проверку installer JAR. |
| FancyModLoader `10.0.36` | [neoforged/FancyModLoader](https://github.com/neoforged/FancyModLoader/tree/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5) | Ровно 36 commits после tag `10.0`; позднее publisher-checksum-verified Maven JAR подтвердил `Build-Number: 10.0.36`, `Git-Commit: 805fe3e7`. Код закрепляет Java 21 и Mixin `0.16.5+mixin.0.8.7`. |

Машина действительно получила эти репозитории по HTTPS через предоставленный Git proxy. Исходники лежат в `/workspace/research/forge`, `/workspace/research/neoforge`, `/workspace/research/modlauncher`, `/workspace/research/fml10` и не включаются автоматически в дистрибутив N9Ezz.

Официальные страницы GitHub Releases Forge и NeoForge отвечают HTTP 200, но обе сообщают `There aren’t any releases here`: эти проекты публикуют бинарные версии другими каналами. При первоначальной проверке следующие Maven запросы не прошли сетевую политику среды, proxy вернул `Tunnel connection failed: 403 Forbidden`:

- `https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml`
- `https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml`

Эта первоначальная ошибка **больше не описывает NeoForge**: повторная проверка 7 октября 2026, 18:18–18:20 по Москве, получила HTTP 200 с официального Maven. Metadata содержит 45 версий `21.11.*`, последняя в ответе `21.11.45` (release status). POM и Gradle module metadata закрепляют NeoForm `1.21.11-20251209.172050`; installer `install_profile.json` задаёт `minecraft=1.21.11`; representative universal class имеет major 65 (Java21). Скачаны и проверены publisher SHA-256 installer, userdev, sources и universal JAR. Подробные URLs/hashes находятся в [platform-availability.md](platform-availability.md) и [platform-artifact-probes.json](platform-artifact-probes.json).

Published NeoForge `21.11.45` использует FML `10.0.36`, ASM `9.8`, Mixin `0.16.5+mixin.0.8.7`, AT `11.0.2`, EventBus `8.0.5`, JarJar `0.5.0`, MixinExtras `0.5.3`. AT/EventBus/JarJar pins опубликованного POM отличаются от отдельных объявлений проверенной source branch; не подменять ими друг друга при составлении lock.

Forge Maven, официальный downloads index `files.minecraftforge.net/.../index_1.21.11.html` и официальный promotions JSON при последнем повторе всё ещё отвечают HTTP 403. Для Forge подтверждена цель в исходниках, но конкретный binary release, artifact checksums и runtime неизвестны. Доступность NeoForge артефактов не означает его совместимость с N9Ezz. TLS/proxy не обходились, upstream installers не исполнялись, новые ветки `26.x` не использовались для вывода о версии `1.21.11`.

## Сравнение механизмов

| Область | Forge 1.21.11 | NeoForge 1.21.11 / FML 10 | Следствие для общего ядра |
| --- | --- | --- | --- |
| Bootstrap | Forge Bootstrap `2.1.8` → ModLauncher `10.2.6` → FML launch service; клиент запускает `net.minecraft.client.main.Main` из game module. | FML `create(StartupArgs)` строит собственную среду; самостоятельные BootstrapLauncher и ModLauncher уже удалены. Есть instrumentation guardian и маскирование game classes, доступных в parent classpath. | N9Ezz имеет один собственный bootstrap. Подключение upstream main classes/launch services означало бы второй runtime; такие механизмы нельзя объявлять совместимыми адаптерами. |
| Class loading | JPMS layers `BOOT`, `SERVICE(BOOT)`, `PLUGIN(BOOT)`, `GAME(PLUGIN,SERVICE)`; `SecureModuleClassLoader`, `SecureJar` и transforming game loader. Mod container находит `Class.forName(module, className)`, а не просто класс по имени. | Собственные `JarContentsModule`, `ModuleClassLoader` и `TransformingClassLoader`; early service/plugin URLClassLoader и общий game layer. Child first для packages своих modules, module visibility и masking имеют значение. | Единственное определение каждого game/mod/API класса, проверка duplicates до `defineClass`, контроль parent delegation и service providers. При отсутствии JPMS semantics моды, требующие module APIs, должны отклоняться с объяснением. |
| Mappings | `minecraft.versions.toml` и build указывают runtime official mappings; историческое имя namespace в `ForgeProdLaunchHandler` — `mcp`. `build.gradle` явно отмечает remaining SRG reflection references в dev code. | NeoForm `1.21.11-20251209.172050`; Minecraft patches и NeoForge API используют Mojang names. | `mcp`, `srg`, `official`, `intermediary`, `named` не взаимозаменяемы. Нужны фиксированные per-version mapping inputs и remapping bytecode, descriptors, inheritance, refmaps, access rules. Изменение metadata не исправляет ссылки в class файлах. |
| Transformations | ModLauncher launch plugins BEFORE → voting PRE_CLASS → FIELD → METHOD → CLASS → launch plugins AFTER. У voting есть YES/NO/DEFER/REJECT, audit и deadlock/rejection errors. | FML graph `ClassProcessorSet` с `runsBefore`, `runsAfter`, stable comparator и duplicate name/cycle checks. Access Transformer и runtime enum extender идут до Mixin; default `SimpleProcessorsGroup` после Mixin и computing-frames marker. | Общая собственная pipeline обязана фиксировать stages и constraint graph. Универсальный порядок «все coremods до Mixin» неверен. Unsupported transformer SPI следует отклонять, а не запускать в случайном порядке. |
| Bytecode hierarchy / frames | `TransformerClassWriter` использует байткод промежуточных состояний; при `COMPUTING_FRAMES_REASON` не запускает повторную computation. | `BytecodeProvider` предоставляет состояние до конкретного processor; только processors за `COMPUTING_FRAMES` могут требовать recompute frames. Mixin loaded-class callback вызывается после окончательной обработки, не при hierarchy reads. | Нужны байткод hierarchy lookup без преждевременной загрузки классов, cycle guards, отдельная финальная проверка и диагностика transformer ID/origin. |
| Access rules | AccessTransformers `8.2.17`; FML предлагает ресурсы AT и naming extension. Это изменение access/final; не loader selection. | Source branch объявляет AT `11.0.1`, опубликованный `21.11.45` разрешает `11.0.2`; `[[accessTransformers]]` и fallback `META-INF/accesstransformer.cfg`; собственный service ordered before Mixin. | Fabric/Quilt access wideners и AT нельзя считать одинаковым форматом. Нужен собственный нормализованный access-plan с namespace conversion и явной обработкой несовместимых требований. |
| Mixin | Sponge Mixin `0.8.7`, MixinExtras Forge/common `0.5.4`; integration привязана к ModLauncher services. | Mixin fork `0.16.5+mixin.0.8.7`, MixinExtras `0.5.3`; собственные `FMLMixinService`, `FMLMixinClassProcessor`, class tracker и Java21 minimum. Configs регистрируются после смены thread context loader. | Один Mixin runtime и один service N9Ezz. Нельзя загрузить одновременно разные `org.spongepowered.asm.*`, хотя номер upstream Mixin совпадает. Совместимость refmaps, fork extensions, behaviorVersion и Extras требует отдельных fixtures. |
| Metadata / mod discovery | `META-INF/mods.toml`; `modLoader`, `loaderVersion`, список `[[mods]]`; ASM scan `@Mod`; service locators, jar-in-jar и library/plugin types. | `META-INF/neoforge.mods.toml`, список модов; `[[mixins]]` с `requiredMods`, `behaviorVersion`, AT declarations; candidate locators и jar-in-jar discovery. | TOML parser обязателен: корректные строки, arrays/tables и placeholders, multi-mod JAR. Чтение `modId` и `version` регулярным выражением — только недостоверная диагностика, не полноценный слой. |
| Dependencies | Maven `ArtifactVersion` / `VersionRange`, mandatory/optional, dependency side, BEFORE/AFTER graph. Optional dependency, если установлен неподходящий вариант, может быть ошибкой. Ordering не равен условию присутствия. | Maven semantics; `type = required / optional / incompatible / discouraged`, `reason`, side, ordering; resolver также выбирает/discards mod files. | Общая модель сохраняет required, optional-if-present, prohibited, discouraged и ordering отдельно. Не подменять Maven ordering приблизительным SemVer; неподдержанное выражение fail closed с исходным текстом. |
| Events / construction | В этой ветке EventBus `7.0.5`: `BusGroup` и typed `EventBus`, отдельная mod bus group. Конструктор no-arg или `FMLJavaModLoadingContext`; automatic subscribers после конструкции. | Source branch объявляет EventBus `8.0.2`, опубликованный `21.11.45` разрешает `8.0.5`; `net.neoforged.bus.api.IEventBus`; FML mod container требует один public constructor и injects context/bus/dist, затем subscribers. | Даже Forge и NeoForge больше не имеют общего бинарного event API. Нужны adapters конкретных signature sets; own event bus не заменяет все upstream interfaces. |
| Minecraft runtime hooks | Patched Minecraft classes, registry creation/freezing, game events, networking, resources, capabilities и client hooks — часть Forge. | Собственный patch set, registry and registration events, payload/network lock, resources, capabilities/attachments и client hooks — часть NeoForge. | Установка FML APIs или вызов `@Mod` конструктора не делает полноценный Forge/NeoForge runtime. Нужны собственные game hooks с проверенным поведением для явно поддержанных API. Конфликтующие patches нельзя просто наложить одновременно. |

## Таблица конфликтов и решение для N9Ezz

Статус в последнем столбце описывает объём требуемой реализации, а не заявляет, что он уже завершён.

| Конфликт | Что ломается при прямом объединении | Замена / правило общего ядра | Граница заявляемой поддержки |
| --- | --- | --- | --- |
| Несколько bootstrap и classloader graphs | Разные singleton loader instances, game classes и thread context loaders; casts между одноимёнными классами ломаются. | Свой N9Ezz bootstrap, единый class ownership index, один game loader; platform descriptors → общий мод graph. | Full upstream launcher internals / services не поддерживать без адаптера. |
| Namespace / patch set | Fabric intermediary methods не находятся в Mojang runtime; Forge/Neo patched members отсутствуют в vanilla. | Явный mapping contract для каждой версии и собственные game hooks; diagnostic с namespace/owner/member. | Пустой shim не считается compatibility. Неизвестный mapping source или отсутствующий patched API — отказ запуска. |
| Mixin service discovery | Fabric, Quilt, ModLauncher и FML services борются за global Mixin environment; два Mixin JAR дают duplicates. | Единственный pinned Mixin artifact, собственный service и config registration после фиксации classpath и до game loads. | Fork-specific features и MixinExtras не обещать до проверки fixture. |
| Разный порядок transforms | ModLauncher voting не соответствует FML runsBefore/runsAfter; access updates и frames приходят поздно. | Own stage graph, priorities с устойчивой сортировкой, constraints и cycle diagnostics. Reject непереводимые semantics. | В первом milestone поддерживать свой transformer SPI; чужие coremods отдельно. |
| AW / AT / enum extension | Взаимно несовместимые access/final changes, extension до того как известно имя class; enums расширяются после загрузки. | Объединённый access-plan после mapping, explicit enum phase до Mixin, owner tracing. | Включать только реализованные modifiers и tested targets; unsupported rules — ошибка. |
| SemVer / Maven constraints | `1.0-rc`/`1.0`, ranges/unions и wildcard сравниваются по-разному; optional mods молча пропускаются. | Версионные evaluators платформ сохраняют semantics, итоговая модель constraints едина. | Не делать «примерно работает» с неподдержанным predicate. |
| Одно JAR содержит несколько descriptors / mods | Один и тот же bytecode загружается дважды, mod IDs конфликтуют; dependencies раскрываются по-разному. | JAR origin и классы индексируются один раз; policy для нескольких descriptors явно задана, неоднозначность диагностируется. | Молчаливый выбор первого Fabric/Forge descriptor запрещён. |
| Forge typed BusGroup / Neo IEventBus / Fabric callbacks | Потеря priorities, cancellation, results, deferred work, thread guarantees. | Own event phases плюс отдельные проверяемые adapters каждого API; constructors вызываются один раз. | Поддерживать перечисленные event types/signatures, не всё пространство `net.minecraftforge.*`/`net.neoforged.*`. |
| Registry/game initialization order | Entry point до готовности registry/client; late registrations и wrong-thread Minecraft access. | Own lifecycle barriers и game hooks; dependency-before-dependent, synchronous deferred queue. | Пустой `CLIENT_READY` до запуска Minecraft не доказательство game compatibility. |
| Patched Minecraft methods и side cleaning | Forge/Neo удаляют/меняют разные members, server classes загружаются на client или наоборот. | Собственные эквивалентные hooks и side filters, конфликт на member уровне перед запуском. | Arbitrary Forge/Neo gameplay моды — незавершённая часть до real-game integration. |
| JPMS / split packages / service providers | Module resolver errors или незаметная загрузка parent copy; resource/provider ordering влияет на поведение. | Own class/resource policy, duplicate scan с JAR origin и explicit module support boundary. | Метаданные, которые требуют unsupported module isolation/open/export, отклонять. |

## Реальный порядок upstream lifecycle

Forge source `ModLoader` описывает: construction → automatic subscribers/registry-related phases → config load → common setup → sided setup → enqueue IMC → process IMC → load complete. Инициализация mods использует dependency futures; exceptions прерывают зависимых. Документирующий Javadoc содержит исторические API names, поэтому для реализации нужно опираться и на исполняемые методы соответствующего commit, а не переносить комментарий как актуальную спецификацию.

NeoForge `CommonModLoader` исполняет:

1. `ModLoader.gatherAndInitializeMods` (construction и `FMLConstructModEvent`, dependency futures, deferred work).
2. New registry event → unfreeze → register events → freeze.
3. Client/common config load (кроме datagen), старт game event bus.
4. Parallel common setup, parallel sided setup, subsequent registration events.
5. Enqueue IMC → process IMC → load complete → network registry lock.

У клиента `begin/load/finish` вызываются в разные моменты startup/resource loading. Сервер вызывает три фазы последовательно. Datagen выполняет только `begin`. N9Ezz не должен отправлять все события подряд из installer или pre-game bootstrap и считать их эквивалентными.

## Лицензии при повторном использовании

В этом аудите upstream исходники только изучены. Сборка N9Ezz не получает лицензируемый компонент автоматически из-за наличия research checkout.

| Возможный reused component | Проверенная лицензия / действие перед распространением |
| --- | --- |
| Forge и Forge FML | `LICENSE.txt`, SPDX headers `LGPL-2.1-only`. Сохранять copyright/headers, включить полный текст лицензии, attribution и соответствующие доступные исходники/изменения; не объявлять fork оригинальным upstream. |
| NeoForge и новые FML classes | `LICENSE.txt`, большинство SPDX headers `LGPL-2.1-only`. Проверять каждый исходный файл; общее repository license не покрывает все унаследованные исключения. |
| ModLauncher и унаследованные FML transformation/classloading classes | `LGPL-3.0-only` / inherited LGPLv3 headers. Например `fml10/.../ClassTransformer.java` сохраняет LGPLv3 header, несмотря на основной LGPL2.1 FML. У FML есть отдельный `modlauncher-LICENSE`. |
| Sponge Mixin / форк | Требуется проверка лицензии именно выбранного artifact/source commit, notices, upstream fork attribution и transitive dependencies. В данном аудите исходный Mixin repository не клонировался; нельзя на основании номера версии заявлять, что все условия уже соблюдены. |
| Access Transformers, eventbus, SecureModules / JarContents, NightConfig, ASM, mappings tools | Отдельные upstream licenses/notices и pinned artifacts должны быть включены в dependency inventory, если они реально войдут в JAR. NeoForge POM/module доступны; полный transitive binary/license inventory в этом аудите не удостоверен. Forge metadata остаётся недоступна. |
| Minecraft game / Mojang mappings | Minecraft JAR не становится open source из-за Forge/Neo patch set; не включать game files в distributable. Учесть notices/условия официальных mappings при получении и remapping. |

Количество собственного и upstream кода не является проверкой архитектуры или лицензии. Практический критерий: один runtime, нужное проверенное поведение, documented boundary и воспроизводимые artifacts.

## Минимальные необходимые проверки совместимости

- Metadata fixtures: multi-mod TOML, unsupported loaderVersion, mandatory absent, optional present with wrong version, incompatible/discouraged, side, before/after, cycles, unresolved `${...}`, malformed TOML, duplicates.
- Class fixtures: одинаковый class в двух mods; class также в parent; split packages; nested JAR origin; cross-mod cast и ServiceLoader resource ordering.
- Transformer fixtures: deterministic ordering; access update до Mixin; Neo default coremod после Mixin; cycle/duplicate processor; frame hierarchy lookup без `defineClass`; transformation exception содержит source mod, processor ID и class.
- Lifecycle fixtures: single construction, dependency-before-dependent, failure propagation, event priorities/cancellation, deferred work на нужном потоке, registry barrier и game startup timing.
- Real-game checks: vanilla 1.21.11 Java21; собственный минимальный mod; только затем по одному конкретному Fabric/Quilt/Forge/NeoForge mod с pinned version и API inventory. Получение главного меню/мира, события и логи нужны отдельно от synthetic bootstrap checks.

Нельзя считать metadata parsing, loading test JAR или SKlauncher profile успешной проверкой четырёх платформ. Совместимость N9Ezz client с Fabric API/mappings должна проверяться отдельно по предоставленным исходникам и его реальному запуску.

## Воспроизводимые source checks

```sh
git ls-remote --heads https://github.com/MinecraftForge/MinecraftForge.git refs/heads/1.21.11
git ls-remote --heads https://github.com/neoforged/NeoForge.git refs/heads/1.21.11
git ls-remote --tags https://github.com/neoforged/NeoForge.git 'refs/tags/21.11*'
git -C /workspace/research/modlauncher rev-list --count 10.2..b5f35aa3d7a6369e13053b1fbb165796ab8b8bb1
# 6; candidate source correspondence for Forge's declared ModLauncher 10.2.6
git -C /workspace/research/fml10 rev-list --count 10.0..805fe3e71a18cf512f711a0d3ff6ba6c335a88f5
# 36; candidate source correspondence for NeoForge's declared FML 10.0.36
```

### Точные source references

- Forge [versions](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/minecraft.versions.toml), [dependencies](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/settings.gradle), [runtime official mappings/build](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/build.gradle).
- Forge [FMLLoader](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/fmlloader/src/main/java/net/minecraftforge/fml/loading/FMLLoader.java), [ModSorter](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/fmlloader/src/main/java/net/minecraftforge/fml/loading/ModSorter.java), [ModInfo dependencies](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/fmlloader/src/main/java/net/minecraftforge/fml/loading/moddiscovery/ModInfo.java).
- Forge [ModLoader lifecycle](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/fmlcore/src/main/java/net/minecraftforge/fml/ModLoader.java), [FMLModContainer](https://github.com/MinecraftForge/MinecraftForge/blob/1dab50ca003abc59e4115a329bcb46f76c105e15/javafmllanguage/src/main/java/net/minecraftforge/fml/javafmlmod/FMLModContainer.java).
- ModLauncher [layers](https://github.com/MinecraftForge/ModLauncher/blob/b5f35aa3d7a6369e13053b1fbb165796ab8b8bb1/src/main/java/cpw/mods/modlauncher/api/IModuleLayerManager.java), [ModuleLayerHandler](https://github.com/MinecraftForge/ModLauncher/blob/b5f35aa3d7a6369e13053b1fbb165796ab8b8bb1/src/main/java/cpw/mods/modlauncher/ModuleLayerHandler.java), [transforms and voting](https://github.com/MinecraftForge/ModLauncher/blob/b5f35aa3d7a6369e13053b1fbb165796ab8b8bb1/src/main/java/cpw/mods/modlauncher/ClassTransformer.java).
- NeoForge [version properties](https://github.com/neoforged/NeoForge/blob/bef35d56255d4cb4a3aa58e1f4c27b41c61d3000/gradle.properties), [metadata](https://github.com/neoforged/NeoForge/blob/bef35d56255d4cb4a3aa58e1f4c27b41c61d3000/src/main/templates/neoforge.mods.toml), [CommonModLoader](https://github.com/neoforged/NeoForge/blob/bef35d56255d4cb4a3aa58e1f4c27b41c61d3000/src/main/java/net/neoforged/neoforge/internal/CommonModLoader.java).
- FML10 [own bootstrap/classloading](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/loading/FMLLoader.java), [processor ordering](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/classloading/transformation/ClassProcessorSet.java), [access transform before Mixin](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/common/asm/AccessTransformerService.java), [simple processors after Mixin](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/common/asm/SimpleProcessorsGroup.java).
- FML10 [metadata parser](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/loading/moddiscovery/ModFileParser.java), [dependency model](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/loading/moddiscovery/ModInfo.java), [construction](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/javafmlmod/FMLModContainer.java), [Mixin integration](https://github.com/neoforged/FancyModLoader/blob/805fe3e71a18cf512f711a0d3ff6ba6c335a88f5/loader/src/main/java/net/neoforged/fml/loading/mixin/FMLMixinClassProcessor.java).

## Незавершённые части этого аудита

Не получены Forge Maven artifacts; не выполнены upstream test builds и реальные Forge/NeoForge игровые запуски. NeoForge `21.11.45` installer/userdev/sources/universal publisher SHA-256 проверены, FML `10.0.36` manifest подтвердил source commit. Detached signatures не проверялись; полный transitive component inventory не выполнен. N9Ezz API inventory, Fabric/Quilt и конечная сборка находятся в отдельных отчётах. Этот документ не является сертификатом поддержки готовых модов.
