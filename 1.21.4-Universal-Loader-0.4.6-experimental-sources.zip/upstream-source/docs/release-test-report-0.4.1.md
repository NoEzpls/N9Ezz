# N9Ezz 0.4.1 experimental: проверки выпуска

Цель: Minecraft 1.21.11, Java 21. Изменение по запросу пользователя:
внешние моды принимаются только в собственном формате `n9ezz.mod.json`.
Обычные Fabric/Quilt/Forge/NeoForge архивы, смешанные descriptors и вложенные
JAR внешних модов отклоняются до выполнения внешнего кода. Встроенные
зафиксированные N9Ezz/API остаются в установщике.

## Изменение контракта

Новая политика распространяется на игровой bootstrap и API-only CLI.
Собственный descriptor не подтверждает автора и не обеспечивает sandbox;
это явный формат подключения к API N9Ezz. Обычный мод нельзя сделать
совместимым одним переименованием. Полный контракт и Java-пример:
[native-mod-policy.md](native-mod-policy.md).

Quilt/FML реализации остаются внутренними адаптерами с низкоуровневыми
проверками. Путь подключения четырёх внешних platform fixtures из 0.4.0
намеренно закрыт. Их прежний игровой PASS не засчитывается новой версии.

Встроенный полный клиент не меняется; проверенный SHA-256:
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
Логика клиентских модулей и сетевые packets не переписываются.

## Результаты 0.4.1

Полная Java 21 сборка завершилась с exit 0. Точный JAR: 53 561 899 bytes,
SHA-256 `b81855307752b3d20df9bff66175914d2a118e7cce688c15e24b153952c60b3b`.

| Проверка | Результат |
| --- | --- |
| Полная сборка и существующие regression suites | PASS, без --skip-tests |
| Собственная политика допуска, обе bootstrap ветви и library classpaths | 36 PASS; чужой код не исполняется |
| Core/resolver/events/bytecode | 54 PASS; внутренние adapter fixtures используют test-only pinned BuiltinModSource |
| Universal game policy; Quilt/FML internals | 23 / 34 / 33 PASS |
| Mapping index/fingerprint; access widener; nested discovery | 26/17; 18; 40 PASS |
| Mixin; Fabric services/entrypoints/dependencies | 11; 9/9/77 PASS |
| Game integration; local diagnostic redaction | 20; 71 PASS |
| Client contract; resource bridge; updater | 21; 29; 8 PASS |
| Готовый встроенный TargetGeometry.class | 3036 PASS, production_geometry_recompiled=false |
| Native packaged initializer; installer metadata | PASS; 11 PASS |
| Gameplay/cross-platform acceptance parsers | 9/24 PASS, synthetic inputs, не новые game runs четырёх платформ |
| Четыре настоящих platform fixtures из 0.4.0 через новый packaged CLI | 4 ожидаемых отказа EXTERNAL_MOD_NOT_N9EZZ |
| Java-пример HelloN9 из инструкции | compile/package/verify/run PASS |

Raw результаты: `build-0.4.1.log`, `executable-tests-0.4.1.log`,
`packaged-admission-0.4.1-result.json`, `native-example-0.4.1-result.json`
и `embedded-hitbox-0.4.1-result.json` в docs. Успех старых внутренних
adapter tests не открывает закрытый внешний platform admission.

## Реальный запуск Minecraft

9 октября 2026 года точный JAR запущен через собственный GameBootstrap на
Java 21, с official Minecraft 1.21.11, Xvfb/Mesa и offline demo. Два отдельных
native observer mod поступили через обычную папку mods; собственные callbacks
N9Ezz/Pulse вручную не вызывались. Использована копия прежнего локального
save/config/options, без прежних mods или runtime cache. Mapping/cache
подготовлены заново обычным runtime.

| Наблюдение | Результат |
| --- | --- |
| Base и world acceptance | Оба PASS, harness exit0, без replay |
| Длительность | 189.4 с с остановкой runner-ом; заданный deadline180с, процесс exit143 |
| Клиентские START/END | 1000 записанных сбалансированных пар, orderingFailures=0 |
| Мир/игрок | 1500 callbacks; последний world sample имеет client counter1713 |
| Integrated server | Запущен, 89 фактических simulation ticks, затем пауза demo modal |
| Рендер мира | 100 явно сбалансированных START/END; 282 завершённых кадра в последнем sample, orderingFailures=0 |
| Инициализация | 113 зарегистрированных модулей, 30 addon fields; Aura/Triggerbot/Hitboxes присутствуют |
| События | CLIENT_STARTED, SERVER_STARTING/STARTED, INIT/JOIN, world change |
| Общая среда | Один UnifiedClassLoader@d3aa9f3 у клиента, N9Ezz, мира, игрока, сервера и observers |

Screenshot подтверждает demo modal поверх настоящего мира. Пауза после89
серверных тиков не считается длительной unpaused simulation. World callbacks
и client ticks во время этой паузы не выдаются за simulation ticks. Атаки,
PvP, packet behavior и другой игрок не проверялись.
Raw evidence: `game-0.4.1-result.json`, `world-0.4.1-result.json`,
`game-0.4.1-command.json` и `game-0.4.1-launch.log` в docs.

Итоговый source ZIP фиксируется после этих записей. Результат отдельной
offline-пересборки и побайтного сравнения JAR/source ZIP помещается во внешние
`RELEASE-MANIFEST.md` и `dist/tests-0.4.1/reproduction.json`, чтобы source ZIP
не включал собственный checksum. Источник полного Pulse остаётся pinned binary.

## Аудит переданных файлов

Переданные установщики платформ рассматриваются как исследовательские
материалы; они не устанавливаются как mods и не изменяют правило допуска.
NeoForge 21.6.19-beta относится к Minecraft 1.21.6. Файл с именем
`1.21.11-forge-61.2.1.jar` побайтно совпадает с официальным vanilla client
1.21.11 и не содержит Forge. Имена файлов не считаются доказательством
содержимого. Дополнительный JSON — профиль Forge со ссылками на отдельные
Maven libraries; client.txt — официальные mappings 1.21.11, не исходники Pulse.
Forge runtime binaries эти два файла не содержат. Полные metadata и hashes:
[uploaded-platforms-0.4.1.md](uploaded-platforms-0.4.1.md).

## История и ограничения

[0.4.0 report](release-test-report-0.4.md),
[0.3.1 report](release-test-report-0.3.1.md) и старые JAR/ZIP сохранены.
Game evidence каждой версии относится только к её указанному бинарнику.

Полные Forge/NeoForge game patches и registry/global-event APIs, stock QSL
ранние registry hooks, general Mojang/SRG/named remapping, AT/JarJar/module
semantics и dedicated-server bootstrap не реализованы. Ограничение внешних
модов не заменяет эти механизмы и не доказывает полную совместимость четырёх
платформ. Target acquisition против другого игрока, attacks, damage и PvP
не проверены. Исходники базового Pulse отсутствуют; source archive включает
собственный Java-код, дополнения и зафиксированные binary inputs.
