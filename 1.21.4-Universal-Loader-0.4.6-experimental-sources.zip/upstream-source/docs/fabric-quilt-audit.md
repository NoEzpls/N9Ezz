# Аудит Fabric и Quilt для N9Ezz Universal Loader

Проверено 7 октября 2026 года. Это аудит официальных исходников и доступности
версий, а не утверждение совместимости N9Ezz или сторонних модов с новым ядром.
Исходники двух загрузчиков прочитаны в отдельных checkout под
`/workspace/research`; upstream-файлы не изменялись, upstream-сборки не запускались.

## Зафиксированные источники

| Источник | Версия / ref | Точный commit | Что подтверждено |
| --- | --- | --- | --- |
| [Fabric Loader](https://github.com/FabricMC/fabric-loader) | `0.19.2` | `d112641382563b3b1139c8168db07ee71a982eda` | Тег существует; исходники скачаны и прочитаны |
| [Quilt Loader](https://github.com/QuiltMC/quilt-loader) | `0.30.1` | `b33861b30a815f327652015018d2d1262f12b63a` | Тег существует; исходники скачаны и прочитаны |
| [Fabric Yarn](https://github.com/FabricMC/yarn) | ветка `1.21.11` | `ee98590897c919286b96b7c7f2c89ae4ac737762` | Ref найден через `git ls-remote`; это не проверка опубликованного номера build |
| [Fabric Intermediary](https://github.com/FabricMC/intermediary) | `master`, файл `mappings/1.21.11.tiny` | `916868752f6935dda70c4490404641a701335d81` | Исходный Tiny v1 `official` → `intermediary` доступен; SHA256 `d54cd7b17e0d43634fe5657e535d40a040a3f3b0c4eae2c4c174e29f66244b3c` |
| [Fabric API](https://github.com/FabricMC/fabric-api) | `0.141.6+1.21.11` | `28e4019ae9dc6713d6797da19f60386debb25460` | Тег найден; `gradle.properties` задаёт Minecraft `1.21.11` и Loader `0.17.3` |
| [Quilt mappings](https://github.com/QuiltMC/quilt-mappings) | ветка `1.21.11` | `fc18573e7e0b7630314858b46d58410c569b6acc` | `gradle/libs.versions.toml`: Minecraft `1.21.11`; `gradle.properties`: `java=21` |
| [Quilt Standard Libraries](https://github.com/QuiltMC/quilt-standard-libraries) | ветка `1.21.5` | `fef35afe5fb046e6339a3dfc8478a65b5bfce3bc` | Изучены initializer API descriptors; `git ls-remote` не обнаружил branch/tag для `1.21.11`, опубликованные Maven-версии не проверены |

Названные пользователем Fabric `0.19.2` и Quilt `0.30.1` действительно существуют.
Quilt `0.30.1` не является точной копией Fabric `0.19.2`: его changelog говорит
об обновлении до Fabric `0.19.3`.

## Доступность Minecraft 1.21.11 и Java 21

Fabric содержит запись Minecraft `1.21.11` и отдельной экспериментальной
`1.21.11_unobfuscated` в
[`minecraft_versions.json`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/minecraft/src/test/resources/minecraft_versions.json#L8714).
Оба загрузчика умеют нормализовать эту версию; Quilt `0.30.0` явно добавил
поддержку snapshot-версий `1.21.11`.
Версия с суффиксом `_unobfuscated` и обычная `1.21.11` различаются: нельзя
предположить одинаковый namespace только по похожему номеру версии.

Fabric требует Java 21+ для сборки в
[`settings.gradle`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/settings.gradle#L17),
но основную библиотеку выпускает с `--release 8`; это не требование Java 8 к
Minecraft. Оба Minecraft game provider вычисляют минимальную Java из major
version игрового bytecode (`classVersion - 44`) и добавляют зависимость `java`.
Java 21 является целевым toolchain N9Ezz; реальная загрузка игрового JAR должна
отдельно проверить major `65` и применимость всех преобразователей.

Показательные upstream integration-test проекты здесь всё ещё задают
Minecraft `1.20.2` (Fabric) и `1.20.6` (Quilt). Поэтому даже их успешный
upstream build не заменил бы проверку игрового запуска `1.21.11`.

Официальные запросы metadata были выполнены через наследуемый прокси, с
сохранённой TLS-проверкой:

| Операция | Результат |
| --- | --- |
| `https://meta.fabricmc.net/v2/versions/loader/1.21.11/0.19.2` | Первоначально `CONNECT tunnel failed, response 403`; 7 октября 2026 в 18:20 по Москве повтор дал HTTP 200 и exact version `0.19.2` для game `1.21.11` |
| `https://meta.quiltmc.org/v3/versions/loader/1.21.11/0.30.1` | Первоначально `CONNECT tunnel failed, response 403`; 7 октября 2026 в 18:20 по Москве повтор дал HTTP 200 и exact version `0.30.1` для game `1.21.11` |
| Fabric Maven `fabric-loader-0.19.2.jar` | HTTP 200; 1 968 930 bytes, SHA-256 `1b91025ac6b5253a49aabb22f658b5eed9fbba6dc88eb0e4a9364c7b2d1d1865`, проверен по publisher `.sha256` и совпадает с legacy bundle |
| Quilt Maven `quilt-loader-0.30.1.jar` | HTTP 200; 3 149 891 bytes, SHA-256 `a561a9fe9abb45556c696095a29e81477618bf2408b86c36db5aecdcd6a86fdb`, проверен по publisher `.sha256` и совпадает с legacy bundle; **отличается от Quilt Meta hash** |
| Mojang game JSON `1.21.11` | HTTP 200, `javaVersion.majorVersion=21`, `mainClass=net.minecraft.client.main.Main`; это metadata evidence, не запуск игры |
| `git ls-remote` / clone официальных GitHub-репозиториев | Успешно |

Первоначальный policy snapshot и ошибки 403 устарели относительно поздних
успешных запросов: использовать текущие operation results, а не выводить
недоступность из старой ошибки. TLS, proxy и ожидаемые checksums не обходились.
Подробные live URLs/timestamps/results: [platform-availability.md](platform-availability.md),
[platform-metadata-probes.json](platform-metadata-probes.json),
[platform-artifact-probes.json](platform-artifact-probes.json).

Обнаружено расхождение официальных Quilt источников: Meta сообщает loader
SHA-256 `a60c9dd429151c426b09b96147b76de1a7cf51c6ce47ee72be77acbdcc195b87`,
но Maven JAR и Maven publisher `.sha256` дают `a561a9fe...`. Размер одинаков.
Причина не установлена; не менять ожидаемый Meta hash для получения PASS.
В отчёте проверка against Maven checksum успешна, а Meta/Maven consistency — FAIL.
Новые mapping/API artifacts и real Minecraft/Fabric/Quilt запуск не проверены
в рамках этого аудита. Loader availability не подтверждает QSL/QFAPI или N9Ezz.

## Сопоставление механизмов

| Механизм | Fabric Loader 0.19.2 | Quilt Loader 0.30.1 | Требование к общей среде N9Ezz |
| --- | --- | --- | --- |
| Владение runtime | `FabricLoaderImpl.INSTANCE`, launcher singleton, Knot game provider | `QuiltLoaderImpl.INSTANCE`, собственный launcher singleton; Fabric API loader-обёртки | Один N9Ezz runtime; API-адаптеры обращаются к нему, upstream launcher не запускается |
| Class loading | Изолированный Knot loader, child-first для целевых классов, JDK/разрешённые библиотеки из parent; ограничение раннего доступа к игровому classpath | Knot + transform bundle, hidden classes, plugin classloader routing, отдельная маршрутизация log4j/slf4j | Одна политика владельцев классов и parent-first для JDK/ядра/API; предварительное выявление дубликатов |
| Namespace | `official`, `clientOfficial`, `serverOfficial`, `intermediary`, `named`; фактический namespace выбирается по доступным mappings/game provider | Обычно `named` в dev и `intermediary` в production; для `_unobfuscated` и Minecraft >25 — пустые mappings/`official` | Один явно фиксированный namespace и одна version-pinned таблица преобразований; нельзя одновременно определить две версии Minecraft-класса |
| Remapping | Tiny Remapper; отдельно remap game; dev-mod remap при предоставленном classpath; class tweaker и Mixin extension | Tiny Remapper внутри transform-cache; source namespace задаётся mod option; ресурсы/refmaps/AW входят в bundle | Один remap-план до определения классов; remap descriptors, refmaps и access rules вместе с bytecode |
| Metadata | `fabric.mod.json` schema 0/1; зависимости, provides, side, entrypoints/language adapters, nested JAR, Mixin, class tweaker | `quilt.mod.json` schema 1, group/id, richer dependency predicates, `intermediate_mappings`, nested JAR; отдельный Fabric plugin | Нормализовать метаданные в общую модель, сохранить platform origin; неизвестные обязательные поля отклонять |
| Dependencies | SAT4J solver с nested candidates, вариантами версии, builtin/provides, soft/hard dependencies, conflicts/breaks, environment | Plugin manager + SAT4J rules, aliases, any/all/unless, optional/mandatory options, overrides | Один resolver для всех форматов; выбор версии и lifecycle order — разные задачи; не выдавать урезанный resolver за SAT4J-эквивалент |
| Transformations | Entrypoint patch → raw fallback → FabricTransformer (environment/package access/class tweaks) → Mixin → defineClass | Remap → entrypoint/QuiltTransformer → optional Chasm → internal hiding в cache; Mixin при загрузке → defineClass | Один упорядоченный pipeline; каждая стадия выполняется ровно один раз, имеет owner/version/hash и диагностику |
| Mixin | Sponge Mixin с Fabric fork, свой `IMixinService`; глобальный bootstrap; duplicate config names отклоняются | Тот же стек с собственной service; Quilt configs имеют виртуальный префикс `#modid:path`, Fabric configs отдельно | Одна Mixin service; собственный resource resolver для platform-specific config имен; один набор ASM/Mixin/MixinExtras |
| Начальная инициализация | discovery/resolve → freeze → class tweakers → Mixin bootstrap → transformers → unlock → `preLaunch` → запуск игры → `main` → `client`/`server` | plugins/solve → bundle/freeze → Mixin → transformers → unlock/config init → `pre_launch`, `preLaunch` → игра → Fabric `main`/`client`/`server` hooks | Одна lifecycle state machine; startup-stage и game-stage различать; Fabric callbacks вызывать в правильной точке игры |
| API событий | Loader entrypoints; игровые tick/render/network/registry callbacks принадлежат Fabric API, а не Loader | Loader entrypoints; Quilt Standard Libraries/QFAPI — отдельные модули | Собственная event bus не реализует автоматически Fabric API/QSL; API bridges и игровые hooks тестируются отдельно |
| Диагностика | Resolution explanations, FormattedException, Mixin owner/config/class errors | SAT explanations/plugin errors, mod origin/hash/hidden reasons, structured report/GUI | Ошибка содержит mod, archive, stage, class, transform order, expected/actual version и исходную cause |

### Точные ссылки на прочитанные реализации

Fabric, commit `d112641382563b3b1139c8168db07ee71a982eda`:

- [`Knot.init`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/launch/knot/Knot.java#L134) — bootstrap sequence и `preLaunch`.
- [`KnotClassDelegate`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/launch/knot/KnotClassDelegate.java#L292) — isolation, повторная проверка `findLoadedClass` после Mixin, defineClass; [pipeline](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/launch/knot/KnotClassDelegate.java#L427).
- [`MappingConfiguration`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/launch/MappingConfiguration.java#L129) — runtime и distribution namespace.
- [`RuntimeModRemapper`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/discovery/RuntimeModRemapper.java#L69) — mappings, class tweakers, Mixin remap extension.
- [`FabricLoaderImpl.setup`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/FabricLoaderImpl.java#L209), [`ModResolver`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/discovery/ModResolver.java#L53) — discover/resolve/remap и SAT resolution.
- [`V1ModMetadataParser`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/metadata/V1ModMetadataParser.java#L104) — metadata fields.
- [`FabricMixinBootstrap`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/src/main/java/net/fabricmc/loader/impl/launch/FabricMixinBootstrap.java#L51) — global service, refmap remapper, owner/config collision checks.
- [`Minecraft Hooks`](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/minecraft/src/main/java/net/fabricmc/loader/impl/game/minecraft/Hooks.java#L45) — `main` перед `client`/`server`.

Quilt, commit `b33861b30a815f327652015018d2d1262f12b63a`:

- [`Knot.init`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/launch/knot/Knot.java#L136), [`invokePreLaunch`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/QuiltLoaderImpl.java#L1246) — initialization; обе platform prelaunch keys.
- [`QuiltLoaderImpl.setup`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/QuiltLoaderImpl.java#L312) — plugin solve, deterministic shuffle, transform cache.
- [`TransformCacheGenerator`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/transformer/TransformCacheGenerator.java#L45), [`KnotClassDelegate`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/launch/knot/KnotClassDelegate.java#L527) — preprocessing и Mixin на define boundary.
- [`RuntimeModRemapper`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/transformer/RuntimeModRemapper.java#L72) — namespace checks и отказ Mojang→другой namespace.
- [`V1ModMetadataReader`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/metadata/qmj/V1ModMetadataReader.java#L288) — поддержанные intermediate mapping identifiers, явный отказ hashed.
- [`QuiltMixinBootstrap`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/java/org/quiltmc/loader/impl/launch/common/QuiltMixinBootstrap.java#L77) — config resolution и namespace remapping.
- [`MinecraftGameProvider`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/minecraft/src/main/java/org/quiltmc/loader/impl/game/minecraft/MinecraftGameProvider.java#L315) — обычные/необфусцированные версии.
- [`0.30.0 changelog`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/resources/changelog/0.30.0.txt), [`0.30.1 changelog`](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/src/main/resources/changelog/0.30.1.txt) — upstream lineage и версии компонентов.

## Таблица конфликтов и замены

| Конфликт | Почему нельзя объединить без изменений | Собственная замена / поведение | Условие проверки |
| --- | --- | --- | --- |
| Два Knot и два singleton | Разные определения одного Minecraft/API класса вызывают LinkageError/ClassCastException; два game provider считают себя владельцами запуска | N9Ezz bootstrap + один transforming classloader; platform facades используют общие containers | Все mod classloaders и game class owners совпадают; duplicate definition test |
| Две Mixin service | Глобальная Mixin environment не является четырьмя независимыми пространствами; ServiceLoader/property зависит от classpath | Один `IMixinService`, один bootstrap, общий registry configs с origin | Проверка выбора ровно одной service; ошибки config collisions; реальный injection test |
| Разные ASM/Mixin pins | Fabric: ASM `9.9`, `0.17.2+mixin.0.8.7`; Quilt: ASM `9.10.1`, `0.17.3+mixin.0.8.7`; двойные библиотеки затеняют друг друга | Один проверенный pin на общий runtime; отклонение несовместимых требований | Transform class major 65, frames/verification; fixtures обеих платформ |
| `official`/`intermediary`/`named` | Имена bytecode, descriptors, AW и refmaps должны соответствовать одной версии игры | Одна mapping graph и нормализация до defineClass; hash/version keyed cache | Реальные method/field references и refmaps, обе стороны; unknown namespace rejection |
| Quilt hashed/Mojang | Quilt 0.30.1 явно отказывает hashed; Mojang моды нельзя remap обратно существующим кодом | Явная capability gate; будущий общий graph, без молчаливой подмены namespace | Отказ с понятным namespace diagnostic; support claim только после real-mod test |
| Live transformer против Quilt cache | Двойное widening/patching, отличающиеся скрытые классы и устаревший cache | Собственный pipeline и cache с input/config/mappings/transformer hash | Повторный запуск совпадает; изменение rules инвалидирует cache |
| Class/environment stripping | Quilt дополнительно обрабатывает lambdas, mod condition annotations и internal/reflective fixes | Единая side policy; неподдержанные class conditions отклоняются | Client/server fixtures, отсутствующая optional dependency, stripped lambda |
| Metadata precedence/nested mods | В одном архиве могут быть оба metadata; nested versions/provides нельзя решать независимо | Один выбор origin и общий dependency model; unsupported nested features — fail before load | Mixed metadata, duplicate IDs/provides, invalid nesting/path traversal |
| SAT selection против простой topo sort | Версии, aliases, optional/unless и циклы не выражаются только порядком инициализации | Собственные строгие predicates + resolver capability gate; lifecycle DAG отдельно | Missing/version mismatch/hard breaks; optional present mismatch; cycles |
| `preLaunch` / `pre_launch` / `main` | Разные keys не означают одинаковую игровую точку; Quilt QSL `init` не принадлежит core Hooks | Один lifecycle с точной mapping callbacks; QSL bridge отдельно | Trace всех events; каждый callback once; dependency-before-dependent где это контракт |
| Fabric API / QSL | Это игровые библиотеки со своими mixins, registries и event contracts, а не только loader interface | Подключать проверенные API модули и собственные game hooks поэтапно | N9Ezz callback/injection/registry smoke test на exact version; loader-only мод недостаточен |
| Resource/config names | Fabric считает Mixin path глобальным; Quilt виртуализирует `#modid:path` | Общий resource ownership registry; collision diagnostic и resolver | Два архива с одинаковым Mixin path, порядок ресурсов/service descriptors |

Это проектные требования к ядру. Наличие строки в таблице не означает, что
соответствующая замена уже реализована в поставляемом N9Ezz.

### Узкий descriptor-контракт QSL, доступный для fixtures

В официальном QSL source `1.21.5` подтверждены три интерфейса:

- `org.quiltmc.qsl.base.api.entrypoint.ModInitializer`: `ENTRYPOINT_KEY = "init"`, `void onInitialize(org.quiltmc.loader.api.ModContainer)`.
- `org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer`: `ENTRYPOINT_KEY = "client_init"`, `void onInitializeClient(org.quiltmc.loader.api.ModContainer)`.
- `org.quiltmc.qsl.base.api.entrypoint.server.DedicatedServerModInitializer`: `ENTRYPOINT_KEY = "server_init"`, `void onInitializeServer(org.quiltmc.loader.api.ModContainer)`.

Источник:
[`QSL initializer`](https://github.com/QuiltMC/quilt-standard-libraries/blob/fef35afe5fb046e6339a3dfc8478a65b5bfce3bc/library/core/qsl_base/src/main/java/org/quiltmc/qsl/base/api/entrypoint/ModInitializer.java).
Он документирует запуск `init` в `Minecraft Bootstrap.bootstrap()` перед
замораживанием встроенных registries. Client initializer запускается в
конструкторе Minecraft client перед созданием GameOptions. Shim с теми же
descriptors позволяет проверить fixture, но вызов shim до запуска игры не
сохраняет этот lifecycle-контракт. Совместимость QSL на `1.21.11` не доказана.

Quilt Loader `0.30.1` подтверждает цепочку `ModContainer.metadata()` →
`ModMetadata.id()` / `ModMetadata.version()` → `Version.raw()`. Поддержка только
этой цепочки не равна полной binary compatibility Loader API.

## Лицензии и повторное использование

Оба Loader — Apache-2.0:
[Fabric LICENSE](https://github.com/FabricMC/fabric-loader/blob/d112641382563b3b1139c8168db07ee71a982eda/LICENSE)
и [Quilt LICENSE](https://github.com/QuiltMC/quilt-loader/blob/b33861b30a815f327652015018d2d1262f12b63a/LICENSE).
Quilt сохраняет Fabric copyright в унаследованных классах. При копировании
компонента нужны его лицензия, имеющиеся notices/copyright и заметное указание
изменений; лицензия самого Loader не покрывает автоматически все транзитивные
библиотеки. SAT4J использует отдельные attribution файлы (`about-sat4j.html`),
которые upstream build сохраняет при shading. ASM, Mixin, Tiny Remapper,
Mapping-IO, Class Tweaker, MixinExtras, parsers и API-модули требуют собственной
проверки лицензии точного артефакта и включения в third-party manifest.

Исходные Fabric Intermediary mappings имеют
[CC0-1.0 LICENSE](https://github.com/FabricMC/intermediary/blob/916868752f6935dda70c4490404641a701335d81/LICENSE).
Это отдельный доступный компонент; скачивание source-файла не доказывает
корректность будущего remapper. QSL API source сохраняет Apache-2.0 и copyright
The Quilt Project.

В этом аудите upstream-код не копировался в продукт: только ссылки и описание
поведения. Ориентир 50/50 не считается по строкам. Минимальное собственное ядро
может иметь иной состав; техническая пригодность, тесты и сохранение лицензий
важнее искусственного числа скопированных строк.

## Границы текущих доказательств

Не проверены N9Ezz client/installer, старый установочный JAR, точный список
использованных клиентом Fabric API и mappings, запуск через SKlauncher,
Quilt QSL/QFAPI, реальные bytecode transformers или Minecraft client/server.
Первоначально attachments превышали download-tool limit, но позднее тот же
исходный ZIP и reference JAR получены из `NoEzpls/N9Ezzz`, commit
`07a77dd4dc3c2a909e3ec1b082c6d67c83684255`; loader/client исследованы отдельно
в `source-loader-audit.md` и `n9ezz-integration-audit.md`. Этот source audit сам
по себе не удостоверяет совместимость клиента с новым runtime.
Этот аудит не доказывает поддержку произвольных Fabric/Quilt-модов и ничего
не доказывает о Forge/NeoForge; соответствующий аудит находится отдельно.
