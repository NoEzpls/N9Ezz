# Minecraft 1.21.11 smoke report

Проверка выполнена 7 октября 2026 на Temurin 21.0.8+9, официальном Mojang
client `1.21.11` (client SHA-1
`ba2df812c2d12e0219c489c4cd9a5e1f0760f5bd`), 61 Linux-библиотеке и 4,591
asset object. Каждый файл сверялся с SHA-1 из официального version JSON или
asset index; TLS и подпись Debian-пакетов для локального Xvfb оставались
включены. Запуск использовал новый `GameBootstrap`, один
`UnifiedClassLoader`, встроенный native smoke-mod и `--accessToken 0` как
явный offline placeholder. Аккаунт и сетевую аутентификацию не настраивали.

## Что прошло

- `class-load-probe.log`: `net.minecraft.client.main.Main` загружен из
  официального client JAR через `UnifiedClassLoader`; native smoke-mod и
  obfuscated fixture принадлежат тому же loader; lifecycle дошёл до `READY`.
- `game-launch.log`: `GameBootstrap` вызвал настоящий
  `net.minecraft.client.main.Main`; Datafixer, LWJGL 3.3.3, OpenGL 4.5 Mesa
  llvmpipe и загрузка vanilla resource atlases прошли. Это реальный вызов
  Minecraft main, а не только проверка PID.
- Локальный Xvfb предоставляет GLX; `glxinfo -B` подтвердил software OpenGL
  4.5. Все скачанные библиотеки и assets проверены до запуска.

## Ограничения результата

Это не полноценная игровая приёмка: до title-screen screenshot/world entry
проверка не дошла. Серверные auth/profile/Realms endpoints намеренно закрыты
для offline smoke; лог содержит ожидаемые `AuthenticationUnavailable` и
`UnknownHostException`. OpenAL не нашёл аудиоустройство, а Xvfb сообщил
`X11: Standard cursor shape unavailable`; Minecraft продолжил загрузку ресурсов,
но этот headless host не даёт считать UI полностью проверенным. N9Ezz/Fabric
client не устанавливался: его mixin, intermediary namespace, Fabric API и
nested libraries пока отклоняются ядром. Полный лог и командная строка
сохранены в `/workspace/minecraft-smoke/game-launch.log` и
`/workspace/minecraft-smoke/launch-command.json`.

Следующая игровая проверка должна использовать авторизованный профиль пользователя
в подходящем лаунчере и добавить отдельный Mixin/remapping stage; offline token
из этого smoke-теста нельзя использовать как учетные данные.

После добавления обязательного встроенного N9Ezz `GameBootstrap` использует
`runBundledGame`. Описанный выше vanilla smoke относится к предыдущему этапу
моста, когда запускался только native test mod. Итоговый профиль дополнительно
проверен с настоящим vanilla JAR: встроенный `pulse` обнаружен автоматически,
затем загрузка завершилась ожидаемым `METADATA_UNSUPPORTED` до Minecraft main.
См. `embedded-profile-launch.log`. Это не успешный запуск текущего N9Ezz-профиля.
