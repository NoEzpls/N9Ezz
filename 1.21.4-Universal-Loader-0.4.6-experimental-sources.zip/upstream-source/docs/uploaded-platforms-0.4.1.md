# User-supplied platform archive audit — 0.4.1

Inspected on 2026-10-09. These attachments were read as ZIP archives only; no installer, class, embedded script, or instruction from them was executed. All four ZIP CRC checks passed. File names and manifest strings alone do not establish publisher provenance. The hashes below identify the exact user-supplied bytes; the Minecraft client additionally matches the previously cached official Mojang download metadata and client bytes.

| Uploaded file | Actual contents | Minecraft target / runtime relevance |
| --- | --- | --- |
| `fabric-installer-1.1.2.jar` | Fabric installer; `Main-Class: net.fabricmc.installer.Main`, implementation version `1.1.2` | Generic installer, no pinned Minecraft version or embedded Fabric Loader runtime. The installer version is not a Loader version. |
| `quilt-installer-0.15.1.jar` | Quilt installer; `Main-Class: org.quiltmc.installer.Main`, implementation version `0.15.1` | Generic installer, no pinned Minecraft version or embedded Quilt Loader runtime. Manifest declares required Java 17 and a Java 25.0.3 build; this is metadata, not a runtime execution check. |
| `neoforge-21.6.19-beta-installer.jar` | NeoForge installer; `net.minecraftforge.installer.SimpleInstaller`, installer implementation `3.0.39`; includes install recipe and binary patches | Both `install_profile.json.minecraft` and `version.json.inheritsFrom` specify **1.21.6**, not 1.21.11. Recipe selects NeoForge `21.6.19-beta`, FML `8.0.5`, NeoForm `1.21.6-20250617.151856`. |
| `1.21.11-forge-61.2.1.jar` | **Unmodified official Minecraft 1.21.11 client JAR**, despite its file name | `Main-Class: net.minecraft.client.Main`, game `version.json` says `1.21.11`. No Forge classes, Forge installer recipe, or embedded JARs. It supplies no Forge `61.2.1` runtime. |

## Exact identity and attachment provenance

| File | Bytes | SHA-256 | Upload identifier |
| --- | ---: | --- | --- |
| `fabric-installer-1.1.2.jar` | 212123 | `61e035bf7bf70153e127440ce34de47c9036f0a2d0c65d1529454bd35ceefe4f` | `file_00000000b92882108aecbe3dc15f55dc` |
| `quilt-installer-0.15.1.jar` | 8734533 | `0a229138caa1b87fd8f5622038410696f98bb85871a279640e7002404c4d0dc2` | `file_00000000b148820a8dc02f673cac4eff` |
| `neoforge-21.6.19-beta-installer.jar` | 6194509 | `0e4e29cfac9617f98e1b50acf6670b8d660543c7b6102064aaa9a6316d5a2ca4` | `file_00000000d080820abd12dae392a62192` |
| `1.21.11-forge-61.2.1.jar` | 31152600 | `1473c9489ac50fda3c435049a76a70d61a10b8610db27f5ba9d8756b686cd3bd` | `file_00000000270481f4913a4cf62c0dfd9c` |

Workspace attachment paths, in table order:

- `/workspace/attachments/f5bdd33b-3ec8-4274-a606-c8ca47efb724/fabric-installer-1.1.2.jar`
- `/workspace/attachments/2ef5afda-394a-4a86-81b7-a69f4849b239/quilt-installer-0.15.1.jar`
- `/workspace/attachments/8eab7a83-ba84-485d-8095-13226ea3830b/neoforge-21.6.19-beta-installer.jar`
- `/workspace/attachments/a26ad600-3698-402b-aa88-b0fc49f35436/1.21.11-forge-61.2.1.jar`

The Forge-named file is byte-identical to `/workspace/minecraft-smoke/client.jar`. Its SHA-1 is `ba2df812c2d12e0219c489c4cd9a5e1f0760f5bd`, matching the client entry in cached `/workspace/minecraft-smoke/1.21.11.json` and the [official Mojang client URL](https://piston-data.mojang.com/v1/objects/ba2df812c2d12e0219c489c4cd9a5e1f0760f5bd/client.jar). No download was performed for this audit.

## Embedded libraries and impact on the project

None of the four archives contains a nested `.jar`. Fabric's shaded library metadata identifies `org.sharegov:mjson:1.4.1`. NeoForge's installer embeds Gson `2.11.0`, error-prone annotations `2.27.0`, and jopt-simple `5.0.4`; these are installer dependencies, not the game runtime. Quilt has bundled installer dependencies but no embedded Loader runtime or separate Maven `pom.properties` version inventory.

NeoForge's **download recipe**, rather than embedded runtime binaries, references FML `8.0.5`, Bus `8.0.5`, ModLauncher `11.0.5`, BootstrapLauncher `2.0.2`, SecureJarHandler `3.0.8`, access transformers `11.0.2`, ASM `9.8`, Sponge Mixin `0.15.2+mixin.0.8.7`, and `net.neoforged:neoforge:21.6.19-beta:universal`. Embedded `/data/client.lzma` and `/data/server.lzma` are 1.21.6 patch inputs and must not be applied to 1.21.11. Their presence does not change the project's audited NeoForge 1.21.11 API baseline.

**The uploaded Forge-named file does not unblock Forge binary or patch validation. There are no usable embedded Forge binary paths to extract.** A genuine `forge-1.21.11-61.2.1-installer.jar`, `forge-1.21.11-61.2.1-universal.jar`, and corresponding sources remain distinct artifacts. The existing official-source audit remains valid; previous missing-binary limitations remain. Implementing the requested restriction to N9Ezz-specific mods does not depend on obtaining those artifacts. None of these uploaded installer archives is bundled into the N9Ezz runtime by this audit.

## Additional launcher profile and official mappings

The additional `1.21.11-forge-61.2.1.json` is a launcher version profile:
`inheritsFrom=1.21.11`, `mainClass=net.minecraftforge.bootstrap.ForgeBootstrap`.
It explains the earlier vanilla JAR: Forge runtime binaries are separate Maven
libraries, not necessarily stored in the version-folder JAR. The JSON itself
contains no executable Forge implementation. Its 17,481 bytes have SHA-256
`3026dff3aa39000cde3ecd0bdc9da8a8a27c4d9db5acea604211a6de98568ccc`.
Attachment: `file_00000000f8bc81f49074c0253bca3b1d`. Publisher authenticity of
the profile has not been independently established; the following pins are
reported from the supplied profile, not independently fetched artifacts.

| Separate artifact named by profile | Bytes | Declared SHA-1 |
| --- | ---: | --- |
| forge-1.21.11-61.2.1-universal.jar | 2911066 | `21f077688a2ab13d18c32cad45d55128c093576e` |
| forge-1.21.11-61.2.1-client.jar | 32624066 | `632ace45e535291c7576764c1c8d6388b73c9a75` |
| fmlcore-1.21.11-61.2.1.jar | 128228 | `383a0484f6357408ab44503b7c2e652316cab4dc` |
| fmlloader-1.21.11-61.2.1.jar | 265392 | `9351679136288ef90d1cc458e3175c7e942e6882` |
| javafmllanguage-1.21.11-61.2.1.jar | 27045 | `148de342d4fa67dd03883c0c5d06aba6824d8e31` |

The `client` classifier has an empty download URL in this profile; it is a
locally produced/patched installation artifact, not a substitute for the
vanilla version JAR. The universal/fml libraries are referenced under official
`https://maven.minecraftforge.net/` paths. The corresponding installed files
would normally be under `.minecraft/libraries/net/minecraftforge/`, including
`forge/1.21.11-61.2.1/forge-1.21.11-61.2.1-universal.jar` and the `client` JAR.
The profile also names Bootstrap 2.1.8, EventBus 7.0.5, AT 8.2.17,
ModLauncher 10.2.6 and SecureModules 2.2.24. These references improve the
dependency inventory; they do not demonstrate those binary APIs working.

`client.txt` is the official Mojang client mappings for Minecraft 1.21.11,
not a client log or the Pulse source code. Its 11,779,287 bytes have SHA-256
`517799a8485e107e932dc1bd27c002b2d0b9207eb2396b685bcfe6c3321a9fbd`
and SHA-1 `031a68bebf55d824f66d6573d8c752f0e1bf232a`, exactly matching
`downloads.client_mappings` in the cached official 1.21.11 manifest.
Attachment: `file_00000000e16c82109e8ba36c81bcfe9c`.
The mapping text was inspected as data only. Its development-use notice
restricts redistribution of the complete unmodified mapping document, so it
is retained as an uploaded research input and is not added to the installer
or source ZIP. This release keeps its existing pinned intermediary mappings.

The extra files establish version/profile/mapping information. No Forge
binary or patch validation is claimed from either file.
