# Preserved installer baseline: 0.1.0

The exact historical `N9Ezz-Loader-0.1.0.jar` executable was not included in the
provided source handoff. The existing installer source and prepared resources
were rebuilt without changes into
`baseline/N9Ezz-Loader-0.1.0-rebuilt.jar`. This is a rebuilt baseline, not a claim
of byte identity with a previous executable or a verified Minecraft game launch.

Artifact size: **53,352,825 bytes**.

SHA-256:

```text
512bfa32b73f4635e0f406b98395392c05c7c83e24c3f87a61a99e7108bab28d
```

`baseline/rebuilt-installer-provenance.json` and the adjacent `.sha256` file record
the artifact's origin. Input snapshots under `/workspace/input/extracted/N9Ezz-Codex`
remain available. The handoff hashes verified 39 original loader input files
after rebuilding and testing. The only changed originally recorded loader file
was the expected generated `loader/build/test-results.json`. Java sources, tests,
build scripts, declarations, lockfile and prepared bundle resources were unchanged.
No components were downloaded or regenerated during this baseline build; the
original build verified their embedded SHA-256 values before packaging.

Commands run from `loader`:

```bash
source /workspace/toolchains/activate-temurin21.sh
export JAVA_TOOL_OPTIONS=-Xmx512m
python3 build.py
python3 test_installer.py
```

The tests take no command-line arguments. JDK: Eclipse Temurin 21.0.8+9-LTS;
the original script compiles installer and tests with `--release 17`. The trusted
JDK download and official SHA-256 are recorded in
`/workspace/toolchains/temurin21-toolchain.json`. System Java was not replaced.

Result: **27 existing unit checks and 12 existing integration checks passed**.

- Embedded bundle integrity and unchanged N9Ezz identification.
- Honest Fabric/experimental Quilt/blocked Forge and NeoForge statuses.
- Strict JSON, Unicode/BOM, traversal rejection, game-argument ambiguity and gates.
- No installation writes for unsupported engines, unapproved Quilt or missing game.
- Fabric installation into a disposable launcher fixture, isolated game directory,
  byte-identical bundled mod and exact profile backup; unrelated settings preserved.
- Idempotent repeated installation with no profile/component rewrites.
- Duplicate Pulse and other-platform mod detection without deleting user files.
- Explicit experimental Quilt installation into a separate fixture profile.
- Existing-file conflict rejection before component writes.
- Detection of modified installed components and tampered embedded dependencies.

The installer fixture contains a placeholder archive explicitly labelled
`Not Minecraft. Installation test only.` No real Minecraft process, account,
world or graphical client was launched. The original suite's additional Java 17
bootstrap-refusal check is conditional on a Java 17 host and did not execute on
this Java 21 toolchain; it is not counted among the 12 passes. Windows GUI,
SKlauncher behavior, actual Quilt client compatibility and game initialization
remain unverified by these results. The baseline still launches a selected
Fabric or experimental Quilt engine; it is preserved separately from the new
experimental shared runtime.
