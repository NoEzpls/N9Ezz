# N9Ezz 0.4.1: native admission and internal compatibility contracts

One N9Ezz runtime and one UnifiedClassLoader own the game, built-in client and
admitted own mods. No upstream platform engine is selected or launched.

## External admission in 0.4.1

External mods must use only `n9ezz.mod.json`. The game bootstrap and API-only
CLI reject ordinary Fabric/Quilt/Forge/NeoForge descriptors, mixed native/foreign
descriptors and nested JARs in external native mods before external code runs.
Lower-level metadata parsers and adapters do not bypass this public entry policy.
The user can still copy files into the directory; the loader refuses to load
unsupported archives and reports their paths without deleting them.

| Input | Admitted through public external discovery? |
| --- | --- |
| `n9ezz.mod.json` | Yes, subject to own API, dependency, namespace and class validation |
| `fabric.mod.json` | No |
| `quilt.mod.json` | No, including former `quilt-lifecycle-v1` opt-in |
| `META-INF/mods.toml` | No, including former `fml-lifecycle-v1` opt-in |
| `META-INF/neoforge.mods.toml` | No, including former `fml-lifecycle-v1` opt-in |
| Own and foreign descriptors in one JAR | No |
| Nested JAR in an external mod | No |

The built-in N9Ezz and selected official Fabric API archives retain their
internal verified-source path and SHA-256 pins. A matching name, mod ID or
cache location does not turn an external archive into a built-in source.
The own format is not a signature, authorship proof or Java sandbox. It is an
explicit API contract; changing metadata alone does not port unsupported code.
See [native-mod-policy.md](native-mod-policy.md) for an actual Java example.

## Retained internal layers

The following bounded implementations remain in the codebase and in lower-level
regression tests. Their external platform descriptors are no longer accepted by
the public game or CLI discovery path. The 0.4.0 four-platform fixture game run
is preserved historical evidence, not a new admission exception or 0.4.1 proof.

| Internal format/layer | Contract | ABI baseline / boundary |
| --- | --- | --- |
| Native | `N9ModInitializer` common/client | Own runtime context/events; public external mod format |
| Fabric | Selected built-in game path | Loader public ABI 0.19.2; six official Fabric API modules 0.141.3+1.21.11 |
| Quilt | `quilt-lifecycle-v1` internal adapter | Loader 0.30.1 services; QSL callback descriptors from source 1.21.5 |
| Forge | `fml-lifecycle-v1` internal adapter | JavaFML 61.0-source and EventBus7 typed lifecycle subset |
| NeoForge | `fml-lifecycle-v1` internal adapter | NeoForge 21.11.45 / FML 10.0.36 / Bus8.0.5 lifecycle subset |

The internal contracts accept only intermediary/none namespaces; javafml is
scoped per format (Forge 61.0, NeoForge 10.0.36). Global forge/neoforge identities
are not fabricated to satisfy platform dependencies. Reserved identities cannot
be replaced by an external mod. The FML adapter rejects every direct Minecraft
reference because game patches and mod remapping are absent.

API-only CLI commands remain separate from the game and use the same external
native-only admission rule. `--verify-bundled` retains its strict diagnostic
semantics; success of native `--run` does not prove a Minecraft game launch.

## Exact retained API surfaces

| Layer | Implemented public API | Initialization behavior |
| --- | --- | --- |
| Native | dev.n9ezz.loader.api.N9ModInitializer.onInitialize(ModContext) | Explicit common/client callbacks in dependency order |
| Fabric | net.fabricmc.api.ModInitializer and ClientModInitializer; documented net.fabricmc.loader.api services | main/common and client typed calls; verified official API module static entrypoints only |
| Fabric events | Official base, command-api-v2, key-binding-api-v1, lifecycle-events-v1, networking-api-v1, rendering-v1 | Original pinned Mixin hooks share the own service/classloader; arbitrary Fabric API modules are absent |
| Quilt loader | org.quiltmc.loader.api.QuiltLoader, ModContainer, ModMetadata, Version.raw(), MappingResolver and BasicSourceType | Immutable common-runtime mod/container/resource views, checked origin/CodeSource, game instance bound once |
| Quilt callbacks | org.quiltmc.qsl.base.api.entrypoint.ModInitializer.onInitialize(ModContainer); client.ClientModInitializer.onInitializeClient(ModContainer) | init/client_init, one retained instance/container, common then client before GameOptions |
| Forge construction/context | net.minecraftforge.fml.common.Mod; FMLJavaModLoadingContext.get(), getModBusGroup(), covariant getContainer(); FMLModContainer | Public context constructor preferred, otherwise public no-arg; one instance, active owning mod context |
| Forge mod bus | net.minecraftforge.eventbus.api.bus.BusGroup, EventBus<T>, listener EventListener/Priority; IModBusEvent | Typed per-mod buses, stable listener priority/order, lifecycle event class getBus(group) |
| Forge lifecycle | net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent, FMLClientSetupEvent, FMLLoadCompleteEvent; ParallelDispatchEvent.enqueueWork(Runnable/Supplier) | Global phase barrier, then FIFO work with owning context before next phase |
| NeoForge construction/context | net.neoforged.fml.common.Mod; ModLoadingContext, ModContainer/FMLModContainer; Dist | Exactly one public constructor with supported unique IEventBus/container/Dist parameters; client dist and depends filtering |
| NeoForge mod bus | net.neoforged.bus.api.IEventBus, Event, EventPriority | Per-mod lifecycle listeners; explicit event class required for erased lambdas/method references |
| NeoForge lifecycle | net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent, FMLClientSetupEvent, FMLLoadCompleteEvent; ParallelDispatchEvent/DeferredWorkQueue enqueueWork | Same own global phase/deferred barrier, separate event types and contexts |

Only the documented API member descriptors are implemented by these internal layers. Environment annotation shapes
do not provide full environment stripping or server bootstrap. FML bus support
is limited to those lifecycle events; it does not expose the complete gameplay
event bus or cancellation/registry/subscriber surface. Reflection-constructed
unknown APIs are outside static analysis and fail normally when called.

Quilt services include game/config/cache directories, mod/alias queries,
game/version/environment queries, game instance, exact mapping resolver,
archive paths/source views and common classloader identity. Semantic Version
parsing, plugins and arbitrary Quilt/QSL APIs are absent. The full member
inventory and source provenance are in
[quilt-game-contract.md](quilt-game-contract.md).
The exact FML member inventory, construction rules and source provenance are in
[fml-game-contract.md](fml-game-contract.md).

## Retained internal lifecycle and registry semantics

The game is remapped/prepared and Mixin configured before target class
definition. The own MinecraftClient constructor hook runs after singleton
and game-thread fields exist and before GameOptions. All common callbacks
and FML constructions finish before FML common events; all listeners for that
FML phase finish before phase-wide FIFO deferred work. Client callbacks/events
and deferred work follow. FML load-complete then runs before common READY.

A native, Fabric or Quilt initializer with a hard dependency on an FML mod or
its alias is rejected before any user code with
`UNSUPPORTED_CROSS_PHASE_DEPENDENCY`. Satisfying it would require completing
an FML common-setup phase before an initializer, contrary to the shared barrier.
An FML mod may require native/Fabric mods and follows dependency order.

This is a registry-independent late-constructor contract. Official QSL common
initialization originally runs in Bootstrap.bootstrap before builtin registry
freeze; that early point and QSL registration modules are not reproduced.
Forge/NeoForge registration events, patched registries and parallel executors
are also absent. Mods needing those behaviors must be rejected rather than
declared compatible because an initializer happened to run.

Each FML mod owns its bus/container/context. Deferred tasks execute on the
shared game thread with the owning context and context classloader restored.
They complete returned futures; failure aborts later phases and pending work.
A future canceled or explicitly completed before execution skips its supplier.
The documented queue has a per-phase bound. Recursive/repeated event posting,
late listeners and a failed callback are not silently retried.

## Preflight, ownership and diagnostics

Every entrypoint/configuration must belong to its declared archive and resolve
through the shared classloader with matching CodeSource. Direct foreign
loader implementations, unsupported platform API members, wrong descriptors,
unaccepted namespaces, duplicate definitions and missing dependencies fail
before entrypoints. Quilt/FML preflight scans all mod classes, not only the
initializer, including signatures/annotations/handles and invokedynamic data.
Unsupported multi-release Quilt/FML mods and JPMS descriptors are rejected.

Own diagnostic messages retain mod/source/phase/codes and nested failures;
recognized credentials are redacted only at the documented local boundaries.
This is a compatibility validator, not a security sandbox. Unknown reflective
calls or computed strings may fail later. Missing Forge/NeoForge patches are
not replaced by fabricated successful services.

## Historical evidence, availability and licensing

The executed **0.4.0** cross-platform probe loaded development-only native, Fabric,
Quilt, Forge and NeoForge fixtures with explicit contracts. It passed retained
instances, phase/deferred boundaries, public queries, one game/mod/context
classloader and actual world/server/network/render observations. The historical
302.5-second run recorded 3698 balanced client ticks, 3500 balanced server ticks
and 3500 world/player callbacks. This proves the selected lifecycle contracts,
not full platform game APIs or the new 0.4.1 admission path.

Official Fabric/Quilt Loader and Neo FML/Bus/MergeTool ABI JARs preceded the own
facade during fixture compilation. Quilt QSL callback shapes came from the own
API. Forge compiled against only the source-derived facade because official
artifact paths were unavailable; it has no independent Forge binary ABI proof.
Exact commands and hashes are retained in the fixture report.

Fabric and Quilt source tags are 0.19.2 and 0.30.1. QSL callback descriptors
come from the official 1.21.5 branch, not a published 1.21.11 aggregate.
Forge current metadata latest 61.2.1/recommended 61.2.0 is available, but
binary artifact paths remain 403; the own Forge API baseline is source-derived
61.0, not verified binary 61.2.1. NeoForge21.11.45/FML10.0.36/Bus8.0.5 official
binary inputs have separate checksum evidence. See
[completion-blockers.md](completion-blockers.md).

API/source attributions and compatible reused components retain their
licenses in THIRD-PARTY-NOTICES and licenses/. No source-line percentage is
claimed. Full upstream engine distributions are not embedded.

Remaining work includes stock QSL and early registries, full FML/Forge/NeoForge
patches/registries/global events, automatic subscribers, AT/JarJar/module
semantics, general official/SRG/named mod/refmap remapping, dedicated-server
bootstrap and arbitrary mods. Geometry fixtures do not establish attacks,
damage or PvP. The historical executed results are in
[release-test-report-0.4.md](release-test-report-0.4.md). New 0.4.1 build/game
status is recorded separately in [release-test-report-0.4.1.md](release-test-report-0.4.1.md).
The newly uploaded files are audited in
[uploaded-platforms-0.4.1.md](uploaded-platforms-0.4.1.md); an installer upload
does not enable its platform as an external mod format.
