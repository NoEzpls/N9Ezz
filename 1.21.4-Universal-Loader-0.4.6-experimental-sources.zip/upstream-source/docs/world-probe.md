# Optional offline world acceptance probe

`universal-loader/scripts/world_probe.py` compiles a separate native observer
mod into an isolated smoke directory and calls the ordinary game smoke runner.
The observer is a development fixture; it is not embedded in the installer or
the builtin client. It registers the exact selected Fabric API callbacks for
server lifecycle/ticks, client networking INIT/JOIN, client world change, and
world-render START_MAIN/END_MAIN. It records real world/player objects and their
classloader ownership. It never calls `Pulse.init()` or `N9Ezz.modules()`.

Run against the prepared Mojang client/libraries/assets and the isolated Xvfb
display:

```sh
python3 universal-loader/scripts/world_probe.py \
  --loader universal-loader/dist/N9Ezz-Universal-Loader-0.3.0-experimental.jar \
  --seconds 180 --name n9ezz-shared-world-1 --demo-world
```

With `--demo-world`, after 100 actual client ticks at the initialized Pulse
menu, the diagnostic mod invokes the pinned 1.21.11 vanilla Play Demo button
handler (`class_442.method_19858`). That handler drives the ordinary
IntegratedWorldLoader, creates or loads `Demo_World`, starts the integrated
server, and establishes the local play connection. The fixture assigns the
handler's screen context, but does not create a synthetic world/player, set
addon initialization flags, or manufacture successful events. Omit the option
to observe a world entered manually instead. No account authentication or
multiplayer endpoint is used; the smoke runner's token is the explicit demo
placeholder `0`.

`scripts/x11_input.py --click 640 350` and `--key Escape` send real X11 input to
the isolated display for manual menu/world controls. The helper uses libX11
and libXtst already installed in the environment. It does not require
`xdotool`.

The bounded runner records screenshots, `launch.log`, the existing gameplay
probe's `result.json`, and the separate `world-result.json`. A deadline exit
143 means the runner terminated an otherwise running game; it does not by
itself establish success. The world report's booleans come only from observed
callbacks and actual state. Inspect exceptions and render ordering counters
before claiming a successful run.

This fixture does not establish combat targeting/attack packets, PvP behavior,
arbitrary mod compatibility, command dispatch, or authenticated multiplayer.
Those require separate fixtures and evidence.

After correcting a report-parser defect, `world_probe.py --replay` can
re-evaluate the unchanged recorded log and corrected base `result.json` without
starting another game. It checks that the supplied loader hash matches both
saved reports, preserves the original world report, and records the original
game harness exit status separately from the replay status. This option cannot
provide a missing game observation.
