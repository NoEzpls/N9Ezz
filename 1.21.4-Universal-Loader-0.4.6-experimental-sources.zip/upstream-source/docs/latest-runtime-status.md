# Shared runtime 0.4.1 experimental: current status

One N9Ezz bootstrap/classloader owns Minecraft 1.21.11, the embedded N9Ezz
client and admitted own mods. The installer creates one profile and offers
no engine selection. Upstream Fabric/Quilt/Forge/NeoForge engines are absent.

The 0.4.1 change restricts **all external mod discovery to `n9ezz.mod.json`**.
Foreign platform descriptors, mixed descriptors and nested JARs in external
mods are rejected before external mod code runs. API-only CLI and game startup
use this rule. Internal N9Ezz and the selected API dependencies are fixed by
the existing embedded-source hash checks; moving an external archive into a
cache or giving it a built-in ID does not grant that provenance.

## Current boundary

| Component | 0.4.1 behavior |
| --- | --- |
| Own external mod | Own descriptor and `N9ModInitializer` contract; existing dependency, collision, namespace and bytecode checks still apply |
| Ordinary Fabric/Quilt/Forge/NeoForge mod | Rejected at admission, including opted-in lifecycle descriptors accepted by 0.4.0 |
| Mixed descriptor archive | Rejected even when `n9ezz.mod.json` is also present |
| External nested archive | Unsupported; libraries must not be supplied as nested JARs |
| Embedded N9Ezz and Fabric API | Pinned internal sources; shared Mixin, mapping, access and original selected API hooks retained |
| Quilt/FML adapters | Internal implementation/lower-level test coverage retained; no public admission of their external platform descriptors |

A descriptor declares a format/API contract, not the identity or intentions of
its author. This is not a signature allowlist or a Java security sandbox.
Existing compatibility checks continue to reject unsupported features; adding
JSON to a stock platform mod does not implement a port. The precise rules and
minimal Java author example are in [native-mod-policy.md](native-mod-policy.md).

## Verification for this binary

The full build passed, including 36 admission checks and all previous suites.
Exact installer SHA-256 is `b81855307752b3d20df9bff66175914d2a118e7cce688c15e24b153952c60b3b`.
Four former platform fixtures are rejected by the packaged CLI. The documented
native Java example compiles/packages/verifies/runs successfully. A real189.4s
Minecraft run with two native observers and N9Ezz passed base/world acceptance:
1000 balanced client tick pairs,1500 world/player callbacks,89 server ticks and
282 completed render frames. The demo modal paused the server; no sustained
simulation or combat claim follows. See [release-test-report-0.4.1.md](release-test-report-0.4.1.md).
Final isolated JAR/source ZIP comparison is recorded externally in RELEASE-MANIFEST.md
and dist/tests-0.4.1/reproduction.json after source archive freeze.

The complete embedded client remains SHA-256
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
This policy change does not rewrite client modules, target geometry or packets.

## Preserved historical evidence

The unchanged [0.4.0 report](release-test-report-0.4.md) records a 302.5-second
run of installer SHA-256
`d5f2417ea56c6a297e543bd92e1d1e850f69479ccb97809e80e501c48926dbd6`:
N9Ezz and four explicitly adapted platform fixtures shared one classloader,
with 3698 balanced client ticks, 3500 balanced server ticks and 3500 world/player
callbacks. **Those external fixtures are now intentionally rejected.**
The earlier result proves the old selected lifecycle contracts, not 0.4.1
admission or support for arbitrary platform mods.

The [0.3.1 report](release-test-report-0.3.1.md) and
[0.3.0 world report](world-probe-results.md) remain separate. Old 0.1.0/0.2.0
baselines and prior release artifacts are preserved.

## Remaining limits

Full FML game patches/registries/global events, stock QSL early registry timing,
general Mojang/SRG/named mod/refmap remapping, AT/JarJar/JPMS and dedicated-server
bootstrap remain unimplemented. The new admission rule is an intentional product
restriction, not completion of those features. Remote authenticated multiplayer,
other-player target acquisition, attacks, damage and PvP are unverified.

The submitted installers are audit inputs, not supported mods; see
[uploaded-platforms-0.4.1.md](uploaded-platforms-0.4.1.md).
For exact internal APIs see [compatibility.md](compatibility.md),
[quilt-game-contract.md](quilt-game-contract.md), [fml-game-contract.md](fml-game-contract.md)
and [shared-mixin.md](shared-mixin.md). Historical platform-availability evidence
remains in [completion-blockers.md](completion-blockers.md).
