# Встроенный клиент и общая среда исполнения

Добавлен `BuiltinModSource`: клиент берётся из ресурса установочного JAR по `META-INF/n9ezz/embedded-client.json`. Источник фиксирует resource, id, version, SHA-256 и размер; дубли полей, некорректные типы и неподдержанные версии Minecraft/Java отклоняются. Бинарник проверяется перед использованием. Cache находится внутри выбранной версии: `<gameDir>/.n9ezz/builtin/<sha256>.jar`; пользовательская папка `mods` не требуется для встроенного клиента.

`RuntimeBootstrap.runBundledGame` автоматически добавляет этот источник в тот же список модов, resolver зависимостей, проверки возможностей, class index, `UnifiedClassLoader` и lifecycle. Обычные `run`/`runGame` сохраняют прежнее поведение. Packaged native self-test теперь тоже использует встроенный источник и проверяет READY при пустой `mods`. Для отдельных фиксированных ресурсов доступен `runBuiltins`.

Cache защищён проверкой SHA/размера и блокировкой на конкретный SHA. Изменённый cache и symlink вызывают диагностику, существующий изменённый файл сохраняется. API `describe()`, `verifiedBytes()` и `materialize(gameDir)` позволяют установщику использовать manifest вместо повторных hardcoded SHA и filename.

Проверка Java 21: **54/54 integration checks PASS**, включая шесть новых проверок: встроенный native-mod и внешний зависимый мод используют один classloader; встроенный источник находится вне `mods`; внешняя копия с тем же id отклоняется; повреждённый ресурс и cache отклоняются; встроенный источник подчиняется ограничениям nested JARs; duplicate integrity keys manifest отклоняются. Проверялось на реальных временных JAR-файлах. Эти проверки доказывают путь встроенного источника для поддержанного native API.

Для сохранённого N9Ezz остаются блокеры: nested libraries, intermediary mappings, Mixin и используемые Fabric API/game lifecycle hooks. `BuiltinModSource` намеренно не снимает ни одну из этих проверок. Текущий полный клиент останавливается при чтении nested JARs до entrypoints; упаковка или подготовка cache не доказывает запуск клиента. Для завершения нужны общий remapper, согласованный Mixin bootstrap/transformer, разрешение nested dependencies и реализованные проверенные game/API hooks; запуск на четырёх upstream engines сюда не добавлен.

`GameBootstrap` теперь вызывает `runBundledGame`, а `InstallService` готовит
встроенный cache через тот же `BuiltinModSource`; отдельного клиентского файла
в `mods` нет. Packaged installer suite прошёл 11 проверок. Реальный профиль с
официальным Minecraft 1.21.11 дошёл до встроенного bootstrap и завершился
ожидаемым `METADATA_UNSUPPORTED [mod=pulse] [phase=builtin-discovery]` до
entrypoints и Minecraft main. Лог: `docs/embedded-profile-launch.log`.
Этот результат подтверждает обязательное подключение встроенного клиента и
сохраняет незавершённый статус его исполнения. Отдельный legacy
Fabric-установщик не является доказательством работы клиента в новом ядре.
