# Metadata adapter contract (experimental 0.2.0)

All five formats are parsed into `dev.n9ezz.loader.metadata.ModMetadata` and
resolved together in one runtime. A format identifies a metadata/API contract;
it does not select or boot Fabric, Quilt, Forge, or NeoForge. Parsing a descriptor
does not prove compatibility with the platform's complete API or a Minecraft mod.

The reader uses independently written format adapters, Gson 2.13.2 for strict
JSON tokenization, and Tomlj 1.1.1 for TOML. The distribution retains their upstream
licenses and notices. Platform format behavior was checked against official
source references in the accompanying audit documents. No loader source was
copied into these adapters.

| Descriptor | Accepted fields relevant to loading | Entrypoints | Default mapping namespace |
| --- | --- | --- | --- |
| `n9ezz.mod.json` | schemaVersion 1 (may be omitted), id, version, depends/recommends/suggests/breaks/conflicts, provides, environment, entrypoints, mixins, namespace | common/client arrays of class names; default adapter | none |
| `fabric.mod.json` | schemaVersion 1, id, version, depends/breaks maps, provides, environment, entrypoints, mixins | main becomes common; client remains client; default Java class adapter | intermediary |
| `quilt.mod.json` | schema_version 1, quilt_loader.id/version/depends/breaks/provides/entrypoints/load_type, minecraft.environment, mixin | main/client as Fabric contracts; init becomes common and uses the limited QSL initializer contract | intermediary |
| `META-INF/mods.toml` | modLoader, loaderVersion, license, multiple mods records, dependencies per mod, mixins and manifest MixinConfigs | matching @Mod class discovered from bytecode; initialized in common phase | official |
| `META-INF/neoforge.mods.toml` | same model; dependency type required/optional/incompatible | matching NeoForge @Mod class discovered from bytecode | official |

Descriptive fields such as names, authors, contact, descriptions and icons do not
affect loading and are not rejected. Unknown fields do not grant functionality.
The reader rejects known unsupported loading mechanisms rather than ignoring
them. No standard loader ABI or engine dependency is satisfied by an unrelated
N9Ezz version.

Native descriptor example:

```json
{
  "schemaVersion": 1,
  "id": "example_mod",
  "version": "1.0.0",
  "namespace": "none",
  "depends": { "java": ">=21", "n9ezz": ">=0.2.0" },
  "entrypoints": { "common": ["example.ExampleMod"] }
}
```

The initializer implements `dev.n9ezz.loader.api.N9ModInitializer`. Fabric and
Quilt JSON may explicitly declare `"n9ezz":{"namespace":"none"}` for API-only
fixtures. TOML may declare the equivalent `[n9ezz]` table. This fixture extension
does not remap game code or make intermediary/named/SRG bytecode runnable.

For Forge/NeoForge-format API-only fixtures, `modLoader="n9ezz"` explicitly opts
into the experimental N9Ezz language contract. `loaderVersion` becomes an actual
dependency on `n9ezz`. Standard `modLoader="javafml"` retains a dependency on
`javafml`; this prototype does not fabricate a JavaFML ABI version and therefore
rejects those mods during resolution. TOML-format smoke success is not a claim
that a standard Forge or NeoForge mod can run.

```toml
modLoader="n9ezz"
loaderVersion=">=0.2.0"
license="MIT"

[[mods]]
modId="example_forge_contract"
version="1.0.0"

[n9ezz]
namespace="none"
```

Dependency maps use string predicates or arrays of predicates. Arrays are OR
alternatives, preserved as ` || ` for the common resolver. Quilt dependencies
use arrays of `{ "id": "...", "versions": "...", "optional": false }` records;
versions may also be an OR-array. TOML dependencies use `[[dependencies.MOD_ID]]`
with `modId`, `versionRange`, `mandatory` or `type`, optional `side`, and optional
`ordering`. `mandatory=false` and `type="optional"` remain optional. A matching
`type="incompatible"` dependency blocks loading. Contradictory `mandatory` and
`type` declarations are errors. Side SERVER dependencies are irrelevant to the
client and excluded. BEFORE/AFTER ordering is explicitly rejected because the
current dependency model cannot preserve those ordering semantics; NONE works.
Engine dependencies such as fabricloader/quilt_loader/forge/neoforge are kept
verbatim and must resolve against an explicitly supported implementation.
Fabric recommends/suggests/conflicts have upstream warning semantics and are
explicitly unsupported when nonempty: the current model cannot preserve soft
diagnostics. Native recommends/suggests define an optional dependency whose
version must match when present; native conflicts/breaks are hard incompatibilities.

One JAR may contain several Forge/NeoForge mods, each with its own dependencies.
Duplicate IDs fail. An independent version for a provides alias is unsupported;
aliases share the provider's real version. Fabric-style metadata supports the
default class adapter only, without class::method factories. The current Quilt
init contract follows the documented QSL API subset, not a verified QSL release
for Minecraft 1.21.11. preLaunch, server, client_init, and server_init phases fail
because this runtime has no accurate game lifecycle hook for them.

Supported mixin metadata is recorded, including JSON client filtering, Quilt
`mixin`, TOML `[[mixins]]`, and manifest `MixinConfigs`. Declared resources must
exist. The runtime currently rejects nonempty mixin lists: metadata support is
not a Mixin transformer implementation. Access wideners, access transformers,
coremods, ModLauncher services, custom language adapters, Quilt plugins and
conditional/grouped Quilt dependencies also fail with explicit diagnostics.
Quilt load_type values other than always and intermediate_mappings other than
net.fabricmc:intermediary are unsupported. Forge/NeoForge feature predicates and
conditional mixin requiredMods are rejected until their conditions can be honored.

ZIP inspection rejects duplicate entries, traversal paths, control characters,
absolute paths, nested JAR resources and Forge JarJar metadata. No archive is
extracted while reading metadata. More than one recognized descriptor format in
one JAR is ambiguous and fails; no engine is selected automatically. A JAR with
no recognized descriptor returns an empty list for discovery to classify.
The installer/runtime JAR itself contains bundled dependency archives and is
not a mod JAR to place in the mods directory.

Descriptors are bounded to 1 MiB decompressed UTF-8. Strict JSON rejects duplicate
keys, comments, trailing content, malformed types and nonintegral schema versions;
depth, item counts and string lengths are bounded. TOML reports parse errors,
duplicate declarations and bounded metadata structures. `${file.jarVersion}` is
supported only for a TOML mod version with a manifest Implementation-Version;
other unresolved placeholders fail. Parser errors use METADATA_INVALID,
METADATA_UNSUPPORTED, METADATA_AMBIGUOUS or METADATA_UNSAFE and include the JAR
name. Initialization occurs only after discovery and resolution succeed.

Integration tests package real temporary JARs for all formats in one runtime and
check event ordering, dependencies, duplicate classes/IDs, ambiguous/malformed
metadata, denied API references and unsupported transforms. Their successful
headless execution verifies this stated subset only. Full N9Ezz-client,
Fabric API, Quilt QSL 1.21.11, Forge and NeoForge game compatibility remains
unverified and incomplete; see the compatibility and test reports.
