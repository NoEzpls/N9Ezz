# N9Ezz 0.3.1 experimental: проверки выпуска

Дата: 8 октября 2026. Цель: Minecraft 1.21.11, Java 21; использован полный
Temurin 21.0.8+9. Это выпуск локальной диагностики с сохранённым общим
runtime. Финальная полная сборка завершилась exit 0. Immutable JAR:
53,452,228 bytes; SHA-256
`91129f58913d00e0d8be74b08c216ade07ec0fd1805df45e5cf3ba5da7e2b7ab`.
Именно этот бинарник прошёл 180-секундный real-game smoke: оба отчёта
`passed: true`, harness exit 0, без replay. Результаты isolated reproduction
JAR/source ZIP публикуются в отдельном внешнем release receipt; source ZIP
не содержит собственной контрольной суммы.

## Изменения и сохранность клиента

Распознанные credentials скрываются в выводе Diagnostic/CLI/game bootstrap/
installer; полные trace frames, codes, nested causes и suppressed exceptions
сохраняются. Help соответствует реализованным Mixin, intermediary mappings и
шести выбранным Fabric API modules. Installer smoke читает версию из
manifest, чтобы проверять устанавливаемый артефакт.

Полный встроенный N9Ezz остаётся SHA-256
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`,
41,062,124 bytes. Все 144 архивируемых файла `client/` совпали byte-for-byte
с source distribution 0.3.0. Module logic и packets не менялись.
Базовый Pulse остаётся binary input: чистых Pulse sources нет, поэтому
полная сборка его host-кода из исходников не заявлена.

## Проверки текущей итерации

| Проверка | Текущий результат | Граница |
| --- | --- | --- |
| Local diagnostic privacy | 71/71 PASS, включая 38 review edge cases | Только перечисленные loader output boundaries |
| Все предыдущие runtime/Java suites | PASS после финальных privacy изменений | Точные counts сохранены в build reports |
| Gameplay acceptance parser | 9/9 PASS | Проверки анализа отчётов, отдельно от реального game run |
| Installer metadata | 11/11 PASS | Manifest-derived version; формат профиля и установка, отдельно от game launch |
| Client сохранность | PASS, 144 source files и полный client SHA-256 неизменны | Это сохранность, не новая проверка атак |
| Финальный JAR | PASS, полный build exit 0; хеш указан выше | Immutable candidate для game run |
| Isolated reproducibility | Сверка отражается во внешнем release receipt | Отдельная чистая пересборка финального source ZIP/JAR |
| Финальный real-game run | PASS, harness exit 0, оба отчёта passed true | Проверен exact immutable SHA-256 выше, без replay |

Повторно прошли: 54 core runtime, 26 mappings, 17 remapper fingerprint/cache,
18 access widener, 40 nested discovery, 11 real Mixin subprocess scenarios,
9 Fabric services, 9 Fabric entrypoints, 77 Fabric dependency, 20 game
integration, 21 builtin client contract, 29 resource-pack checks, 8 client
updater checks и packaged native smoke. Полные результаты находятся в
`universal-loader/dist/`; installer suite содержит 11 проверок.

Финальный world smoke использовал immutable
`/workspace/minecraft-smoke/candidates/N9Ezz-Universal-Loader-0.3.1-reviewed-final.jar`
с указанным выше SHA-256. Его отдельный каталог evidence:
`/workspace/minecraft-smoke/n9ezz-local-diagnostics-031-final/`.

| Наблюдение final 0.3.1 | Результат |
| --- | --- |
| Инициализация | Pulse/N9Ezz initialized, 113 registry entries, 30 addon fields; все три combat modules зарегистрированы |
| Client callbacks | 100 записанных balanced tick pairs, zero ordering failures |
| World/player | 500 callbacks с реальными world/player; последний clientTicks counter 692 |
| Integrated server | SERVER_STARTING/STARTED, 101 genuine simulation tick callbacks |
| Local play | INIT, JOIN, AFTER_CLIENT_WORLD_CHANGE |
| Рендеринг | 100 recorded balanced START_MAIN/END_MAIN frame pairs, zero ordering failures |
| Владение классами | Client/addon/server/network/world/player: `UnifiedClassLoader@7bb35cc6` |

Game process оставался живым до deadline 180 секунд и завершён runner-ом с
exit 143; полное время с bounded shutdown — 185.7 секунды. Harness завершился
exit 0, оба `result.json`/`world-result.json` passed true без replay. Demo modal
оставался открыт и приостановил server simulation после 101 ticks. World-state
callbacks и render frames не выдаются за непрерывную unpaused simulation.
Не заявляется 1000+ balanced client ticks: этот более высокий counter относится
к другому preliminary candidate ниже. Копии raw evidence:
`docs/game-0.3.1-result.json`, `docs/world-0.3.1-result.json` и
`docs/game-0.3.1-launch.log`.

Предварительный 0.3.1 JAR SHA-256
`411eb849dfd192101906253a1e6e8c035e9f581b01c1f78acf5d99bf9b9baf8a`
прошёл 180-секундный shared-runtime world smoke: 1000 matched client tick
pairs, 1500 callbacks с реальными world/player, 48 genuine server ticks,
263 render pairs, zero ordering failures, одинаковый
`UnifiedClassLoader@2c6ee758`. Demo modal приостанавливал server simulation;
client callbacks не выдаются за simulation ticks. Raw evidence находится
в `/workspace/minecraft-smoke/n9ezz-local-diagnostics-031/`.
Эти результаты относятся к предварительному бинарнику.

Историческая 0.3.0 game/rebuild acceptance относится только к JAR
`b52e9c071753fd453f633e65e11fb979179f8674309f730dbd41c97471b847b9`:
300 секунд, 4000 client tick pairs, 4000 world-state callbacks, 3682 server
ticks, 2042 render pairs. Полный неизменённый отчёт находится в
[world-probe-results.md](world-probe-results.md).

## Ограничения

| Возможность | Статус |
| --- | --- |
| Native/shared runtime и выбранные Fabric contracts | Реализованы в одном ядре; точные версии и binary-specific тесты обязательны |
| Fabric API | Только шесть зафиксированных modules, не произвольная umbrella/API совместимость |
| Quilt QSL и Quilt game integration | Не реализованы для gameplay; metadata/API-only fixtures не доказывают game compatibility |
| Forge/NeoForge | Game patches, registries, JavaFML, AT/JarJar/module semantics не реализованы |
| Dedicated server bootstrap | Не реализован; integrated server клиентского demo — отдельная проверенная граница |
| Произвольные mods, named mappings и general refmap remapping | Не поддержаны |
| Hitboxes/TriggerBot/KillAura | Изменения геометрии сохранены; real attack packets, target QA и PvP не проверены |
| Remote authenticated multiplayer и direct command dispatch | Не проверены |

Privacy contract находится в
[local-diagnostics-privacy.md](local-diagnostics-privacy.md). Этот выпуск не
изменяет заявленные платформенные или боевые ограничения.
