# Actual N9Ezz client integration audit

> Historical 0.2.0 integration audit. Its discovery rejection and unavailable
> game mechanisms describe the preserved earlier binary. Source and client
> observations remain useful provenance. Current 0.3.0 integration and actual
> launch results are in [latest-runtime-status.md](latest-runtime-status.md).

The supplied N9Ezz client is **not supported by the new API-only core**. This is established by running verification against its actual unchanged binary, not by treating a fixture as the client. The old bundled client remains preserved.

## Artifacts examined

| Artifact | Identity and integrity | Observation |
| --- | --- | --- |
| Old installer blob `loader/build/resources/bundle/blobs/2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb.jar` | `pulse`, version `1.5.3-n9ezz`; SHA-256 matches its filename | Actual old client; 656 classes, all Java 21 class version 65 |
| Old installer blob `86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5.jar` | `fabric-api`, version `0.141.3+1.21.11`; SHA-256 matches its filename | Fabric API umbrella jar, zero root classes and 43 nested modules; provides alias `fabric` |
| Uploaded `PulseVisuals_crack1.21.11 (4).jar` | `pulse`, version `1.5.0-n9ezz`; SHA-256 `ca978a7726fbb13ad196484439611e2c2ca1ffb1947a3ddb443c8bc30b4bfd52` | Already a patched N9Ezz client, not the original Pulse base requested by the Gradle merge task |
| `client/src/main/resources/fabric.mod.json` | `n9ezz_overlay`, version `1.5.3`; depends on `pulse` | Overlay development metadata; different from the final merged `pulse` client identity |

The original Pulse visual source code is not in the source archive. `client/libs/README.txt` requires `Pulse-visuals-1.21.11-BETA.jar`, which is absent. The supplied archive's `README-CODEX.md` explicitly distinguishes that missing base from already patched N9Ezz jars. Neither existing patched jar was falsely substituted for the missing original in the `fullClient` workflow.

Full static inventory, metadata, nested module versions, mixin lists and referenced binary API members are in [n9ezz-integration-evidence.json](n9ezz-integration-evidence.json).

## Actual metadata and binary contracts

The merged client's two `main` entrypoints are `ru.pulse.Pulse` and `pulse.TestMod`. `javap` verified that both implement `net.fabricmc.api.ModInitializer` and have public no-argument constructors. The `client` entrypoint array is empty. The N9Ezz module setup is integrated into the existing client rather than declared as a separate client initializer in the merged artifact.

Actual root dependencies are `fabricloader >=0.17.0`, `fabric *`, `minecraft 1.21.11`, and `java >=21`. The development overlay requires `fabricloader >=0.19.2` and `pulse *`; `client/build.gradle` pins Fabric Loader `0.19.2`, Fabric API `0.141.3+1.21.11`, Yarn `1.21.11+build.6:v2`, Loom `1.16.2`, and Java 21. Source names use Yarn's named namespace; the packaged runtime binary references intermediary classes such as `net/minecraft/class_310`. A vanilla official-named game jar cannot directly satisfy those descriptors.

The client declares six nested libraries, each carrying Fabric metadata:

| Nested jar | Mod identity | Version |
| --- | --- | --- |
| `json-20250517.jar` | `org_json_json` | `20250517` |
| `kotlin-stdlib-1.9.22.jar` | `org_jetbrains_kotlin_kotlin-stdlib` | `1.9.22` |
| `okhttp-4.12.0.jar` | `com_squareup_okhttp3_okhttp` | `4.12.0` |
| `okhttp-sse-4.12.0.jar` | `com_squareup_okhttp3_okhttp-sse` | `4.12.0` |
| `okio-jvm-3.6.0.jar` | `com_squareup_okio_okio-jvm` | `3.6.0` |
| `zero-allocation-hashing-0.16.jar` | `net_openhft_zero-allocation-hashing` | `0.16` |

Nested extraction therefore requires identity/dependency normalization, one shared classpath, duplicate checks, integrity tracking, and inherited provenance. Removing the `jars` declaration would merely hide those requirements.

## APIs and hooks actually used

Binary constant-pool inspection and source inspection found these required APIs. They are not implemented by the current initializer shims.

| Required API or hook | Actual usage |
| --- | --- |
| `FabricLoader.getInstance().getConfigDir()` | `ConfigSnapshots`, `FriendSupport`, `PowerModes` persist configurations, friends and power mode |
| `ClientTickEvents.START_CLIENT_TICK` | `CombatDispatch` selects and prepares actions at tick start |
| `ClientTickEvents.END_CLIENT_TICK` | `N9Ezz` and `PulsePlayerTracker` update state after a tick |
| `ClientLifecycleEvents.CLIENT_STARTED` / `CLIENT_STOPPING` | Pulse tracker/client startup and shutdown |
| `ClientPlayConnectionEvents.JOIN` / `DISCONNECT` | Server connection state |
| `ClientCommandRegistrationCallback.EVENT`, `ClientCommandManager.literal/argument`, `FabricClientCommandSource.sendFeedback/sendError` | `/cfg` command registration and feedback |
| `KeyBindingHelper.registerKeyBinding` | Pulse GUI keybind registration |
| `WorldRenderEvents.END_EXTRACTION` and `WorldExtractionContext` world/frustum/tickCounter/worldRenderer access | Hitbox visual frame extraction |
| `net.fabricmc.fabric.api.event.Event.register(Object)` | Listener registration for all those modules |

The actual client declares 71 Pulse client mixins plus 10 N9Ezz client mixins. Both configurations are required with `defaultRequire=1`; Pulse also requires `Minecraft-refmap.json`. N9Ezz's source hooks include:

| Mixin | Required game transformation |
| --- | --- |
| `ProjectileTargetMixin` | Redirect `ProjectileUtil.raycast` calls to candidate entity search and bounding-box lookup |
| `PlayerDamageMixin` | Inject before/after `PlayerEntity.attack` |
| `AimFrameMixin` | Inject at `GameRenderer.render` head |
| `CombatInputMixin` | Inject at `KeyboardInput.tick` tail |
| `NoSlowMixin` | Cancellable return injection into active-item movement multiplier |
| `CombatEntityMixin` | Entity push, velocity and slow-movement injections/variable changes |
| `ReachMixin` | Cancellable return injection into entity interaction range |
| `AttackCallbackMixin` | Client interaction manager `attackEntity` head/tail callbacks |
| `CombatTickMixin` | Client player `sendMovementPackets` tail hook for attack dispatch ordering |
| `SlotSyncAccessor` | Invoker for client interaction manager selected-slot synchronization |

Those hooks must run before the corresponding game classes are defined. Merely invoking the two initializer interfaces before vanilla main does not install any of them.

Fabric API's 43 nested modules are also executable integration components, not an initializer-only library. For example, lifecycle-events declares common and client implementation entrypoints and mixins; networking uses `Class::method` entrypoints; command-api declares client/common mixins and an access widener. Twenty of the bundled modules declare access wideners. The current core rejects method adapters, nested jars, mixins and widening semantics. Its reserved platform namespaces also prevent arbitrary Fabric API implementation jars from replacing parent-owned API classes; introducing vetted API modules requires a precise new class-ownership contract.

## Executed verification

Copied the two unchanged old blobs to an isolated temporary mods directory and ran Java 21 against the current compiled core:

```text
java -cp '<compiled core>:universal-loader/.cache/deps/*' \
  dev.n9ezz.loader.launch.Main --verify --game-dir /tmp/n9ezz-integration-audit
```

Result: exit 1, `METADATA_UNSUPPORTED`, phase `discovery`, source `N9Ezz-1.5.3-original.jar`, exact message:

```text
nested JARs/JarJar are unsupported; extract and declare dependencies explicitly
```

An independent second run with only the unchanged Fabric API umbrella jar also returned exit 1 with the same diagnostic and its own jar as the source. No entrypoint ran. Neither run modified a jar or metadata to force a pass.

This is the first measured blocker. Additional unsupported requirements below follow from actual source/bytecode and the core's declared contracts; they are not represented as successful later stages of that failed run:

- The resolver does not advertise a FabricLoader ABI/version provider, so the real `fabricloader` requirement cannot be satisfied.
- The current feature gate rejects both required mixin configurations and the intermediary game namespace.
- Fabric API tick, lifecycle, rendering, networking, command and keybinding hooks are absent.
- FabricLoader configuration access, game remapping, access wideners and Pulse/N9Ezz transforms require real implementations.

## Supported Gradle workflow attempt

Executed the repository's default original-base workflow, with a workspace Gradle home and the installed JDK 21:

```text
JAVA_HOME=/workspace/toolchains/jdk-21.0.8+9 \
GRADLE_USER_HOME=/workspace/caches/gradle \
bash ./gradlew --no-daemon fullClient --stacktrace
```

For this managed environment the JVM additionally used the inherited HTTPS proxy endpoint through JVM proxy properties and the existing trusted system Java CA store `/etc/ssl/certs/java/cacerts`. TLS verification remained enabled; no checksum was altered. An initial direct-JVM DNS failure and the proxy CA trust failure were diagnosed and corrected before this final attempt.

Gradle `9.5.1` started and Loom `1.16.2` configured. The final attempt failed during dependency remapping with `java.nio.file.NoSuchFileException: /workspace/N9Ezz/client/libs/Pulse-visuals-1.21.11-BETA.jar`, wrapped as `Failed to compute checksum`. The exact stacktrace is preserved in [client-gradle-build-attempt.log](client-gradle-build-attempt.log). No build declarations, dependency versions, lockfiles or checksums were changed. `fullClient` and the repository Gradle test tasks therefore did not complete.

A current read-only HTTPS request for the official Loom `1.16.2` POM at `maven.fabricmc.net` returned HTTP 200 through the inherited proxy. The actual final blocker is the absent original Pulse base; this run does not establish that Fabric Maven is currently denied. Some dependency/game artifacts were already present in the workspace cache, so this attempt also does not prove a clean online client build.

Later official platform probes are preserved in [platform-metadata-probes.json](platform-metadata-probes.json): Mojang's 1.21.11 release metadata, Fabric 0.19.2 metadata, Quilt 0.30.1 metadata, and NeoForge 21.11.45 artifact metadata were accessible. Forge Maven metadata returned HTTP 403. These measured results supersede any earlier blanket assumption that Minecraft/Fabric/Quilt/NeoForge hosts were denied. They do not establish that all dependencies of a clean build or any platform game launch succeed.

## Addon compilation and tests completed

A separate supported compile/test command used the unchanged old `1.5.3-n9ezz` jar strictly as a **compile dependency**, without invoking `mergeClient` or `fullClient`:

```text
bash ./gradlew --no-daemon --max-workers=2 \
  classes remapJar qaClasses \
  combatTest animationTest aimTest pvpTest systemsTest powerTest hitboxTest \
  -PpulseJar=/workspace/N9Ezz/loader/build/resources/bundle/blobs/2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb.jar \
  --stacktrace
```

The same JDK 21, workspace Gradle home, managed JVM proxy and verified system CA store were used. Repository parallel execution remains disabled; maximum Gradle workers were limited to two, with the repository's 2 GiB JVM cap. Loom rebuilt its cache after the earlier failed configuration and remapped the different dependency; this rebuild was necessary because its input changed.

Result: **BUILD SUCCESSFUL**, exit 0, 14 tasks executed in 2 minutes 55 seconds. The changed production classes, all mixin source classes, and the QA fixture sources compiled against the pinned Minecraft/Yarn/Fabric artifacts. `remapJar` produced the `n9ezz_overlay` artifact `client/build/libs/n9ezz-fabric-1.21.11-1.5.3.jar` (SHA-256 `80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206`). This 168 KiB jar is an addon overlay, not the complete N9Ezz client.

| Repository task | Passed checks |
| --- | ---: |
| `combatTest` | 1,647 |
| `animationTest` | 1,003 |
| `aimTest` | 14,073 |
| `pvpTest` | 113 |
| `systemsTest` | 13,679 |
| `powerTest` | 1,063 |
| `hitboxTest` | 3,036 |
| Total | 34,614 |

Output is preserved in [client-addon-build-attempt.log](client-addon-build-attempt.log). The remapped old dependency produced unresolved-target warnings for some existing Pulse mixin members; these were retained, and successful addon compilation does not validate those old transforms. `qaClasses` checked source compilation only: in-world and wire-order fixtures were not executed. No Minecraft launch is claimed by this successful compile/test command.

An eventual updater for an already patched client must replace the old addon classes and validate all preserved host-to-addon references while retaining existing host hooks exactly once. The existing `MergeClient` assumes an original host and injects hooks and metadata unconditionally; it must not be run on the patched old client as though it were the missing original base.

## Integration stages still required

1. Obtain the actual original Pulse base for the declared reproducible `fullClient` workflow, or design an explicitly separate, provenance-preserving update workflow for an already patched client. A patched jar must not be mislabeled as the original base.
2. Add bounded nested-jar discovery and dependency/provider normalization, retaining immutable hashes, licenses and the single runtime classloader; test class/provider duplicates and nested ownership.
3. Pin and implement the 1.21.11 game namespace strategy, remap official/intermediary/named descriptors consistently, preserve refmaps, and verify transformed bytecode.
4. Install one real shared Mixin service and access-widener pipeline before any target game class definition. Validate all 81 actual client mixins and needed selected Fabric API mixins against exact game bytes.
5. Implement the required config-directory service and selected Fabric API events with actual Minecraft lifecycle, rendering, connection and tick hooks. Bridge them to the shared environment rather than invoking a Fabric loader engine.
6. Run both actual initializers at their required game stages, verify N9Ezz registration, and then test real vanilla client startup, world entry, module toggles, tick/input/attack ordering, disconnection and shutdown. Preserve the existing Fabric-based old build until those launches pass.

The source/fixture checks available in the experimental core do not replace these real integration tests. No Minecraft launch or N9Ezz execution under the new runtime is claimed by this audit.

## Subsequent bundled-client update and profile verification

The separate provenance-preserving updater from stage 1 above is now implemented
and tested. `MergeBundledClient` updates the fixed original 1.5.3 client with the
compiled Java addon, retains host hooks/metadata/refmap/nested libraries, and
produces SHA-256 `2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
See [client-bundle-overlay-review.md](client-bundle-overlay-review.md) for the
ABI, bytecode and repeatability evidence. The original `fullClient` workflow
remains unavailable because its clean Pulse input is absent; the new updater
does not relabel the patched input as a clean base.

The updated complete client is embedded in the universal installer. It is
automatically registered through `BuiltinModSource` and `runBundledGame` in the
same resolver/classloader, outside the user mods folder. The installed profile
with real official Minecraft 1.21.11 bytes was exercised: bootstrap selected the
builtin source and returned the expected `METADATA_UNSUPPORTED` for nested JARs
before any entrypoint or game main. Evidence:
[embedded-profile-launch.log](embedded-profile-launch.log) and
[embedded-runtime-review.md](embedded-runtime-review.md).
This supersedes the earlier packaging gap while preserving the unimplemented
game runtime stages 2–6 and the unverified N9Ezz gameplay status.
