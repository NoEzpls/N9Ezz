# Bounded shared-runtime nested discovery

`NestedJarResolver` is Java 21 code owned by N9Ezz. It discovers an explicit Fabric
jar-in-jar closure without starting Fabric Loader, executing a nested entrypoint,
or constructing another classloader. Builtin modules enter as materialized,
manifest-verified `Source` paths; external mods enter through sorted
`directorySources`. The runtime consumes one result with `mods`, metadata-less
`libraries`, all included `archives`, `features`, and an `omitted` inventory.

The existing `MetadataReader.read(path)` contract is unchanged. It still rejects
nested archives, access wideners, custom entrypoint references, and unsupported
platform transformers. Only the explicit `ReadPolicy.FABRIC_RUNTIME` accepts
Fabric `jars`, one declared access-widener resource, default `Class::member`
entrypoint references, and optional/incompatible dependency metadata. Parsing
retains declarations; the runtime must activate supported mechanisms separately.
Quilt nested archives, Forge JarJar, FML transformers, custom language adapters,
and non-client entrypoint phases remain rejected.

Each root may pin a SHA-256. Every child is extracted exactly as stored under
`.n9ezz/nested/<sha256>.jar`; its recorded provenance includes original source,
parent SHA-256, resource entry, depth, length, IDs and content hash. Existing cache
bytes must match their name and expected length. Corrupt files are preserved with
a diagnostic, and per-hash file locks prevent simultaneous extraction. Cache and
source symlinks are rejected. All archive entry paths, duplicate ZIP entries,
decompressed lengths and CRC-32 are checked. Roots are hashed again after
discovery to detect changes during scanning.

Default limits are depth 8, 256 inspected archives, 128 MiB per archive, 64 MiB
per child, 256 MiB expanded bytes across the scan, 200,000 entries per archive,
and compression ratio 1000 for entries larger than 1 MiB. These are upper bounds,
not targets. A declared nested library may omit metadata only when explicitly
allowed by `Limits`; a metadata-less JAR in the external mod directory fails.

Identical content shared by multiple parents is loaded once and retains every
origin. Different content with the same mod ID or alias fails before entrypoints.
Different archives containing the same effective Java class also fail. An
ancestry guard rejects a repeated ancestor content hash; recursive archives are
independently bounded by depth. Selection must name exact child mod IDs and
cannot change for the same root content within one closure.

The verified N9Ezz 1.5.3 base client has six nested generated-library descriptors:

| ID | Version | SHA-256 |
| --- | --- | --- |
| `org_json_json` | `20250517` | `fa57ffcb3ce9bd1612da3a47e1d6e955137628d9a4af525d283c0035e94c48e6` |
| `org_jetbrains_kotlin_kotlin-stdlib` | `1.9.22` | `954494dbf818f915bc8ae0e5df87250e8bbe63da29fda35ba02f4751d3c167c7` |
| `com_squareup_okhttp3_okhttp` | `4.12.0` | `5bb8c90585971a170662fc80aa4196642f34dfbe24b86a3befef48f9d651c0fc` |
| `com_squareup_okhttp3_okhttp-sse` | `4.12.0` | `9b072b85ee96f680d76fb9a27f863ff74e2900ba026982ee4961b3daf30e8ec2` |
| `com_squareup_okio_okio-jvm` | `3.6.0` | `2730b50b06f35bb59a2984c0a2336c613f6e961f14759777545a552e209a338b` |
| `net_openhft_zero-allocation-hashing` | `0.16` | `758f4c38f8831a16838d75d41527944f68618da69018e62aa029543905ec291b` |

The official Fabric API `0.141.3+1.21.11` umbrella is pinned to
`86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5`.
It declares 43 child modules and the alias `fabric`. The targeted runtime selects
six modules; the remaining 37 are inventoried and validated but excluded from
the classpath. Keeping the original alias satisfies the client's published
dependency identity; it does not promise all Fabric API APIs are implemented.

| Included module | Version | Access widener |
| --- | --- | --- |
| `fabric-api-base` | `1.0.5+4ebb5c083e` | none |
| `fabric-command-api-v2` | `2.4.7+6b42a6003e` | `fabric-command-api-v2.accesswidener` |
| `fabric-key-binding-api-v1` | `1.1.7+4fc5413f3e` | none |
| `fabric-lifecycle-events-v1` | `2.6.15+4ebb5c083e` | `fabric-lifecycle-events-v1.accesswidener` |
| `fabric-networking-api-v1` | `5.1.5+ae1e07683e` | `fabric-networking-api-v1.accesswidener` |
| `fabric-rendering-v1` | `16.2.10+0290ad933e` | none |

`NestedDiscoveryTests` passes 44 checks with these real artifacts: 14 included
archives/mod descriptors, 37 omitted modules, three access wideners, and no class
collision in the selected closure. The tests also cover corrupted caches/pins,
shared dependencies, external ID/alias and class conflicts, missing/ambiguous
selections, metadata-less library policy, nested depth/count/size/entry limits,
compressed ZIP bombs, duplicate ZIP entries, bad CRCs and source/cache symlinks.
The cycle guard uses a simulated ancestry state: a finite physical archive
containing its own SHA-256-identical byte representation would require a hash
fixed point, so no artificial self-nested binary is claimed as a real fixture.

These discovery checks do not establish successful Minecraft startup, Mixin
application, access widening, Fabric API hook invocation, or N9Ezz gameplay.
Those mechanisms are tested by the runtime integration reports separately.
