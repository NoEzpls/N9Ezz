# Shared Mixin implementation

The common runtime now has one real `IMixinService` implementation, `UniversalMixinService`, plus its bootstrap and global property services. It runs Sponge Mixin and MixinExtras directly. It does not instantiate Knot, LaunchWrapper, FML or ModLauncher.

## Locked upstream components

| Component | Provenance | Version | SHA-256 | License |
|---|---|---|---|---|
| Fabric's Sponge Mixin distribution | `net.fabricmc:sponge-mixin`; official Fabric Loader 0.19.2 `gradle.properties` pins this exact release | `0.17.2+mixin.0.8.7` | `95cef6aebd9da1559cf9c4624eafae2ce1242d0167e3587d5d62c488e45b6999` | MIT, retained verbatim |
| MixinExtras | `io.github.llamalad7:mixinextras-fabric`; exact Fabric Loader 0.19.2 pin | `0.5.4` | `bd79ddb2f54b39a08deeb50cb12439bba01481264dd5a9f5ea830551bfef31ff` | MIT, retained verbatim |

The Fabric-named MixinExtras artifact contains the platform-independent bootstrap and injector implementation. N9Ezz calls `MixinExtrasBootstrap.init()` itself; it does not start its Fabric plugin or a Fabric loader. ASM 9.9.1 remains the single ASM implementation. Mixin's POM requests ASM tree, commons and util; the Mixin archive contains its internally relocated Guava classes, so an additional Guava implementation is unnecessary.

## Runtime contract and ordering

`MixinRuntime.register(pipeline)` inserts exactly one transformer in `MIXIN`, after `MAPPING`, `ACCESS` and `CORE`, before `POST`. Indexing freezes the pipeline before the host attaches. Initialization selects the own host explicitly with Mixin's supported service system properties and verifies the global property provider. Own service descriptors are retained under `META-INF/services`.

The bytecode provider reads `UnifiedClassLoader.classBytes(name, true)` with only stages before `MIXIN`. It does not recursively run Mixin or `POST` while Mixin resolves target and hierarchy bytecode. Raw requests return copies of the original indexed bytes. Target classes, loadable accessor interfaces, configuration plugins and generated inner helpers use the same `UnifiedClassLoader`. Non-loadable implementation mixins are registered as invalid and cannot be defined directly.

Initialization advances upstream phases `PREINIT -> INIT -> DEFAULT` before any game or entrypoint class definitions. Upstream has no public phase advancement API for this host model, so the single bridge uses the pinned version's `MixinEnvironment.gotoPhase` reflectively and reports bootstrap failure if its contract changes. The side is explicitly `CLIENT` or `SERVER`. Configurations carry mod IDs in Mixin's source and Fabric-distribution decorations; failures retain their real injector cause. Config plugins may load their own ordinary classes during initialization; a plugin which prematurely defines a target is subject to upstream loaded-target rejection.

The upstream subsystem has JVM-lifetime singleton state. A second common Mixin runtime in one JVM is rejected, including after close. Launcher restarts use a fresh JVM. This prevents claiming that unrelated sessions can safely share cached upstream config and transformer state.

## Executable verification

`dev.n9ezz.loader.tests.MixinIntegrationTests` runs eleven isolated Java 21 processes. Positive fixtures execute a real `@Inject` result of 13 after `CORE` changes 2 to 3, a real `@Redirect` result of 8, a MixinExtras `@ModifyReturnValue` result of 10, private-field accessors, a private-method invoker, an actual generated inner helper returning 31, a config plugin, and client/server filtering. The audit trail confirms actual application and helper generation. Class tracking verifies target definition and blocks non-loadable mixin implementations.

Negative fixtures reject missing, duplicate and malformed configs, reject an unmatched required injection before target definition and before `POST`, and reject transformation after closing the runtime. The negative required-injection case deliberately emits an upstream fatal diagnostic while the test checks that the failure is caught and no target is defined.

These fixtures establish working Mixin machinery. They do not establish that all N9Ezz or Fabric API mixins match Minecraft 1.21.11. The game integration report must separately list which pinned configurations actually applied during an official game launch and where that launch stopped.
