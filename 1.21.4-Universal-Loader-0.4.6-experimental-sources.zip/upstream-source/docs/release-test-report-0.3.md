# N9Ezz Universal Loader 0.3.0 experimental — отчёт выпуска

Проверено 8 октября 2026 UTC. Цель сборки: Minecraft **1.21.11**, Java **21**.
Runtime, установщик и изменения клиента написаны на Java; Python используется
для сборки и диагностических запусков.

## Выдаваемая сборка

`N9Ezz-Universal-Loader-0.3.0-experimental.jar`, 53 446 937 байт, SHA-256:

```text
b52e9c071753fd453f633e65e11fb979179f8674309f730dbd41c97471b847b9
```

Один JAR содержит собственный установщик/ядро, исправленный встроенный N9Ezz
1.5.3, выбранные компоненты Fabric API и библиотеки с лицензиями. Устанавливается
один профиль `N9Ezz-Universal-1.21.11`; выбора платформ нет. Для установки нужна
уже установленная vanilla 1.21.11. После установки профиль запускается обычной
кнопкой «Играть» Minecraft-лаунчера. Клиент извлекается в проверяемый builtin
cache вне `mods`; пользователю не нужен отдельный клиентский JAR.

```sh
java -jar N9Ezz-Universal-Loader-0.3.0-experimental.jar
# Или CLI:
java -jar N9Ezz-Universal-Loader-0.3.0-experimental.jar --install --game-dir /path/to/.minecraft
```

Bootstrap, поиск модов, зависимости, события, диагностика, classloader и
порядок преобразований собственные. Порядок: `MAPPING → ACCESS → CORE → MIXIN
→ POST`; игровой архив remap-ится до индексации. Дубли ID/aliases/classes,
чужие Mixin configs и неподдержанные платформенные требования отвергаются до
инициализации. Common/client entrypoints выполняются после игрового singleton
и thread, перед GameOptions; READY публикуется после их успешного завершения.

Mixin использует собственный SPI service и общий classloader. В продукте нет
запуска Knot, Quilt, Forge или ModLauncher. Fabric Loader 0.19.2 служит точной
проверенной границей публичного ABI собственного совместимого фасада.

## Проверенные компоненты

| Компонент | Фиксированная версия / область |
| --- | --- |
| Minecraft | Официальный client 1.21.11, SHA-1 `ba2df812c2d12e0219c489c4cd9a5e1f0760f5bd` |
| Java | Temurin 21.0.8+9, полная JDK с `ct.sym`, `--release 21` |
| Mixin | `0.17.2+mixin.0.8.7`, собственный service/bootstrap/global properties |
| MixinExtras | `0.5.4` |
| ASM | `9.9.1`, исходные manifest version attributes сохранены |
| TinyRemapper | `0.13.0`, matching source ZIP и LGPL включены; фактический binary fingerprint входит в cache key |
| Class Tweaker | `0.3.0-beta.2`, поддержанные access widener v1/v2 |
| Fabric API | `0.141.3+1.21.11`, только шесть перечисленных ниже исходных модулей |
| N9Ezz | Исправленный полный builtin 1.5.3, SHA-256 `2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424` |

Модули API: `fabric-api-base` 1.0.5+4ebb5c083e,
`fabric-command-api-v2` 2.4.7+6b42a6003e,
`fabric-key-binding-api-v1` 1.1.7+4fc5413f3e,
`fabric-lifecycle-events-v1` 2.6.15+4ebb5c083e,
`fabric-networking-api-v1` 5.1.5+ae1e07683e,
`fabric-rendering-v1` 16.2.10+0290ad933e. Остальные 37 модулей umbrella не
попадают в classpath; alias `fabric` обозначает этот проверенный subset.
Точные SHA и контракт находятся в [fabric-runtime-contract.md](fabric-runtime-contract.md).

Собственная реализация клиентского resource pack подключает 398 исходных
assets через native Minecraft pack provider. Ресурсы, в том числе шрифты,
текстуры и shaders, доступны игре; модуль Fabric resource-loader не заявлен.

## Выполненные проверки

| Проверка | Результат |
| --- | --- |
| Core: metadata, зависимости, события, class collisions, диагностика | 54/54 |
| Mappings и binary fingerprint/cache | 26 + 17 PASS |
| Access widening | 18 PASS |
| Nested discovery, hashes, aliases, bounds, CRC/cache | 40 PASS |
| Настоящий Mixin в упакованном JAR | 11/11, Inject/Redirect/Accessor/Invoker/plugin/MixinExtras/generated helpers и негативные сценарии |
| Fabric services/selection и entrypoints | 9 + 9 PASS |
| Fabric dependencies, включая настоящий builtin/API closure из 14 архивов | 77 PASS |
| Game integration: constructor boundary, deferred trace, cleanup, class ownership | 20 PASS |
| Точный контракт двух существующих builtin render bridge classes | 21 PASS |
| Resource pack | 29 PASS; отдельно actual game constructor даёт 30-й check |
| Native Minecraft pack metadata/autoselection/exact splash bytes | 3 PASS |
| Безопасное обновление builtin клиента | 8 PASS, ABI/host hooks/refmap/nested libraries сохранены |
| Установщик: один профиль, сохранение старых файлов, repeat install | 11 PASS |
| Упакованный минимальный native мод | PASS, общий classloader и весь lifecycle |
| Парсер игрового отчёта | 9 regression checks PASS |
| Java client addon checks из предыдущего этапа | 34 614 PASS, включая 3036 production geometry checks; это не реальные атаки |

Все обычные suites выполняются через `python3 universal-loader/build.py
--offline`. Негативный Mixin test намеренно выводит FATAL для отсутствующего
injection target и проверяет диагностику: это ожидаемый сценарий теста.
Отдельные native/game checks требуют официальной установленной игры.

## Настоящий запуск финального JAR

Запущен обычный `GameBootstrap` из **этого же JAR с SHA b52e…b847b9**: Java 21,
Xvfb, Mesa software OpenGL, null OpenAL, offline demo authentication `0`.
Дополнительные native observer fixtures регистрировали callbacks и читали
живое состояние. Они не вызывали Pulse/N9Ezz init вручную и не создавали
фиктивные world/player. Vanilla Play Demo handler загрузил настоящий мир,
интегрированный сервер и локальный игровой протокол.

- Pulse/N9Ezz инициализированы: 30 addon fields, 113 module entries;
  Kill Aura, Triggerbot и Hitboxes действительно присутствуют в registry.
- CLIENT_STARTED и **4000 пар START/END client ticks**, ноль ошибок порядка.
- SERVER_STARTING/SERVER_STARTED, **3682 server tick callbacks**.
- INIT/JOIN, AFTER_CLIENT_WORLD_CHANGE, world/player присутствуют в 4000
  клиентских callbacks; этот счётчик не подменяет отдельные server ticks.
- **2042 пары START_MAIN/END_MAIN** рендеринга, ноль ошибок порядка.
- MinecraftClient, addon, server, network handler, world и player используют
  один `dev.n9ezz.loader.core.UnifiedClassLoader@10667848`.
- Native resource manager включает `n9ezz/builtin/pulse, vanilla`.
  Осмотренный screenshot показывает настоящий лес, HUD и руку игрока;
  missing-texture pattern отсутствует.

Процесс оставался живым до 300-секундного deadline; остановлен runner-ом,
exit 143, 302.0 секунды с завершением. Fatal game/Mixin errors не записаны.
Offline auth/public-key requests ожидаемо не проходят. Windows WMedia.dll
недоступна на Linux и выключается; функциональность этого модуля не проверена.
Производительность software GL не является benchmark для пользовательского ПК.

Первый harness report ошибочно отверг class ownership: regex не принимал
цифру в ключе `n9ezzLoader`. Парсер исправлен, исходные отрицательные отчёты
сохранены; неизменный лог того же запуска переоценён с проверкой SHA JAR.
Текущие base/world acceptance checks PASS. Это не второй игровой запуск:
original harness subprocess exit 1 и replay exit 0 записаны раздельно.

Доказательства: [game-0.3-result.json](game-0.3-result.json),
[world-0.3-result.json](world-0.3-result.json),
[game-0.3-launch.log](game-0.3-launch.log),
[world-probe-results.md](world-probe-results.md). Raw screenshots и command
сохранены в `/workspace/minecraft-smoke/n9ezz-shared-world-final/`.

## Воспроизводимость и сохранённые версии

Сборка установщика воспроизводима из выдаваемого source ZIP с полной JDK 21
и SHA-проверенным dependency cache; без cache `build.py` получает только
зафиксированные в `deps-lock.json` HTTPS artifacts. Build не использует
upstream launcher engines и не запускает пользовательский мод при обновлении
client archive. Компилируемые source/resource files проверяются на изменения
между compilation, packaging и созданием source ZIP.

В archive входят Java sources ядра, доступные client/legacy installer sources,
аудиты, build scripts, mapping data, matching LGPL source, licenses и pinned
client/API inputs. Universal build безопасно обновляет зафиксированный client
из готовых base/overlay input JARs. Это **не** полная пересборка Pulse host
из исходников: оригинальные host sources и pristine исходный Pulse JAR не
предоставлены. Предыдущая addon compile/remap проверка документирована
отдельно; она не означает fresh online rebuild всех Gradle dependencies.

Старые файлы сохранены и повторно сверены:

| Сохранённая сборка | SHA-256 |
| --- | --- |
| Loader 0.1.0 rebuilt | `512bfa32b73f4635e0f406b98395392c05c7c83e24c3f87a61a99e7108bab28d` |
| Universal 0.2.0 | `3e62ed316b868e640c382ce8e20e0b1be9a1784855199feb1ff6abca3f314366` |
| Исходная полная client база 1.5.3 | `2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb` |

Final source ZIP SHA и результат независимой полной сборки фиксируются во
внешнем `RELEASE-MANIFEST.md` и `dist/SHA256SUMS`, чтобы архив не включал свой
собственный рекурсивный checksum.

## Незавершённые части

- Quilt/Forge/NeoForge игровые слои ещё не реализованы. Их metadata и малые
  API-only fixtures не означают поддержку игровых модов. Forge binary
  availability не подтверждена из-за официальных HTTP 403; Quilt Meta/Maven
  hash disagreement остаётся открытым. Exact source pins и таблицы конфликтов:
  [platform-availability.md](platform-availability.md),
  [source-loader-audit.md](source-loader-audit.md),
  [fabric-quilt-audit.md](fabric-quilt-audit.md),
  [forge-neoforge-audit.md](forge-neoforge-audit.md).
- Встроенные Hitboxes/Aura/Triggerbot используют общую исправленную геометрию,
  но модульные toggles, acquisition, реальные attack packets и PvP ещё не
  проверены. Поведение reference 1.5.0 не обещано точь-в-точь для 1.5.3.
- Authenticated multiplayer, прямые command dispatch/key presses и этот
  release в SKlauncher/других сторонних лаунчерах не проверены.
- Arbitrary Fabric API/QSL/mods, named/refmap remapping, custom language
  adapters, external resource packs/datapacks, dedicated server bootstrap,
  Quilt nested archives, Forge JarJar/AT/JavaFML/modules и game patches
  неподдержаны. Две pinned render bridges имеют описанные ограничения:
  [client-render-bridges.md](client-render-bridges.md).

Это проверенный экспериментальный этап единого ядра с builtin N9Ezz и
Mixin/Fabric hooks, а не завершённая совместимость с четырьмя платформами.
Облачные install/start инструкции сохранены в configuration draft; публикация
и fresh-task restoration этим сохранением не подтверждены.
