# Recorded shared-runtime world runs

This report records particular candidate binaries. Their hashes identify the
observed runs; they are not automatically checksums for a later release.

## Cold candidate run, 2026-10-08 UTC

- Candidate SHA-256:
  `38a91ff2aed078eff674ac572bd9b46085747faf319fc0f82c2d137dccbc6f6a`.
- Java: Temurin 21.0.8+9; official Minecraft 1.21.11 client SHA-1:
  `ba2df812c2d12e0219c489c4cd9a5e1f0760f5bd`.
- Ordinary `GameBootstrap`, one `UnifiedClassLoader`, builtin corrected N9Ezz
  client and six selected original Fabric API modules; no upstream loader
  engine. Two extra native observer mods were installed only in the isolated
  development smoke directory.
- Offline demo token `0`, Xvfb/software OpenGL, null OpenAL. The run had a
  180-second deadline and took 186.6 seconds including bounded shutdown. It
  remained running until the runner terminated it; exit 143 is that deadline.
- Raw evidence:
  `/workspace/minecraft-smoke/n9ezz-shared-world-1/launch.log`, `result.json`,
  `world-result.json`, and screenshots.

| Observed boundary | UTC time / evidence |
| --- | --- |
| Mod initialization | 06:56:41; native observers registered, CLIENT_SETUP and READY delivered |
| Actual client startup | 06:57:03; official CLIENT_STARTED callback |
| Addon registry and tick order | 06:57:11; Pulse and N9Ezz initialized, 30 addon fields, 113 module entries, Kill Aura/Triggerbot/Hitboxes in registry, 100 matched START/END client ticks, zero ordering failures |
| Builtin resource pack | 06:56:45; ResourceManager `n9ezz/builtin/pulse, vanilla`; visually inspected `display-135.png` shows the actual Pulse menu panorama, fonts and icons without the prior missing-texture pattern |
| Vanilla demo world request | 06:57:11; exact Play Demo button handler invoked after ordinary client startup |
| Integrated server | SERVER_STARTING at 06:57:15, SERVER_STARTED at 06:57:31, 100 genuine server tick callbacks by 06:57:49 |
| Local play network | INIT at 06:57:44; JOIN at 06:57:46 |
| Client world | AFTER_CLIENT_WORLD_CHANGE at 06:57:46; real world and player observed for 20 client tick callbacks by 06:57:51 |
| Actual world rendering | First START_MAIN/END_MAIN pair at 06:57:47; two completed frame pairs by 06:57:51, zero observed render ordering failures |
| Class ownership | MinecraftClient, N9Ezz, integrated server, network handler, world and player all reported the same `UnifiedClassLoader@12d67b88` instance |

The world observations are not fabricated by calling addon initializers or
assigning a synthetic world/player. The opt-in diagnostic fixture invoked the
normal vanilla demo handler, which generated terrain and ran the integrated
server/local play protocol. `display-150.png` and `display-165.png` show the real
Loading Terrain screen. The cold startup consumed most of the deadline, so no
fully entered-world screenshot was captured in this run. The event/state
observations establish the server/network/world/render boundaries; they do not
establish sustained play or combat behavior.

Expected offline authentication/public-key fetch failures were present.
No fatal game-thread exception, Mixin apply failure, or missing texture/font/
shader error was recorded. A single failed development `jcmd` attach produced
a JVM thread dump in the log; that is diagnostic noise, not a loader error.

An attempted warm second run in `n9ezz-shared-world-2` was deliberately stopped
before game startup to await the final rebuilt candidate. Its interrupted
report is not a passing game run.

No authenticated multiplayer, PvP, module toggles, combat target selection,
attack packets or general four-platform mod compatibility was tested here.

## Final immutable candidate run, 2026-10-08 UTC

The immutable candidate
`/workspace/minecraft-smoke/candidates/N9Ezz-Universal-Loader-0.3.0-final.jar`
has SHA-256
`b52e9c071753fd453f633e65e11fb979179f8674309f730dbd41c97471b847b9`.
The 300-second fixture used a copy of the first isolated game directory, with
the verified mappings cache and the real saved demo world. Its separate raw
evidence is `/workspace/minecraft-smoke/n9ezz-shared-world-final/`.

| Observed boundary | UTC time / evidence |
| --- | --- |
| Deferred addon initialization | 07:07:05; listeners registered, CLIENT_SETUP/READY |
| Actual client startup | 07:07:18; CLIENT_STARTED |
| Module initialization and tick order | 07:07:24; 100 matched START/END client ticks, Pulse/N9Ezz initialized, 30 addon fields and 113 module entries, all three combat modules registered |
| Demo world load | 07:07:24; normal vanilla Play Demo handler, existing world |
| Integrated server | SERVER_STARTING at 07:07:31, SERVER_STARTED at 07:07:46 |
| Local play network and world | INIT at 07:07:53, JOIN/AFTER_CLIENT_WORLD_CHANGE/world/player at 07:07:54 |
| Render order | 100 completed START_MAIN/END_MAIN pairs by 07:08:15; zero ordering failures |
| Actual UI input | Real X11 mouse click at 758,472 dismissed the displayed Continue Playing demo modal; the Purchase Now control was not clicked |
| Continued client loop | 4000 matched client START/END tick callbacks by 07:11:05, zero ordering failures, correct addon registry, world/player present and screen absent |
| Continued world/server/render | By 07:11:18, world/player observed in 4000 client callbacks, 3682 genuine server callbacks and 2042 completed render pairs, zero observed render ordering failures |
| Ownership | MinecraftClient, N9Ezz, server, network handler, world and player all report `UnifiedClassLoader@10667848` |
| Visual world | Inspected `world-unpaused.png` and `display-285.png` show actual unpaused forest terrain, sky, player hand and vanilla HUD without missing textures |

The process remained alive until its bounded deadline; total duration was
302.0 seconds including shutdown. It was terminated with
exit 143. No fatal game-thread exception or Mixin apply failure was recorded.
The native observer's `worldTicks` counter means client callbacks in which the
real world and player existed; genuine simulation callbacks are reported
separately as `serverTicks`.

The initial strict harness result reported a failure even though the game
observations above succeeded. Its log parser accepted only letters in key
names, so `n9ezzLoader` became `ezzLoader`; the ownership acceptance check then
compared the actual `clientLoader` value with a missing key. The raw result was
preserved while the parser was corrected and the captured log re-evaluated.
The corrected base report and the world report replay both pass all acceptance
checks. `result-harness-parser-v1.json` and
`world-result-harness-parser-v1.json` preserve the original false-negative
reports; `world-result.json` explicitly records replay mode and original
harness subprocess exit 1 separately from replay exit 0. This is a harness
defect, not evidence of a game/classloader failure. Report
re-evaluation must preserve the candidate hash, original game log, deadline
and observations; it does not represent a second game launch.

This run still does not test combat module toggles, target acquisition,
attack packets, PvP, authenticated multiplayer, command dispatch or arbitrary
mod compatibility.
