# Forge и NeoForge: контракт `fml-lifecycle-v1`

Это ограниченный слой API внутри собственного N9Ezz runtime, а не установка Forge, NeoForge или FML. Оба формата метаданных могут участвовать в общем графе вместе с native, Fabric и разрешённым Quilt. Моды, классы игры и callbacks используют общий N9Ezz classloader; API слоя принадлежат родительскому runtime. ModLauncher, FMLLoader, module layers и чужие bootstrap не запускаются.

## Проверенные источники и двоичная база

- Forge: официальная ветка Minecraft `1.21.11`, commit `1dab50ca003abc59e4115a329bcb46f76c105e15`, исходная граница JavaFML `61.0` и EventBus `7.0.5`. Это **исходная ABI-граница**; получение version metadata не заменяет проверку Forge JAR. На текущем этапе отдельный официальный Forge/JavaFML binary для компиляции fixture не получен; fixture компилируется против собственного ограниченного API. Последующие проверки доступности фиксируются отдельно в platform audit.
- NeoForge: опубликованная версия `21.11.45`, FancyModLoader `10.0.36` (commit `805fe3e71a18cf512f711a0d3ff6ba6c335a88f5`), EventBus `8.0.5`. Официальные JAR `loader-10.0.36.jar`, `bus-8.0.5.jar` и `mergetool-2.0.0-api.jar` получены отдельно для проверки ABI; они не включены в runtime вместо собственного слоя.
- SHA-256 проверенных Neo API: loader `5711bb95b45b421ada6e5f0f4600ac441c3509446178da5de927135f8bd6b0c9`; bus `705e24f37752809499a5cd0c7dd31eaabf3d933c5d3b2060168e94e9ef62593a`; mergetool API `0260881294d8b218afe3d673f084d3745a55c28b35205d07d5e62d7f22202a00`. Publisher checksums совпали с загруженными байтами.

Версия языка `javafml` для Neo здесь `10.0.36`, а не `1`. Значения версии языка проверяются отдельно от API всей игровой платформы. Слой не объявляет глобальные providers `forge` или `neoforge`: наличие common/client событий не удовлетворяет зависимости на полную платформу.

## Явный выбор контракта

Игровой профиль принимает мод только с собственной декларацией:

```toml
[n9ezz]
compatibility = "fml-lifecycle-v1"
namespace = "none"
```

`intermediary` также допустим как объявление, однако **любая прямая ссылка на `net.minecraft.*` во всех class-файлах этого FML профиля отклоняется**. Mojang/SRG mod remapping и недостающие patched Minecraft members ещё не реализованы. Namespace не является способом обойти эту проверку. Обычный upstream Forge/NeoForge мод без opt-in не объявляется совместимым автоматически. JavaFML constraints остаются настоящими version predicates; полный Forge/NeoForge dependency нельзя заменить фиктивной установленной версией.

## Поддержанные конструкции и API

| Контракт | Реализованное поведение |
| --- | --- |
| Forge `@Mod("id")` | Одна соответствующая public concrete entrypoint class. Предпочтение public конструктора `FMLJavaModLoadingContext`; при отсутствии такого конструктора — public no-arg. Конструктор исполняется один раз. |
| Forge context/container | `FMLJavaModLoadingContext.get()`, `getModBusGroup()`, covariant `getContainer()`. `ModLoadingContext.get()`, `getContainer()`, `getActiveContainer()`, `getActiveNamespace()`, `extension()`. Container `getModId()`, `getNamespace()`, `getModBusGroup()`. |
| Forge typed bus | Собственные `BusGroup`/`EventBus<T>` с исходными erased descriptors: `addListener(Consumer)` возвращает `EventListener`, `addListener(byte,Consumer)`, remove/re-add того же listener, `post(Event):boolean`, `fire(Event):Event`, `hasListeners()`. Приоритеты: 127/64/0/-64/-127/-128; равный приоритет сохраняет порядок регистрации. Group startup/shutdown/dispose/trim поддерживаются в пределах этого контракта. |
| Forge lifecycle | Точные common/client/load-complete классы и static `getBus(BusGroup)`, `ParallelDispatchEvent.enqueueWork(Runnable/Supplier)`. Lifecycle bus исполняется один раз и освобождает listeners. `IModBusEvent` остаётся интерфейсом через `InheritableEvent`; `ModLifecycleEvent` реализует его, без выдуманного superclass. |
| NeoForge `@Mod` | `value`, `dist`, `depends`. Server-only entrypoints не запускаются на клиенте; optional entrypoint с отсутствующим `depends` пропускается. Порядок: меньше depends, затем общий side перед одним side, затем стабильное имя класса. |
| NeoForge constructor | Ровно один public constructor. Уникальные optional параметры `IEventBus`, `ModContainer`, `FMLModContainer`, `Dist`; оба container типа получают тот же объект. Повтор одного типа или неизвестный параметр — ошибка до запуска конструктора. |
| NeoForge context/container | `ModLoadingContext.get()`, `getActiveContainer()`, `getActiveNamespace()`; container `getModId()`, `getNamespace()`, `getEventBus()`. `Dist.CLIENT`, `DEDICATED_SERVER`, `isClient()`, `isDedicatedServer()`. |
| NeoForge event bus | `addListener(Class<T>,Consumer<T>)` и варианты с EventPriority/receiveCanceled, unregister по identity, post и per-priority post, start. Только три lifecycle event types. Эти события не отменяются, поэтому receiveCanceled не меняет результат. |
| NeoForge inferred Consumer | Anonymous/generic Consumer с доступным конкретным Event типом может определяться автоматически. Для erased lambda/method reference необходимо `addListener(EventClass.class, consumer)`; отсутствие определимого типа вызывает понятную ошибку, а не широкую регистрацию на все события. |
| NeoForge lifecycle | Common/client/load-complete events, `getContainer()`, `enqueueWork(Runnable/Supplier):CompletableFuture`. |

API-реализации написаны самостоятельно; исходные реализации upstream event buses, контейнеров и deferred executors не скопированы. Имена, сигнатуры и порядок проверены по официальным исходникам; уже используемые внешние компоненты сохраняют свои отдельные лицензии.

## Порядок и потоки

Все выбранные FML архивы проходят preflight **до любого mod initializer или конструктора**. Затем общий bootstrap выполняет:

1. Все mod constructors в разрешённом dependency order.
2. Common setup listeners всех FML модов.
3. Общую FIFO очередь common deferred work.
4. После общих client initializers — client setup listeners всех FML модов.
5. Общую FIFO очередь client deferred work.
6. Load-complete listeners и соответствующую deferred очередь перед READY.

Это проверенный синхронный startup контракт на потоке инициализации клиента. Он не имитирует параллельные upstream executors и не обещает полный upstream registry/config/IMC lifecycle. Каждый constructor, listener и deferred task временно получает свой active container и общий context classloader; предыдущее состояние восстанавливается в `finally`. Нельзя вызвать следующий barrier из текущего callback или enqueueWork вне активной фазы. Работа ограничена 10 000 задачами за фазу; очередь безгранично самопорождающих callbacks отклоняется.

Ошибка конструктора/события сохраняет настоящий cause и останавливает дальнейшие фазы. Отменённый или явно завершённый до исполнения future не запускает supplier, как CompletableFuture async work upstream. Pending futures завершаются exceptionally; diagnostic deferred failure указывает мод, создавший failing task. Повторный вызов не исполняет провалившуюся или завершённую фазу заново. Close освобождает listeners, container bindings и очереди; закрытый runtime повторно не используется.

## Preflight и ограничения

Проверяются class/field/method descriptors, generic signatures, annotations и type annotations, nest/record сведения, массивы, try/catch types, static versus instance platform members, method handles, invokedynamic и вложенные ConstantDynamic. Неподдержанный член даже у известного API owner отклоняется. Неаннотированный вспомогательный класс проверяется так же, как entrypoint. Class name обязан совпадать с JAR path; multi-release FML mods и module descriptors отклоняются. Ссылки на private bootstrap, `cpw.mods.*`, недоступные platform types и внутренние N9Ezz binding helpers не получают разрешение.

Preflight — проверка явно поддержанного ABI, а не security sandbox или доказательство произвольного reflection поведения. Динамические reflection, native/instrumentation code и скрытые зависимости находятся вне контракта; никакой поддержки произвольных модов не обещается.

Незавершены: registries/DeferredRegister, config specs и configs, automatic annotation event subscribers, capabilities/attachments, networking и payload registries, platform client tick/game events, registry freezes, AT/coremod/JarJar/SPI semantics, JPMS visibility, IMC и полный patched Minecraft API. Для игрового proof общий native/Fabric observer может проверять реальные ticks и мир; эти наблюдения не объявляют реализацию Forge/Neo game event hooks.

## Проверки

`dev.n9ezz.loader.fml.FmlCompatibilityTests` компилирует реальные временные mod JAR, использует настоящий UnifiedClassLoader и проверяет provenance, constructor injection, event ordering/priorities, phase-wide FIFO queues, same classloader/TCCL, once-only behavior, restoration/cleanup, future failures, side filtering, exact unsupported APIs и отсутствие Minecraft references. Это исполняемые ABI/fixture проверки, не самостоятельный запуск Minecraft. Итоговый счёт и реальный cross-platform game probe приведены в отчёте выпуска; только проведённый запуск конкретного JAR является game proof.
