# Minecraft 1.21.11 / Java 21: подтверждённая доступность платформ

Последняя независимая проверка: **7 октября 2026, 18:18–18:21, Europe/Moscow**. Все requests выполнены по официальным HTTPS URLs через inherited proxy с TLS verification. Исторические 403 сохранены как история; текущий вывод опирается на повторные requests и полученные bytes. У upstream installers код не исполнялся, upstream binaries в N9Ezz не добавлялись.

Это проверка существования source/release artifacts и их целостности. Она не подтверждает совместимость этих runtimes или произвольных модов с новым ядром N9Ezz. Реальные игровые проверки отражаются отдельно.

## Актуальное состояние

| Цель | Официальное доказательство | Результат / ограничение |
| --- | --- | --- |
| Minecraft `1.21.11` | Mojang manifest содержит release `1.21.11`; game JSON HTTP 200, `javaVersion.majorVersion=21`, `mainClass=net.minecraft.client.main.Main` | Версия и Java21 подтверждены. Game installation/startup этим metadata probe не проверяются. |
| Fabric Loader `0.19.2` | Meta endpoint для game `1.21.11` HTTP 200; официальный Maven JAR и `.sha256` совпали | Доступен exact artifact, версия в Meta имеет `stable=false`. Loader availability не подтверждает N9Ezz/Fabric API или own-core compatibility. |
| Quilt Loader `0.30.1` | Meta endpoint для game `1.21.11` HTTP 200; официальный Maven JAR и Maven `.sha256` совпали | Доступен exact artifact. **Meta и Maven hash расходятся**, причина неизвестна; consistency FAIL. Quilt остаётся экспериментальной платформой в старом N9Ezz, support own runtime не доказан. |
| Forge `1.21.11` | Официальная source branch `1.21.11` с Java21; tags `61.0`, `61.1`, `61.2` | Источники доступны. Maven metadata, downloads page и promotions JSON при последних probes HTTP 403; конкретная опубликованная binary version/checksums не подтверждены. |
| NeoForge `21.11.45` | Maven metadata HTTP 200: 45 версий `21.11.*`, последняя в ответе `21.11.45`; POM/module/installer явно указывают `1.21.11` | Release artifacts скачаны, publisher SHA-256 проверены; universal representative class major65. NeoForge availability не означает наличие NeoForge API/game hooks в N9Ezz. |

## Официальные URLs и проверки

- [Mojang version manifest](https://piston-meta.mojang.com/mc/game/version_manifest_v2.json), [exact 1.21.11 game JSON](https://piston-meta.mojang.com/v1/packages/6827f8e998ee6add1b3acff9286b6c95ebeebdc1/1.21.11.json). Manifest releaseTime `2025-12-09T12:23:30+00:00`, selected metadata SHA1 `6827f8e998ee6add1b3acff9286b6c95ebeebdc1`.
- [Fabric Meta 1.21.11/0.19.2](https://meta.fabricmc.net/v2/versions/loader/1.21.11/0.19.2), [Maven JAR](https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.19.2/fabric-loader-0.19.2.jar), [publisher SHA-256](https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.19.2/fabric-loader-0.19.2.jar.sha256).
- [Quilt Meta 1.21.11/0.30.1](https://meta.quiltmc.org/v3/versions/loader/1.21.11/0.30.1), [Maven JAR](https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-loader/0.30.1/quilt-loader-0.30.1.jar), [publisher SHA-256](https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-loader/0.30.1/quilt-loader-0.30.1.jar.sha256).
- [NeoForge Maven metadata](https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml), [21.11.45 POM](https://maven.neoforged.net/releases/net/neoforged/neoforge/21.11.45/neoforge-21.11.45.pom), [Gradle module metadata](https://maven.neoforged.net/releases/net/neoforged/neoforge/21.11.45/neoforge-21.11.45.module).
- Forge requests, все HTTP 403: [Maven metadata](https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml), [official 1.21.11 downloads](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.21.11.html), [official promotions](https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json). Unofficial mirrors и обход denied host не использовались.

## Проверенные бинарные fingerprints

Контрольные суммы сверены с publisher `.sha256`; для NeoForge sources/universal дополнительно использовались size/SHA-256 из Gradle module metadata. Файлы прочитаны как ZIP; классы не исполнялись.

| Артефакт | Bytes | Проверенный SHA-256 |
| --- | --- | --- |
| Fabric Loader `0.19.2` | 1 968 930 | `1b91025ac6b5253a49aabb22f658b5eed9fbba6dc88eb0e4a9364c7b2d1d1865` |
| Quilt Loader `0.30.1`, Maven JAR | 3 149 891 | `a561a9fe9abb45556c696095a29e81477618bf2408b86c36db5aecdcd6a86fdb` |
| NeoForge `21.11.45` installer | 4 236 966 | `e54350cc68d7dec6cb0523a0597a6a2fa664c1acd878b456af4564ee126da00a` |
| NeoForge `21.11.45` userdev | 4 527 591 | `787d546a162add664f40d9e26ff3db8d39670392c9132e8626022213a97b53c2` |
| NeoForge `21.11.45` sources | 2 028 989 | `da38660fabd4479065d9149399c0d830ffc724d21960590ea8c6037488ac72bd` |
| NeoForge `21.11.45` universal | 3 831 805 | `0d9ab82c37319ed6514e8e28e5ab357ba5e9b8043ee4621333cf45b743039cba` |
| FancyModLoader `10.0.36` loader | 660 602 | `5711bb95b45b421ada6e5f0f4600ac441c3509446178da5de927135f8bd6b0c9` |

NeoForge installer `install_profile.json`: `version=neoforge-21.11.45`, `minecraft=1.21.11`. Installer game profile main class `net.neoforged.fml.startup.Client`. Userdev `config.json`: `mcp=net.neoforged:neoform:1.21.11-20251209.172050@zip`. Sources/universal `META-INF/neoforge.mods.toml` фиксируют version `21.11.45`. Universal manifest указывает Minecraft `1.21.11`, NeoForm `1.21.11-20251209.172050`, NeoForge `21.11.45`; `net/neoforged/neoforge/common/NeoForge.class` имеет class major65.

У installer variant указан Java8 bytecode compatibility самого установщика; у universal variant — Java21. Это не основание запускать Minecraft1.21.11 под Java8. Новое ядро/клиент N9Ezz имеют целевой Java21.

Published NeoForge `21.11.45` POM/module dependencies: NeoForm `1.21.11-20251209.172050`, FML `10.0.36`, ASM `9.8`, AccessTransformers `11.0.2`, EventBus `8.0.5`, Mixin `0.16.5+mixin.0.8.7`, MixinExtras `0.5.3`, JarJar `0.5.0`, NightConfig `3.8.3`. Эти разрешённые binary pins отличать от отдельных исходных properties branch.

### Несогласованные Quilt checksums

Quilt Meta указывает SHA-256 `a60c9dd429151c426b09b96147b76de1a7cf51c6ce47ee72be77acbdcc195b87`; Maven JAR, Maven `.sha256` и legacy bundle совпадают на `a561a9fe...`. Размер у Meta/Maven одинаков — 3 149 891 bytes. Это два официальных источника с разными digests; причина не установлена. Ожидаемая Meta checksum не менялась, Meta-vs-Maven check остаётся FAIL. Maven artifact удостоверен относительно Maven publisher checksum, но это не удостоверяет consistency Meta и не превращает Quilt в проверенную game compatibility.

## Source pins

| Исследованная реализация | Точный commit |
| --- | --- |
| Fabric Loader `0.19.2` | `d112641382563b3b1139c8168db07ee71a982eda` |
| Quilt Loader `0.30.1` | `b33861b30a815f327652015018d2d1262f12b63a` |
| Forge branch `1.21.11` | `1dab50ca003abc59e4115a329bcb46f76c105e15` |
| Forge ModLauncher source candidate for `10.2.6` | `b5f35aa3d7a6369e13053b1fbb165796ab8b8bb1` |
| NeoForge branch `1.21.11` | `bef35d56255d4cb4a3aa58e1f4c27b41c61d3000` |
| FancyModLoader `10.0.36`, confirmed binary manifest | `805fe3e71a18cf512f711a0d3ff6ba6c335a88f5` |

FML binary manifest `Build-Number: 10.0.36`, `Git-Commit: 805fe3e7` подтверждает ранее выбранный source pin по tag offset. Для Forge ModLauncher такого binary manifest evidence нет: correspondence остаётся source candidate. Архитектурные конфликты, lifecycle/mappings/Mixin и licensing рассмотрены в [fabric-quilt-audit.md](fabric-quilt-audit.md) и [forge-neoforge-audit.md](forge-neoforge-audit.md).

## Что изменилось после первых probes

Первоначальная среда возвращала proxy CONNECT403 для Fabric Meta, Quilt Meta и обоих Forge/NeoForge Maven. Поздние requests Fabric/Quilt/Mojang/NeoForge успешны HTTP200; **это supersedes старые выводы о недоступности**. Forge два официальных hosts всё ещё возвращают HTTP403. Не установлено, чем был вызван переход доступности; локальный startup policy snapshot не объявляется доказательством текущей remote response.

Машиночитаемые evidence с exact request timestamps (UTC и Moscow), byte sizes, manifests и digests: [platform-artifact-probes.json](platform-artifact-probes.json). Первые повторные metadata snapshots основного runtime процесса: [platform-metadata-probes.json](platform-metadata-probes.json). Требование разрешить Maven NeoForge больше не актуально; Forge binary validation остаётся unresolved. Наличие любого loader release не доказывает его интеграцию с общим ядром N9Ezz.
