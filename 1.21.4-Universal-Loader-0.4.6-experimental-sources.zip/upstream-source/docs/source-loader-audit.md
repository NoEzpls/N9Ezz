# Аудит исходного N9Ezz Loader 0.1.0

Проверка 2026-10-07. Источник: [NoEzpls/N9Ezzz, commit `07a77dd4dc3c2a909e3ec1b082c6d67c83684255`](https://github.com/NoEzpls/N9Ezzz/tree/07a77dd4dc3c2a909e3ec1b082c6d67c83684255). Это репозиторий с **тремя `z`**, отличный от ранее выбранного пустого `NoEzpls/N9Ezz`.

## Состав и сохранение оригиналов

Git checkout `/workspace/input/N9Ezzz` содержит `.gitattributes`, ZIP исходников и reference client JAR. `AGENTS.md` в checkout, ZIP и проверенных workspace paths не найден. Тексты README/test-results в архиве рассмотрены как документация предыдущей сборки; их утверждения о тестах не заменяют новые проверки.

| Входной файл / компонент | Размер, байт | SHA-256 |
| --- | --- | --- |
| `N9Ezz-Codex-sources.zip` | 61 602 308 | `5d922123df2bb7b03f624dee1ba7d8e3a868a22a78f761bf42ee5c79540f417d` |
| `PulseVisuals_crack1.21.11 (4).jar` (reference N9Ezz `1.5.0-n9ezz`) | 41 051 058 | `ca978a7726fbb13ad196484439611e2c2ca1ffb1947a3ddb443c8bc30b4bfd52` |
| Embedded legacy N9Ezz `1.5.3-n9ezz` из ZIP | 41 069 456 | `2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb` |
| Embedded Fabric API `0.141.3+1.21.11` | 2 412 693 | `86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5` |

ZIP содержит 234 entries, суммарно 63 166 074 uncompressed bytes. В нём есть полные исходники прежнего installer и его готовые bundle resources, но **нет** самостоятельного `N9Ezz-Loader-0.1.0.jar` или release ZIP. Среди JAR вне `bundle/blobs` имеется только клиентский Gradle wrapper. Поэтому сохранение старой рабочей версии должно означать сохранение исходного ZIP и byte-identical embedded client; installer baseline следует отдельно пересобрать из ресурсов и протестировать. Исторический SHA installer JAR неизвестен.

Извлечение, согласованное основным процессом, находится в `/workspace/input/extracted/N9Ezz-Codex`. Этот аудит не изменял исходные ZIP/JAR, upstream checkout или извлечённые loader sources.

## Архитектура текущего installer

| Исходник (относительно `N9Ezz-Codex/loader`) | Поведение |
| --- | --- |
| `src/dev/n9ezz/loader/Installer.java` | Swing GUI и CLI `--check-bundle`, `--platforms`, `--install`, `--verify`; UI `JComboBox` содержит Fabric, Quilt, Forge, NeoForge. Forge/NeoForge installation disabled; Quilt требует explicit experimental flag. |
| `src/dev/n9ezz/loader/InstallEngine.java` | Offline unpack компонентов, isolated instance и Minecraft Launcher profile, staging/hash verification, backup original `launcher_profiles.json`, conflict refusal и rollback созданных файлов. Создаёт game version с `mainClass=dev.n9ezz.loader.Bootstrap`. |
| `src/dev/n9ezz/loader/Bootstrap.java` | Читает `n9ezz.backend` (default Fabric), проверяет Java21/gameDir/direct mod JAR metadata, восстанавливает два встроенных mods, затем отражением вызывает main upstream выбранного loader. |
| `src/dev/n9ezz/loader/Bundle.java` | Schema1 index, backend gates, SHA-256 assets, извлечение новых файлов без перезаписи отличающихся существующих компонентов. |
| `src/dev/n9ezz/loader/SafeFiles.java` | Relative path validation, symlink checks, bounded metadata reads, digest и atomic replacement profile. |
| `src/dev/n9ezz/loader/Json.java` | Собственный JSON parser/serializer. |
| `build.py` | Получает Fabric/Quilt profile и Maven components или использует уже подготовленные resources; собирает Java17 installer JAR с embedded N9Ezz и Fabric API. |
| `test_installer.py`, `tests/.../UnitChecks.java` | Проверки установки/CLI/metadata/path handling; синтетический Minecraft version, без загрузки game client. |

Fabric integration сейчас полностью делегирована `net.fabricmc.loader.impl.launch.knot.KnotClient`; Quilt — `org.quiltmc.loader.impl.launch.knot.KnotClient`. Profile JSON содержит upstream libraries; `InstallEngine` добавляет `-Dn9ezz.backend=fabric|quilt` и для Quilt experimental property. Установщик создаёт разные version IDs и instance directories для выбранной платформы.

**В собственном коде текущей версии нет** общего transforming classloader, mapping runtime, dependency solver, Mixin service, mod entrypoint runtime или game events. Duplicate check `Bootstrap.checkExistingMods` читает только direct JARs в `mods` и Fabric ID; dependencies и nested JAR resolution оставлены upstream loader. Это installer/bootstrap wrapper вокруг отдельного Fabric/Quilt runtime, а не начальная реализация единого ядра четырёх платформ.

## Зафиксированный комплект

| Runtime | Декларация комплекта | Проверенный факт |
| --- | --- | --- |
| Fabric `0.19.2` | ASM `9.9`, Fabric Sponge Mixin `0.17.2+mixin.0.8.7`, intermediary `1.21.11`, KnotClient | Все встроенные bytes совпадают с legacy lock; gameLaunchTested=false. |
| Quilt `0.30.1` | ASM `9.10.1`, Fabric Sponge Mixin `0.17.3+mixin.0.8.7`, Quilt JSON5 `1.0.4+final`, Config `1.3.3`, hashed/intermediary `1.21.11`, KnotClient | Все встроенные bytes совпадают с legacy lock; explicit experimental status, gameLaunchTested=false. |
| Forge / NeoForge | `status=blocked`, нет components | Их runtime, API и patches в ZIP installer bundle отсутствуют. Наличие upstream исходников для 1.21.11 проверено отдельно в `forge-neoforge-audit.md`. |

`dependencies.lock.json` побайтно совпадает с `build/resources/bundle/index.json`. Независимая проверка этого аудита прочитала **20 различных embedded assets** и подтвердила SHA-256, SHA-1 и размер каждого. Это проверка целостности supplied archive относительно его lock; новая сверка с publisher metadata и подписями официальных releases не выполнялась.

## Клиентский контракт, важный для нового ядра

Reference client JAR (`1.5.0-n9ezz`) и legacy embedded JAR (`1.5.3-n9ezz`) являются разными артефактами. У обоих `fabric.mod.json`:

- ID `pulse`, видимое имя `N9Ezz`, environment `client`, declared license `All-Rights-Reserved`.
- Main entrypoints `ru.pulse.Pulse` и `pulse.TestMod`; client entrypoint list пуст. Нужно сохранить семантику Fabric main/client phases, не угадывать её по названию класса.
- Mixin configs `pulse.mixins.json` и `n9ezz.mixins.json`.
- Requires Fabric loader `>=0.17.0`, Fabric API `*`, Minecraft `1.21.11`, Java `>=21`.
- Nested JARs: `json-20250517`, Kotlin stdlib `1.9.22`, OkHttp `4.12.0`, OkHttp SSE `4.12.0`, Okio JVM `3.6.0`, zero-allocation-hashing `0.16`.

Это требует реализации/remapping конкретных Minecraft/Fabric references, nested libraries, Mixin и игровых hooks. Простое чтение metadata или вызов `pulse.TestMod` не подтверждает работу клиента. Изменения Triggerbot/KillAura/Hitboxes и их реальные игровые тесты относятся к отдельному клиентскому аудиту/реализации, а не к installer. Исторический запуск bootstrap через SKlauncher следует считать отдельным наблюдением пользователя; supplied tests его не воспроизводят.

## Сборка и тесты: факты и ограничения

Извлечённый `loader/build.py` не требует Gradle или внешней Java библиотеки для compilation loader: Python3.10+ и JDK17+; `javac --release 17`. Сам Minecraft требует Java21+. Prepared bundle resources позволяют повторить legacy build offline без `--payload` или `--from-bundle`. `--from-bundle` требует отсутствующего в ZIP standalone old installer, поэтому этот аргумент здесь применять нельзя до первой baseline сборки.

В новых reports необходимо отличать:

- Supplied `TEST_RESULTS.md` и `build/test-results.json`: утверждают 13 integration scenarios / 27 unit checks и `minecraft_executed=false`; этот аудит не запускал их повторно.
- Новая независимая проверка здесь: archive inventory, source architecture, 20 asset digests/lengths, metadata сравнение, lock/index identity.
- Не проверены: запуск vanilla/Fabric/Quilt Minecraft, главного меню/мира, клиентских модулей/native code, GUI на Windows или SKlauncher.

Legacy build не является побайтно воспроизводимым: `jar.write` сохраняет filesystem timestamps, `writestr` использует текущие timestamps, старые `build/classes` и resources не очищаются. Устойчивый порядок entries уже есть, но для новой сборки нужны отдельные clean outputs, fixed ZIP timestamps, pinned toolchain/components и сравнение SHA двух независимых сборок.

`requireVanilla` проверяет присутствие game JSON/JAR и version ID, но не запускает игру и не удостоверяет целостность game JAR. Existing tests создают dummy base version, что правильно для installer integration; эти результаты нельзя обозначать real Minecraft launch.

## Рекомендации сохранения и миграции

1. Сохранить входной repo commit, исходные ZIP/reference JAR и embedded client с приведёнными hashes. Скопировать legacy installer sources/resources в отдельный baseline каталог; пересобрать `0.1.0` до изменения кода и записать новый baseline hash и фактические результаты тестов.
2. Использовать новый output/package/version для собственного ядра. Не подменять `0.1.0` и не затрагивать прежние `fabric-1.21.11`/`quilt-1.21.11` game directories.
3. Новый installer создаёт один N9Ezz profile/instance с собственным bootstrap; убрать backend options и JVM engine selector из нового UX и profile.
4. Сохранить полезное installer поведение: stage-before-commit, digest checks, receipts, conflict refusal, profile backups, idempotence и user files preservation. Их наличие не зависит от Fabric engine.
5. Начать own runtime с минимального native N9Ezz API test mod; подключать metadata/API adapters только с фиксированными supported signatures. Явно диагностировать неподдержанный Mixin, remapping, platform runtime hook или nested library.
6. Отдельно подтвердить N9Ezz client compatibility на Java21/Minecraft1.21.11. До этого новый own core JAR должен честно указывать prototype/test-mod support boundary и не выдавать old payload за проверенный клиент нового runtime.

Legacy own installer sources/scripts имеют MIT license из `loader/LICENSE`; `THIRD_PARTY.md` требует сохранения идентичности/лицензий встроенных компонентов. MIT installer license не переносится на Pulse/N9Ezz client или bundled libraries. Существующие license notices следует сохранить при перенесении допустимых installer компонентов.
