# TinyRemapper binary provenance and game cache

The game cache schema is `n9ezz-game-remap-v2`. Its directory key includes
the actual TinyRemapper binary SHA-256, in addition to the pinned original
Minecraft client, mappings, remapper version label, ASM version and sorted
library hashes. `remap.json` records `remapperSha256`; cache reuse validates
that field as well as the key, game/mapping hashes, output hash and mapped
MinecraftClient symbols. Earlier version-only cache receipts are not reused.

When TinyRemapper is loaded from a separate JAR, including a compatible
replacement placed earlier on the Java classpath, the runtime hashes that
JAR's actual `CodeSource` file. It does not use the installer’s old copy.
For a normal combined installer, it hashes the preserved original archive
under `META-INF/n9ezz/dependencies/tiny-remapper-*.jar`. It first checks all
expanded TinyRemapper class bytes against that archive. If someone edits
shaded library classes without updating the preserved archive, the runtime
uses a deterministic fingerprint of the actual package classes instead.
Loose class-directory builds use that same sorted package fingerprint.
The normal path avoids hashing the complete installer or embedded client.

Replacing a compatible TinyRemapper binary and rebuilding from an updated
`deps-lock.json` invalidates the old game cache automatically. Updating
`GameMappings.REMAPPER_VERSION` remains useful for a readable version label
but is not required to distinguish changed library binaries. Unsupported or
missing binary provenance fails before a cache is selected.

Validation: 26 mapping semantics checks and 17 binary/cache checks passed
with JDK 21. The latter cover separate replacement JARs, changes to helper
classes with the same version, shaded edits, unchanged unrelated installer
payloads, renamed modified archives, loose classes, and old or mismatched
receipts. Fixtures synthesize minimal class headers; no Minecraft binary is
included in them. See [the test report](remapper-cache-test-report.txt).
