# Selected Fabric API in the N9Ezz common runtime

The runtime reuses official Fabric API components from the preserved `0.141.3+1.21.11` umbrella JAR (SHA-256 `86c453a86139662e775697d03b0ca7867f547374868c0cb3e3dc06f98dbfeef5`). It does not start Fabric Loader, Knot, or a separate Fabric classloader. The selected components share the game's N9Ezz classloader and shared Mixin transformation service.

`SelectedFabricApi` verifies the official umbrella and all selected module hashes. Its deterministic curated container retains the original `fabric-api` identity, version and `fabric` alias, reducing only the nested `jars` declaration to the six modules below. The changed outer metadata invalidates its original signature, so the outer signature files and manifest digest sections are removed explicitly. The nested modules retain their complete original bytes, metadata, signatures, mixins, access wideners and Apache-2.0 licenses. A `META-INF/n9ezz/fabric-api-selection.json` entry records this modification and its provenance. This alias describes a selected compatibility subset; it does not claim all 43 umbrella modules are installed.

| Module | Verified version | SHA-256 |
| --- | --- | --- |
| fabric-api-base | 1.0.5+4ebb5c083e | `bce4ae302479d627bd614b97edf69a6bc13a9f2c50509c9c92a65a6febc7db68` |
| fabric-command-api-v2 | 2.4.7+6b42a6003e | `1478069c47f0fd536794e7278a058276263048b7492b4425ec5d62c88a7de282` |
| fabric-key-binding-api-v1 | 1.1.7+4fc5413f3e | `758c2777045e3e357981ebf99cdecbcafeca21580f4736d00e95b0bf6327f45a` |
| fabric-lifecycle-events-v1 | 2.6.15+4ebb5c083e | `2ce334ea2c050f532443a19addf97ac3e9edcb7b1e3a4a2075dbea0207fe51b0` |
| fabric-networking-api-v1 | 5.1.5+ae1e07683e | `0cb3c3dd650c6fe970181dbd8fbd3281e3a43fc8ad2305856276313b31600aba` |
| fabric-rendering-v1 | 16.2.10+0290ad933e | `d2a97821550e1dca3e0522fc99fa25eea0bf390fea04d1358ff5f1f7cd407518` |

Declared dependencies and binary references of these six modules form a closed Fabric API set: only the base and lifecycle modules are required across the selected modules. Binary inspection found no references to Fabric Loader engine implementation packages. The only selected module calling `FabricLoader` is the networking module's `CommandsMixin`, which queries `isDevelopmentEnvironment()`. The actual bundled N9Ezz classes query `FabricLoader.getInstance().getConfigDir()`.

## Own game initialization boundary

N9Ezz's main initializer calls `KeyBindingHelper.registerKeyBinding`. The official keybinding registry expects the Minecraft singleton to exist while `GameOptions` is still uninitialized. Invoking this initializer before vanilla `Main` violates that requirement.

`GameInitializationHook` therefore validates the exact Minecraft 1.21.11 intermediary constructor `(Lnet/minecraft/class_542;)V`. It requires one `PUTSTATIC class_310.field_1700`, followed by one `PUTFIELD class_310.field_1696:Ljava/lang/Thread;`, followed by one `NEW class_315`. It inserts the own `FabricRuntime.bootstrapGame(Object)` call immediately after the game thread assignment. This preserves access to the actual singleton and game thread while running registrations before options construction. Missing, duplicated or reordered anchors fail with `GAME_INITIALIZATION_HOOK_MISMATCH`; repeated transformation also fails. A second initialization attempt is rejected rather than running entrypoints twice.

The runtime installs read-only services before this boundary. Its deferred callback initializes the resolved common and client entrypoints in dependency order and reports READY only after successful completion. The existing native verification path is separate from this game-boundary execution.

## Official hook contracts

The following descriptors were inspected in the compiled official module bytes, including their statically remapped Mixin annotations. These hooks are supplied by those official components through the single Mixin pipeline, rather than duplicate N9Ezz injections into the same methods.

| Contract used by N9Ezz | Actual intermediary target and timing |
| --- | --- |
| START_CLIENT_TICK / END_CLIENT_TICK | `class_310.method_1574()V`, HEAD / every normal RETURN |
| CLIENT_STARTED | `class_310.method_1514()V`, after `field_1696` is set in the run loop, before the first tick |
| CLIENT_STOPPING | `class_310.method_1490()V`, after the shutdown log call |
| Keybind array merge | `class_315.method_1636()V`, HEAD; official registry rejects duplicate IDs and late registration |
| Play INIT / JOIN | `class_634.<init>(class_310,class_2535,class_8675)` RETURN / `method_11120(class_2678)` RETURN; networking mixin priority 999 |
| Client command registration | `class_634.method_11120(class_2678)` and `method_11145(class_2641)` RETURN |
| Client command execution | `class_634.method_45730(String)` HEAD and `method_71927(String,class_437)` HEAD; official dispatch cancels handled local commands |
| END_EXTRACTION | `class_761.method_22710(class_9922,class_9779,boolean,class_4184,Matrix4f,Matrix4f,Matrix4f,GpuBufferSlice,Vector4f,boolean)`, at the official extraction/drawing boundary before the weather extraction call |

The rendering component supplies the complete official `WorldExtractionContext`; the N9Ezz hitbox callback receives its actual world, renderer, frustum and tick counter. The command and networking components retain their official packet/dispatcher behavior. Merely registering a listener or manually invoking an event is not evidence that these game hooks work.

## Loader ABI subset and limits

The own `FabricRuntime` implements the exact descriptor subset needed for the selected modules and N9Ezz: config/game directories, client environment, development flag (false for this packaged runtime), raw 1.21.11 game version, actual game instance, loaded mod/alias lookup, immutable mod enumeration, immutable identification metadata, archive resource access and mapping resolver queries. Archive resources use tracked ZIP filesystems closed with the runtime registration. Reflection mapping queries use the same pinned official/intermediary `TinyMappingIndex` as game remapping. Unknown namespaces, including `named`, are rejected; binary class names are required.

The builtin `fabricloader` compatibility provider exposes `0.19.2` to satisfy the ABI baseline checked for this bounded client. Its display name explicitly says `N9Ezz Fabric Loader ABI compatibility`; no Fabric engine is present. The shim does not implement arbitrary Fabric Loader entrypoint queries, custom language adapters, object sharing, launch argument access or the full metadata API. Those are outside this compatibility contract. Server launch and additional Fabric API modules are unverified.

## Executed checks

`FabricCompatibilityTests` passed 10 checks on Java 21. Tests verified exact hashes/licenses/module selection, deterministic curated archive bytes, source/cache corruption rejection, alias/identity/config services, mapping queries, execution of the transformed constructor fixture with the exact target descriptors, rejection of reordered anchors/repeated initialization and acceptance of the actual pinned intermediary Minecraft constructor bytes with exactly one inserted hook.

These checks establish the own initialization boundary and component selection. The actual lifecycle/tick/render/network callbacks require the shared Mixin integration and real Minecraft launch report; this document does not infer successful gameplay from static inspection or fixture registration.
