# Built-in Pulse rendering bridges

The corrected N9Ezz client archive contains exactly two classes in the
`net.minecraft` namespace which are not supplied by Minecraft 1.21.11. The original
game archive and the official-to-intermediary remapped archive both lack these
exact class names. They are pre-existing Pulse compatibility classes, not a second
game archive or a reason to permit arbitrary mod definitions of game classes.

| Class | Bytes | SHA-256 |
| --- | ---: | --- |
| `net.minecraft.client.gl.ShaderProgramKeys` | 1,836 | `0620bce88d16df2ee6cda788ccd3b59a257deeed8d649daf35bc49a32cbe32a3` |
| `net.minecraft.client.render.BufferRenderer` | 3,949 | `6a446f06f3ba3f43523e657dfcae3df09e85f12eba21789ba7fd64f18fbf7a3e` |

The containing corrected archive is pinned to 41,062,124 bytes and SHA-256
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
`BundledClientContract.isVerifiedClass` verifies the complete archive and the
individual class bytes. The runtime must also establish that the source path is
the explicitly materialized built-in client. Merely matching the class name,
archive filename, mod id, or metadata does not establish that role. Ordinary
external mod/library JARs retain the reserved game namespace check, and the normal
duplicate class check still applies even to a verified bridge.

## Verified bytecode behavior

`javap -p -c` shows that `ShaderProgramKeys` creates 25 distinct plain `Object`
tokens. Its fields do not have Minecraft shader key types and do not compile or
select shaders themselves. Existing callers pass tokens such as `POSITION_COLOR`
and `POSITION_TEX_COLOR` into Pulse's `RenderSystemHelper.setShader(Object)`, whose
implementation searches `RenderSystem` reflectively. This is a legacy adapter,
not the complete Minecraft shader key API.

`BufferRenderer` accepts intermediary `net.minecraft.class_9801` built buffers.
It uploads vertex bytes through LWJGL, creates its own VAO/VBO/EBO, generates quad
indices, and draws with Pulse's `passthrough_color` shader when no custom Pulse
shader is already bound. `draw` delegates to `drawWithGlobalProgram`; buffers are
closed even when rendering fails. Direct callers include Pulse world rendering
and label, item and player list HUD mixins. Removing the bridge would break these
existing binary references. The remapped game provides all four directly used
buffer members with the required descriptors: `class_9801.method_60818()` returning
`ByteBuffer`, `method_60822()` returning `class_9801$class_4574`, that record's
`comp_750()` returning `int`, and `class_9801.close()` returning `void`.

The inspected adapter has inherited limitations. It always divides the vertex
count by four and draws indexed triangles, so this does not establish support for
all Minecraft primitive modes or vertex formats. It queries
`GL_FRAMEBUFFER_BINDING` and later passes that value to `glBindVertexArray`, and
queries `GL_VERTEX_ARRAY_BINDING` and later passes that value to
`glBindBuffer(GL_ARRAY_BUFFER, ...)`; these are not the correct VAO/VBO state
restoration queries. Its `catch (Throwable)` also hides draw errors. The loader
exception permits the preserved class bytes to link; it does not assert that
every world/HUD rendering feature is visually correct. Any future repair must
update the pinned client archive and bridge hash, with actual rendering tests.

## Provenance and licenses

These binary classes already exist in the user-supplied base client
`base-client-1.5.3.jar` and remain byte-identical after the N9Ezz overlay. Their
original archive entries and accompanying notices are preserved. No source code
for these bridges or separate license grant was present in the supplied project;
the audit does not assign them Minecraft, Fabric, or N9Ezz source licenses. The
new verification code is part of the Java loader sources. This change adds no
copied Mojang game class and does not bundle the game archive.

## Validation

The contract tests accept each bridge from the pinned corrected client and reject
changed class bytes, renamed candidates, the original uncorrected client, and a
different archive carrying a byte-identical bridge. They also verify that trust
is not retained after modifying a previously accepted archive. Class index tests
must separately cover explicit source roles and game duplicates.

The standalone Java 21 test completed with `PASS: 21 built-in render bridge
provenance checks` against the actual corrected and original archives.
