# Shared game runtime integration review

The review checks the boundaries between the own core, selected Fabric API
components, Mixin preparation, deferred game initialization and session cleanup.
It does not establish compatibility with arbitrary Fabric mods or any Forge,
NeoForge or Quilt game hooks.

The reviewed implementation is `GameRuntimeBootstrap`, `UnifiedClassLoader` and
`RuntimeSession`. Regression checks are in
`universal-loader/src/test/java/dev/n9ezz/loader/core/GameIntegrationTests.java`.
They load actual temporary JARs with Java 21 bytecode. They do not launch
Minecraft, render a world or prove N9Ezz combat behavior.

## Confirmed defects and regressions

| Boundary | Confirmed behavior before correction | Required behavior |
| --- | --- | --- |
| Fabric API archive ownership | A caller could put a fabricated JAR in `GameIntegration.fabricApiJars` and define reserved `net.fabricmc.fabric.*` classes. The normal bootstrap verified hashes, but the public classloader constructor did not enforce its own role contract. | Grant this role only to exact hash-pinned selected API modules. |
| Generated class lifecycle | `loadClass` could define an unindexed generated helper after `close()`, because only `findClass` checked the closed state. | Block new generated definitions after session closure while permitting access to already defined classes. |
| Resource cleanup | A resource throwing `Error` prevented older resources from closing. Ordinary exceptions were already collected and remaining resources closed. | Attempt every resource in reverse order and preserve failures. |

The initial run against the then-current compiled core reproduced all three:
17 checks passed and 3 checks failed. Corrections are made in the own core;
none require another loader engine.

After the core corrections, the same checks passed **20/20** on Java 21.
The report is `docs/game-runtime-review-test-report.txt`. The role constructor
now verifies original API module hashes, shutdown shares the class-definition
lock and blocks helper creation, and cleanup collects both exceptions and
errors while continuing through remaining resources.

## Other checked contracts

- Minecraft classes require an explicit, unique game archive role. A mod may
  reference game classes only in the opt-in game integration mode. The referenced
  game class and the referencing mod are defined by the same loader.
- Opting into game integration does not allow references to Fabric, Quilt, Forge,
  NeoForge or ModLauncher implementation classes.
- Java 21 multi-release libraries select the highest eligible logical class and
  resource. Versioned entries without the manifest flag are ignored. Classes
  supplied by two archives still fail as duplicates, including selected
  multi-release definitions.
- Mixin byte inspection executes mapping, access and core transformations without
  recursively applying Mixin or post transformations. Actual class definition
  subsequently executes the full ordered pipeline.
- Generated helpers are defined by the common loader and pass class-name and ASM
  checks. Parent-owned loader APIs cannot be replaced by a generated helper.
- Definitions in Mixin mode are serialized across threads and permit recursive
  definitions on the same thread. The test starts competing class loads and
  verifies that their transformation calls do not overlap across threads.
- A Mixin configuration must exist in its declaring archive. Duplicate declared
  names and ambiguous resources from mod libraries or the parent classpath fail
  before Mixin initialization.
- Native and selected Fabric game contracts are supported. Other game platform
  formats and mod namespaces requiring additional remapping fail explicitly.
- Only the selected Fabric Loader ABI version is advertised to dependencies in
  game integration mode. The strict API-only mode does not advertise that ABI;
  other engine dependencies and impersonated built-in identities still fail.
- A game session exposes snapshots of its deferred lifecycle trace. Later game
  phases appear in new snapshots, and callers cannot mutate those snapshots.
- Session cleanup runs in reverse resource order and is idempotent after an
  attempted close.

## Deferred initialization review

The initializer callback is installed before Mixin configuration plugins are
loaded. It therefore needs an explicit preparation gate: a plugin must not be
able to construct MinecraftClient and invoke common/client mod callbacks before
Mixin preparation and transformer readiness. This supplements the real Mixin
loaded-target tracker. The reviewed correction adds that gate and also rejects
constructor initialization in a verify-only session. Constructor timing itself is covered separately by
`FabricCompatibilityTests`, including actual Minecraft constructor bytes when
the intermediary game JAR is provided.

Real game startup, actual Fabric event delivery and N9Ezz module initialization
must be recorded separately from these archive and lifecycle regression checks.
