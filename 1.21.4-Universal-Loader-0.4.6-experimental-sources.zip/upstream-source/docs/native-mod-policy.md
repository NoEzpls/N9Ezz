# Собственные моды N9Ezz: политика 0.4.1

Внешние моды должны быть написаны или явно перенесены на собственный контракт
N9Ezz. Обычные архивы Fabric, Quilt, Forge и NeoForge в папке `mods` больше
не принимаются, даже если в 0.4.0 они объявляли ограниченный lifecycle opt-in.
Общее ядро и встроенные API-компоненты сохраняются; меню платформ не появляется.

## Правила допуска

| Внешний архив | Результат |
| --- | --- |
| Один корневой `n9ezz.mod.json`, поддержанные metadata/entrypoints | Допуск к обычной проверке зависимостей, namespace, классов и API |
| `fabric.mod.json` | Отклонение до entrypoint |
| `quilt.mod.json` | Отклонение до entrypoint |
| `META-INF/mods.toml` | Отклонение до entrypoint |
| `META-INF/neoforge.mods.toml` | Отклонение до entrypoint |
| Собственный descriptor вместе с любым указанным сторонним | Отклонение; собственный JSON не перекрывает запрет |
| Собственный архив с вложенным JAR | Отклонение; внешняя nested dependency resolution не поддерживается |
| Архив без собственного descriptor | Отклонение |

Обычная библиотека в дополнительном classpath также не может содержать
mod descriptor или вложенный JAR: это не обход каталога `mods`.
Внешние mod/library файлы должны быть обычными JAR, а не символическими
ссылками. Обычные библиотеки при необходимости включаются классами с
соблюдением их лицензий; дубли API/runtime классов не разрешаются.

| Код диагностики | Причина |
| --- | --- |
| `EXTERNAL_MOD_NOT_N9EZZ` | Нет собственного корневого descriptor |
| `EXTERNAL_MOD_AMBIGUOUS` | Вместе с собственным descriptor присутствует сторонний |
| `EXTERNAL_NESTED_MOD_UNSUPPORTED` | Внешний мод содержит вложенный JAR |
| `EXTERNAL_CLASSPATH_MOD` | Mod descriptor или вложенный JAR обнаружен в library classpath |

Политика применяется до исполнения внешнего кода и в игровом bootstrap, и в
API-only CLI. Она не запрещает копирование файлов средствами операционной
системы: загрузчик отказывается их загружать. Ошибка называет проблемный
архив; загрузчик не удаляет файл.
Идентичность встроенного компонента не определяется названием JAR, mod ID или
расположением в cache. Встроенные источники поступают из установщика и проходят
существующие проверки SHA-256; эта ограниченная доверенная ветвь сохраняет
полный N9Ezz и выбранные Fabric API модули.

Это ограничение формата подключения, а не доказательство авторства. Любой
разработчик может создать собственный мод по открытому API. Здесь нет подписи,
центральной выдачи разрешений или песочницы исполнения Java. Переименование
файла или добавление descriptor не заменяет перенос initializer, зависимостей
и вызовов API; неподдержанные классы и механизмы остаются несовместимыми.

## Минимальный мод на Java 21

Пример использует тот же API, что и поставляемый
`universal-loader/src/demo/java/dev/n9ezz/examples/SmokeMod.java`.
Он не ссылается на Minecraft и пригоден для отдельного API-only прогона.

Структура исходников:

```text
hello-n9/
  n9ezz.mod.json
  src/example/HelloN9.java
```

`n9ezz.mod.json`:

```json
{
  "schemaVersion": 1,
  "id": "hello_n9",
  "version": "1.0.0",
  "namespace": "none",
  "entrypoints": {
    "common": ["example.HelloN9"]
  },
  "depends": {
    "java": ">=21",
    "n9ezz": ">=0.4.1"
  }
}
```

`src/example/HelloN9.java`:

```java
package example;

import dev.n9ezz.loader.api.ModContext;
import dev.n9ezz.loader.api.N9ModInitializer;
import dev.n9ezz.loader.core.LifecycleEvent;

public final class HelloN9 implements N9ModInitializer {
    @Override
    public void onInitialize(ModContext context) {
        System.out.println("Initialized own mod: " + context.modId());
        context.events().on(LifecycleEvent.READY, 0,
                event -> System.out.println("Shared runtime is ready"));
    }
}
```

Из `hello-n9/` выполните полным JDK 21; замените путь в `N9EZZ_JAR`:

```bash
N9EZZ_JAR=/absolute/path/N9Ezz-Universal-Loader-0.4.1-experimental.jar
mkdir -p build/classes build/mods
javac --release 21 -cp "$N9EZZ_JAR" -d build/classes src/example/HelloN9.java
jar --create --file build/mods/hello-n9-1.0.0.jar -C build/classes . -C . n9ezz.mod.json
java -jar "$N9EZZ_JAR" --verify --game-dir build/test-game --mods-dir build/mods
java -jar "$N9EZZ_JAR" --run --game-dir build/test-game --mods-dir build/mods
```

Не включайте установщик, его API-классы или исходные JAR зависимостей внутрь
мода. Установочный JAR используется в `javac -cp` только как compile-time API.
Готовый `hello-n9-1.0.0.jar` помещается в
`.minecraft/n9ezz-universal/mods/`; игру запускают через профиль N9Ezz.
Команды `--verify` и `--run` выше не запускают Minecraft.

`ModContext` предоставляет `modId()`, `gameDirectory()` и `events()`.
Фаза `common` использует `N9ModInitializer.onInitialize(ModContext)`;
`client` использует тот же интерфейс и задаётся отдельным массивом в
`entrypoints`. `READY` публикуется после успешной инициализации. Это не
обещание, что мир или игрок уже существуют. `namespace: "none"` подходит
модам без ссылок на классы Minecraft. Game-aware моды должны соблюдать
зафиксированный namespace и реально доступные API ядра; универсального
переноса mappings/patches сторонних платформ здесь нет.

## Версии и проверки

Политика введена в 0.4.1. Результаты admission, initializer и настоящего
игрового прогона новой версии записываются в
[release-test-report-0.4.1.md](release-test-report-0.4.1.md).
Сохранённый [0.4.0 cross-platform run](release-test-report-0.4.md) проверял
предыдущую политику и не применяется к новому установщику. Описания внутренних
слоёв — в [compatibility.md](compatibility.md).
