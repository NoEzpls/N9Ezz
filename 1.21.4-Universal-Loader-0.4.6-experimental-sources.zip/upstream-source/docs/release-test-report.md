# N9Ezz 0.2.0 experimental: итоговые проверки

Дата: 7 октября 2026. JDK: Temurin 21.0.8+9; runtime/compiler target: Java 21.
Установочный JAR содержит полный обновлённый N9Ezz как обязательный встроенный
модуль. Пользовательская папка `mods` для клиента не нужна. Реальное исполнение
этого клиента в новом ядре пока заблокировано; сборка экспериментальная.

| Проверка | Результат | Что подтверждено |
| --- | --- | --- |
| Собственное ядро | PASS, 54/54 | Пять metadata formats, один classloader, dependency order, lifecycle, ASM order/validation, duplicates, native builtin и проверки повреждённых ресурсов/cache |
| Packaged builtin self-test | PASS, READY | Реальный test-mod JAR и initializer в общей среде при пустой `mods` |
| Установщик | PASS, 11/11 | Один профиль/библиотека, автоматический builtin, повторная установка, сохранность старых файлов, backup, malformed metadata/cache/symlink rejection |
| Обновление полного клиента | PASS, 8/8 | Pinned inputs, deterministic merge, неизменные host/metadata/Mixin config, отказ overwrite и изменённому overlay |
| Проверка обновлённых классов | PASS | 82 класса ASM-verified; 35 host ABI references, 2593 subsystem references, 10 неизменных Mixin contracts |
| Отдельная symbol-проверка с Minecraft intermediary | PASS | Два inherited Input fields разрешены; итоговый client SHA совпадает |
| Client addon compile/remap и source suites | PASS, 34614 checks | Включая 3036 shared targeting geometry checks; игровые QA fixtures скомпилированы |
| Итоговый профиль с официальным vanilla 1.21.11 | EXPECTED FAILURE, exit 1 | Обязательный builtin `pulse` найден; `METADATA_UNSUPPORTED` до entrypoints и Minecraft main |
| Предыдущий vanilla smoke через общее ядро | Частично PASS | Реальный Minecraft main, OpenGL/resource initialization; относится к этапу до обязательного N9Ezz builtin |
| Title screen, world entry, PvP/wire fixtures, N9Ezz gameplay | UNRUN | Тесты геометрии и bytecode не доказывают игровое поведение |
| Произвольные моды четырёх платформ | UNSUPPORTED | Проверены только документированные API/metadata fixtures |
| Сохранённый старый installer | PASS, 27 unit + 12 integration checks | Пересборка старого 0.1.0, контрольные суммы исходной базы; gameplay отдельно не проверялся |

Сборка: `source /workspace/toolchains/activate-temurin21.sh`, затем
`python3 universal-loader/build.py --offline`. Подробные результаты сохраняются
в `universal-loader/dist/{test-report,packaged-smoke-report,installer-report,
client-bundle-tests,client-bundle-report,client-bundle-symbols-report}.txt`.
Новые defaults и итоговая attack validation описаны в `client-hitbox-audit.md`.

Проверка реального установленного профиля воспроизводится отдельно:

```sh
python3 universal-loader/scripts/profile_bootstrap_probe.py \
  --installer universal-loader/dist/N9Ezz-Universal-Loader-0.2.0-experimental.jar \
  --prepared-game /workspace/minecraft-smoke \
  --report /tmp/n9ezz-profile-probe.log
```

Проверка использует официальный client JAR, сверяет SHA-1 и запускает main class
установленного профиля. Она ожидает конкретную неподдержанную возможность;
её PASS означает корректное подключение/отклонение builtin, а не работающую игру.

Незавершённые части: shared nested-JAR resolver, official/intermediary/named
remapper, реальный Mixin/refmap service, access wideners/transformers, Fabric
API/QSL game hooks, JavaFML/module semantics и Forge/NeoForge game patches и
registries. Forge binary availability для 1.21.11 не удостоверена из-за HTTP 403;
Quilt Meta/Maven checksum disagreement остаётся отдельным FAIL. См.
`platform-availability.md` и `compatibility.md`.

Компиляция выдаёт предупреждения об optional ErrorProne annotations Gson,
serializable exception fields, старом URL constructor и некоторых test
resources. Они сохранены в output; compilation и перечисленные тесты завершились
с exit 0. Игровой отказ builtin клиента не записывается как успешный запуск.
