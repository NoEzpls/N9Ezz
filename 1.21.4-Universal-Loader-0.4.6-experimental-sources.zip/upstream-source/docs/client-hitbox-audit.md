# N9Ezz Hitboxes / Triggerbot / Kill Aura: аудит и исправление

> Исторический аудит от 7 октября. В 0.3.0 исправленный клиент уже встроен в собственное ядро и прошёл запуск в демо-мире; actual targeting/attack packets/PvP по-прежнему не проверены. Текущий отчёт: [latest-runtime-status.md](latest-runtime-status.md).

Проверено 7 октября 2026 года. Изменён настоящий клиент из пользовательского
архива в `client/`; его исходная копия в `/workspace/input/extracted/N9Ezz-Codex`
не изменялась. Исправление относится к Fabric-клиенту и отдельно от собственного
Universal Loader. Наличие тестов геометрии не подтверждает запуск клиента в
новом ядре.

## Исходные версии и сохранённая база

- Прикреплённый reference JAR: `PulseVisuals_crack1.21.11 (4).jar`, metadata
  `1.5.0-n9ezz`, Minecraft `1.21.11`, Java `>=21`, Fabric Loader `>=0.17.0`.
  SHA256: `ca978a7726fbb13ad196484439611e2c2ca1ffb1947a3ddb443c8bc30b4bfd52`.
- Клиент в установочном bundle: metadata `1.5.3-n9ezz`, SHA256
  `2d074935e2445b29d5478e1e0c15064c55ba40f268c817920b5bf7f000d8d8eb`.
  Этот JAR использован как неизменяемая старая база; исправления в нём не
  выполнялись.
- Исходники `client/build.gradle`: версия `1.5.3`, Java 21, Loom `1.16.2`,
  Minecraft `1.21.11`, Yarn `1.21.11+build.6`, Fabric Loader `0.19.2`, Fabric API
  `0.141.3+1.21.11`. Объявленные зависимости не менялись.
- Точные неизменённые copies семи исходных файлов и SHA256 находятся в
  `client/docs/hitbox-baseline/`. `sha256.json` включает оба старых JAR.

Reference и текущие исходники имеют разные версии. Заявление «сделано точь-в-точь
как reference JAR» было бы неверным: исправление сохраняет текущую архитектуру
1.5.3 и устраняет несогласованную геометрию, а не возвращает весь старый клиент.

## Что показали исходники и bytecode reference

В исходниках Hitboxes не меняет `Entity.getBoundingBox()`. `Targeting.box()`
создаёт отдельную увеличенную область, а `HitboxVisuals` рисует её рамку.
`ProjectileTargetMixin` расширяет только клиентский выбор в ProjectileUtil и
добавляет игроков, пропущенных обычным broad-phase.

Однако до исправления:

| Стадия | Использовавшаяся геометрия | Результат |
| --- | --- | --- |
| Отрисовка и расширенное picking | `Targeting.box()` | Расширенная рамка и предварительная цель видны |
| Aura `acquire.valid()` | `realDistance`, nearest point обычной коробки | Расширенная цель отвергается независимо от рамки |
| Aura `aimPoint()` | обычная коробка | Камера наводится на другую геометрию |
| Trigger/Aura `exactHit` | значение по умолчанию `true` | Предварительный луч тоже выбирает обычную коробку |
| `Attacks.valid()` | `realDistance` | Дополнительный независимый фильтр обычной геометрии |
| `Attacks.flush()` | `underCrosshairEntity(..., false)` всегда | Даже при `exactHit=false` окончательная атака отвергает расширенный hit |

Reference исследован только статически: необходимые class-файлы извлечены,
прочитаны через `javap -c -p` и CFR `0.152`. CFR скачан с Maven Central с
сохранённой TLS-проверкой; официальный `.sha256` совпал с
`f686e8f3ded377d7bc87d216a90e9e9512df4156e75b06c655a16648ae8765b2`.
Чужой код и reference binary не выполнялись.

Исходный `ObfuscateClient.java` объясняет имена reference:

| Исходный класс | Reference class / методы | Подтверждённое поведение |
| --- | --- | --- |
| `Targeting` | `pulse.n9ezz.d`, `m4`, `m7`, `m9`, `m15`, `m17` | `m4` расширяет; `m7` считает expanded distance; `m9` считает original distance; `m15` использует original validity; `m17` выбирает expanded только при переданном флаге |
| `Attacks` | `pulse.n9ezz.e`, `m2` | Проверяет `d.m9` и original-body LOS; атакует сразу, без текущей pending-after-movement стадии |
| `KillAura` | `pulse.n9ezz.u0` | `exactHit=true`, вызов `d.m17(range,!exactHit)` |
| `Triggerbot` | `pulse.n9ezz.u1` | `exactHit=true`, тот же флаг выбора геометрии |
| `Hitboxes` | `pulse.n9ezz.u3` | X/Y/Z, range, onlyTarget и визуальные настройки сохраняют знакомый интерфейс |

Reference тоже не является доказательством исправно согласованных hitboxes:
его attack-range/LOS остаются обычными. Новая финальная проверка всегда обычной
коробки появилась в архитектуре 1.5.3 и усилила это расхождение.

## Сделанные изменения

`TargetGeometry` — один собственный вычислительный модуль для scale, nearest
point, расстояния, segment/AABB intersection, предела луча и block cutoff.
`Targeting.box()`, nearest-point calculations и picking используют его.
Обычная геометрия остаётся неизменной при коэффициенте 1; тест обнаружил и
исправил преждевременное округление при пересчёте тождественного scale.
Граничная конвенция собственного ray/AABB алгоритма явная: касание грани и
конца луча считается попаданием; совпадающий по расстоянию блок имеет приоритет.

Выбор `expanded` теперь передаётся от Triggerbot/Aura в `Attacks.Options` и
сохраняется у pending attack. Поиск Aura, scoring/FOV, её aim point, Triggerbot
ray, выбранная дальность и финальный ray используют одинаковую политику.
Перед доставкой атака повторно проверяет текущую геометрию: выключенные Hitboxes
уже дают обычную коробку, поэтому прежний near-miss не проходит. Исчезнувшая
цель, изменившийся слот/предмет и ручная атака сохраняют свои существующие guards.

Aura вычисляет ближайшую точку **после** смещения коробки на interpolated
position. Ранее ближайшая точка вычислялась по tick-position и потом смещалась,
что могло увести её от настоящего ближайшего места движущейся цели.

Физическая дальность и LOS проверяются отдельно от виртуальной рамки:

- Обычное тело игрока остаётся в пределах исходного attribute
  `ENTITY_INTERACTION_RANGE`; клиентский Reach этот guard не меняет.
- Block cutoff проверяется на луче к выбранной области.
- Обычное тело должно оставаться видимым. Расширенная коробка, выступающая
  перед стеной, не разрешает атаку на полностью закрытого игрока.
- Серверные boxes, collision, damage, reach и игровая проверка сервером не
  изменяются. Сервер может отклонить клиентскую попытку независимо от рамки.

`Обычное попадание=true` остаётся явным режимом исходной коробки; его название,
поле и сохранённые пользовательские значения сохранены. Для свежего клиента
default теперь `false`; встроенные профили, включающие Hitboxes, также выбирают
`false`. Сетевой `/cfg pvp` сохраняет свой прежний обычный режим и выключает
Hitboxes. В старом конфиге с `true` для совместной работы нужно выключить
«Обычное попадание». Настройка `Только текущая цель` не расширяет произвольного
нового игрока: ей нужен уже tracked target, как раньше.

## Проверки и статус

Выполнено в Java 21:

```sh
cd /workspace/N9Ezz/client
N9EZZ_JAVA_BIN=/workspace/toolchains/jdk-21.0.8+9/bin/java \
N9EZZ_JAVAC_BIN=/workspace/toolchains/jdk-21.0.8+9/bin/javac \
bash tools/run-hitbox-tests.sh
```

Результат: **PASS: 3036 shared targeting geometry checks**.
Suite использует production `TargetGeometry`, проверяет ordinary miss /
expanded hit, окончательный miss, target вне обычного broad-phase, grazing
boundary, eye-inside и zero-length ray, reversed ray, exact range endpoint,
блок перед/после цели, block tie, ближнего entity-occluder, отделение physical
reach/LOS от protruding expansion, nearest point движущейся коробки, identity
scale и некорректные числа. 1000 фиксированных diagonal fixtures проверяют
translation invariance и монотонность первой точки попадания при расширении.
Добавлена Gradle-задача `hitboxTest` для того же suite без новых test dependency.

Также обновлены настоящие game-world fixtures `PvpChecks` и `WireChecks`:
expanded near-miss Aura/Triggerbot должен отправить ровно одну заряженную атаку,
ordinary opt-out — ни одной; включены broad-phase, onlyTarget, disable и
through-wall assertions. Между успешными атаками выполняется зарядка оружия.
Эти fixtures требуют реального Minecraft world и packet-capture mixin;
их обновление или компиляция не считается пройденным игровым запуском.

Фактическая addon-сборка также завершилась успешно: Gradle `classes`,
`remapJar`, `qaClasses`, `combatTest`, `animationTest`, `aimTest`, `pvpTest`,
`systemsTest`, `powerTest`, `hitboxTest`. Итого **34614 checks**: combat 1647,
animation 1003, aim 14073, pvp 113, systems 13679, power 1063, hitbox 3036.
`qaClasses` подтверждает компиляцию обновлённых игровых fixtures; это не их
исполнение в мире. Полный log: `docs/client-addon-build-attempt.log`.

Сборка использовала старый встроенный `1.5.3` JAR только как неизменяемую
compile dependency через `-PpulseJar=...`. Получен
`client/build/libs/n9ezz-fabric-1.21.11-1.5.3.jar`, SHA256
`80d7fc348a48c1f284ddd1410fb5e86cf6bc0ca4ddc247aefb12af52f2cef206`.
Это remapped **addon overlay**, не merged Pulse/N9Ezz client и не установочный
Universal Loader. Сам overlay нельзя устанавливать вместо полного клиента.
Отдельный проверенный `MergeBundledClient` теперь заменяет весь N9Ezz subsystem
в сохранённой полной базе, согласуя class/member aliases без повторных host
patches. Получен полный обновлённый клиент SHA256
`2f6a4d54a96ecfc1b8fb15fb8e86fe552e213e25ffd3bf95c5fde587f06da424`.
Metadata, refmap, nested libraries и host classes сохранены byte-identical;
отчёт: `docs/client-bundle-overlay-review.md`. Существующий `fullClient` merge
на уже patched/obfuscated base повторяет старые patches и не применялся.

Реальный запуск новых game fixtures, сетевой сервер и совместимость исходного
Fabric-клиента с собственным ядром остаются отдельными проверками; статический
аудит reference и addon compile их не заменяют.
