from pathlib import Path
import hashlib
import shutil

def apply(loader_root: Path, overlay: Path):
    # Paths and visible labels only: retain descriptor names, ABI packages and mod IDs.
    pairs = {'.n9ezz/':'.pulsevisuals/', '.n9ezz-backups':'.pulsevisuals/backups',
             '.n9ezz-install.lock':'.pulsevisuals/install.lock', 'n9ezz-universal':'pulsevisuals-universal',
             'embedded/n9ezz-client-1.5.3.jar':'embedded/pulsevisuals-client-1.5.3.jar',
             'dev/n9ezz/universal-loader/':'dev/pulsevisuals/universal-loader/',
             'dev.n9ezz:universal-loader:':'dev.pulsevisuals:universal-loader:'}
    for area in ('src','scripts'):
        for p in (loader_root/area).rglob('*'):
            if not p.is_file() or p.suffix not in ('.java','.py','.json'): continue
            s=p.read_text()
            for a,b in pairs.items():s=s.replace(a,b)
            # Some cache paths are assembled from a directory component, not a slash path.
            s=s.replace('".n9ezz"', '".pulsevisuals"').replace('/.n9ezz"', '/.pulsevisuals"')
            # No Java identifiers named N9Ezz occur in this loader implementation.
            s=s.replace('N9Ezz','PulseVisuals')
            p.write_text(s)
    for p in overlay.rglob('*.java'):
        target=loader_root/p.relative_to(overlay);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    smoke=loader_root/'scripts/installer_smoke.py'
    s=smoke.read_text()
    h=bytearray(hashlib.md5(b'PulseVisuals:universal:1.21.11').digest());h[6]=(h[6]&15)|48;h[8]=(h[8]&63)|128
    s=s.replace('PROFILE = "PulseVisuals-Universal-1.21.11"','PROFILE = "PulseVisuals-Universal-1.21.11"\nPROFILE_KEY = "'+h.hex()+'"')
    s=s.replace('{PROFILE: {"name": "User profile"}}','{PROFILE_KEY: {"name": "User profile"}}')
    # A key collision now creates a separate profile instead of aborting installation.
    # Preserve the old safety assertion and add stable repeat/backup assertions for
    # the newly supported success path; unrelated profile data is never overwritten.
    previous = '''    invoke(foreign_profile, False)
    assert (foreign_profile / "launcher_profiles.json").read_bytes() == foreign
    assert not (foreign_profile / "libraries").exists()
    case("foreign profile with same id is preserved")'''
    replacement = '''    foreign_report = json.loads(invoke(foreign_profile, True).stdout)
    foreign_path = foreign_profile / "launcher_profiles.json"
    foreign_root = json.loads(foreign_path.read_text())
    assert foreign_report["profileKey"] != PROFILE_KEY
    assert foreign_root["profiles"][PROFILE_KEY] == {"name": "User profile"}
    assert len(foreign_root["profiles"]) == 2
    assert foreign_root["profiles"][foreign_report["profileKey"]]["lastVersionId"] == PROFILE
    saved = list((foreign_profile / ".pulsevisuals/backups").rglob("launcher_profiles.json"))
    assert len(saved) == 1 and saved[0].read_bytes() == foreign
    fixed_bytes = foreign_path.read_bytes()
    fixed_stamp = foreign_path.stat().st_mtime_ns
    repeat_foreign = json.loads(invoke(foreign_profile, True).stdout)
    assert repeat_foreign["profileKey"] == foreign_report["profileKey"]
    assert foreign_path.read_bytes() == fixed_bytes and foreign_path.stat().st_mtime_ns == fixed_stamp
    case("foreign profile preserved; separate stable profile created with exact backup")'''
    if s.count(previous) != 1:
        raise RuntimeError("Pinned foreign-profile test fixture changed; inspect before updating")
    s=s.replace(previous, replacement)
    smoke.write_text(s)
