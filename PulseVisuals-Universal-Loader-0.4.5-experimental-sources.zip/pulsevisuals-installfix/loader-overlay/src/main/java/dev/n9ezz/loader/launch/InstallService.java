package dev.n9ezz.loader.launch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.n9ezz.loader.core.BuiltinModSource;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;
import java.util.jar.JarFile;

/** Installs one profile into an existing Java-21 vanilla launcher installation. */
public final class InstallService {
    public static final String MINECRAFT_VERSION = "1.21.11";
    /** Launcher profile keys and version IDs are different namespaces. */
    public static final String PROFILE_ID = "PulseVisuals-Universal-1.21.11";
    public static final String PROFILE_KEY = UUID.nameUUIDFromBytes(
            ("PulseVisuals:universal:" + MINECRAFT_VERSION).getBytes(StandardCharsets.UTF_8)).toString().replace("-", "");
    private static final String LEGACY_PROFILE_ID = "N9Ezz-Universal-1.21.11";
    private static final String COORDINATE = "dev.pulsevisuals:universal-loader:" + Main.VERSION;
    // Preserve explicit nulls in unrelated launcher entries too. Gson's default
    // would drop an occupied null-valued profile while serializing our new entry.
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().serializeNulls().create();

    private InstallService() { }

    public static Map<String, Object> install(Path minecraftHome, Path installerJar) throws Exception {
        if (Runtime.version().feature() < 21) throw new IllegalStateException("Java 21 or newer is required.");
        Path home = minecraftHome.toAbsolutePath().normalize();
        if (!Files.isDirectory(home) || Files.isSymbolicLink(home)) {
            throw new IOException("Select an existing Minecraft directory (symlink roots are unsupported): " + home);
        }
        ensureWithin(home, home.resolve("versions"));
        Path vanilla = home.resolve("versions/1.21.11/1.21.11.json");
        Path vanillaJar = home.resolve("versions/1.21.11/1.21.11.jar");
        if (!Files.isRegularFile(vanilla, LinkOption.NOFOLLOW_LINKS) || !Files.isRegularFile(vanillaJar, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("BASE_VERSION_MISSING: install and start vanilla Minecraft 1.21.11 once in your launcher. No game binaries are bundled.");
        }
        ensureWithin(home, vanilla);
        ensureWithin(home, vanillaJar);
        JsonObject base = readObject(vanilla);
        if (!base.has("id") || !MINECRAFT_VERSION.equals(base.get("id").getAsString()) || base.has("inheritsFrom")) {
            throw new IOException("The base version must be unmodified vanilla 1.21.11.");
        }
        if (!base.has("javaVersion") || base.getAsJsonObject("javaVersion").get("majorVersion").getAsInt() != 21) {
            throw new IOException("Base version does not declare the required Java 21 runtime.");
        }
        try (JarFile jar = new JarFile(installerJar.toFile())) {
            if (jar.getManifest() == null || !Main.VERSION.equals(jar.getManifest().getMainAttributes().getValue("Implementation-Version"))) {
                throw new IOException("Installer manifest/version mismatch.");
            }
        }
        Path profilesPath = home.resolve("launcher_profiles.json");
        ensureWithin(home, profilesPath);
        byte[] profilesBefore = Files.exists(profilesPath) ? Files.readAllBytes(profilesPath) : null;
        JsonObject profilesRoot = Files.exists(profilesPath) ? readObject(profilesPath) : new JsonObject();
        if (profilesRoot.has("profiles") && !profilesRoot.get("profiles").isJsonObject()) {
            throw new IOException("Invalid launcher_profiles.json profiles object; preserving original file.");
        }
        JsonObject originalProfilesRoot = profilesRoot.deepCopy();
        byte[] artifact = Files.readAllBytes(installerJar);
        BuiltinModSource clientSource = BuiltinModSource.embeddedClient();
        BuiltinModSource.BundleInfo client = clientSource.describe();
        String relativeLibrary = "dev/pulsevisuals/universal-loader/" + Main.VERSION + "/universal-loader-" + Main.VERSION + ".jar";
        Path library = home.resolve("libraries").resolve(relativeLibrary);
        Path versionPath = home.resolve("versions").resolve(PROFILE_ID).resolve(PROFILE_ID + ".json");
        Path instance = home.resolve("pulsevisuals-universal");
        Path clientTarget = instance.resolve(".pulsevisuals/builtin").resolve(client.sha256() + ".jar");
        for (Path path : new Path[] {library, versionPath, instance.resolve("mods"), clientTarget,
                instance.resolve("logs"), clientTarget.resolveSibling(client.sha256() + ".lock"),
                home.resolve(".pulsevisuals/backups"), home.resolve(".pulsevisuals/install.lock")}) {
            ensureWithin(home, path);
        }
        JsonObject version = new JsonObject();
        version.addProperty("id", PROFILE_ID);
        version.addProperty("inheritsFrom", MINECRAFT_VERSION);
        version.addProperty("type", "release");
        version.addProperty("time", "2026-10-07T00:00:00+00:00");
        version.addProperty("releaseTime", "2026-10-07T00:00:00+00:00");
        version.addProperty("mainClass", "dev.n9ezz.loader.launch.GameBootstrap");
        version.addProperty("minimumLauncherVersion", 21);
        version.add("javaVersion", base.get("javaVersion").deepCopy());
        JsonObject lib = new JsonObject();
        lib.addProperty("name", COORDINATE);
        // Already copied into the launcher's Maven-layout library cache.
        // There is deliberately no invented remote distribution URL.
        com.google.gson.JsonArray libraries = new com.google.gson.JsonArray();
        libraries.add(lib);
        version.add("libraries", libraries);
        version.addProperty("pulsevisualsExperimental", true);

        String profileKey = updateProfiles(profilesRoot, instance, Instant.now());
        // Do not rewrite an already-correct launcher's formatting or timestamps.
        byte[] profileContent = originalProfilesRoot.equals(profilesRoot) && profilesBefore != null
                ? profilesBefore : JSON.toJson(profilesRoot).getBytes(StandardCharsets.UTF_8);
        List<Migration> migration = planMigration(home, instance);
        Path lockPath = home.resolve(".pulsevisuals/install.lock");
        Files.createDirectories(lockPath.getParent());
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             FileLock lock = acquireLock(channel)) {
            // Read/prepare happened before locking: refuse a concurrent profile edit.
            assertProfilesUnchanged(profilesPath, profilesBefore);
            // The same verified, content-addressed source is used by bootstrap.
            // A modified cache is rejected before any launcher metadata changes.
            boolean clientPresent = Files.exists(clientTarget, LinkOption.NOFOLLOW_LINKS);
            Path preparedClient = clientSource.materialize(instance);
            Path backup = home.resolve(".pulsevisuals/backups").resolve(Instant.now().toString().replace(':', '-') + "-" + UUID.randomUUID());
            writePreserving(home, backup, library, artifact);
            writePreserving(home, backup, versionPath, JSON.toJson(version).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            Files.createDirectories(instance.resolve("mods"));
            Files.createDirectories(instance.resolve("logs"));
            int migrated = migrateMissing(home, migration);
            // The install lock coordinates our installers, not an open launcher. Check again
            // immediately before publishing the profile so its newer settings are preserved.
            assertProfilesUnchanged(profilesPath, profilesBefore);
            writePreserving(home, backup, profilesPath, profileContent);
            Map<String, Object> report = new LinkedHashMap<>();
            report.put("profile", PROFILE_ID);
            report.put("profileKey", profileKey);
            report.put("profileName", profilesRoot.getAsJsonObject("profiles")
                    .getAsJsonObject(profileKey).get("name").getAsString());
            report.put("minecraft", MINECRAFT_VERSION);
            report.put("runtime", "one PulseVisuals core / " + Main.VERSION);
            report.put("instance", instance.toString());
            report.put("librarySha256", HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(artifact)));
            report.put("oldProfilesPreserved", true);
            report.put("settingsMigrated", migrated);
            report.put("migrationPolicy", "copy missing config/options only; preserve source and existing destination; no external mods copied");
            report.put("clientBundled", true);
            report.put("clientSource", "built-in runtime module; no separate mod installation");
            report.put("clientPath", preparedClient.toString());
            report.put("clientSha256", client.sha256());
            report.put("clientSize", client.size());
            report.put("clientInstallStatus", clientPresent ? "already-present" : "installed");
            report.put("clientRunnableInUniversalCore", true);
            report.put("clientExecutionStatus", "pinned-client: shared mappings, Mixin, resources and selected API hooks; see release test report for verified scope");
            report.put("realMinecraftLaunchVerified", false);
            report.put("verificationScope", "This installation checks files and profiles; game launch is validated separately in the release report");
            return report;
        }
    }


    static String updateProfiles(JsonObject root, Path instance, Instant now) {
        JsonObject profiles = root.has("profiles") ? root.getAsJsonObject("profiles") : new JsonObject();
        String key = null;
        // Launchers can discard unknown fields and change a profile's display name/key.
        // The selected version AND the absolute game directory identify this installation;
        // neither the optional marker nor its name alone authorizes overwriting a profile.
        if (belongsToInstance(profiles.get(PROFILE_KEY), instance)) {
            key = PROFILE_KEY;
        } else {
            for (String candidate : profiles.keySet().stream().sorted().toList()) {
                if (belongsToInstance(profiles.get(candidate), instance)) {
                    key = candidate;
                    break;
                }
            }
        }
        boolean existing = key != null;
        JsonObject profile = existing ? profiles.getAsJsonObject(key).deepCopy() : new JsonObject();
        if (!existing) {
            key = freeProfileKey(profiles);
            if (profiles.has(LEGACY_PROFILE_ID) && profiles.get(LEGACY_PROFILE_ID).isJsonObject()) {
                JsonObject legacy = profiles.getAsJsonObject(LEGACY_PROFILE_ID);
                var marker = legacy.get("n9ezzManaged");
                if (marker != null && marker.isJsonPrimitive() && marker.getAsJsonPrimitive().isBoolean()
                        && marker.getAsBoolean()) profile = legacy.deepCopy();
            }
        }
        profile.remove("n9ezzManaged");
        String name = stringProperty(profile, "name");
        if (!existing || name == null || name.isBlank()) {
            profile.addProperty("name", "PulseVisuals Universal (experimental)");
        }
        profile.addProperty("type", "custom");
        profile.addProperty("lastVersionId", PROFILE_ID);
        profile.addProperty("gameDir", instance.toString());
        profile.addProperty("pulsevisualsManaged", true);
        if (!profile.has("created")) profile.addProperty("created", now.toString());
        if (!profile.has("lastUsed")) profile.addProperty("lastUsed", now.toString());
        profiles.add(key, profile);
        root.add("profiles", profiles);
        return key;
    }

    private static boolean belongsToInstance(com.google.gson.JsonElement entry, Path instance) {
        if (entry == null || !entry.isJsonObject()) return false;
        JsonObject profile = entry.getAsJsonObject();
        if (!PROFILE_ID.equals(stringProperty(profile, "lastVersionId"))) return false;
        String directory = stringProperty(profile, "gameDir");
        if (directory == null || directory.isBlank()) return false;
        try {
            Path recorded = Path.of(directory);
            // Native Path comparison handles Windows case/separators. Do not guess a base
            // for relative paths, resolve symlinks, or match only the last folder component.
            return recorded.isAbsolute()
                    && recorded.normalize().equals(instance.toAbsolutePath().normalize());
        } catch (InvalidPathException invalid) {
            return false;
        }
    }

    private static String stringProperty(JsonObject object, String name) {
        var value = object.get(name);
        return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()
                ? value.getAsString() : null;
    }

    private static String freeProfileKey(JsonObject profiles) {
        // Preserve every occupied entry, including malformed and unrelated entries.
        // Deterministic 32-hex keys remain compatible with launchers; identity lookup above
        // reuses the chosen key on subsequent installs rather than creating duplicates.
        for (int index = 0; index <= profiles.size(); index++) {
            String candidate = index == 0 ? PROFILE_KEY : UUID.nameUUIDFromBytes(
                    ("PulseVisuals:universal:" + MINECRAFT_VERSION + ":installation:" + index)
                            .getBytes(StandardCharsets.UTF_8)).toString().replace("-", "");
            if (!profiles.has(candidate)) return candidate;
        }
        throw new IllegalStateException("No unused launcher profile key could be allocated");
    }
    private record Migration(Path source,Path target) {}
    private static List<Migration> planMigration(Path home,Path instance)throws IOException {
        List<Migration> plan=new ArrayList<>();Path old=home.resolve("n9ezz-universal");
        for(String part:List.of("config","pulse/config","options.txt","pulse.cfg")) {
            Path source=old.resolve(part);ensureWithin(home,source);
            if(!Files.exists(source,LinkOption.NOFOLLOW_LINKS))continue;
            List<Path> list;
            if(Files.isDirectory(source,LinkOption.NOFOLLOW_LINKS)){try(var walk=Files.walk(source)){list=walk.sorted().toList();}}
            else list=List.of(source);
            for(Path file:list){ensureWithin(home,file);if(Files.isDirectory(file,LinkOption.NOFOLLOW_LINKS))continue;
                if(!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS)||Files.size(file)>16*1024*1024)throw new IOException("Unsupported settings migration file");
                String rel=old.relativize(file).toString().replace('\\','/');
                if(rel.startsWith("config/n9ezz/"))rel="config/pulsevisuals/"+rel.substring(13);
                if(rel.startsWith("pulse/"))rel="pulsevisuals/"+rel.substring(6);
                if(rel.endsWith("pulse.cfg"))rel=rel.substring(0,rel.length()-9)+"pulsevisuals.cfg";
                Path target=instance.resolve(rel);ensureWithin(home,target);plan.add(new Migration(file,target));
            }
        } return plan;
    }
    private static int migrateMissing(Path home,List<Migration> plan)throws IOException {
        int count=0;for(Migration item:plan){ensureWithin(home,item.source());ensureWithin(home,item.target());
            if(Files.exists(item.target(),LinkOption.NOFOLLOW_LINKS))continue;
            Files.createDirectories(item.target().getParent());
            try{Files.copy(item.source(),item.target());count++;}catch(java.nio.file.FileAlreadyExistsException concurrent){/* Keep newer user settings. */}
        }return count;
    }
    private static FileLock acquireLock(FileChannel channel)throws IOException {
        try{FileLock lock=channel.tryLock();if(lock==null)throw new IOException("Another PulseVisuals installer is running");return lock;}
        catch(OverlappingFileLockException e){throw new IOException("Another PulseVisuals installer is running",e);}
    }
    private static void assertProfilesUnchanged(Path path,byte[] expected)throws IOException {
        byte[] actual=Files.exists(path)?Files.readAllBytes(path):null;
        if(!java.util.Arrays.equals(expected,actual))throw new IOException("Launcher profiles changed; close launcher and retry");
    }

    private static JsonObject readObject(Path path) throws IOException {
        if (Files.size(path) > 16 * 1024 * 1024) throw new IOException("Unexpectedly large JSON: " + path);
        try {
            var value = JsonParser.parseString(Files.readString(path));
            if (!value.isJsonObject()) throw new IllegalArgumentException("Root is not an object");
            return value.getAsJsonObject();
        } catch (RuntimeException failure) {
            throw new IOException("Malformed JSON, original file preserved: " + path, failure);
        }
    }

    private static void ensureWithin(Path home, Path path) throws IOException {
        Path normalized = path.toAbsolutePath().normalize();
        if (!normalized.startsWith(home)) throw new IOException("Path escapes Minecraft directory: " + path);
        Path relative = home.relativize(normalized);
        Path current = home;
        for (Path part : relative) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current)) throw new IOException("Symlink installation paths are unsupported: " + current);
        }
    }

    private static void writePreserving(Path home, Path backup, Path target, byte[] content) throws IOException {
        if (Files.exists(target) && java.util.Arrays.equals(Files.readAllBytes(target), content)) return;
        if (Files.exists(target)) {
            Path saved = backup.resolve(home.relativize(target));
            Files.createDirectories(saved.getParent());
            Files.copy(target, saved, StandardCopyOption.COPY_ATTRIBUTES);
        }
        Files.createDirectories(target.getParent());
        Path temporary = Files.createTempFile(target.getParent(), ".pulsevisuals-", ".tmp");
        try {
            Files.write(temporary, content);
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException unsupported) {
                throw new IOException("Atomic install unsupported; original file preserved: " + target, unsupported);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }
}
