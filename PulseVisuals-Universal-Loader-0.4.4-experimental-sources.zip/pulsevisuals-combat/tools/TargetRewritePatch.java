import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Replaces Triggerbot's controller and client acquisition geometry, preserving public ABI. */
public final class TargetRewritePatch implements Opcodes {
    public static final Set<String> MUTABLE=Set.of("pulse/n9ezz/d.class","pulse/n9ezz/u1.class","pulse/n9ezz/u3.class");
    private static final String CONTROLLER="pulse/n9ezz/TriggerV2Controller", RUNTIME="pulse/n9ezz/TargetV2Runtime";
    public static void apply(Map<String,byte[]> files){
        ClassNode c=FeaturePatch.read(files,"pulse/n9ezz/d");MethodNode m=FeaturePatch.method(c,"m4");
        FeaturePatch.reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(FeaturePatch.call(RUNTIME,"box","(Lnet/minecraft/class_1297;)Lnet/minecraft/class_238;"));m.instructions.add(new InsnNode(ARETURN));FeaturePatch.write(files,c);
        c=FeaturePatch.read(files,"pulse/n9ezz/u3");
        addField(c,"alignment","Lpulse/settings/BooleanSetting;");addField(c,"alignmentTurn","Lpulse/settings/SliderSetting;");
        for(AbstractInsnNode i:FeaturePatch.method(c,"<init>").instructions.toArray())if(i.getOpcode()==RETURN){
            InsnList q=new InsnList();alias(q,c.name,"alignment","ALIGNMENT","Lpulse/settings/BooleanSetting;");alias(q,c.name,"alignmentTurn","ALIGNMENT_TURN","Lpulse/settings/SliderSetting;");FeaturePatch.method(c,"<init>").instructions.insertBefore(i,q);
        }
        description(c,"Области выбора X/Y/Z и видимая доводка Triggerbot к настоящему телу. Серверный хитбокс не меняется.");FeaturePatch.write(files,c);
        c=FeaturePatch.read(files,"pulse/n9ezz/u1");
        c.fields.add(new FieldNode(ACC_PRIVATE|ACC_FINAL,"pulsevisuals$controller","L"+CONTROLLER+";",null,null));
        addField(c,"retainTarget","Lpulse/settings/SliderSetting;");
        MethodNode ctor=FeaturePatch.method(c,"<init>");
        for(AbstractInsnNode i:ctor.instructions.toArray())if(i.getOpcode()==RETURN){InsnList q=new InsnList();q.add(new VarInsnNode(ALOAD,0));q.add(new TypeInsnNode(NEW,CONTROLLER));q.add(new InsnNode(DUP));q.add(new VarInsnNode(ALOAD,0));q.add(new MethodInsnNode(INVOKESPECIAL,CONTROLLER,"<init>","(Lpulse/n9ezz/u1;)V",false));q.add(new FieldInsnNode(PUTFIELD,c.name,"pulsevisuals$controller","L"+CONTROLLER+";"));q.add(new VarInsnNode(ALOAD,0));controller(q,c.name);q.add(new FieldInsnNode(GETFIELD,CONTROLLER,"retainMs","Lpulse/settings/SliderSetting;"));q.add(new FieldInsnNode(PUTFIELD,c.name,"retainTarget","Lpulse/settings/SliderSetting;"));ctor.instructions.insertBefore(i,q);}
        delegate(c,"tick","tick","()V",RETURN);delegate(c,"reset","reset","()V",RETURN);delegate(c,"target","target","()Lnet/minecraft/class_1657;",ARETURN);
        InsnList q=new InsnList();controller(q,c.name);q.add(new MethodInsnNode(INVOKEVIRTUAL,CONTROLLER,"reset","()V",false));FeaturePatch.method(c,"onEnable").instructions.insert(q);
        description(c,"Выбирает цель по лучу, доводит расширенную область до физического попадания и сохраняет темп при коротких промахах прицела.");FeaturePatch.write(files,c);
    }
    private static void addField(ClassNode c,String name,String desc){if(c.fields.stream().anyMatch(f->f.name.equals(name)))throw new IllegalStateException("Field collision "+name);c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,name,desc,null,null));}
    private static void alias(InsnList q,String owner,String field,String source,String desc){q.add(new VarInsnNode(ALOAD,0));q.add(new FieldInsnNode(GETSTATIC,RUNTIME,source,desc));q.add(new FieldInsnNode(PUTFIELD,owner,field,desc));}
    private static void controller(InsnList q,String owner){q.add(new VarInsnNode(ALOAD,0));q.add(new FieldInsnNode(GETFIELD,owner,"pulsevisuals$controller","L"+CONTROLLER+";"));}
    private static void delegate(ClassNode c,String old,String next,String desc,int returnOpcode){MethodNode m=FeaturePatch.method(c,old);FeaturePatch.reset(m);controller(m.instructions,c.name);m.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,CONTROLLER,next,desc,false));m.instructions.add(new InsnNode(returnOpcode));}
    private static void description(ClassNode c,String text){if(c.visibleAnnotations!=null)for(AnnotationNode a:c.visibleAnnotations)if(a.desc.equals("Lpulse/module/ModuleInfo;"))for(int i=0;i<a.values.size();i+=2)if(a.values.get(i).equals("b"))a.values.set(i+1,text);}
}
