package pulse.n9ezz;

/** Finite, absolute horizontal speed math. It never multiplies last tick's velocity. */
public final class SpeedV2 {
    private SpeedV2() {}
    public record Horizontal(double x, double z) {}
    public static double factor(double power) {
        if (!Double.isFinite(power) || power <= 0) return 1;
        return 1 + 4 * Math.max(1, Math.min(100, power)) / 100.0;
    }
    public static Horizontal desired(double x, double z, double base, double power, double distanceLimit) {
        if (!Double.isFinite(x) || !Double.isFinite(z) || !Double.isFinite(base)
            || !Double.isFinite(distanceLimit) || base <= 0 || distanceLimit <= 0) return new Horizontal(0, 0);
        double length = Math.hypot(x, z);
        if (!Double.isFinite(length) || length < 1e-8) return new Horizontal(0, 0);
        double magnitude = Math.min(Math.min(base, 1.0) * factor(power), distanceLimit) * Math.min(1, length);
        return new Horizontal(x / length * magnitude, z / length * magnitude);
    }
    public static boolean prefer(double health, double distance, int id, double bestHealth, double bestDistance, int bestId) {
        if (!Double.isFinite(health) || health <= 0 || !Double.isFinite(distance) || distance < 0) return false;
        int c = Double.compare(health, bestHealth);
        return c < 0 || (c == 0 && (distance < bestDistance || (distance == bestDistance && id < bestId)));
    }
    /** Corrections latch until an explicit enable/resume; incoming velocity gets a quiet window. */
    public static final class State {
        private Object world, player;
        private boolean armed, bound, blocked;
        private long quietUntil;
        private String reason = "выключено";
        public void enable() { world = player = null; armed = true; bound = blocked = false; quietUntil = Long.MIN_VALUE; reason = "активен"; }
        public void disable() { armed = false; world = player = null; bound = blocked = false; reason = "выключено"; }
        public boolean armed() { return armed; }
        public String reason() { return reason; }
        public void correction() { if (armed) { blocked = true; reason = "сервер скорректировал позицию; /pv speedresume или выключить/включить Speed"; } }
        public void disconnect() { if (armed) { blocked = true; reason = "мир/сервер изменился; требуется повторное включение Speed"; } world = player = null; }
        public void velocity(long tick) { if (armed) { quietUntil = Math.max(quietUntil, tick + 10); reason = "обработка серверной скорости (10 тиков)"; } }
        public boolean ready(Object nextWorld, Object nextPlayer, long tick) {
            if (!armed || blocked) return false;
            if (nextWorld == null || nextPlayer == null) { disconnect(); return false; }
            if (!bound) { world = nextWorld; player = nextPlayer; bound = true; }
            else if (world != nextWorld || player != nextPlayer) { disconnect(); return false; }
            if (tick < quietUntil) return false;
            reason = "активен";
            return true;
        }
    }
}
