package pulse.n9ezz;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import pulse.settings.BooleanSetting;
import pulse.settings.SliderSetting;

/** Client acquisition plus visible physical alignment. No packet or server-box edits. */
public final class TargetV2Runtime {
    public static final BooleanSetting ALIGNMENT = new BooleanSetting("Доводка Triggerbot", "Если луч выбрал расширенную область, повернуть прицел к видимой точке настоящего тела. Удар — только после физического попадания.", true);
    public static final SliderSetting ALIGNMENT_TURN = new SliderSetting("Доводка за тик (°)", "Ограничение видимого поворота Triggerbot к настоящему хитбоксу. Расширение области само не увеличивает серверное попадание.",35,1,180,1);
    private TargetV2Runtime() {}
    public static class_238 box(class_1297 entity) {
        class_238 original=entity.method_5829();
        u3 hitboxes=N9Ezz.HITBOXES;
        var mc=class_310.method_1551();
        if (!(entity instanceof class_1657 candidate)||hitboxes==null||!hitboxes.isEnabled()||InterfaceMode.hidden()
                ||mc.field_1724==null||mc.field_1687==null||!d.m1(candidate)) return original;
        double limit=hitboxes.range.get();
        if(!Double.isFinite(limit)||limit<=0||d.m14(candidate)>Math.min(12,limit)
                ||hitboxes.onlyTarget.get()&&CombatTargets.tracked()!=candidate) return original;
        var scaled=TargetV2Math.expand(new TargetV2Math.Bounds(original.field_1323,original.field_1322,original.field_1321,
                original.field_1320,original.field_1325,original.field_1324),hitboxes.x.get(),hitboxes.y.get(),hitboxes.z.get(),hitboxes.effectivePower());
        return new class_238(scaled.minX(),scaled.minY(),scaled.minZ(),scaled.maxX(),scaled.maxY(),scaled.maxZ());
    }
    public static boolean mayAlign() {
        return N9Ezz.HITBOXES!=null&&N9Ezz.HITBOXES.isEnabled()&&!InterfaceMode.hidden()&&ALIGNMENT.get();
    }
    public static boolean align(class_1657 target, double attackRange) {
        var mc=class_310.method_1551();
        if(!mayAlign()||mc.field_1724==null||!d.m3(false)||!d.m21(target,true,true)
                ||!Double.isFinite(attackRange)||attackRange<=0||d.m14(target)>attackRange) return false;
        class_243 point=d.m18(target,1f,0,false),eye=mc.field_1724.method_33571();
        if(!d.m19(point)) return false;
        double dx=point.field_1352-eye.field_1352,dy=point.field_1351-eye.field_1351,dz=point.field_1350-eye.field_1350;
        if(!CombatRules6.meaningfulDirection(dx,dy,dz))return false;
        double yaw=Math.toDegrees(Math.atan2(dz,dx))-90,pitch=-Math.toDegrees(Math.atan2(dy,Math.hypot(dx,dz)));
        mc.field_1724.method_36456(TargetV2Math.turn(mc.field_1724.method_36454(),yaw,ALIGNMENT_TURN.get(),false));
        mc.field_1724.method_36457(TargetV2Math.turn(mc.field_1724.method_36455(),pitch,ALIGNMENT_TURN.get(),true));
        // Only the ordinary physical ray can authorize the later attack. A selected
        // expanded box is an invitation to align, never proof of a server hit.
        return d.m28(attackRange,false)==target;
    }
}
