package pulse.n9ezz;

import java.util.Arrays;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_1268;
import pulse.settings.BooleanSetting;
import pulse.settings.SliderSetting;

/** New aura selector, rotation controller and scheduler. Transport remains the native attack pipeline. */
public final class AuraController {
    public final BooleanSetting airCritOnly = new BooleanSetting("В воздухе только криты", "При подъёме удар ждёт настоящего падения и заряда выше 90%; на земле действует обычный порог заряда.", true);
    public final BooleanSetting doubleAttack = new BooleanSetting("Второй удар сразу", "После первого отправленного удара повторить обычную атаку по той же цели без повторной проверки заряда. Дополнительный урон сервером не гарантируется.", false);
    public final BooleanSetting fastRotation = new BooleanSetting("Быстрый поворот", "Сразу повернуться к боковой или задней цели в пределах заданного угла за тик. Поворот виден в обычном движении клиента.", true);
    public final SliderSetting maxTurn = new SliderSetting("Поворот за тик (°)", "Верхняя граница поворота камеры за 50 мс. Не изменяет серверные правила попадания.", 180, 1, 180, 1);
    public final SliderSetting jitterMs = new SliderSetting("Jitter задержки (мс)", "Случайная добавочная задержка 0–N мс между попытками. Таймер применяется только к атакам, без задержки ответов серверу.", 0, 0, 100, 1);
    private static AuraController current;
    private final u0 module;
    private final c clock = new c();
    private final b misses = new b();
    private final AuraSchedule schedule = new AuraSchedule();
    private class_1657 target;
    private Object world, player;
    private long acquiredAt, lastRotation, manualUntil;
    private float expectedYaw, expectedPitch;
    private boolean observed;

    public AuraController(u0 module) { this.module = module; current = this; }
    public class_1657 target() { return target; }
    public void reset() {
        target = null; world = player = null; acquiredAt = lastRotation = manualUntil = 0;
        observed = false; clock.m0(); misses.m0(); schedule.reset(); e.m2();
    }
    private void clearTarget() {
        target = null; acquiredAt = 0; lastRotation = manualUntil = 0; observed = false; e.m2();
        // Do not reset the attack clock on a brief occlusion or target change: doing so
        // erased the preceding attempt's interval and made target switching inconsistent.
    }
    private boolean active() { return module.isEnabled() && module.powered() && !InterfaceMode.hidden(); }
    public boolean controlsView() {
        return active() && target != null && !"Без поворота".equals(module.rotation.selectedValue());
    }
    private boolean eligible(class_1657 candidate, double range, boolean shared) {
        if (!d.m21(candidate, module.invisible.get(), module.unarmored.get()) || !d.m20(candidate, false)) return false;
        double distance = d.m14(candidate);
        if (!Double.isFinite(distance) || distance > range) return false;
        return shared || AuraRules.withinFov(d.m13(candidate, false), module.fov.get());
    }
    private class_1657 acquire(double attackRange) {
        if (CombatSession.juggernaut()) {
            class_1657 shared = CombatSession.target();
            return shared != null && eligible(shared, 12, true) ? shared : null;
        }
        if (module.lockTarget.get() && target != null && eligible(target, attackRange, false)) return target;
        int priority = Arrays.asList(module.priority.values()).indexOf(module.priority.selectedValue());
        class_1657 best = null; double bestScore = Double.POSITIVE_INFINITY;
        // One explicit user FOV governs acquisition. The old hidden power-dependent
        // second cone excluded side/back targets even when the FOV slider read 360°.
        for (class_1657 candidate : class_310.method_1551().field_1687.method_18456()) {
            if (!eligible(candidate, attackRange, false)) continue;
            double score = CombatRules.targetScore(priority, d.m14(candidate), candidate.method_6032() + candidate.method_6067(), candidate.method_6096(), d.m13(candidate, false));
            if (Double.isFinite(score) && score < bestScore) { best = candidate; bestScore = score; }
        }
        return best;
    }
    public void tick() {
        class_310 mc = class_310.method_1551();
        if (!active() || !d.m3(false)) { clearTarget(); return; }
        if (world != mc.field_1687 || player != mc.field_1724) {
            reset(); world = mc.field_1687; player = mc.field_1724;
        }
        double attackRange = d.m15(module.range.get());
        if (!Double.isFinite(attackRange) || attackRange <= 0) { clearTarget(); return; }
        long now = System.nanoTime(); class_1657 next = acquire(attackRange);
        if (next != target) {
            target = next; acquiredAt = now; e.m2();
            // A new target does not consume a tick merely to initialize the old easing object.
            lastRotation = 0; observed = false;
        }
        if (target == null) return;
        rotate(now, 1f);
        if (now - acquiredAt < Math.max(0, module.confirmation.get()) * 1_000_000d) return;
        if (d.m14(target) > attackRange) return; // Juggernaut may track a player outside attack reach.
        int cps = PowerCurve.cps(module.cps.roundedInt(), module.strength());
        if (!schedule.ready(now, cps) || d.m28(attackRange, false) != target) return;
        // e.m7 validates the real player state; e.m8 revalidates after this tick's native
        // movement/rotation, weapon and target. No extra look/movement packet is sent here.
        e.m7(target, clock, misses, new Attacks$Options(cps,
                Arrays.asList(module.speed.values()).indexOf(module.speed.selectedValue()),
                module.miss.roundedInt(), module.cooldown.get(), module.range.get(),
                module.weaponsOnly.get(), false, module.resetSprint.get() && airCritOnly.get(), false));
    }
    public void frame(long now, float progress) {
        if (controlsView() && d.m3(false) && d.m21(target, module.invisible.get(), module.unarmored.get())) rotate(now, progress);
    }
    private void rotate(long now, float progress) {
        if (!controlsView()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        float yaw = mc.field_1724.method_36454(), pitch = mc.field_1724.method_36455();
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) return;
        if (observed && (Math.abs(AuraRules.wrap(yaw - expectedYaw)) > .001 || Math.abs(pitch - expectedPitch) > .001))
            manualUntil = now + Math.max(0, module.manualOverride.roundedInt()) * 1_000_000L;
        expectedYaw = yaw; expectedPitch = pitch; observed = true;
        double seconds = lastRotation == 0 ? .05 : Math.max(0, Math.min(.05, (now - lastRotation) / 1e9));
        lastRotation = now;
        if (now < manualUntil || seconds == 0) return;
        class_243 point = d.m18(target, progress, 0, false), eye = mc.field_1724.method_33571();
        double dx = point.field_1352 - eye.field_1352, dy = point.field_1351 - eye.field_1351, dz = point.field_1350 - eye.field_1350;
        if (!CombatRules6.meaningfulDirection(dx, dy, dz)) return;
        double desiredYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90;
        double desiredPitch = -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        double smoothing = fastRotation.get() ? 1 : 1 - .9 * Math.max(0, Math.min(100, module.smoothing.get())) / 100;
        double limit = Math.max(1, Math.min(180, maxTurn.get())) * seconds / .05 * smoothing;
        expectedYaw = AuraRules.turn(yaw, desiredYaw, limit, false);
        expectedPitch = AuraRules.turn(pitch, desiredPitch, limit, true);
        mc.field_1724.method_36456(expectedYaw); mc.field_1724.method_36457(expectedPitch);
    }
    public static boolean attackAllowed(boolean grounded, double verticalVelocity, double fallDistance,
            float charge, int restrictions, boolean sprinting, boolean pendingSprintReset) {
        AuraController aura = current;
        boolean critOnly = aura == null || !aura.active() || aura.airCritOnly.get();
        return AuraRules.attackAllowed(critOnly, grounded, verticalVelocity, fallDistance, charge, restrictions, sprinting, pendingSprintReset);
    }
    public static void attempted(class_1657 target, long now) {
        AuraController aura = current;
        if (aura != null && aura.active() && aura.target == target) aura.schedule.attempted(now, aura.jitterMs.roundedInt());
    }
    /** Called only after the first native attack AND swing succeeded, never by the polling scheduler. */
    public static int afterAttack(class_1657 source, class_1657 attacked) {
        AuraController aura = current;
        if (aura == null || !aura.active() || !aura.doubleAttack.get() || aura.target != attacked) return 0;
        // Explicitly no second charge/ray/critical readiness test: the user's optional repeat
        // uses the same player and target, the same ordinary attack path, then one ordinary swing.
        class_310.method_1551().field_1761.method_2918(source, attacked);
        source.method_6104(class_1268.field_5808);
        return 1;
    }
}
