package pulse.n9ezz;

import java.util.Arrays;

/** The requested combat + visual module policy, shared by registration, saved state and UI. */
public final class ModuleRules6 {
    private ModuleRules6() {}

    public static boolean allowed(Object module) {
        if (module == null) return false;
        // Use identity of the implementation, not a translated/configurable display name.
        // Legacy instances remain available for binary references but cannot be activated.
        return switch (module.getClass().getName()) {
            case "pulse.modules.visuals.AspectRatio", "pulse.modules.utilities.Optimization", "pulse.modules.visuals.MotionBlur", "pulse.n9ezz.u0", "pulse.n9ezz.u1", "pulse.n9ezz.u2",
                 "pulse.n9ezz.u3", "pulse.n9ezz.u4", "pulse.n9ezz.u5", "pulse.n9ezz.u20" -> true;
            default -> false;
        };
    }

    public static boolean state(boolean requested, Object module) {
        return requested && allowed(module);
    }

    public static Object[] retain(Object[] modules) {
        // Arrays.copyOf preserves the runtime component type for the original API cast.
        Object[] result = Arrays.copyOf(modules, modules.length);
        int count = 0;
        for (Object module : modules) if (allowed(module)) result[count++] = module;
        return Arrays.copyOf(result, count);
    }

    public static double strength(double percent) {
        // Normalize the slider; the visible selected power level is applied by PowerCurve.
        // Invalid restored settings stop the feature instead of producing NaN timings.
        return Double.isFinite(percent) ? Math.max(0, Math.min(100, percent)) / 100 : 0;
    }
}
