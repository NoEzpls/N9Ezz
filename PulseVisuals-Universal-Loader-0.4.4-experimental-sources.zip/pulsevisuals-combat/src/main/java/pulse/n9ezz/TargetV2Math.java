package pulse.n9ezz;

/** Finite acquisition geometry, separate from the physical ray used to attack. */
public final class TargetV2Math {
    private TargetV2Math() {}
    public record Bounds(double minX,double minY,double minZ,double maxX,double maxY,double maxZ) {}
    public static double scale(double requested, double power) {
        if (!Double.isFinite(requested) || !Double.isFinite(power)) return 1;
        return Math.min(10, 1 + (Math.max(1,Math.min(5,requested))-1) * Math.max(0,Math.min(1000,power))/100);
    }
    public static Bounds expand(Bounds physical, double x, double y, double z, double power) {
        double cx=(physical.minX()+physical.maxX())*.5, cz=(physical.minZ()+physical.maxZ())*.5;
        double hx=(physical.maxX()-physical.minX())*.5*scale(x,power);
        double hz=(physical.maxZ()-physical.minZ())*.5*scale(z,power);
        double height=(physical.maxY()-physical.minY())*scale(y,power);
        if (!Double.isFinite(cx)||!Double.isFinite(cz)||!Double.isFinite(hx)||!Double.isFinite(hz)
                ||!Double.isFinite(height)||hx<0||hz<0||height<0) return physical;
        // Anchor the bottom to the physical feet. Symmetric vertical expansion used
        // to put acquisition volume through the floor; that area cannot produce a hit.
        return new Bounds(cx-hx,physical.minY(),cz-hz,cx+hx,physical.minY()+height,cz+hz);
    }
    public static float turn(float current,double desired,double maximum,boolean pitch) {
        if (!Float.isFinite(current)||!Double.isFinite(desired)||!Double.isFinite(maximum)) return current;
        double delta=(desired-current)%360;
        if(delta>=180)delta-=360; if(delta< -180)delta+=360;
        double limit=Math.max(0,Math.min(180,maximum));
        double result=current+Math.max(-limit,Math.min(limit,delta));
        return (float)(pitch?Math.max(-90,Math.min(90,result)):result);
    }
}
