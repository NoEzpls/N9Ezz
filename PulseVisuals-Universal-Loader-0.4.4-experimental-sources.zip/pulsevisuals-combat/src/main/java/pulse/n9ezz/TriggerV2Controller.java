package pulse.n9ezz;

import java.util.Arrays;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import pulse.settings.SliderSetting;

/** Triggerbot acquisition and physical commit are distinct; brief misses keep attack pacing. */
public final class TriggerV2Controller {
    public final SliderSetting retainMs = new SliderSetting("Память цели (мс)", "Короткий выход прицела не запускает подтверждение той же цели заново. Пока луч не вернулся, ударов нет.",150,0,500,10);
    private final u1 module;
    private final c clock=new c();
    private final b misses=new b();
    private Object world,actor;
    private class_1657 current;
    private UUID watched;
    private long acquiredAt,lastSeen;
    public TriggerV2Controller(u1 module){this.module=module;}
    public class_1657 target(){return current;}
    public void reset(){current=null;watched=null;world=actor=null;acquiredAt=lastSeen=0;clock.m0();misses.m0();e.m2();}
    private void miss(long now){
        current=null;e.m2();
        // Keep the clock: clearing it here erased the preceding attempt's interval.
        // Confirmation memory is separate, bounded, and never permits an off-ray hit.
        double grace=retainMs.get();
        if(!Double.isFinite(grace)||now-lastSeen>Math.max(0,Math.min(500,grace))*1_000_000d){watched=null;acquiredAt=0;}
    }
    public void tick(){tick(System.nanoTime());}
    /** Exposed for deterministic behavior tests; production tick supplies monotonic time. */
    public void tick(long now){
        var mc=class_310.method_1551();
        if(mc.field_1687!=world||mc.field_1724!=actor){reset();world=mc.field_1687;actor=mc.field_1724;}
        if(!module.isEnabled()||!module.powered()||InterfaceMode.hidden()){reset();return;}
        if(!d.m3(false)){miss(now);return;}
        double range=d.m15(module.range.get());
        if(!Double.isFinite(range)||range<=0){miss(now);return;}
        boolean expanded=!module.exactHit.get();
        class_1657 found=d.m27(range,expanded);
        // Shared mode cannot silently attack a different player that crosses the ray.
        if(CombatSession.juggernaut()&&found!=CombatSession.target())found=null;
        if(found==null||!d.m21(found,module.invisible.get(),module.unarmored.get())||d.m14(found)>range){miss(now);return;}
        current=found;lastSeen=now;
        UUID id=found.method_5667();
        if(!id.equals(watched)){watched=id;acquiredAt=now;e.m2();}
        if(d.m28(range,false)!=found&&(!expanded||!TargetV2Runtime.align(found,range)))return;
        double confirmation=module.confirmation.get();
        if(!Double.isFinite(confirmation)||now-acquiredAt<Math.max(0,confirmation)*1_000_000d)return;
        // Use the normal native attack dispatcher, after visible alignment; no forged
        // onGround or movement packets and no expanded final-hit acceptance.
        e.m7(found,clock,misses,new Attacks$Options(module.effectiveCps(),
                Arrays.asList(module.speed.values()).indexOf(module.speed.selectedValue()),module.miss.roundedInt(),
                module.cooldown.get(),module.range.get(),module.weaponsOnly.get(),false,module.resetSprint.get(),false));
    }
}
