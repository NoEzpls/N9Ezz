import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import javax.tools.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/**
 * Headless tests of actual patched methods against minimal Minecraft fixtures.
 * These are not a Minecraft launch, wire capture, server damage test or bypass claim.
 */
public final class CombatTest implements Opcodes {
    private static int checks;
    private static void check(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }
    private static byte[] bytes(Path jar, String name) throws Exception {
        try (JarFile j = new JarFile(jar.toFile())) {
            var e = j.getJarEntry(name + ".class");
            if (e == null) throw new AssertionError("Missing " + name);
            return j.getInputStream(e).readAllBytes();
        }
    }
    private static ClassNode node(byte[] bytes) { ClassNode n = new ClassNode(); new ClassReader(bytes).accept(n, ClassReader.EXPAND_FRAMES); return n; }
    private static MethodNode method(ClassNode c, String name) { return c.methods.stream().filter(m -> m.name.equals(name)).findFirst().orElseThrow(); }
    private static boolean calls(MethodNode m, String owner, String name) {
        for (var i : m.instructions) if (i instanceof MethodInsnNode c && c.owner.equals(owner) && c.name.equals(name)) return true;
        return false;
    }
    private static AbstractInsnNode previous(AbstractInsnNode n) { do { n = n.getPrevious(); } while (n != null && n.getOpcode() < 0); return n; }
    private static byte[] encoded(ClassNode c) { ClassWriter w = new ClassWriter(0); c.accept(w); return w.toByteArray(); }
    private static byte[] select(byte[] bytes, String... methods) {
        ClassNode c = node(bytes); Set<String> keep = Set.of(methods);
        c.methods.removeIf(m -> !keep.contains(m.name)); c.fields.clear(); c.innerClasses.clear(); c.nestMembers = null;
        c.visibleAnnotations = null; c.invisibleAnnotations = null; return encoded(c);
    }
    private static byte[] damagePrefix(byte[] bytes) {
        ClassNode c = node(bytes); c.methods.removeIf(m -> !Set.of("<init>", "tick").contains(m.name));
        c.fields.removeIf(f -> !Set.of("localPlayerId", "localBonus", "DAMAGE").contains(f.name));
        MethodNode m = method(c, "tick"); AbstractInsnNode end = null;
        for (var i : m.instructions) if (i instanceof FieldInsnNode f && f.getOpcode() == PUTSTATIC && f.name.equals("localBonus")) { end = i; break; }
        if (end == null) throw new AssertionError("Damage assignment not found");
        while (end.getNext() != null) m.instructions.remove(end.getNext());
        m.instructions.add(new InsnNode(RETURN)); m.localVariables = null; m.tryCatchBlocks.clear();
        m.visibleAnnotations = null; m.invisibleAnnotations = null; return encoded(c);
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("CombatTest baseline.jar updated.jar");
        Path oldJar = Path.of(args[0]), newJar = Path.of(args[1]);
        for (String n : List.of("ru/pulse/mixin/ClientConnectionMixin", "pulse/n9ezz/mixin/CombatEntityMixin", "pulse/n9ezz/CombatDispatch", "pulse/n9ezz/NetworkPacketPolicy", "pulse/n9ezz/mixin/PlayerDamageMixin"))
            check(Arrays.equals(bytes(oldJar, n), bytes(newJar, n)), "Preserved class " + n);
        for (String n : List.of("pulse/n9ezz/e", "pulse/n9ezz/d", "pulse/n9ezz/u0", "pulse/n9ezz/u1", "pulse/n9ezz/u5", "pulse/n9ezz/N9Ezz", "pulse/n9ezz/ViewMotion", "pulse/n9ezz/mixin/ProjectileTargetMixin")) {
            ClassNode c = node(bytes(newJar, n));
            for (MethodNode m : c.methods) if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0) new Analyzer<>(new BasicVerifier()).analyze(c.name, m);
            check(true, "ASM dataflow " + n);
        }
        ClassNode attacks = node(bytes(newJar, "pulse/n9ezz/e"));
        check(calls(method(attacks, "m7"), attacks.name, "m6"), "Queue executes common validity gate");
        check(calls(method(attacks, "m8"), attacks.name, "m6"), "Flush executes common validity gate");
        check(calls(method(attacks, "m6"), attacks.name, "n9ezz$automaticAttackAllowed"), "Validity includes actual player state");
        check(calls(method(attacks, "m8"), attacks.name, "n9ezz$automaticAttackAllowed"), "Final sprint state independently checked");
        int rays = 0;
        for (var i : method(attacks, "m8").instructions) if (i instanceof MethodInsnNode m && m.owner.equals("pulse/n9ezz/d") && m.name.equals("m28")) {
            check(previous(i).getOpcode() == ICONST_0 && previous(previous(i)).getOpcode() == POP, "Final ray always physical"); rays++;
        }
        check(rays == 1, "Exactly one final attack ray");
        MethodNode point = method(node(bytes(newJar, "pulse/n9ezz/d")), "m18");
        var first = point.instructions.getFirst(); while (first.getOpcode() < 0) first = first.getNext();
        check(first.getOpcode() == ICONST_0 && first.getNext() instanceof VarInsnNode v && v.getOpcode() == ISTORE && v.var == 3, "Aim uses physical box even for expanded acquisition");
        MethodNode ctor = method(node(bytes(newJar, "pulse/n9ezz/u5")), "<init>"); boolean slider = false;
        for (var i : ctor.instructions) if (i instanceof MethodInsnNode c && c.owner.equals("pulse/settings/SliderSetting") && c.name.equals("<init>")) {
            check(previous(previous(i)) instanceof LdcInsnNode l && Float.valueOf(8).equals(l.cst), "Damage slider maximum 8"); slider = true;
        }
        check(slider, "Damage slider found");
        for (String name : List.of("pulse/n9ezz/u0", "pulse/n9ezz/u1")) {
            MethodNode settings = method(node(bytes(newJar, name)), "<init>");
            for (String key : List.of("Заряд удара (%)", "Отпускать свой щит", "Обычное попадание")) {
                int found = 0;
                for (AbstractInsnNode i : settings.instructions) if (i instanceof LdcInsnNode l && key.equals(l.cst)) {
                    check(i.getNext() instanceof LdcInsnNode tooltip && tooltip.cst instanceof String
                            && ((String)tooltip.cst).length() > 50, name + " explains strict policy for " + key);
                    found++;
                }
                check(found == 1, name + " preserves legacy profile key " + key);
            }
            boolean factualCps = false;
            for (AbstractInsnNode i : settings.instructions) if (i instanceof LdcInsnNode l && l.cst instanceof String s) {
                check(!s.contains("Уровень и мощность меняют его до 20"), name + " removes obsolete level multiplier claim");
                factualCps |= s.contains("Автоудар всегда ждёт полного заряда оружия");
            }
            check(factualCps, name + " CPS is an upper limit with full charge");
        }

        Path temp = Files.createTempDirectory("n9ezz-combat-fixtures-");
        try {
            Path classes = temp.resolve("classes"); compileFixtures(temp.resolve("src"), classes);
            Map<String, byte[]> actual = new HashMap<>();
            actual.put("pulse.n9ezz.e", select(bytes(newJar, "pulse/n9ezz/e"), "n9ezz$automaticAttackAllowed"));
            actual.put("pulse.n9ezz.N9Ezz", damagePrefix(bytes(newJar, "pulse/n9ezz/N9Ezz")));
            actual.put("pulse.n9ezz.mixin.ProjectileTargetMixin", select(bytes(newJar, "pulse/n9ezz/mixin/ProjectileTargetMixin"), "n9ezz$targetBox"));
            for (String n : List.of("CombatRules6", "ViewMotion", "AimSmoothing", "AimSmoothing$Turn", "PvPMath", "a")) actual.put("pulse.n9ezz." + n, bytes(newJar, "pulse/n9ezz/" + n));
            try (URLClassLoader loader = new URLClassLoader(new URL[]{classes.toUri().toURL()}, ClassLoader.getPlatformClassLoader()) {
                @Override protected Class<?> findClass(String n) throws ClassNotFoundException {
                    byte[] b = actual.get(n); return b == null ? super.findClass(n) : defineClass(n, b, 0, b.length);
                }
            }) {
                attackFixtures(loader); cameraFixtures(loader); damageFixtures(loader); manualFixture(loader);
            }
        } finally { try (var walk = Files.walk(temp)) { for (Path p : walk.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); } }
        System.out.println("CombatTest PASS: " + checks + " checks; actual patched method fixtures + dataflow; game/server execution not performed");
    }
    private static Object make(ClassLoader l, String name) throws Exception { return l.loadClass(name).getConstructor().newInstance(); }
    private static void set(Object o, String field, Object value) throws Exception { o.getClass().getField(field).set(o, value); }
    private static Object get(Object o, String field) throws Exception { return o.getClass().getField(field).get(o); }
    private static Object client(ClassLoader l) throws Exception { return l.loadClass("net.minecraft.class_310").getMethod("method_1551").invoke(null); }
    private static Object player(ClassLoader l) throws Exception { Object p = make(l, "net.minecraft.class_746"); set(client(l), "field_1724", p); return p; }
    private static void attackFixtures(ClassLoader l) throws Exception {
        Method ready = l.loadClass("pulse.n9ezz.e").getDeclaredMethod("n9ezz$automaticAttackAllowed", boolean.class); ready.setAccessible(true);
        Object p = player(l); check((boolean)ready.invoke(null, false), "Ground, full charge permits ordinary attack");
        set(p, "sprinting", true); check((boolean)ready.invoke(null, false), "Ground sprint does not manufacture a critical");
        for (float charge : new float[]{0, .5f, .9f, .999f, Float.NaN, Float.POSITIVE_INFINITY}) {
            p = player(l); set(p, "charge", charge); check(!(boolean)ready.invoke(null, false), "Low/invalid charge rejected " + charge);
        }
        p = player(l); set(p, "using", true); check(!(boolean)ready.invoke(null, false), "Food/shield/item use preserved");
        p = player(l); set(p, "grounded", false); set(p, "field_6017", .2); set(get(p, "velocity"), "field_1351", .1);
        check(!(boolean)ready.invoke(null, false), "Ascending with stale fallDistance cannot attack");
        set(get(p, "velocity"), "field_1351", 0d); check(!(boolean)ready.invoke(null, false), "Apex cannot attack");
        set(get(p, "velocity"), "field_1351", -.1); check((boolean)ready.invoke(null, false), "Falling valid critical allowed");
        set(p, "field_6017", 0d); check(!(boolean)ready.invoke(null, false), "Descending without fallDistance rejected");
        set(p, "field_6017", .2); set(p, "sprinting", true);
        check((boolean)ready.invoke(null, true), "Pending ordinary sprint reset may be queued");
        check(!(boolean)ready.invoke(null, false), "Final still-sprinting critical rejected");
        for (String restriction : List.of("using", "climbing", "water", "lava", "blind", "riding", "gliding")) {
            p = player(l); set(p, "grounded", false); set(p, "field_6017", .2); set(get(p, "velocity"), "field_1351", -.1); set(p, restriction, true);
            check(!(boolean)ready.invoke(null, false), "Critical prohibited: " + restriction);
        }
        p = player(l); set(p, "grounded", false); set(p, "field_6017", .2); set(get(p, "velocity"), "field_1351", -.1); set(get(p, "abilities"), "field_7479", true);
        check(!(boolean)ready.invoke(null, false), "Creative flight cannot make a critical");
        p = player(l); set(get(p, "velocity"), "field_1351", Double.NaN); check(!(boolean)ready.invoke(null, false), "Non-finite physics fails closed");
        set(client(l), "field_1724", null); check(!(boolean)ready.invoke(null, false), "Disconnect null player fails closed");
    }
    private static void cameraFixtures(ClassLoader l) throws Exception {
        Object p = player(l); set(p, "yaw", 37f); set(p, "pitch", 11f);
        Object motion = make(l, "pulse.n9ezz.ViewMotion"); Class<?> vector = l.loadClass("net.minecraft.class_243");
        Method frame = motion.getClass().getMethod("frame", vector, long.class, float.class, double.class, double.class, int.class);
        Object zero = vector.getConstructor().newInstance();
        frame.invoke(motion, zero, 1_000_000_000L, 1f, 100d, 50d, 0);
        frame.invoke(motion, zero, 1_016_000_000L, 1f, 100d, 50d, 0);
        check(((Number)get(p, "yaw")).floatValue() == 37 && ((Number)get(p, "pitch")).floatValue() == 11, "Coincident aim leaves view unchanged");
        check(((Number)get(p, "rotations")).intValue() == 0, "Coincident aim sends no rotation setters");
        Object bad = vector.getConstructor().newInstance(); set(bad, "field_1352", Double.NaN);
        frame.invoke(motion, bad, 1_032_000_000L, 1f, 100d, 50d, 0);
        frame.invoke(motion, bad, 1_048_000_000L, 1f, 100d, 50d, 0);
        check(((Number)get(p, "rotations")).intValue() == 0, "Non-finite aim leaves camera unchanged");
        Object point = vector.getConstructor().newInstance(); set(point, "field_1350", 2d);
        frame.invoke(motion, point, 1_064_000_000L, 1f, 100d, 50d, 0);
        frame.invoke(motion, point, 1_080_000_000L, 1f, 100d, 50d, 0);
        check(((Number)get(p, "rotations")).intValue() > 0, "Valid aim still updates camera");
    }
    private static void damageFixtures(ClassLoader l) throws Exception {
        Class<?> main = l.loadClass("pulse.n9ezz.N9Ezz"); Constructor<?> ctor = main.getDeclaredConstructor(); ctor.setAccessible(true); Object n = ctor.newInstance();
        Method tick = main.getMethod("tick", l.loadClass("pulse.events.ClientTickEvent"));
        Object damage = make(l, "pulse.n9ezz.u5"); main.getField("DAMAGE").set(null, damage);
        Object mc = client(l); player(l); set(get(damage, "extra"), "value", 8f); set(damage, "strength", 10d);
        set(mc, "server", null); tick.invoke(n, new Object[]{null}); check(main.getField("localBonus").getDouble(null) == 0, "Remote server always zero local bonus");
        set(mc, "server", make(l, "net.minecraft.class_1132")); tick.invoke(n, new Object[]{null}); check(main.getField("localBonus").getDouble(null) == 8, "Integrated bonus capped AFTER scaling");
        set(damage, "strength", .5d); tick.invoke(n, new Object[]{null}); check(main.getField("localBonus").getDouble(null) == 4, "Integrated bonus preserves proportion");
        set(damage, "enabled", false); tick.invoke(n, new Object[]{null}); check(main.getField("localBonus").getDouble(null) == 0, "Disabled damage gives zero");
        set(damage, "enabled", true); set(damage, "strength", Double.NaN); tick.invoke(n, new Object[]{null}); check(main.getField("localBonus").getDouble(null) == 0, "Invalid bonus fails closed");
        set(mc, "field_1724", null); tick.invoke(n, new Object[]{null}); check(main.getField("localBonus").getDouble(null) == 0, "Disconnect clears bonus");
    }
    private static void manualFixture(ClassLoader l) throws Exception {
        Object entity = make(l, "net.minecraft.class_1297"); Class<?> c = l.loadClass("pulse.n9ezz.mixin.ProjectileTargetMixin");
        Method m = c.getDeclaredMethod("n9ezz$targetBox", entity.getClass()); m.setAccessible(true);
        check(m.invoke(null, entity) == get(entity, "box"), "Manual pick returns the identical physical box");
    }
    private static void compileFixtures(Path src, Path out) throws Exception {
        Map<String, String> files = new LinkedHashMap<>();
        files.put("net.minecraft.class_238", "public class class_238 {}");
        files.put("net.minecraft.class_1297", "public class class_1297 { public class_238 box=new class_238(); public class_238 method_5829(){return box;} }");
        files.put("net.minecraft.class_1657", "public class class_1657 extends class_1297 {}");
        files.put("net.minecraft.class_1656", "public class class_1656 { public boolean field_7479; }");
        files.put("net.minecraft.class_243", "public class class_243 { public double field_1352,field_1351,field_1350; public class_243 method_1020(class_243 p){class_243 d=new class_243();d.field_1352=field_1352-p.field_1352;d.field_1351=field_1351-p.field_1351;d.field_1350=field_1350-p.field_1350;return d;} }");
        files.put("net.minecraft.class_746", """
                public class class_746 extends class_1657 {
                  public boolean grounded=true,using,climbing,water,lava,blind,riding,gliding,sprinting;
                  public float charge=1,yaw,pitch; public double field_6017; public int rotations;
                  public class_243 velocity=new class_243(); public class_1656 abilities=new class_1656();
                  public boolean method_24828(){return grounded;} public boolean method_6115(){return using;}
                  public boolean method_6101(){return climbing;} public boolean method_5799(){return water;}
                  public boolean method_5771(){return lava;} public boolean method_74025(){return blind;}
                  public boolean method_5765(){return riding;} public boolean method_6128(){return gliding;}
                  public boolean method_5624(){return sprinting;} public class_1656 method_31549(){return abilities;}
                  public class_243 method_18798(){return velocity;} public float method_7261(float p){return charge;}
                  public float method_36454(){return yaw;} public float method_36455(){return pitch;}
                  public class_243 method_5836(float p){return new class_243();}
                  public void method_36456(float v){yaw=v;rotations++;} public void method_36457(float v){pitch=v;rotations++;}
                  public java.util.UUID method_5667(){return new java.util.UUID(0,1);}
                }
                """);
        files.put("net.minecraft.class_437", "public class class_437 {}");
        files.put("net.minecraft.class_1132", "public class class_1132 {}");
        files.put("net.minecraft.class_7172", "public class class_7172 { public Object method_41753(){return Double.valueOf(.5);} }");
        files.put("net.minecraft.class_315", "public class class_315 { public class_7172 method_42495(){return new class_7172();} }");
        files.put("net.minecraft.class_310", "public class class_310 { private static final class_310 INSTANCE=new class_310(); public class_746 field_1724; public class_437 field_1755; public class_315 field_1690=new class_315(); public class_1132 server; public static class_310 method_1551(){return INSTANCE;} public class_1132 method_1576(){return server;} }");
        files.put("pulse.gui.core.PulseClickGuiScreen", "public class PulseClickGuiScreen extends net.minecraft.class_437 {}");
        files.put("pulse.n9ezz.Stars", "public class Stars { public static void menuClosed(){} }");
        files.put("pulse.events.ClientTickEvent", "public class ClientTickEvent {}");
        files.put("pulse.settings.SliderSetting", "public class SliderSetting { public float value; public float get(){return value;} }");
        files.put("pulse.n9ezz.u5", "public class u5 {public boolean enabled=true;public double strength=1;public pulse.settings.SliderSetting extra=new pulse.settings.SliderSetting();public boolean isEnabled(){return enabled;}public double strength(){return strength;}}");
        List<File> inputs = new ArrayList<>(); Files.createDirectories(out);
        for (var e : files.entrySet()) {
            String name = e.getKey(); Path p = src.resolve(name.replace('.', '/') + ".java"); Files.createDirectories(p.getParent());
            Files.writeString(p, "package " + name.substring(0, name.lastIndexOf('.')) + ";\n" + e.getValue()); inputs.add(p.toFile());
        }
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler(); if (compiler == null) throw new IllegalStateException("Full JDK required for fixture compilation");
        try (var fm = compiler.getStandardFileManager(null, Locale.ROOT, java.nio.charset.StandardCharsets.UTF_8)) {
            check(compiler.getTask(null, fm, null, List.of("--release", "21", "-proc:none", "-classpath", out.toString(), "-d", out.toString()), null, fm.getJavaFileObjectsFromFiles(inputs)).call(), "Fixture compilation");
        }
    }
}
