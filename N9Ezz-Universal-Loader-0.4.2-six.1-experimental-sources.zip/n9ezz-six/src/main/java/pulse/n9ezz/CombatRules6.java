package pulse.n9ezz;

/** Pure predicates used by the six-module patch; no network or game state mutations. */
public final class CombatRules6 {
    private CombatRules6() {}

    /**
     * Bit 0 means an item is in use. Other bits describe states that prohibit a critical:
     * climbing, water, lava, blindness, riding, gliding and creative flight.
     * Ground attacks remain ordinary attacks. Air attacks must be real, fully charged
     * falling attacks; being airborne alone is never enough. A pending request may
     * wait for an ordinary input sprint reset, but the final check must pass false.
     */
    public static boolean automaticAttackAllowed(boolean grounded, double verticalSpeed,
            double fallDistance, float charge, int restrictions, boolean sprinting,
            boolean allowPendingSprintReset) {
        if (!Double.isFinite(verticalSpeed) || !Double.isFinite(fallDistance)
                || !Float.isFinite(charge) || charge < 1.0f || (restrictions & 1) != 0) return false;
        return grounded || (restrictions == 0 && verticalSpeed < 0 && fallDistance > 0
                && (!sprinting || allowPendingSprintReset));
    }

    /** Clamp AFTER applying power, so imported profiles cannot turn +8 into +80. */
    public static double localDamageBonus(double scaledBonus) {
        return Double.isFinite(scaledBonus) ? Math.max(0, Math.min(8, scaledBonus)) : 0;
    }

    /** A coincident aim point has no direction: atan2(0, 0) must not rotate the camera. */
    public static boolean meaningfulDirection(double x, double y, double z) {
        return Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z)
                && x * x + y * y + z * z > 1.0e-12;
    }
}
