package pulse.n9ezz;

import java.util.IdentityHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import pulse.settings.BooleanSetting;
import pulse.settings.SliderSetting;

/** Client acquisition plus visible physical alignment. No packet or server-box edits. */
public final class TargetV2Runtime {
    public static final BooleanSetting ALIGNMENT = new BooleanSetting("Доводка Triggerbot", "Выбрать расширенную область и довести прицел до доступной части настоящего тела. Проверяются несколько видимых точек; сам серверный хитбокс не меняется.", true);
    public static final SliderSetting ALIGNMENT_TURN = new SliderSetting("Доводка за тик (°)", "Максимальный видимый поворот Triggerbot за игровой тик. Расширение помогает выбрать цель, но не увеличивает разрешённую сервером дальность.",35,1,180,1);
    private static long selected,aligned;
    private static String reason="ожидание цели";
    private static Object alignmentWorld,alignmentPlayer;
    private static int alignmentTick=Integer.MIN_VALUE;
    private record CachedAim(TargetV2Math.Bounds bounds,TargetV2Math.Point eye,class_243 point) {}
    private static final IdentityHashMap<class_1657,CachedAim> AIM_CACHE=new IdentityHashMap<>();
    private static Object cacheWorld,cachePlayer;
    private static int cacheTick=Integer.MIN_VALUE;
    private TargetV2Runtime() {}
    private static TargetV2Math.Bounds bounds(class_238 box) {
        return new TargetV2Math.Bounds(box.field_1323,box.field_1322,box.field_1321,box.field_1320,box.field_1325,box.field_1324);
    }
    private static TargetV2Math.Point point(class_243 p) { return p==null?null:new TargetV2Math.Point(p.field_1352,p.field_1351,p.field_1350); }
    private static class_243 nativePoint(TargetV2Math.Point p) { return p==null?null:new class_243(p.x(),p.y(),p.z()); }
    public static String diagnostics() {
        return "Hitboxes: выборов области="+selected+", доводок до тела="+aligned+"; "+reason+"; "+HitboxV3.diagnostics()+" (клиентские проверки, не подтверждение урона)";
    }
    public static void reason(String message) { reason=message; }
    public static class_238 box(class_1297 entity) { return HitboxV3.volume(entity); }
    public static void selected() { selected++; reason="расширенная область выбрана"; }
    /** Shared by Aura, Trigger and the dispatch visibility gate. Never uses an expanded aim point. */
    public static class_243 aimPoint(class_1657 target,float progress,double range) {
        var mc=class_310.method_1551();
        if(mc.field_1724==null||mc.field_1687==null||!d.m1(target)||!Float.isFinite(progress))return null;
        var eye=point(mc.field_1724.method_33571());
        var physical=bounds(target.method_5829());
        if(cacheWorld!=mc.field_1687||cachePlayer!=mc.field_1724||cacheTick!=mc.field_1724.field_6012){
            AIM_CACHE.clear();cacheWorld=mc.field_1687;cachePlayer=mc.field_1724;cacheTick=mc.field_1724.field_6012;
        }
        CachedAim cached=AIM_CACHE.get(target);
        // Reuse only geometry from this tick, and ray-test its visibility again.
        // A changed block cannot authorize a stale hit, while repeated frame/queue
        // checks avoid scanning all body samples after finding an exposed shoulder.
        if(cached!=null&&cached.bounds.equals(physical)&&cached.eye.equals(eye)
                &&Double.isFinite(range)&&range>0&&TargetV2Math.distance(eye,point(cached.point))<=range
                &&d.m19(cached.point))return cached.point;
        var direction=TargetV2Math.direction(mc.field_1724.method_36454(),mc.field_1724.method_36455());
        // d.m18 is only a preference. Its interpolated/inset nearest point may be
        // obstructed or beyond reach while a shoulder/head/near face is usable.
        var preferred=point(d.m18(target,Math.max(0,Math.min(1,progress)),0,false));
        class_243 result=nativePoint(TargetV2Math.aim(physical,eye,preferred,direction,range,
                candidate->d.m19(nativePoint(candidate))));
        if(result!=null)AIM_CACHE.put(target,new CachedAim(physical,eye,result));else AIM_CACHE.remove(target);
        return result;
    }
    /** Legacy d.m20 ABI: visibility must not reject a whole body because one point is hidden. */
    public static boolean visible(class_1657 target,boolean expanded) {
        return aimPoint(target,1f,Double.MAX_VALUE)!=null;
    }
    public static boolean mayAlign() {
        return N9Ezz.HITBOXES!=null&&N9Ezz.HITBOXES.isEnabled()&&!InterfaceMode.hidden()&&ALIGNMENT.get();
    }
    /** Shared expanded-volume selector; final Trigger dispatch remains physical. */
    public static class_1657 acquire(double range,boolean expanded,boolean invisible,boolean unarmored) {
        return HitboxV3.acquire(range,expanded,invisible,unarmored);
    }
    public static boolean align(class_1657 target, double attackRange) {
        var mc=class_310.method_1551();
        if(!mayAlign()||mc.field_1724==null||!d.m3(false)||!d.m21(target,true,true)
                ||!Double.isFinite(attackRange)||attackRange<=0||d.m14(target)>attackRange) return false;
        if(d.m28(attackRange,false)==target)return true;
        class_243 aim=aimPoint(target,1f,attackRange),eye=mc.field_1724.method_33571();
        if(aim==null){reason="нет видимой физической точки в пределах дальности";return false;}
        // One rotation allowance per client tick, including multiple callbacks.
        // Repeated callbacks must not multiply the configured angular speed.
        if(alignmentWorld!=mc.field_1687||alignmentPlayer!=mc.field_1724){alignmentWorld=mc.field_1687;alignmentPlayer=mc.field_1724;alignmentTick=Integer.MIN_VALUE;}
        if(alignmentTick==mc.field_1724.field_6012)return false;
        alignmentTick=mc.field_1724.field_6012;
        double dx=aim.field_1352-eye.field_1352,dy=aim.field_1351-eye.field_1351,dz=aim.field_1350-eye.field_1350;
        if(!CombatRules6.meaningfulDirection(dx,dy,dz))return false;
        double yaw=Math.toDegrees(Math.atan2(dz,dx))-90,pitch=-Math.toDegrees(Math.atan2(dy,Math.hypot(dx,dz)));
        float beforeYaw=mc.field_1724.method_36454();
        float afterYaw=TargetV2Math.turn(beforeYaw,yaw,ALIGNMENT_TURN.get(),false);
        SpeedV2Runtime.viewTurn(beforeYaw,afterYaw);
        mc.field_1724.method_36456(afterYaw);
        mc.field_1724.method_36457(TargetV2Math.turn(mc.field_1724.method_36455(),pitch,ALIGNMENT_TURN.get(),true));
        // Selection is not permission to hit. Native physical ray, walls, reach
        // and the authoritative attack dispatcher are still checked after turning.
        boolean ready=d.m28(attackRange,false)==target;
        if(ready){aligned++;reason="наведение на настоящее тело завершено";}else reason="доводка продолжается; физический луч пока мимо";
        return ready;
    }
}
