package pulse.n9ezz;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import pulse.settings.BooleanSetting;

/** One selection volume shared by outlines, manual picking and Trigger acquisition. */
public final class HitboxV3 {
    public static final BooleanSetting MANUAL = new BooleanSetting("Ручные удары по рамке",
            "Расширенная рамка участвует в выборе игрока обычным кликом. Не поворачивает камеру. Реальная дистанция и препятствия сохраняются; сервер может отклонить удар.", true);
    // Picking runs while rendering the crosshair: this counts successful queries,
    // not mouse clicks, sent attacks or damage acknowledged by the server.
    private static long manualSelections;
    private static String reason = "ожидание выбора";
    private HitboxV3() {}
    private static TargetV2Math.Bounds bounds(class_238 b) {
        return new TargetV2Math.Bounds(b.field_1323,b.field_1322,b.field_1321,b.field_1320,b.field_1325,b.field_1324);
    }
    private static TargetV2Math.Point point(class_243 p) { return new TargetV2Math.Point(p.field_1352,p.field_1351,p.field_1350); }
    private static class_243 vector(TargetV2Math.Point p) { return new class_243(p.x(),p.y(),p.z()); }
    private static boolean enabled() {
        var mc=class_310.method_1551();
        return N9Ezz.HITBOXES!=null&&N9Ezz.HITBOXES.isEnabled()&&!InterfaceMode.hidden()
                &&mc.field_1724!=null&&mc.field_1687!=null;
    }
    public static class_238 volume(class_1297 entity) {
        class_238 physical=entity.method_5829();
        if(!enabled()||!(entity instanceof class_1657 target)||!d.m1(target))return physical;
        var settings=N9Ezz.HITBOXES;
        double range=settings.range.get(),distance=d.m14(target);
        if(!Double.isFinite(range)||range<=0||!Double.isFinite(distance)||distance>Math.min(12,range)
                ||settings.onlyTarget.get()&&CombatTargets.tracked()!=target)return physical;
        var expanded=TargetV2Math.expand(bounds(physical),settings.x.get(),settings.y.get(),settings.z.get(),settings.effectivePower());
        return new class_238(expanded.minX(),expanded.minY(),expanded.minZ(),expanded.maxX(),expanded.maxY(),expanded.maxZ());
    }
    private record Selection(class_1657 target,class_243 hit,double distance) {}
    private static Selection select(class_243 start,class_243 end,double range,double maxSquared,
            Predicate<class_1297> predicate,boolean invisible,boolean unarmored) {
        if(!enabled()||start==null||end==null||predicate==null||!Double.isFinite(range)||range<=0
                ||!Double.isFinite(maxSquared)||maxSquared<=0)return null;
        var eye=point(start);var finish=point(end);
        double rayLength=TargetV2Math.distance(eye,finish);
        if(!Double.isFinite(rayLength)||rayLength<1e-8)return null;
        var dir=new TargetV2Math.Point((finish.x()-eye.x())/rayLength,(finish.y()-eye.y())/rayLength,(finish.z()-eye.z())/rayLength);
        double limit=Math.min(range,Math.min(rayLength,Math.sqrt(maxSquared)));
        Selection best=null;
        for(class_1657 target:class_310.method_1551().field_1687.method_18456()) {
            if(!d.m21(target,invisible,unarmored)||!predicate.test(target))continue;
            var body=bounds(target.method_5829());
            // A volume protruding into reach must not turn a physically distant
            // player into a valid target. Both live and supplied ray origins matter.
            if(d.m14(target)>range||TargetV2Math.distance(eye,TargetV2Math.clamp(body,eye))>range)continue;
            double hitDistance=TargetV2Math.rayDistance(bounds(volume(target)),eye,dir,limit);
            if(!Double.isFinite(hitDistance)||hitDistance*hitDistance>=maxSquared)continue;
            class_243 hit=vector(TargetV2Math.along(eye,dir,hitDistance));
            // The apparent box may stick out of cover. Require a visible selection
            // ray AND an exposed reachable physical point before returning an entity.
            if(!d.m19(hit)||TargetV2Runtime.aimPoint(target,1f,range)==null)continue;
            if(best==null||hitDistance<best.distance||hitDistance==best.distance&&target.method_5628()<best.target.method_5628())
                best=new Selection(target,hit,hitDistance);
        }
        return best;
    }
    /** Runs after the native physical raycast; an existing native hit always wins. */
    public static class_3966 manualPick(class_1297 source,class_243 start,class_243 end,class_238 search,
            Predicate<class_1297> predicate,double maxSquared,class_3966 original) {
        if(original!=null||!MANUAL.get()||!enabled())return original;
        var mc=class_310.method_1551();
        // Restrict the hook to the local player's client view. Projectile physics,
        // another camera entity and the integrated-server thread stay native.
        if(!mc.method_18854()||source!=mc.field_1724||source.method_73183()!=mc.field_1687
                ||mc.method_1560()!=mc.field_1724||mc.field_1755!=null)return original;
        double reach=d.m15(N9Ezz.HITBOXES.range.get());
        Selection chosen=select(start,end,reach,maxSquared,predicate,true,true);
        if(chosen==null){reason="расширенная рамка не дала доступной цели";return original;}
        manualSelections++;reason="игрок выбран по расширенной рамке";
        // This result goes through Minecraft's normal crosshair/attack handling.
        // No automatic swing, extra attack, rotation or network packet is generated.
        return new class_3966(chosen.target,chosen.hit);
    }
    /** Trigger keeps its physical final ray/rotation, using the same selection volume. */
    public static class_1657 acquire(double range,boolean expanded,boolean invisible,boolean unarmored) {
        var mc=class_310.method_1551();
        if(mc.field_1724==null||mc.field_1687==null||!Double.isFinite(range)||range<=0)return null;
        var nativeHit=d.m28(range,false);
        if(nativeHit!=null)return nativeHit instanceof class_1657 p&&d.m21(p,invisible,unarmored)?p:null;
        if(!expanded||!TargetV2Runtime.mayAlign())return null;
        var start=mc.field_1724.method_33571();
        var direction=TargetV2Math.direction(mc.field_1724.method_36454(),mc.field_1724.method_36455());
        if(direction==null)return null;
        var end=vector(TargetV2Math.along(point(start),direction,range));
        // Trigger's previous acquisition included the exact end face; preserve
        // that boundary separately from native manual raycast's strict maxSquared.
        Selection chosen=select(start,end,range,Math.nextUp(range*range),p->true,invisible,unarmored);
        if(chosen!=null)TargetV2Runtime.selected();
        return chosen==null?null:chosen.target;
    }
    public static String diagnostics() {
        return "выборов по рамке (кадры)="+manualSelections+"; "+reason+"; это выбор цели, не подтверждение урона";
    }
}
