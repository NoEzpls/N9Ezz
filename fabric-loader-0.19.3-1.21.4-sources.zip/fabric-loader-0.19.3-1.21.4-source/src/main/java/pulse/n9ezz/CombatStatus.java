package pulse.n9ezz;

/** Local observations only: a queued/native attack is not server-confirmed damage. */
public final class CombatStatus {
    private CombatStatus() {}
    public static String describe() {
        return "PulseVisuals 0.5.0: " + CombatSession.status()
                + "\n" + AuraController.diagnostics()
                + "\nHitboxes/Trigger: " + TargetV2Runtime.diagnostics()
                + "\nSpeed: " + SpeedV2Runtime.diagnostics()
                + "\n" + e.m3()
                + "\nСчётчики описывают действия клиента; подтверждение урона сервером не измеряется.";
    }
}
