package pulse.n9ezz;

/** Finite, absolute horizontal speed math. It never multiplies last tick's velocity. */
public final class SpeedV2 {
    private SpeedV2() {}
    public record Horizontal(double x, double z) {}
    public static double factor(double power) {
        if (!Double.isFinite(power) || power <= 0) return 1;
        return 1 + 4 * Math.max(1, Math.min(100, power)) / 100.0;
    }
    public static Horizontal desired(double x, double z, double base, double power, double distanceLimit) {
        if (!Double.isFinite(x) || !Double.isFinite(z) || !Double.isFinite(base)
            || !Double.isFinite(distanceLimit) || base <= 0 || distanceLimit <= 0) return new Horizontal(0, 0);
        double length = Math.hypot(x, z);
        if (!Double.isFinite(length) || length < 1e-8) return new Horizontal(0, 0);
        double magnitude = Math.min(Math.min(base, 1.0) * factor(power), distanceLimit) * Math.min(1, length);
        return new Horizontal(x / length * magnitude, z / length * magnitude);
    }
    public static boolean prefer(double health, double distance, int id, double bestHealth, double bestDistance, int bestId) {
        if (!Double.isFinite(health) || health <= 0 || !Double.isFinite(distance) || distance < 0) return false;
        int c = Double.compare(health, bestHealth);
        return c < 0 || (c == 0 && (distance < bestDistance || (distance == bestDistance && id < bestId)));
    }
    /**
     * While movement keys are held, compensate only rotations made by our aiming
     * controllers. Mouse rotation is not subtracted, so the player can still steer.
     * Releasing the keys starts the next movement from the current camera heading.
     */
    public static final class ViewFrame {
        private double automaticYaw;
        private double pendingYaw;
        private long pendingTick = Long.MIN_VALUE;
        private boolean moving;
        public void clear() { automaticYaw = pendingYaw = 0; pendingTick = Long.MIN_VALUE; moving = false; }
        public double inputYaw(double visibleYaw, boolean hasInput) {
            return inputYaw(visibleYaw, hasInput, Long.MIN_VALUE);
        }
        public double inputYaw(double visibleYaw, boolean hasInput, long tick) {
            if (!Double.isFinite(visibleYaw)) { clear(); return 0; }
            if (!hasInput) { clear(); return visibleYaw; }
            if (!moving) {
                // Aura's tick callback runs before native keyboard input. A turn
                // earlier in this SAME tick belongs to the initial movement too.
                // A stationary turn from an older tick must not steer a later keypress.
                automaticYaw = tick != Long.MIN_VALUE && pendingTick == tick ? pendingYaw : 0;
                pendingYaw = 0; pendingTick = Long.MIN_VALUE; moving = true;
            }
            return wrap(visibleYaw - automaticYaw);
        }
        public void turned(double before, double after) {
            if (moving && Double.isFinite(before) && Double.isFinite(after))
                automaticYaw = wrap(automaticYaw + wrap(after - before));
        }
        public void turned(double before, double after, long tick) {
            if (!Double.isFinite(before) || !Double.isFinite(after)) return;
            if (moving) { turned(before, after); return; }
            if (tick == Long.MIN_VALUE) return;
            if (pendingTick != tick) pendingYaw = 0;
            pendingTick = tick;
            pendingYaw = wrap(pendingYaw + wrap(after - before));
        }
        public double compensation() { return automaticYaw; }
        private static double wrap(double angle) {
            double value = angle % 360;
            return value >= 180 ? value - 360 : value < -180 ? value + 360 : value;
        }
    }
    /** Phases advance with game ticks, never with render callbacks or busy-loop frequency. */
    public static final class Pulse {
        private long start = Long.MIN_VALUE, last = Long.MIN_VALUE;
        private int boost = 1, rest = 1;
        private boolean active;
        public void reset() { start = last = Long.MIN_VALUE; active = false; }
        public boolean active(long tick, int boostTicks, int restTicks) {
            // The same tick must give the same answer even when called a million
            // times or when a setting changes between two input callbacks.
            if (tick == last && start != Long.MIN_VALUE) return active;
            int nextBoost = Math.max(1, Math.min(20, boostTicks));
            int nextRest = Math.max(1, Math.min(100, restTicks));
            if (start == Long.MIN_VALUE || tick < last || boost != nextBoost || rest != nextRest) {
                start = tick; boost = nextBoost; rest = nextRest;
            }
            last = tick;
            active = Math.floorMod(tick - start, boost + rest) < boost;
            return active;
        }
    }
    /** Native corrections are applied first; optional retries wait and have a session limit. */
    public static final class State {
        private Object world, player;
        private boolean armed, bound, blocked;
        private long quietUntil;
        private long corrections, velocities, worldChanges;
        private boolean autoRetry, retryPending;
        private long retryAt, observedTick;
        private int retries;
        private String reason = "выключено";
        public void enable() { world = player = null; armed = true; bound = blocked = retryPending = false; retries = 0; quietUntil = Long.MIN_VALUE; reason = "активен"; }
        public void disable() { armed = false; world = player = null; bound = blocked = retryPending = false; reason = "выключено"; }
        public void autoRetry(boolean enabled) {
            autoRetry = enabled;
            if (!enabled && retryPending) {
                retryPending = false;
                reason = "сервер скорректировал позицию; автоповтор выключен; /pv speedresume";
            }
        }
        public boolean armed() { return armed; }
        public String reason() { return reason; }
        public String diagnostics() { return reason + "; коррекций: " + corrections + "; обновлений скорости: " + velocities + "; смен мира: " + worldChanges + "; автоповторов: " + retries + "/3"; }
        public int retries() { return retries; }
        /** Read-only preview for view compensation; never consumes or enables a retry. */
        public boolean retryDue(Object nextWorld, Object nextPlayer, long tick) {
            return armed && blocked && retryPending && autoRetry && bound
                    && world != null && player != null && world == nextWorld && player == nextPlayer
                    && tick >= retryAt && tick >= quietUntil;
        }
        public void correction() { correction(observedTick); }
        public void correction(long tick) {
            if (!armed) return;
            corrections++; blocked = true;
            // An unbound/new world must never be rearmed by a teleport packet.
            retryPending = autoRetry && bound && world != null && player != null && retries < 3;
            retryAt = tick + 20;
            reason = retryPending ? "сервер скорректировал позицию; ожидание 20 тиков перед автоповтором"
                    : retries >= 3 ? "сервер скорректировал позицию; лимит 3 автоповторов исчерпан; /pv speedresume"
                    : "сервер скорректировал позицию; /pv speedresume или выключить/включить Speed";
        }
        public void disconnect() { if (armed) { if (world != null || player != null) worldChanges++; blocked = true; retryPending = false; reason = "мир/сервер изменился; требуется повторное включение Speed"; } world = player = null; }
        public void velocity(long tick) {
            if (armed) {
                velocities++;
                quietUntil = Math.max(quietUntil, tick + 10);
                // A velocity update is not permission to resume after a correction.
                // Retain the latched reason; otherwise status claimed a 10-tick wait
                // although ready() would remain false indefinitely.
                if (!blocked) reason = "обработка серверной скорости (10 тиков)";
            }
        }
        public boolean ready(Object nextWorld, Object nextPlayer, long tick) {
            return ready(nextWorld, nextPlayer, tick, true);
        }
        /** Camera observation must not consume a movement retry before input settings are read. */
        public boolean ready(Object nextWorld, Object nextPlayer, long tick, boolean permitRetry) {
            if (!armed) return false;
            if (nextWorld == null || nextPlayer == null) { disconnect(); return false; }
            if (!bound) { world = nextWorld; player = nextPlayer; bound = true; }
            else if (world != nextWorld || player != nextPlayer) { disconnect(); return false; }
            observedTick = tick;
            if (blocked) {
                if (!retryPending || !autoRetry || !permitRetry) return false;
                long remaining = Math.max(retryAt, quietUntil) - tick;
                if (remaining > 0) {
                    reason = "сервер скорректировал позицию; до автоповтора: " + remaining + " тиков";
                    return false;
                }
                // Consume the retry only when the same world/player can actually
                // resume. Polling and incoming velocity packets cannot reset its limit.
                retries++; blocked = retryPending = false;
            }
            if (tick < quietUntil) return false;
            reason = "активен";
            return true;
        }
    }
}
