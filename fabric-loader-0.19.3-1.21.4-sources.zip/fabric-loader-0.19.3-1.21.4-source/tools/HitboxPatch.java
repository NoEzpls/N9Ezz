import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Preserve native picking, then add expanded selection only when it missed. */
public final class HitboxPatch implements Opcodes {
    private static final String R="pulse/n9ezz/HitboxV3";
    private static final String ARGS="Lnet/minecraft/class_1297;Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lnet/minecraft/class_238;Ljava/util/function/Predicate;D";
    public static void apply(Map<String,byte[]> files) {
        ClassNode c=FeaturePatch.read(files,"pulse/n9ezz/mixin/ProjectileTargetMixin");
        MethodNode candidates=FeaturePatch.method(c,"n9ezz$candidates");
        // Vanilla broadphase is sufficient for the first, physical pass. The
        // fallback independently scans expanded volumes, avoiding narrow-prism misses.
        FeaturePatch.reset(candidates);
        for(int i=0;i<4;i++)candidates.instructions.add(new VarInsnNode(ALOAD,i));
        candidates.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/class_1937","method_8333",
                "(Lnet/minecraft/class_1297;Lnet/minecraft/class_238;Ljava/util/function/Predicate;)Ljava/util/List;",false));
        candidates.instructions.add(new InsnNode(ARETURN));
        MethodNode pick=new MethodNode(ACC_PRIVATE|ACC_STATIC,"n9ezz$expandedPick",
                "("+ARGS+"Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;)V",null,null);
        AnnotationNode inject=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/Inject;");
        AnnotationNode at=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/At;");at.values=new ArrayList<>(List.of("value","RETURN"));
        inject.values=new ArrayList<>(List.of("method",List.of("method_18075("+ARGS+")Lnet/minecraft/class_3966;"),
                "at",List.of(at),"cancellable",true,"require",1));pick.visibleAnnotations=new ArrayList<>(List.of(inject));
        InsnList p=pick.instructions;
        p.add(new VarInsnNode(ALOAD,7));
        for(int i=0;i<5;i++)p.add(new VarInsnNode(ALOAD,i));p.add(new VarInsnNode(DLOAD,5));
        p.add(new VarInsnNode(ALOAD,7));p.add(new MethodInsnNode(INVOKEVIRTUAL,"org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable","getReturnValue","()Ljava/lang/Object;",false));
        p.add(new TypeInsnNode(CHECKCAST,"net/minecraft/class_3966"));
        p.add(FeaturePatch.call(R,"manualPick","("+ARGS+"Lnet/minecraft/class_3966;)Lnet/minecraft/class_3966;"));
        p.add(new MethodInsnNode(INVOKEVIRTUAL,"org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable","setReturnValue","(Ljava/lang/Object;)V",false));p.add(new InsnNode(RETURN));
        c.methods.add(pick);FeaturePatch.write(files,c);
        c=FeaturePatch.read(files,"pulse/n9ezz/u3");
        c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,"manualPicking","Lpulse/settings/BooleanSetting;",null,null));
        for(AbstractInsnNode i:FeaturePatch.method(c,"<init>").instructions.toArray())if(i.getOpcode()==RETURN){
            InsnList q=new InsnList();q.add(new VarInsnNode(ALOAD,0));q.add(new FieldInsnNode(GETSTATIC,R,"MANUAL","Lpulse/settings/BooleanSetting;"));
            q.add(new FieldInsnNode(PUTFIELD,c.name,"manualPicking","Lpulse/settings/BooleanSetting;"));FeaturePatch.method(c,"<init>").instructions.insertBefore(i,q);
        }
        for(AnnotationNode a:c.visibleAnnotations)if(a.desc.equals("Lpulse/module/ModuleInfo;"))for(int i=0;i<a.values.size();i+=2)
            if(a.values.get(i).equals("b"))a.values.set(i+1,"Единая расширенная рамка для отображения, ручного выбора игрока и Triggerbot. Клик по рамке выбирает цель в реальной дальности; сервер может отклонить удар.");
        FeaturePatch.write(files,c);
    }
}
