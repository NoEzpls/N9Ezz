import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Coordinates existing native-action modules through one explicitly enabled target session. */
public final class JuggernautPatch implements Opcodes {
    static final String IM="pulse/n9ezz/InterfaceMode", SESSION="pulse/n9ezz/CombatSession", N="pulse/n9ezz/N9Ezz";
    static final String SL="pulse/settings/SliderSetting", BO="pulse/settings/BooleanSetting";
    static MethodInsnNode call(String o,String n,String d){return new MethodInsnNode(INVOKESTATIC,o,n,d,false);}
    static void frame(InsnList p){p.add(new FrameNode(F_NEW,2,new Object[]{"java/lang/String",INTEGER},0,null));}
    static void module(InsnList p,String field,String type){p.add(new FieldInsnNode(GETSTATIC,N,field,"Lpulse/n9ezz/"+type+";"));}
    static void slider(InsnList p,String field,String type,String setting,float value){module(p,field,type);p.add(new FieldInsnNode(GETFIELD,"pulse/n9ezz/"+type,setting,"L"+SL+";"));p.add(new LdcInsnNode(value));p.add(new MethodInsnNode(INVOKEVIRTUAL,SL,"set","(F)V",false));}
    static void bool(InsnList p,String field,String type,String setting,boolean value){module(p,field,type);p.add(new FieldInsnNode(GETFIELD,"pulse/n9ezz/"+type,setting,"L"+BO+";"));p.add(new InsnNode(value?ICONST_1:ICONST_0));p.add(new MethodInsnNode(INVOKEVIRTUAL,BO,"set","(Z)V",false));}
    static void enabled(InsnList p,String field,String type,boolean value){module(p,field,type);p.add(new InsnNode(value?ICONST_1:ICONST_0));p.add(new MethodInsnNode(INVOKEVIRTUAL,"pulse/n9ezz/"+type,"setEnabled","(Z)V",false));}
    public static void apply(Map<String,byte[]> files){
        ClassNode c=FeaturePatch.read(files,"pulse/n9ezz/CombatTargets");
        MethodNode tracked=FeaturePatch.method(c,"tracked");InsnList p=new InsnList();p.add(call(SESSION,"juggernaut","()Z"));LabelNode normal=new LabelNode();p.add(new JumpInsnNode(IFEQ,normal));p.add(call(SESSION,"target","()Lnet/minecraft/class_1657;"));p.add(new InsnNode(ARETURN));p.add(normal);p.add(new FrameNode(F_NEW,0,new Object[]{},0,null));tracked.instructions.insert(p);
        p=new InsnList();p.add(call(SESSION,"clear","()V"));FeaturePatch.method(c,"clear").instructions.insert(p);FeaturePatch.write(files,c);
        // Hide/disableAll already clears CombatTargets. Speed resides in the same
        // filtered module list, so no hidden independently-running movement loop exists.
        c=FeaturePatch.read(files,"pulse/n9ezz/NetworkPreset");
        MethodNode preset=FeaturePatch.method(c,"m0");
        for(AbstractInsnNode i:preset.instructions.toArray())if(i instanceof MethodInsnNode m&&m.owner.equals(SL)&&m.name.equals("set")){
            AbstractInsnNode v=FeaturePatch.previous(i),f=FeaturePatch.previous(v);
            if(f instanceof FieldInsnNode field && field.name.equals("fov"))preset.instructions.set(v,new LdcInsnNode(360f));
        }
        for(AbstractInsnNode i:preset.instructions.toArray())if(i.getOpcode()==RETURN){p=new InsnList();
            bool(p,"AURA","u0","fastRotation",true);bool(p,"AURA","u0","airCritOnly",true);
            // The requested follow-up strike is explicitly enabled in the new combat profile.
            // This schedules a native repeat, never a promise of additional server damage.
            bool(p,"AURA","u0","doubleAttack",true);
            slider(p,"AURA","u0","trackingRange",5);
            slider(p,"AURA","u0","manualOverride",0);
            bool(p,"STRAFE","u20","freeMovement",true);
            slider(p,"AURA","u0","maxTurn",180);slider(p,"AURA","u0","jitterMs",10);
            bool(p,"HITBOXES","u3","alignment",true);slider(p,"HITBOXES","u3","alignmentTurn",35);
            // A fresh profile must allow expanded acquisition before a tracked target exists.
            bool(p,"HITBOXES","u3","onlyTarget",false);
            preset.instructions.insertBefore(i,p);
        }
        // The old conflict text called every enabled Hitboxes a network conflict.
        // Replacement geometry/alignment preserves final physical rays, so that stale
        // message would misdescribe our own coordinated preset.
        MethodNode conflicts=FeaturePatch.method(c,"conflicts");FeaturePatch.reset(conflicts);
        conflicts.instructions.add(new LdcInsnNode("Финальная дальность и попадание проверяются по физической цели; сервер может отклонить действия."));conflicts.instructions.add(new InsnNode(ARETURN));FeaturePatch.write(files,c);
        c=FeaturePatch.read(files,IM);
        MethodNode jug=new MethodNode(ACC_PUBLIC|ACC_STATIC,"pulsevisuals$juggernaut","()V",null,null);p=jug.instructions;
        p.add(call("pulse/n9ezz/NetworkPreset","apply","()V"));
        enabled(p,"TRIGGER","u1",false);enabled(p,"AIM","u2",false);enabled(p,"AURA","u0",true);enabled(p,"HITBOXES","u3",true);
        bool(p,"AURA","u0","doubleAttack",true);bool(p,"AURA","u0","lockTarget",false);
        slider(p,"STRAFE","u20","speedPower",25);slider(p,"STRAFE","u20","targetRange",12);slider(p,"STRAFE","u20","radius",2);
        bool(p,"STRAFE","u20","freeMovement",false);bool(p,"STRAFE","u20","pursue",true);enabled(p,"STRAFE","u20",true);
        p.add(call("pulse/n9ezz/SpeedV2Runtime","resume","()V"));p.add(new InsnNode(ICONST_1));p.add(call(SESSION,"setJuggernaut","(Z)V"));p.add(new InsnNode(RETURN));c.methods.add(jug);
        MethodNode handle=FeaturePatch.method(c,"handleCommand");LookupSwitchInsnNode sw=null;
        for(AbstractInsnNode i:handle.instructions)if(i instanceof LookupSwitchInsnNode s){sw=s;break;}
        if(sw==null)throw new IllegalStateException("Local command switch absent");
        LabelNode reply=null;for(AbstractInsnNode i:handle.instructions)if(i instanceof JumpInsnNode j&&j.getOpcode()==GOTO){reply=j.label;break;}
        if(reply==null)throw new IllegalStateException("Local command reply absent");
        InsnList extra=new InsnList();
        for(int action:new int[]{5,6,7,8}){LabelNode label=new LabelNode();sw.keys.add(action);sw.labels.add(label);extra.add(label);frame(extra);
            if(action==5){extra.add(call(IM,jug.name,jug.desc));extra.add(new LdcInsnNode("PulseVisuals: Juggernaut включён — общая цель с меньшим HP, второй удар, Speed ×2. /pv juggernaut off — остановить."));}
            else if(action==6){extra.add(call(N,"disableAll","()I"));extra.add(new InsnNode(POP));extra.add(call(SESSION,"clear","()V"));extra.add(new LdcInsnNode("PulseVisuals: Juggernaut и боевые модули остановлены."));}
            else if(action==7){extra.add(call("pulse/n9ezz/CombatStatus","describe","()Ljava/lang/String;"));}
            else{extra.add(call("pulse/n9ezz/SpeedV2Runtime","resume","()V"));extra.add(new LdcInsnNode("PulseVisuals: пауза Speed сброшена. Модуль включается отдельно; сервер может снова скорректировать движение."));}
            extra.add(new JumpInsnNode(GOTO,reply));
        }
        handle.instructions.insertBefore(sw.dflt,extra);
        for(AbstractInsnNode i:handle.instructions)if(i instanceof LdcInsnNode l&&l.cst instanceof String s){
            if(s.startsWith("PulseVisuals: быстрый бой применён."))l.cst="PulseVisuals 0.4.9: бой 360°, поиск 5 блоков, второй удар включён, Speed выключен. /pv status — причины ожидания; /pv hide — пауза.";
            if(s.equals("PulseVisuals: /pv hide, /pv show, /pv combat. Команды выполняются локально."))l.cst="PulseVisuals: /pv combat, /pv juggernaut [off], /pv hide, /pv show, /pv status, /pv speedresume.";
        }
        FeaturePatch.write(files,c);
    }
}
