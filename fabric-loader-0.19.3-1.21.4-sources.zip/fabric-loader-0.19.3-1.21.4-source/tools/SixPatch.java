import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Applies the reviewed patch to one exact, previously inspected network.1 client.
 * This is a binary overlay: it does not claim to rebuild the unavailable Pulse source.
 */
public final class SixPatch {
    public static final String BASE_SHA = "5dbb9f72359d8371b7069dbf4f421c358c28a8c11af23e06c9182ec793aada6a";
    private static final Set<String> MUTABLE = Set.of(
        "pulse/module/ModuleRegistry.class", "pulse/module/ClientModule.class",
        "pulse/n9ezz/N9Ezz.class", "pulse/n9ezz/InterfaceMode.class",
        "pulse/n9ezz/PowerCurve.class", "pulse/n9ezz/PowerCurve$Level.class",
        "pulse/n9ezz/CheatModule.class", "pulse/gui/modules/ModulesTab.class",
        "pulse/n9ezz/Stars.class", "pulse/n9ezz/ConfigCommands.class",
        "pulse/n9ezz/e.class", "pulse/n9ezz/d.class", "pulse/n9ezz/u5.class",
        "pulse/n9ezz/u0.class", "pulse/n9ezz/u1.class", "pulse/n9ezz/ViewMotion.class",
        "pulse/n9ezz/mixin/ProjectileTargetMixin.class", "pulse/n9ezz/NetworkPreset.class", "ru/pulse/mixin/ChatScreenMixin.class", "pulse/n9ezz/u3.class", "pulse/n9ezz/u20.class", "pulse/n9ezz/CombatTargets.class", "ru/pulse/mixin/MixinClientPlayNetworkHandler.class");
    private static final Set<String> NETWORK = Set.of(
        "ru/pulse/mixin/ClientConnectionMixin.class",
        "pulse/n9ezz/mixin/CombatEntityMixin.class",
        "pulse/n9ezz/CombatDispatch.class", "pulse/n9ezz/NetworkPacketPolicy.class");
    private static String sha(byte[] data) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
    }
    private static boolean helper(String name) {
        return name.matches("pulse/n9ezz/(CombatRules6|ModuleRules6|BrandPaths|ClientCommandText|CombatSession|CombatStatus|Aura[A-Za-z0-9_]*|TargetV2[A-Za-z0-9_]*|TriggerV2[A-Za-z0-9_]*|SpeedV2[A-Za-z0-9_]*|HitboxV3)(\\$[A-Za-z0-9_]+)?\\.class");
    }
    private static void validPath(String name) {
        if (name.startsWith("/") || name.contains("\\") || name.contains(":") ||
            Arrays.stream(name.split("/", -1)).anyMatch(s -> s.equals("..") || s.equals(".")))
            throw new IllegalArgumentException("Unsafe entry: " + name);
    }
    private static Map<String, byte[]> read(Path path) throws Exception {
        Map<String, byte[]> result = new TreeMap<>();
        try (ZipFile zip = new ZipFile(path.toFile())) {
            var all = zip.entries();
            while (all.hasMoreElements()) {
                ZipEntry entry = all.nextElement();
                validPath(entry.getName());
                if (entry.isDirectory()) continue;
                byte[] data;
                try (InputStream input = zip.getInputStream(entry)) { data = input.readAllBytes(); }
                CRC32 crc = new CRC32(); crc.update(data);
                if (crc.getValue() != entry.getCrc()) throw new IOException("Bad CRC: " + entry.getName());
                if (result.put(entry.getName(), data) != null)
                    throw new IOException("Duplicate entry: " + entry.getName());
            }
        }
        return result;
    }
    private static int verify(String name, byte[] data) throws Exception {
        ClassNode node = new ClassNode(); new ClassReader(data).accept(node, 0);
        if (!(node.name + ".class").equals(name)) throw new IOException("Wrong class path: " + name);
        int count = 0;
        for (MethodNode method : node.methods) {
            if ((method.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) continue;
            try { new Analyzer<>(new BasicVerifier()).analyze(node.name, method); }
            catch (AnalyzerException error) {
                throw new IOException("Invalid bytecode " + name + "." + method.name + method.desc, error);
            }
            count++;
        }
        return count;
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("baseline.jar helper-classes output.jar");
        Path input = Path.of(args[0]), helpers = Path.of(args[1]), output = Path.of(args[2]);
        if (Files.exists(output)) throw new FileAlreadyExistsException(output.toString());
        if (!sha(Files.readAllBytes(input)).equals(BASE_SHA))
            throw new IOException("Unknown input client; refusing to patch another layout");
        Map<String, byte[]> original = read(input), entries = new TreeMap<>(original);
        // Compose disjoint method changes against the current map, not fresh copies of baseline.
        ModulePatch.apply(entries);
        CombatPatch.apply(entries);
        FeaturePatch.apply(entries);
        BrandPatch.apply(entries);
        AuraRewritePatch.apply(entries);
        TargetRewritePatch.apply(entries);
        HitboxPatch.apply(entries);
        SpeedPatch.apply(entries);
        JuggernautPatch.apply(entries);
        try (var files = Files.walk(helpers)) {
            for (Path file : files.filter(Files::isRegularFile).sorted().toList()) {
                String name = helpers.relativize(file).toString().replace(File.separatorChar, '/');
                if (!helper(name)) throw new IOException("Unexpected helper: " + name);
                if (entries.putIfAbsent(name, Files.readAllBytes(file)) != null)
                    throw new IOException("Helper overwrites baseline: " + name);
            }
        }
        int classes = 0, methods = 0;
        for (String name : original.keySet()) {
            if (!entries.containsKey(name)) throw new IOException("Removed baseline resource: " + name);
            if (!Arrays.equals(original.get(name), entries.get(name))) {
                if (!MUTABLE.contains(name) && !BrandPatch.CLASSES.contains(name) && !name.equals("fabric.mod.json")) throw new IOException("Unexpected modification: " + name);
                if(name.endsWith(".class")){methods += verify(name, entries.get(name)); classes++;}
                System.out.println("CHANGED " + name + " " + sha(entries.get(name)));
            }
        }
        for (String name : entries.keySet()) {
            if (original.containsKey(name)) continue;
            if (!helper(name)) throw new IOException("Unexpected added entry: " + name);
            methods += verify(name, entries.get(name)); classes++;
        }
        for (String name : NETWORK) {
            if (!original.containsKey(name) || !Arrays.equals(original.get(name), entries.get(name)))
                throw new IOException("Transport invariant changed: " + name);
        }
        if (classes == 0) throw new IOException("Empty patch");
        entries.put("META-INF/fabric-loader-0.19.3-1.21.4/build.json", ("{\"version\":\"0.4.8-experimental\","
            + "\"baselineSha256\":\"" + BASE_SHA + "\",\"sourceType\":\"partial-source-and-bytecode-overlay\","
            + "\"gameVersion\":\"1.21.11\",\"registryCount\":90,\"restoredPulseModules\":83,\"n9ezzModules\":[\"KillAura\",\"Triggerbot\",\"AimBot\","
            + "\"Hitboxes\",\"AutoTotem\",\"IncreasedDamage\",\"Speed\"]}\n").getBytes(StandardCharsets.UTF_8));
        Files.createDirectories(output.toAbsolutePath().getParent());
        // Write a complete deterministic ZIP first; never replace an existing release artifact.
        Path temporary = Files.createTempFile(output.toAbsolutePath().getParent(), ".six-", ".jar");
        try {
            try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(temporary))) {
                for (var item : entries.entrySet()) {
                    ZipEntry entry = new ZipEntry(item.getKey()); byte[] data = item.getValue();
                    CRC32 crc = new CRC32(); crc.update(data);
                    entry.setMethod(ZipEntry.STORED); entry.setSize(data.length); entry.setCrc(crc.getValue());
                    entry.setTimeLocal(LocalDateTime.of(1980, 1, 2, 0, 0));
                    zip.putNextEntry(entry); zip.write(data); zip.closeEntry();
                }
            }
            Files.move(temporary, output);
        } finally { Files.deleteIfExists(temporary); }
        System.out.println("PASS: " + classes + " patched/helper classes; " + methods
            + " methods pass ASM BasicVerifier; 4 transport classes identical; all other bytes preserved.");
        System.out.println("CLIENT SHA256 " + sha(Files.readAllBytes(output)));
    }
}
