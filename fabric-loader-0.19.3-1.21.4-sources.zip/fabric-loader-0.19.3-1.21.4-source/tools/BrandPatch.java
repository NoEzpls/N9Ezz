import java.util.*;
import java.nio.charset.StandardCharsets;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import com.google.gson.*;

/** User-visible branding; internal Java/API identifiers remain binary-compatible. */
public final class BrandPatch implements Opcodes {
    public static final Set<String> CLASSES=Set.of("pulse/gui/core/PulseLogoOverlay.class","pulse/n9ezz/PowerModes.class",
        "pulse/n9ezz/ConfigSnapshots.class","pulse/n9ezz/FriendSupport.class","pulse/config/LocalConfigManager.class",
        "pulse/config/ConfigManager.class","pulse/hud/core/HudElement.class","pulse/module/ClientModule.class",
        "pulse/settings/Setting.class","ru/pulse/Pulse.class","pulse/n9ezz/ConfigCommands.class");
    public static void apply(Map<String,byte[]> files){
        for(String name:CLASSES){ClassNode c=FeaturePatch.read(files,name.substring(0,name.length()-6));
            for(FieldNode field:c.fields)if(field.value instanceof String s)field.value=replace(c.name,s);
            for(MethodNode m:c.methods)for(AbstractInsnNode i:m.instructions)if(i instanceof LdcInsnNode l&&l.cst instanceof String raw){
                boolean encoded=raw.startsWith("\u0001");String text=encoded?decode(raw):raw;String next=replace(c.name,text);
                if(!next.equals(text))l.cst=encoded?encode(next):next;
            }
            if(c.name.equals("ru/pulse/Pulse")){
                MethodNode init=FeaturePatch.method(c,"onInitialize");InsnList p=new InsnList();
                p.add(new MethodInsnNode(INVOKESTATIC,"net/fabricmc/loader/api/FabricLoader","getInstance","()Lnet/fabricmc/loader/api/FabricLoader;",true));
                p.add(new MethodInsnNode(INVOKEINTERFACE,"net/fabricmc/loader/api/FabricLoader","getGameDir","()Ljava/nio/file/Path;",true));
                p.add(FeaturePatch.call("pulse/n9ezz/BrandPaths","migrateGame","(Ljava/nio/file/Path;)V"));init.instructions.insert(p);
            }
            FeaturePatch.write(files,c);
        }
        JsonObject mod=JsonParser.parseString(new String(files.get("fabric.mod.json"),StandardCharsets.UTF_8)).getAsJsonObject();
        // Cosmetic display name only. Stable mod IDs, Java names and genuine
        // crash stack traces remain intact; this is not a log scrubber.
        mod.addProperty("name","Anti invise");mod.addProperty("description","N9Ezz combat tools and Pulse visual settings for Minecraft 1.21.11; Anti invise is the display name.");
        files.put("fabric.mod.json",new Gson().toJson(mod).getBytes(StandardCharsets.UTF_8));
    }
    static String replace(String owner,String s){
        // The logo already chooses its title from InterfaceMode.hidden(). Preserve
        // that runtime branch: normal combat menu is N9Ezz, hidden menu PulseVisuals.
        // This changes presentation only, never loaded classes or filesystem paths.
        if(owner.equals("pulse/gui/core/PulseLogoOverlay")){
            if(s.equals("N9Ezz"))return "N9Ezz";
            if(s.equals("Pulse"))return "PulseVisuals";
        }
        if(s.equals("N9Ezz"))return "Anti invise";
        if(s.startsWith("n9ezz/"))return "fabric-loader-0.19.3-1.21.4/"+s.substring(6);
        if(s.equals("pulse/config"))return "fabric-loader-0.19.3-1.21.4/config";
        if(owner.equals("pulse/config/LocalConfigManager")){
            if(s.equals("pulse"))return "fabric-loader-0.19.3-1.21.4";
            if(s.contains("pulse.cfg"))return s.replace("pulse.cfg","fabric-loader-0.19.3-1.21.4.cfg");
            if(s.equals("pulse-autosave"))return "fabric-loader-0.19.3-1.21.4-autosave";
        }
        if(owner.equals("pulse/n9ezz/ConfigCommands")&&s.contains("Сетевая настройка применена."))
            return "PulseVisuals: быстрый бой применён. Hight ×2.5, заряд 95%, подтверждение 0 мс. /pv hide — пауза.";
        return s;
    }
    static String decode(String s){byte[] b=Base64.getDecoder().decode(s.substring(1));for(int i=0;i<b.length;i++)b[i]^=(byte)(0x59+i*31+(i>>>2)*17);return new String(b,StandardCharsets.UTF_8);}
    static String encode(String s){byte[] b=s.getBytes(StandardCharsets.UTF_8);for(int i=0;i<b.length;i++)b[i]^=(byte)(0x59+i*31+(i>>>2)*17);return "\u0001"+Base64.getEncoder().encodeToString(b);}
}
