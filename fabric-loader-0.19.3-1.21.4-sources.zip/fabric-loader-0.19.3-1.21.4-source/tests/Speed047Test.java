import pulse.n9ezz.SpeedV2;

/** Tick phases and bounded retries, including the requested million-call scenario. */
public final class Speed047Test {
    static int checks;
    static void check(boolean value, String message) { checks++; if (!value) throw new AssertionError(message); }
    public static void main(String[] args) {
        SpeedV2.Pulse pulse = new SpeedV2.Pulse();
        check(pulse.active(10, 1, 1), "first pulse boosts");
        boolean stable = true;
        for (int i=0; i<1_000_000; i++) stable &= pulse.active(10, 1, 1);
        check(stable, "million callbacks cannot advance a single game tick");
        check(!pulse.active(11, 1, 1), "rest tick does not boost");
        check(pulse.active(12, 1, 1), "next full cycle boosts");
        pulse.reset();
        for (int i=0; i<20; i++) check(pulse.active(100+i, 2, 3) == (i%5<2), "two-on/three-off tick " + i);
        pulse.reset();
        check(pulse.active(0, 0, -9), "invalid settings bounded to nonzero phases");
        check(!pulse.active(1, 0, -9), "invalid settings cannot remove rest phase");
        pulse.reset();
        check(pulse.active(0, 1, 1) && !pulse.active(101, 1, 1), "missed ticks never replay catch-up pulses");

        SpeedV2.State s = new SpeedV2.State();
        Object world = new Object(), player = new Object();
        s.enable(); s.autoRetry(true); check(s.ready(world, player, 10), "bind first session");
        for (int retry=0; retry<3; retry++) {
            long now = 10 + retry*25;
            s.correction(now);
            for (int dt=0; dt<20; dt++) check(!s.ready(world, player, now+dt), "full wait before retry " + retry);
            check(s.retries()==retry, "polling does not consume retry count");
            check(!s.ready(world, player, now+20, false), "camera observation cannot resume before movement input");
            check(s.retries()==retry, "camera does not consume retry");
            check(s.retryDue(world, player, now+20) && !s.retryDue(new Object(), player, now+20), "retry preview requires same world");
            check(s.retries()==retry, "retry preview is read-only");
            check(s.ready(world, player, now+20), "resume exactly at 20 ticks");
            check(s.retries()==retry+1, "retry counted once");
        }
        s.correction(100);
        check(!s.ready(world, player, 10000), "fourth correction latches after three retries");
        check(s.reason().contains("лимит 3"), "exhaustion reason visible");
        s.enable(); s.autoRetry(true); s.ready(world, player, 20); s.correction(20); s.velocity(35);
        check(!s.ready(world, player, 40), "retry respects later native velocity quiet window");
        check(s.ready(world, player, 45), "both native velocity and correction waits expired");
        s.correction(46);
        check(!s.ready(new Object(), player, 100), "world change wins over expired retry");
        check(!s.ready(world, player, 10000), "old world cannot resume a disconnected session");
        s.enable(); s.autoRetry(true); s.ready(world, player, 1); s.correction(1); s.autoRetry(false);
        check(!s.ready(world, player, 1000), "switching retry off cancels pending restart");
        s.autoRetry(true);
        check(!s.ready(world, player, 1001), "switching option back on does not restart old correction");
        s.enable(); s.ready(world, player, 1); s.correction(1); s.disable();
        check(!s.ready(world, player, 1000), "disable prevents pending restart");
        System.out.println("Speed047Test PASS: " + checks + " checks, including 1,000,000 same-tick polls; no server simulation");
    }
}
