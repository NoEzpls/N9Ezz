"""Prove this Speed/path update leaves the previously shipped combat classes byte-identical."""
from pathlib import Path
import io
import json
import sys
import zipfile

previous_loader, new_client = map(Path, sys.argv[1:])
protected = [
    'AuraController', 'AuraRules', 'AuraSchedule', 'u0',
    'TriggerV2Controller', 'u1', 'TargetV2Math', 'TargetV2Runtime', 'u3',
    'u2', 'u4', 'u5', 'e', 'd', 'CombatRules6', 'CombatSession',
    'CombatTargets', 'CombatDispatch', 'NetworkPacketPolicy', 'ViewMotion',
    'PowerCurve',
]
with zipfile.ZipFile(previous_loader) as loader:
    data=loader.read('embedded/client-profile-1.5.3.jar')
with zipfile.ZipFile(io.BytesIO(data)) as old, zipfile.ZipFile(new_client) as new:
    names=[name for name in old.namelist() if any(
        name=='pulse/n9ezz/'+base+'.class' or name.startswith('pulse/n9ezz/'+base+'$')
        for base in protected)]
    names += ['pulse/gui/modules/ModulesTab.class', 'pulse/gui/core/PulseLogoOverlay.class',
              'ru/pulse/mixin/ClientConnectionMixin.class', 'pulse/n9ezz/mixin/CombatEntityMixin.class']
    for name in names:
        assert old.read(name)==new.read(name), 'Unexpected combat/menu/transport change: '+name
    assert len(names)>=len(protected)+4
    assert old.read('pulse/n9ezz/SpeedV2Runtime.class')!=new.read('pulse/n9ezz/SpeedV2Runtime.class'), 'Speed runtime did not change'
print(json.dumps({'result':'PASS','unchangedClasses':len(names),'classes':names,'speedChanged':True}))
