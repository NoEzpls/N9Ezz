"""Build portability checks; execution of Windows itself is a separate scenario."""
from pathlib import Path
import importlib.util
import os
import subprocess
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('build_module', Path(__file__).resolve().parents[1] / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)


class BuildToolTests(unittest.TestCase):
    def test_platform_executable_names_and_missing_jdk(self):
        with tempfile.TemporaryDirectory(prefix='jdk fixture ') as td:
            root = Path(td)
            (root / 'bin').mkdir()
            for name in ('java', 'javac', 'java.exe', 'javac.exe'):
                (root / 'bin' / name).touch()
            self.assertEqual(build.java_tool(root, 'java', True).name, 'java.exe')
            self.assertEqual(build.java_tool(root, 'javac', True).name, 'javac.exe')
            self.assertEqual(build.java_tool(root, 'java', False).name, 'java')
            (root / 'bin/java.exe').unlink()
            with self.assertRaisesRegex(RuntimeError, 'complete JDK'):
                build.java_tool(root, 'java', True)

    def test_real_compilation_with_spaces_unicode_and_argument_file(self):
        with tempfile.TemporaryDirectory(prefix='n9ezz build проверка ') as td:
            root = Path(td)
            source = root / 'Hello.java'
            source.write_text('public class Hello {public static void main(String[] args) {System.out.println("OK");}}', encoding='utf-8')
            args = root / 'compile args.txt'
            build.write_javac_args(args, ['--release', '21', '-encoding', 'UTF-8', '-d', root / 'classes with spaces', source])
            javac = build.java_tool(Path(os.environ['JAVA_HOME']), 'javac')
            proc = subprocess.run([str(javac), '@' + str(args)], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertTrue((root / 'classes with spaces/Hello.class').is_file())

    def test_argument_file_escaping_and_reject_line_injection(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'args.txt'
            build.write_javac_args(p, ['C:\\Java 21\\bin', 'a"b'])
            self.assertEqual(p.read_text(), '"C:\\\\Java 21\\\\bin"\n"a\\"b"\n')
            with self.assertRaises(ValueError):
                build.write_javac_args(p, ['bad\n-option'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
