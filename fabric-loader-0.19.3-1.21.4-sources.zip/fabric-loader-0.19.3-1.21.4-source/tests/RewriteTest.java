import java.nio.file.*;
import java.net.*;
import java.util.*;
import javax.tools.ToolProvider;
import java.util.zip.ZipFile;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Runs production controllers against a deterministic client/world fixture. Not a live duel. */
public final class RewriteTest {
    public static void main(String[] args)throws Exception {
        if(args.length!=5)throw new IllegalArgumentException("baseline.jar updated.jar fixture-directory minecraft-api.jar previous-loader.jar");
        Path fixture=Path.of(args[2]),temp=Files.createTempDirectory("pulsevisuals-rewrite-");
        try{
            Path classes=temp.resolve("classes");Files.createDirectories(classes);
            List<String> compile=new ArrayList<>(List.of("--release","21","-proc:none","-classpath",Path.of(args[1]).toAbsolutePath().toString(),"-d",classes.toString()));
            try(var walk=Files.walk(fixture)){
                for(Path p:walk.filter(x->x.toString().endsWith(".txt")).toList()){
                    Path target=temp.resolve(fixture.relativize(p).toString().replace(".txt",".java"));Files.createDirectories(target.getParent());Files.copy(p,target);compile.add(target.toString());
                }
            }
            if(ToolProvider.getSystemJavaCompiler().run(null,null,null,compile.toArray(String[]::new))!=0)throw new AssertionError("Controller fixtures did not compile");
            // Execute the pinned game's real entity-selection loop, with small
            // world/math fixtures. Game bytes stay in the temporary test directory.
            try(ZipFile minecraft=new ZipFile(args[3])) {
                ClassNode nativePick=new ClassNode();
                new ClassReader(minecraft.getInputStream(minecraft.getEntry("net/minecraft/class_1675.class")).readAllBytes()).accept(nativePick,0);
                nativePick.methods.removeIf(m->!m.name.equals("method_18075"));
                nativePick.fields.clear();nativePick.innerClasses.clear();nativePick.nestMembers=null;
                if(nativePick.methods.size()!=1)throw new AssertionError("Pinned native selection method changed");
                ClassWriter w=new ClassWriter(0);nativePick.accept(w);
                Files.write(classes.resolve("net/minecraft/class_1675.class"),w.toByteArray());
            }
            Path previous=temp.resolve("previous-client.jar");
            try(ZipFile loader=new ZipFile(args[4])) {
                Files.write(previous,loader.getInputStream(loader.getEntry("embedded/fabric-loader-0.19.3-1.21.4-1.5.3.jar")).readAllBytes());
            }
            try(URLClassLoader l=new URLClassLoader(new URL[]{classes.toUri().toURL(),previous.toUri().toURL()},ClassLoader.getPlatformClassLoader())) {
                boolean reproduced=false;
                try{l.loadClass("Hitboxes048Probe").getMethod("main",String[].class).invoke(null,(Object)new String[]{});}
                catch(java.lang.reflect.InvocationTargetException e) {
                    reproduced=e.getCause() instanceof AssertionError && e.getCause().getMessage().equals("clicking displayed expanded margin must select the player");
                    if(!reproduced)throw new AssertionError("Previous-version regression failed for an unrelated reason",e.getCause());
                }
                if(!reproduced)throw new AssertionError("Reported manual-picking regression not reproduced in pinned 0.4.7");
                System.out.println("Reproduced 0.4.7: native ray misses the expanded margin and the player is not selected");
            }
            try(URLClassLoader l=new URLClassLoader(new URL[]{classes.toUri().toURL(),Path.of(args[1]).toUri().toURL()},ClassLoader.getPlatformClassLoader())){
                try{for(String probe:List.of("RewriteProbe", "Aura046Probe", "Targeting046Probe", "Integrated046Probe", "Speed047Probe", "Hitboxes048Probe")) l.loadClass(probe).getMethod("main",String[].class).invoke(null,(Object)new String[]{});}
                catch(java.lang.reflect.InvocationTargetException e){throw new AssertionError("Actual controller fixture failed",e.getCause());}
            }
            // Replace only the four fixture module implementations with the actual patched
            // classes. Retain constructors and exposed replacement entrypoints, excluding
            // unrelated renderer methods whose native dependencies are absent in this test.
            try(ZipFile zip=new ZipFile(args[1])){
                for(String name:List.of("u0","u1","u3","u20")){
                    ClassNode c=new ClassNode();new ClassReader(zip.getInputStream(zip.getEntry("pulse/n9ezz/"+name+".class")).readAllBytes()).accept(c,0);
                    Set<String> keep=name.equals("u20")?Set.of("<init>","input","onEnable","onDisable"):Set.of("<init>","tick","reset","target","controlsView","frame","effectiveCps");
                    c.methods.removeIf(m->!keep.contains(m.name));ClassWriter w=new ClassWriter(0);c.accept(w);Files.write(classes.resolve("pulse/n9ezz/"+name+".class"),w.toByteArray());
                }
            }
            try(URLClassLoader l=new URLClassLoader(new URL[]{classes.toUri().toURL(),Path.of(args[1]).toUri().toURL()},ClassLoader.getPlatformClassLoader())){
                try{l.loadClass("AdapterProbe").getMethod("main",String[].class).invoke(null,(Object)new String[]{});}
                catch(java.lang.reflect.InvocationTargetException e){throw new AssertionError("Actual module adapter failed",e.getCause());}
            }
        }finally{try(var walk=Files.walk(temp)){for(Path p:walk.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
    }
}
