#!/usr/bin/env python3
"""Packaged installer migration, profile preservation and idempotence; no game launch."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile

jar = Path(sys.argv[1]).resolve()
checks = 0

def check(ok, why):
    global checks
    checks += 1
    if not ok:
        raise AssertionError(why)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value)

def invoke(home):
    p = subprocess.run(['java', '-jar', str(jar), '--install', '--game-dir', str(home)], capture_output=True, text=True)
    if p.returncode:
        raise AssertionError(p.stdout + p.stderr)
    return json.loads(p.stdout)

with tempfile.TemporaryDirectory(prefix='pulsevisuals-migration-') as temporary:
    home = Path(temporary)
    write(home/'versions/1.21.11/1.21.11.json', json.dumps({'id':'1.21.11','javaVersion':{'majorVersion':21}}))
    with zipfile.ZipFile(home/'versions/1.21.11/1.21.11.jar', 'w') as z:
        z.writestr('FIXTURE.txt', 'Installer metadata test only; no Minecraft binary')
    legacy = {'name':'N9Ezz Universal', 'n9ezzManaged':True, 'lastVersionId':'N9Ezz-Universal-1.21.11',
              'javaArgs':'-Xmx4G', 'javaDir':'C:/Java21/bin/javaw.exe', 'created':'2025-01-01T00:00:00Z',
              'lastUsed':'2026-10-18T00:00:00Z', 'icon':'Grass', 'custom':{'keep':True}}
    write(home/'launcher_profiles.json',json.dumps({'profiles':{'N9Ezz-Universal-1.21.11':legacy},'settings':{'custom':True}}))
    old = home/'n9ezz-universal'
    paths = {'config/n9ezz/power.properties':'mode=hight','pulse/config/pulse.cfg':'profile',
             'pulse.cfg':'root profile','options.txt':'key-key.attack:key.mouse.left',
             'mods/thirdparty.jar':'must not copy','logs/latest.log':'must not copy log'}
    for rel,text in paths.items(): write(old/rel,text)
    fresh = home/'profiles/fabric-loader-0.19.3-1.21.4'
    write(fresh/'options.txt','user current settings')
    report = invoke(home)
    check(report['settingsMigrated']==3,'three missing configuration files copied')
    check(report['profile']=='fabric-loader-0.19.3-1.21.4','new version ID')
    profiles_path = home/'launcher_profiles.json'
    root = json.loads(profiles_path.read_text())
    check(root['profiles']['N9Ezz-Universal-1.21.11']==legacy,'old launcher profile unchanged')
    profile = root['profiles'][report['profileKey']]
    check(len(report['profileKey'])==32 and all(c in '0123456789abcdef' for c in report['profileKey']),'stable hexadecimal launcher key')
    for key in ('javaArgs','javaDir','created','lastUsed','icon','custom'):
        check(profile[key]==legacy[key], 'preserve launcher preference '+key)
    check(profile['lastVersionId']==report['profile'] and profile['pulsevisualsManaged'],'new profile points to new version')
    check(profile['gameDir']==str(fresh),'new profile directory')
    check(root['settings']=={'custom':True},'launcher settings untouched')
    check((fresh/'config/fabric-loader-0.19.3-1.21.4/power.properties').read_text()=='mode=hight','power config renamed')
    check((fresh/'fabric-loader-0.19.3-1.21.4/config/fabric-loader-0.19.3-1.21.4.cfg').read_text()=='profile','nested config renamed')
    check((fresh/'fabric-loader-0.19.3-1.21.4.cfg').read_text()=='root profile','root config renamed')
    check((fresh/'options.txt').read_text()=='user current settings','existing destination wins')
    check(not (fresh/'mods/thirdparty.jar').exists() and not (fresh/'logs/latest.log').exists(),'external mods and logs not migrated')
    for rel,text in paths.items():check((old/rel).read_text()==text,'legacy data preserved '+rel)
    before = profiles_path.read_bytes()
    stamp = profiles_path.stat().st_mtime_ns
    repeat = invoke(home)
    check(repeat['settingsMigrated']==0,'repeat copies nothing')
    check(profiles_path.read_bytes()==before and profiles_path.stat().st_mtime_ns==stamp,'repeat preserves exact launcher bytes and timestamp')
    cache = Path(report['clientPath'])
    check('.fabric-loader-0.19.3-1.21.4/builtin' in str(cache) and hashlib.sha256(cache.read_bytes()).hexdigest()==report['clientSha256'],'verified client under new cache path')

    # Reuse the installed library/cache for all metadata cases: each case changes
    # only the launcher input, not a duplicate 50 MB client fixture.
    canonical_key = report['profileKey']
    seed = copy.deepcopy(profile)
    seed.update({
        'name':'Мой переименованный профиль',
        'javaArgs':'-Xmx8G -Dfixture.keep=true',
        'javaDir':'C:/My Java/bin/javaw.exe',
        'created':'2024-02-03T04:05:06Z',
        'lastUsed':'2026-10-18T08:09:10Z',
        'custom':{'nested':['keep',17,False]},
    })

    def metadata_case(entries, label):
        """Exercise the packaged CLI and its exact backup/idempotence behavior."""
        input_root = {'profiles':copy.deepcopy(entries), 'settings':{'keep':'launcher'},
                      'customRoot':{'nested':[1,2,3]}}
        write(profiles_path,json.dumps(input_root,ensure_ascii=False,indent=3)+'\n')
        input_bytes = profiles_path.read_bytes()
        existing_backups = set((home/'.fabric-loader-0.19.3-1.21.4/backups').rglob('launcher_profiles.json'))
        result = invoke(home)
        output = json.loads(profiles_path.read_text())
        check(output['settings']==input_root['settings'] and output['customRoot']==input_root['customRoot'],
              label+': unrelated root settings preserved')
        new_backups = set((home/'.fabric-loader-0.19.3-1.21.4/backups').rglob('launcher_profiles.json'))-existing_backups
        check(any(p.read_bytes()==input_bytes for p in new_backups),
              label+': exact input launcher JSON backed up')
        final_bytes = profiles_path.read_bytes()
        final_stamp = profiles_path.stat().st_mtime_ns
        repeated = invoke(home)
        check(repeated['profileKey']==result['profileKey'],label+': repeat uses same key')
        check(profiles_path.read_bytes()==final_bytes and profiles_path.stat().st_mtime_ns==final_stamp,
              label+': repeat preserves exact bytes and timestamp')
        return result, output

    def check_preferences(actual, label):
        for key in ('name','javaArgs','javaDir','created','lastUsed','custom'):
            check(actual[key]==seed[key],label+': preserve '+key)
        check(actual['lastVersionId']==report['profile'],label+': correct version identity')
        check(actual['gameDir']==str(fresh),label+': canonical installation directory')
        check(actual['pulsevisualsManaged'] is True,label+': restore advisory marker')

    # Third-party launchers can discard unknown properties. Marker type/value is
    # never ownership evidence; recognized version + directory is what matters.
    for label, value in [('missing',None),('false',False),('string','not-a-boolean'),
                         ('null',None),('array',[]),('object',{'unexpected':True})]:
        candidate = copy.deepcopy(seed)
        if label=='missing':
            candidate.pop('pulsevisualsManaged',None)
        else:
            candidate['pulsevisualsManaged']=value
        # The directory is the same despite a redundant parent segment. Its
        # normalization is native to the test host; this is not a Windows run.
        candidate['gameDir']=str(fresh/'..'/'fabric-loader-0.19.3-1.21.4')
        result, output = metadata_case({canonical_key:candidate},'marker '+label)
        check(result['profileKey']==canonical_key and len(output['profiles'])==1,
              'marker '+label+': existing profile reused without duplicate')
        check_preferences(output['profiles'][canonical_key],'marker '+label)

    changed_key = '11111111111111111111111111111111'
    moved = copy.deepcopy(seed)
    moved.pop('pulsevisualsManaged',None)
    result, output = metadata_case({changed_key:moved},'launcher rewrote profile key')
    check(result['profileKey']==changed_key and len(output['profiles'])==1,
          'find existing installation under a different launcher key')
    check_preferences(output['profiles'][changed_key],'rewritten key')

    # A collision is not permission to overwrite another profile, even if it
    # carries our old flag or malformed JSON values.
    foreign_cases = [
        ('unmanaged foreign',{'name':'User profile'}),
        ('flag with other version',{**seed,'lastVersionId':'some-other-version'}),
        ('flag with other directory',{**seed,'gameDir':str(home/'other-instance')}),
        ('malformed value','do not replace this'),
        ('null value',None),
        ('array value',[{'keep':True}]),
        ('malformed directory',{**seed,'gameDir':['not','a','path']}),
        ('malformed version',{**seed,'lastVersionId':{'version':'not a string'}}),
    ]
    alternate_key = None
    for label, foreign in foreign_cases:
        result, output = metadata_case({canonical_key:foreign},label)
        check(output['profiles'][canonical_key]==foreign,label+': foreign entry preserved exactly')
        key = result['profileKey']
        check(key!=canonical_key and len(key)==32 and all(c in '0123456789abcdef' for c in key),
              label+': allocate separate hexadecimal key')
        check(len(output['profiles'])==2,label+': add exactly one managed profile')
        created = output['profiles'][key]
        check(created['lastVersionId']==report['profile'] and created['gameDir']==str(fresh)
              and created['pulsevisualsManaged'] is True,label+': new profile has correct identity')
        if alternate_key is None:
            alternate_key = key
        else:
            check(key==alternate_key,label+': deterministic alternate key for this installation')

    occupied = {'name':'Another unrelated profile','custom':{'do':'not overwrite'}}
    foreign = {'name':'User profile'}
    result, output = metadata_case({canonical_key:foreign,alternate_key:occupied},'alternate key occupied')
    check(output['profiles'][canonical_key]==foreign and output['profiles'][alternate_key]==occupied,
          'both occupied profile keys preserved')
    check(result['profileKey'] not in (canonical_key,alternate_key) and len(output['profiles'])==3,
          'allocate another free key without deleting either collision')

    # Both preceding generations can exist. Latest PulseVisuals settings and
    # preferences win over N9Ezz; the already existing new destination wins over both.
    renamed_home = home/'two-generations'
    write(renamed_home/'versions/1.21.11/1.21.11.json', json.dumps({'id':'1.21.11','javaVersion':{'majorVersion':21}}))
    with zipfile.ZipFile(renamed_home/'versions/1.21.11/1.21.11.jar','w') as z:
        z.writestr('FIXTURE.txt','Installer metadata only')
    recent_dir = renamed_home/'pulsevisuals-universal'
    oldest_dir = renamed_home/'n9ezz-universal'
    destination = renamed_home/'profiles/fabric-loader-0.19.3-1.21.4'
    recent_profile = {**legacy, 'name':'Recent renamed profile', 'lastVersionId':'PulseVisuals-Universal-1.21.11',
                      'gameDir':str(recent_dir), 'javaArgs':'-Xmx9G', 'custom':{'recent':True}}
    recent_profile.pop('n9ezzManaged',None) # Identity works without an advisory flag.
    initial_root = {'profiles':{'N9Ezz-Universal-1.21.11':legacy,'opaque-recent-key':recent_profile}}
    write(renamed_home/'launcher_profiles.json',json.dumps(initial_root))
    recent_files = {'config/pulsevisuals/power.properties':'recent power',
                    'config/n9ezz/power.properties':'stale duplicate',
                    'pulsevisuals/config/pulsevisuals.cfg':'recent nested',
                    'pulsevisuals.cfg':'recent root','options.txt':'recent options',
                    'mods/keep.jar':'do not copy','logs/latest.log':'do not copy log'}
    oldest_files = {'config/n9ezz/power.properties':'old power',
                    'config/n9ezz/only-old.properties':'fallback',
                    'pulse/config/pulse.cfg':'old nested','pulse.cfg':'old root','options.txt':'old options'}
    for rel,value in recent_files.items():write(recent_dir/rel,value)
    for rel,value in oldest_files.items():write(oldest_dir/rel,value)
    write(destination/'config/fabric-loader-0.19.3-1.21.4/power.properties','current wins')
    migrated = invoke(renamed_home)
    check(migrated['settingsMigrated']==4,'two generations copy four missing destinations')
    renamed_root=json.loads((renamed_home/'launcher_profiles.json').read_text())
    check(renamed_root['profiles']['opaque-recent-key']==recent_profile,'previous PulseVisuals profile unchanged')
    check(renamed_root['profiles']['N9Ezz-Universal-1.21.11']==legacy,'oldest profile unchanged after two-generation migration')
    new_profile=renamed_root['profiles'][migrated['profileKey']]
    check(new_profile['javaArgs']=='-Xmx9G' and new_profile['custom']=={'recent':True},'latest profile preferences take precedence')
    check(new_profile['name']=='fabric-loader-0.19.3-1.21.4','new display distinguishes file label from actual Minecraft version')
    check(new_profile['gameDir']==str(destination),'neutral instance path is used')
    check(migrated['minecraft']=='1.21.11','file rename never downgrades Minecraft')
    check((destination/'config/fabric-loader-0.19.3-1.21.4/power.properties').read_text()=='current wins','new destination still wins over both generations')
    check((destination/'fabric-loader-0.19.3-1.21.4/config/fabric-loader-0.19.3-1.21.4.cfg').read_text()=='recent nested','latest nested config wins')
    check((destination/'fabric-loader-0.19.3-1.21.4.cfg').read_text()=='recent root','latest root config wins')
    check((destination/'options.txt').read_text()=='recent options','latest options win')
    check((destination/'config/fabric-loader-0.19.3-1.21.4/only-old.properties').read_text()=='fallback','oldest missing config remains available')
    check(not (destination/'mods/keep.jar').exists() and not (destination/'logs/latest.log').exists(),'neither external mods nor logs migrate')
    for rel,value in recent_files.items():check((recent_dir/rel).read_text()==value,'recent source preserved '+rel)
    for rel,value in oldest_files.items():check((oldest_dir/rel).read_text()==value,'oldest source preserved '+rel)
    second=invoke(renamed_home)
    check(second['settingsMigrated']==0 and second['profileKey']==migrated['profileKey'],'neutral path update is idempotent')
    version=json.loads((renamed_home/'versions/fabric-loader-0.19.3-1.21.4/fabric-loader-0.19.3-1.21.4.json').read_text())
    check(version['inheritsFrom']=='1.21.11','launcher inherits actual game version')
    check(version['libraries'][0]['name'].startswith('local.profile:fabric-loader-0.19.3-1.21.4:'),'neutral loader library coordinate')
    # Symlink rejection happens during plan validation, before metadata publication.
    (recent_dir/'config/pulsevisuals/linked.properties').symlink_to(recent_dir/'options.txt')
    stable_profiles=(renamed_home/'launcher_profiles.json').read_bytes()
    rejected=subprocess.run(['java','-jar',str(jar),'--install','--game-dir',str(renamed_home)],capture_output=True,text=True)
    check(rejected.returncode!=0 and 'Symlink' in rejected.stderr+rejected.stdout,'legacy symlink configuration rejected')
    check((renamed_home/'launcher_profiles.json').read_bytes()==stable_profiles,'symlink rejection preserves launcher metadata')

    # Upgrade the actual 0.4.6 paths. Saving module values is essential: a rename
    # must not silently reset Aura/Trigger settings while changing only Speed.
    upgrade = home/'upgrade-046'
    write(upgrade/'versions/1.21.11/1.21.11.json',json.dumps({'id':'1.21.11','javaVersion':{'majorVersion':21}}))
    with zipfile.ZipFile(upgrade/'versions/1.21.11/1.21.11.jar','w') as z:z.writestr('FIXTURE.txt','metadata fixture')
    previous_dir=upgrade/'profiles/client-1.21.11'
    previous_profile={'name':'Client profile (Minecraft 1.21.11)','lastVersionId':'Client-Universal-1.21.11',
                      'gameDir':str(previous_dir),'javaArgs':'-Xmx7G','custom':{'046':True}}
    write(upgrade/'launcher_profiles.json',json.dumps({'profiles':{'previous':previous_profile}}))
    previous_files={'config/client-profile/power.properties':'046 settings',
                    'client-profile/config/client-profile.cfg':'046 Aura/Trigger settings',
                    'client-profile/power-mode.json':'046 power mode',
                    'client-profile/friends.json':'046 friends',
                    'client-profile/configs/duel.json':'046 snapshot',
                    'client-profile.cfg':'046 root','options.txt':'046 keys',
                    'logs/latest.log':'private log','mods/private.jar':'private mod'}
    for rel,value in previous_files.items():write(previous_dir/rel,value)
    write(upgrade/'pulsevisuals-universal/pulsevisuals.cfg','older root')
    result=invoke(upgrade)
    latest=upgrade/'profiles/fabric-loader-0.19.3-1.21.4'
    profiles=json.loads((upgrade/'launcher_profiles.json').read_text())['profiles']
    check(profiles['previous']==previous_profile,'046 profile preserved exactly')
    selected=profiles[result['profileKey']]
    check(selected['name']=='fabric-loader-0.19.3-1.21.4','requested profile label exact')
    check(selected['javaArgs']=='-Xmx7G' and selected['custom']=={'046':True},'046 launcher preferences copied')
    check((latest/'config/fabric-loader-0.19.3-1.21.4/power.properties').read_text()=='046 settings','046 power settings migrated')
    check((latest/'fabric-loader-0.19.3-1.21.4/config/fabric-loader-0.19.3-1.21.4.cfg').read_text()=='046 Aura/Trigger settings','046 combat settings migrated intact')
    for rel in ['power-mode.json','friends.json','configs/duel.json']:
        check((latest/'fabric-loader-0.19.3-1.21.4'/rel).read_text()==(previous_dir/'client-profile'/rel).read_text(),'046 mod data migrated: '+rel)
    check((latest/'fabric-loader-0.19.3-1.21.4.cfg').read_text()=='046 root','046 root beats older branding')
    check(not (latest/'client-profile.cfg').exists() and not (latest/'client-profile').exists(),'fresh destination has no obsolete config names')
    check(not (latest/'logs/latest.log').exists() and not (latest/'mods/private.jar').exists(),'private files not migrated')
    for rel,value in previous_files.items():check((previous_dir/rel).read_text()==value,'046 source retained: '+rel)
    stable=(upgrade/'launcher_profiles.json').read_bytes();again=invoke(upgrade)
    check(again['settingsMigrated']==0 and (upgrade/'launcher_profiles.json').read_bytes()==stable,'046 upgrade repeats without edits')

    # The selected name can already belong to an actual Fabric 1.21.4 profile.
    # Reject before any writes rather than overwrite another loader's descriptor.
    conflict=home/'existing-fabric'
    write(conflict/'versions/1.21.11/1.21.11.json',json.dumps({'id':'1.21.11','javaVersion':{'majorVersion':21}}))
    with zipfile.ZipFile(conflict/'versions/1.21.11/1.21.11.jar','w') as z:z.writestr('FIXTURE.txt','metadata fixture')
    official=conflict/'versions/fabric-loader-0.19.3-1.21.4/fabric-loader-0.19.3-1.21.4.json'
    write(official,json.dumps({'id':'fabric-loader-0.19.3-1.21.4','inheritsFrom':'1.21.4','mainClass':'net.fabricmc.loader.impl.launch.knot.KnotClient'}))
    original=official.read_bytes()
    rejected=subprocess.run(['java','-jar',str(jar),'--install','--game-dir',str(conflict)],capture_output=True,text=True)
    check(rejected.returncode!=0 and 'VERSION_ID_CONFLICT' in rejected.stdout+rejected.stderr,'existing Fabric version not overwritten')
    check(official.read_bytes()==original,'existing Fabric descriptor preserved byte-for-byte')
    check(not (conflict/'libraries').exists() and not (conflict/'launcher_profiles.json').exists(),'conflict fails before metadata/library writes')

print(f'InstallerMigration PASS: {checks} checks; packaged installer, no Minecraft launch')
