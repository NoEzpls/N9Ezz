import java.util.zip.ZipFile;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Check the packaged controller and actual dispatcher wiring, not a source-text claim. */
public final class Aura049Test {
 static int checks;
 static void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
 static ClassNode read(ZipFile z,String name)throws Exception{var c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(c,0);return c;}
 public static void main(String[] args)throws Exception{
  try(var z=new ZipFile(args[1])){
   var aura=read(z,"pulse/n9ezz/AuraController");
   for(var method:aura.methods)for(var i:method.instructions)if(i instanceof MethodInsnNode m){
    check(!m.name.equals("method_36456")&&!m.name.equals("method_36457"),"Aura cannot write yaw or pitch");
    check(!m.owner.equals("pulse/n9ezz/ViewMotion"),"Aura cannot delegate a camera turn");
    check(!m.owner.startsWith("net/minecraft/class_2828"),"Aura cannot synthesize movement/look packets");
   }
   var attacks=read(z,"pulse/n9ezz/e");int visible=0,finalGate=0;
   for(var method:attacks.methods)for(var i:method.instructions)if(i instanceof MethodInsnNode m&&m.owner.equals("pulse/n9ezz/AuraController")){
    if(m.name.equals("requestVisible")){check(method.name.equals("m6"),"visibility participates in shared queue/flush validity");visible++;}
    if(m.name.equals("dispatchTarget")){check(method.name.equals("m8"),"target policy executes at actual flush");finalGate++;}
   }
   check(visible==1&&finalGate==1,"one request-scoped gate at both production sites");
   var module=read(z,"pulse/n9ezz/u0");check(module.fields.stream().anyMatch(f->f.name.equals("throughBlocks")),"new setting exposed to actual module serializer");
  }
  System.out.println("Aura049Test PASS: "+checks+" packaged camera/dispatch assertions; no server acceptance claim");
 }
}
