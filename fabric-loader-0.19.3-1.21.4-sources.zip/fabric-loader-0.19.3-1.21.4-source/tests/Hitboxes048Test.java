import java.nio.file.Path;
import java.util.*;
import java.util.zip.ZipFile;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Verify the production Mixin is actually attached to the native picking return. */
public final class Hitboxes048Test {
    static int checks;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static Object value(AnnotationNode a,String key){for(int i=0;i<a.values.size();i+=2)if(a.values.get(i).equals(key))return a.values.get(i+1);return null;}
    public static void main(String[] args)throws Exception {
        try(ZipFile z=new ZipFile(Path.of(args[1]).toFile())) {
            ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry("pulse/n9ezz/mixin/ProjectileTargetMixin.class")).readAllBytes()).accept(c,0);
            MethodNode hook=c.methods.stream().filter(m->m.name.equals("n9ezz$expandedPick")).findFirst().orElseThrow();
            String nativeArgs="Lnet/minecraft/class_1297;Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lnet/minecraft/class_238;Ljava/util/function/Predicate;D";
            check((hook.access&Opcodes.ACC_STATIC)!=0,"native static method has a static callback");
            check(hook.desc.equals("("+nativeArgs+"Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;)V"),"full native argument list captured");
            AnnotationNode injection=hook.visibleAnnotations.stream().filter(a->a.desc.equals("Lorg/spongepowered/asm/mixin/injection/Inject;")).findFirst().orElseThrow();
            check(value(injection,"method").equals(List.of("method_18075("+nativeArgs+")Lnet/minecraft/class_3966;")),"exact pinned native selection descriptor");
            check(Boolean.TRUE.equals(value(injection,"cancellable")),"RETURN handler may replace a missed result");
            check(Integer.valueOf(1).equals(value(injection,"require")),"missing hook fails loudly instead of silent no-op");
            List<?> at=(List<?>)value(injection,"at");check(at.size()==1&&"RETURN".equals(value((AnnotationNode)at.get(0),"value")),"fallback runs after native physical raycast");
            int picks=0,setters=0;
            for(var i:hook.instructions)if(i instanceof MethodInsnNode m){
                if(m.owner.equals("pulse/n9ezz/HitboxV3")&&m.name.equals("manualPick"))picks++;
                if(m.name.equals("setReturnValue"))setters++;
                check(!m.name.equals("method_2918")&&!m.name.equals("method_6104"),"selection hook does not synthesize attack/swing");
            }
            check(picks==1&&setters==1,"exactly one selector call returns into native picking");
            MethodNode physical=c.methods.stream().filter(m->m.name.equals("n9ezz$targetBox")).findFirst().orElseThrow();
            int physicalCalls=0;
            for(var i:physical.instructions)if(i instanceof MethodInsnNode m&&m.owner.equals("net/minecraft/class_1297")&&m.name.equals("method_5829"))physicalCalls++;
            check(physicalCalls==1,"first pass keeps physical priority before expansion");
            ClassNode module=new ClassNode();new ClassReader(z.getInputStream(z.getEntry("pulse/n9ezz/u3.class")).readAllBytes()).accept(module,0);
            check(module.fields.stream().anyMatch(f->f.name.equals("manualPicking")&&f.desc.equals("Lpulse/settings/BooleanSetting;")),"setting exposed to existing menu/config collector");
        }
        System.out.println("Hitboxes048Test PASS: "+checks+" production Mixin/setting wiring assertions; live Minecraft UNRUN");
    }
}
