"""Compare every client class against 0.4.9, allowing only the scoped release diff."""
from pathlib import Path
import io
import json
import sys
import zipfile

reference_loader, candidate_client = map(Path, sys.argv[1:])
with zipfile.ZipFile(reference_loader) as loader:
    metadata = json.loads(loader.read('META-INF/n9ezz/embedded-client.json'))
    reference = loader.read(metadata['resource'])
with zipfile.ZipFile(io.BytesIO(reference)) as before, zipfile.ZipFile(candidate_client) as after:
    old = {n for n in before.namelist() if n.endswith('.class')}
    new = {n for n in after.namelist() if n.endswith('.class')}
    assert old == new, 'Client classes were added or removed'
    changed = {n for n in old if before.read(n) != after.read(n)}
    expected = {'pulse/n9ezz/TriggerV2Controller.class', 'pulse/n9ezz/CombatStatus.class',
                'pulse/n9ezz/InterfaceMode.class'}
    assert changed == expected, f'Unexpected client code changes: {changed ^ expected}'
    print(json.dumps({'result': 'PASS', 'unchangedClasses': len(old) - len(changed),
                      'changedClasses': sorted(changed),
                      'preserved': 'All other client classes, including Aura, Hitboxes, Speed, settings, menu and transport'}))
