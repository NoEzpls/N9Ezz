"""Negative and positive tests of the read-only uploaded TestKit auditor."""
from pathlib import Path
import contextlib
import hashlib
import importlib.util
import io
import json
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile
import struct

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('audit', ROOT / 'testkit/tools/audit_n9ezz.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def archive(entries):
    output = io.BytesIO()
    with warnings.catch_warnings(), zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as z:
        warnings.simplefilter('ignore', UserWarning)
        for name, data in entries:
            z.writestr(name, data)
    return output.getvalue()


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def jar(self, entries=None, overrides=None, outer=None):
        client = archive(entries if entries is not None else [('fixture.class', b'NOT EXECUTABLE')])
        meta = dict(resource='embedded/client.jar', size=len(client), sha256=hashlib.sha256(client).hexdigest(),
                    minecraft='1.21.11', java=21, updateVersion='fixture')
        meta.update(overrides or {})
        path = self.root / ('input-' + str(len(list(self.root.glob('*.jar')))) + '.jar')
        path.write_bytes(archive(outer if outer is not None else [
            (audit.META, json.dumps(meta)), ('embedded/client.jar', client)]))
        return path

    def test_static_audit_never_executes_candidate(self):
        p = self.jar([('pulse/n9ezz/CompatibilityProfile.class', b'NOT EXECUTABLE')])
        with patch.object(audit.subprocess, 'run', side_effect=AssertionError('executed input')), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(audit.main([str(p), str(p), '--out', str(self.root / 'reports')]), 0)
        report = json.loads((self.root / 'reports/audit.json').read_text())
        self.assertEqual(report['status'], 'PASS')
        self.assertEqual(report['compatibility_profile_unit_test']['status'], 'SKIPPED')
        self.assertEqual(report['changed_files'], [])

    def test_absent_profile_is_skipped(self):
        value = audit.open_loader(self.jar())
        self.assertEqual(audit.java_profile_test(value, Path('absent.java'), True)['status'], 'SKIPPED')

    def test_target_comes_from_metadata(self):
        for overrides in ({'minecraft': '1.21.4'}, {'java': 17}, {'java': True}, {'java': '21'}):
            with self.subTest(overrides=overrides), self.assertRaisesRegex(ValueError, 'Unsupported target'):
                audit.open_loader(self.jar(overrides=overrides))

    def test_sha_and_size_are_checked(self):
        for overrides in ({'sha256': '0' * 64}, {'size': 1}, {'size': True}, {'size': -1}, {'sha256': 'not a digest'}):
            with self.subTest(overrides=overrides), self.assertRaises(ValueError):
                audit.open_loader(self.jar(overrides=overrides))

    def test_resource_cannot_escape_archive(self):
        for value in ('../client.jar', '/client.jar', 'C:/client.jar', 'embedded/../client.jar', 'embedded/client.txt', None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                audit.open_loader(self.jar(overrides={'resource': value}))

    def test_unsafe_and_duplicate_nested_names(self):
        for name in ('../x.class', 'a//x.class', 'a/./x.class', '/x.class', 'C:/x.class', 'a\\x.class'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                audit.open_loader(self.jar([(name, b'a')]))
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            audit.open_loader(self.jar([('same.class', b'a'), ('same.class', b'b')]))

    def test_duplicate_outer_and_metadata_fields(self):
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            audit.open_loader(self.jar(outer=[(audit.META, '{}'), (audit.META, '{}')]))
        with self.assertRaisesRegex(ValueError, 'Duplicate metadata'):
            audit.open_loader(self.jar(outer=[(audit.META, '{"size":1,"size":2}')]))

    def test_symlink_is_rejected(self):
        link = zipfile.ZipInfo('link.class')
        link.create_system = 3
        link.external_attr = 0o120777 << 16
        with self.assertRaisesRegex(ValueError, 'symlink'):
            audit.open_loader(self.jar([(link, b'target')]))

    def test_corrupt_crc_is_rejected(self):
        p = self.jar(outer=[('payload', b'UNIQUE-CONTENT')])
        data = p.read_bytes().replace(b'UNIQUE-CONTENT', b'BROKEN-CONTENT')
        p.write_bytes(data)
        with self.assertRaisesRegex(ValueError, 'CRC'):
            audit.open_loader(p)

    def test_budgets_apply_before_decompression(self):
        p = self.jar()
        with patch.object(audit, 'MAX_JAR_BYTES', 1), self.assertRaisesRegex(ValueError, 'budget'):
            audit.open_loader(p)
        with patch.object(audit, 'MAX_ENTRIES', 1), self.assertRaisesRegex(ValueError, 'too many'):
            audit.open_loader(p)
        with patch.object(audit, 'MAX_EXPANDED_BYTES', 1), self.assertRaisesRegex(ValueError, 'budget'):
            audit.open_loader(p)

    def test_failed_run_replaces_previous_pass(self):
        good = self.jar()
        out = self.root / 'reports'
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(audit.main([str(good), str(good), '--out', str(out)]), 0)
            self.assertEqual(audit.main([str(good), str(self.root / 'missing.jar'), '--out', str(out)]), 1)
        self.assertEqual(json.loads((out / 'audit.json').read_text())['status'], 'FAIL')
        self.assertIn('FAIL', (out / 'audit.txt').read_text())

    def test_corrupt_deflate_replaces_previous_pass(self):
        good = self.jar()
        bad = self.root / 'corrupt-deflate.jar'
        with zipfile.ZipFile(bad, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('payload', b'compressible-data' * 30)
        data = bytearray(bad.read_bytes())
        name_length, extra_length = struct.unpack_from('<HH', data, 26)
        data[30 + name_length + extra_length] = 0x07  # Reserved DEFLATE block type.
        bad.write_bytes(data)
        out = self.root / 'reports'
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(audit.main([str(good), str(good), '--out', str(out)]), 0)
            self.assertEqual(audit.main([str(good), str(bad), '--out', str(out)]), 1)
        report = json.loads((out / 'audit.json').read_text())
        self.assertEqual(report['status'], 'FAIL')
        self.assertIn('invalid block type', report['checks'][0]['reason'])

    def test_truncated_decompression_replaces_previous_pass(self):
        good = self.jar()
        out = self.root / 'reports'
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(audit.main([str(good), str(good), '--out', str(out)]), 0)
            with patch.object(audit, 'open_loader', side_effect=EOFError('truncated compressed stream')):
                self.assertEqual(audit.main([str(good), str(good), '--out', str(out)]), 1)
        self.assertEqual(json.loads((out / 'audit.json').read_text())['status'], 'FAIL')

    def test_actual_byte_differences_reported(self):
        a = self.jar([('same.class', b'1'), ('changed.class', b'a'), ('removed.class', b'0')])
        b = self.jar([('same.class', b'1'), ('changed.class', b'b'), ('added.class', b'0')])
        out = self.root / 'reports'
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(audit.main([str(a), str(b), '--out', str(out)]), 0)
        report = json.loads((out / 'audit.json').read_text())
        self.assertEqual(report['changed_files'], ['changed.class'])
        self.assertEqual(report['added_files'], ['added.class'])
        self.assertEqual(report['removed_files'], ['removed.class'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
