from pathlib import Path
import hashlib
import shutil

def apply(loader_root: Path, overlay: Path):
    # Paths and visible labels only: retain descriptor names, ABI packages and mod IDs.
    pairs = {'.n9ezz/':'.fabric-loader-0.19.3-1.21.4/', '.n9ezz-backups':'.fabric-loader-0.19.3-1.21.4/backups',
             '.n9ezz-install.lock':'.fabric-loader-0.19.3-1.21.4/install.lock',
             # Replace path components, not arbitrary prefixes. A slash inside
             # a Java temporary-directory prefix makes createTempDirectory fail.
             'n9ezz-universal/':'profiles/fabric-loader-0.19.3-1.21.4/',
             '"n9ezz-universal"':'"profiles/fabric-loader-0.19.3-1.21.4"',
             'embedded/n9ezz-client-1.5.3.jar':'embedded/fabric-loader-0.19.3-1.21.4-1.5.3.jar',
             'dev/n9ezz/universal-loader/':'local/profile/fabric-loader-0.19.3-1.21.4/',
             '/universal-loader-':'/fabric-loader-0.19.3-1.21.4-',
             'dev.n9ezz:universal-loader:':'local.profile:fabric-loader-0.19.3-1.21.4:'}
    for area in ('src','scripts'):
        for p in (loader_root/area).rglob('*'):
            if not p.is_file() or p.suffix not in ('.java','.py','.json'): continue
            s=p.read_text(encoding="utf-8")
            for a,b in pairs.items():s=s.replace(a,b)
            # Some cache paths are assembled from a directory component, not a slash path.
            s=s.replace('".n9ezz"', '".fabric-loader-0.19.3-1.21.4"').replace('/.n9ezz"', '/.fabric-loader-0.19.3-1.21.4"')
            # No Java identifiers named N9Ezz occur in this loader implementation.
            s=s.replace('N9Ezz-Universal-1.21.11','fabric-loader-0.19.3-1.21.4')
            s=s.replace('N9Ezz','PulseVisuals')
            p.write_text(s, encoding="utf-8")
    for p in overlay.rglob('*.java'):
        target=loader_root/p.relative_to(overlay);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    smoke=loader_root/'scripts/installer_smoke.py'
    s=smoke.read_text(encoding="utf-8")
    h=bytearray(hashlib.md5(b'fabric-loader-0.19.3-1.21.4:custom:1.21.11').digest());h[6]=(h[6]&15)|48;h[8]=(h[8]&63)|128
    s=s.replace('PROFILE = "fabric-loader-0.19.3-1.21.4"','PROFILE = "fabric-loader-0.19.3-1.21.4"\nPROFILE_KEY = "'+h.hex()+'"')
    s=s.replace('{PROFILE: {"name": "User profile"}}','{PROFILE_KEY: {"name": "User profile"}}')
    # The requested label contains 'fabric'. Verify the launch engine/coordinate,
    # not the absence of that substring in user-visible metadata.
    engine_check = 'assert len(version["libraries"]) == 1 and "fabric" not in json.dumps(version).lower()'
    if s.count(engine_check) != 1:
        raise RuntimeError("Pinned single-engine assertion changed")
    s=s.replace(engine_check, 'assert len(version["libraries"]) == 1 and version["mainClass"] == "dev.n9ezz.loader.launch.GameBootstrap" and version["inheritsFrom"] == "1.21.11"')
    # A key collision now creates a separate profile instead of aborting installation.
    # Preserve the old safety assertion and add stable repeat/backup assertions for
    # the newly supported success path; unrelated profile data is never overwritten.
    previous = '''    invoke(foreign_profile, False)
    assert (foreign_profile / "launcher_profiles.json").read_bytes() == foreign
    assert not (foreign_profile / "libraries").exists()
    case("foreign profile with same id is preserved")'''
    replacement = '''    foreign_report = json.loads(invoke(foreign_profile, True).stdout)
    foreign_path = foreign_profile / "launcher_profiles.json"
    foreign_root = json.loads(foreign_path.read_text(encoding="utf-8"))
    assert foreign_report["profileKey"] != PROFILE_KEY
    assert foreign_root["profiles"][PROFILE_KEY] == {"name": "User profile"}
    assert len(foreign_root["profiles"]) == 2
    assert foreign_root["profiles"][foreign_report["profileKey"]]["lastVersionId"] == PROFILE
    saved = list((foreign_profile / ".fabric-loader-0.19.3-1.21.4/backups").rglob("launcher_profiles.json"))
    assert len(saved) == 1 and saved[0].read_bytes() == foreign
    fixed_bytes = foreign_path.read_bytes()
    fixed_stamp = foreign_path.stat().st_mtime_ns
    repeat_foreign = json.loads(invoke(foreign_profile, True).stdout)
    assert repeat_foreign["profileKey"] == foreign_report["profileKey"]
    assert foreign_path.read_bytes() == fixed_bytes and foreign_path.stat().st_mtime_ns == fixed_stamp
    case("foreign profile preserved; separate stable profile created with exact backup")'''
    if s.count(previous) != 1:
        raise RuntimeError("Pinned foreign-profile test fixture changed; inspect before updating")
    s=s.replace(previous, replacement)
    smoke.write_text(s, encoding="utf-8")
