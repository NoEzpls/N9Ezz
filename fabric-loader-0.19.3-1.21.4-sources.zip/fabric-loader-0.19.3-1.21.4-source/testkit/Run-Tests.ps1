param(
  [Parameter(Mandatory=$true)][string]$Baseline,
  [Parameter(Mandatory=$true)][string]$Candidate
)
$ErrorActionPreference = 'Stop'
$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
New-Item -ItemType Directory -Force -Path (Join-Path $folder 'reports') | Out-Null
python (Join-Path $folder 'tools/audit_n9ezz.py') $Baseline $Candidate --out (Join-Path $folder 'reports')
if ($LASTEXITCODE -ne 0) { throw "Audit failed, exit code $LASTEXITCODE" }
Write-Host "Reports saved to $folder\reports"
