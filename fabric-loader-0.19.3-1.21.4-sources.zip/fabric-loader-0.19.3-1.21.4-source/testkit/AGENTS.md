# Instructions for Codex in this repository

- Project: N9Ezz custom loader for Minecraft Java **1.21.11**, targeting **Java 21**. The `fabric-loader-0.19.3-1.21.4` filename is a legacy label, not the target game version.
- Never confuse archive checksum/unit-test success with a real Minecraft launch, RaidMine server result, or anti-cheat bypass.
- Before and after changing source code, run the existing tests and `python tools/audit_n9ezz.py BASELINE_JAR CANDIDATE_JAR --out reports` when JARs are provided.
- The offline audit must not launch a server, make network requests, or execute untrusted downloaded binaries.
- For real gameplay testing, require an isolated server under the owner's control, a separate test account, logs/metrics and explicit test permissions. Do not test on public player sessions.
- Report PASS/FAIL/SKIPPED separately; give exact commands and attach `reports/audit.json` and `reports/audit.txt`.
- Do not state a guaranteed no-ban percentage. Calculate detection rates only from actual labeled tests with declared scenarios and sample sizes.
- Never rewrite or hide server-side detection logs; retain all original test data.
- Before editing mod behavior, make a backup and describe the diff and its tradeoffs.
