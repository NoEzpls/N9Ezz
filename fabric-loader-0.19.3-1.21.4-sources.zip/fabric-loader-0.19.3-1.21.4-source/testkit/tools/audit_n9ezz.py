#!/usr/bin/env python3
"""Read-only, offline inspection of N9Ezz custom-loader JAR files.

Usage: python tools/audit_n9ezz.py BASELINE_JAR CANDIDATE_JAR [--out reports]
The default audit never runs code from an input JAR or contacts a server.
--run-profile-test opts into executing CompatibilityProfile from a TRUSTED build.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import zipfile
import zlib

META = 'META-INF/n9ezz/embedded-client.json'
KNOWN_CLASSES = [
    'pulse/n9ezz/AuraController.class',
    'pulse/n9ezz/TriggerV2Controller.class',
    'pulse/n9ezz/HitboxV3.class',
    'pulse/n9ezz/CompatibilityProfile.class',
]
MAX_JAR_BYTES = 256 * 1024 * 1024
MAX_EXPANDED_BYTES = 512 * 1024 * 1024
MAX_ENTRIES = 50_000
MAX_META_BYTES = 64 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    # Reject ambiguous names before either zipfile or a class loader interprets
    # them. Duplicate entries must never depend on first/last-entry precedence.
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name or ':' in name:
        raise ValueError('Unsafe archive path: ' + repr(name))
    parts = name.rstrip('/').split('/')
    if PurePosixPath(name).is_absolute() or any(p in ('', '.', '..') for p in parts):
        raise ValueError('Unsafe archive path: ' + repr(name))
    return name


def checked_entries(archive, label):
    entries = archive.infolist()
    if len(entries) > MAX_ENTRIES:
        raise ValueError(label + ': too many entries')
    seen = set()
    total = 0
    for item in entries:
        name = safe_name(item.orig_filename)
        if name != item.filename or name in seen:
            raise ValueError(label + ': duplicate or truncated entry: ' + repr(name))
        seen.add(name)
        if item.flag_bits & 1:
            raise ValueError(label + ': encrypted entries are unsupported')
        if stat.S_ISLNK(item.external_attr >> 16):
            raise ValueError(label + ': symlink entry: ' + repr(name))
        total += item.file_size
        if item.file_size > MAX_JAR_BYTES or total > MAX_EXPANDED_BYTES:
            raise ValueError(label + ': decompression budget exceeded')
    broken = archive.testzip()
    if broken:
        raise ValueError(label + ': bad CRC: ' + broken)
    return entries


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate metadata field: ' + key)
        result[key] = value
    return result


def validate_metadata(metadata):
    if not isinstance(metadata, dict):
        raise ValueError('Embedded metadata must be an object')
    resource = safe_name(metadata.get('resource'))
    if not resource.startswith('embedded/') or not resource.endswith('.jar'):
        raise ValueError('Embedded resource must be an embedded/*.jar entry')
    size = metadata.get('size')
    if type(size) is not int or not 0 < size <= MAX_JAR_BYTES:
        raise ValueError('Embedded size must be a positive bounded integer')
    digest = metadata.get('sha256')
    if not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest):
        raise ValueError('Embedded SHA-256 must be 64 lowercase hexadecimal digits')
    # The filename is a historical label, never a source of target-version data.
    if metadata.get('minecraft') != '1.21.11' or type(metadata.get('java')) is not int or metadata['java'] != 21:
        raise ValueError('Unsupported target: expected Minecraft 1.21.11 / Java 21')
    return resource


def open_loader(path):
    path = Path(path)
    if path.stat().st_size > MAX_JAR_BYTES:
        raise ValueError('Loader exceeds audit size budget: ' + str(path))
    blob = path.read_bytes()
    try:
        with zipfile.ZipFile(io.BytesIO(blob)) as archive:
            checked_entries(archive, 'outer JAR')
            if archive.getinfo(META).file_size > MAX_META_BYTES:
                raise ValueError('Embedded metadata exceeds size budget')
            metadata = json.loads(archive.read(META), object_pairs_hook=unique_json)
            resource = validate_metadata(metadata)
            if archive.getinfo(resource).file_size != metadata['size']:
                raise ValueError('Embedded client size differs from metadata')
            client = archive.read(resource)
            if metadata['sha256'] != sha(client):
                raise ValueError('Embedded client SHA-256 differs from metadata')
            with zipfile.ZipFile(io.BytesIO(client)) as nested:
                entries = checked_entries(nested, 'embedded JAR')
                files = {item.filename: sha(nested.read(item)) for item in entries if not item.is_dir()}
        return {'name': path.name, 'size': len(blob), 'sha256': sha(blob),
                'metadata': metadata, 'client': client, 'files': files}
    except (KeyError, json.JSONDecodeError, zipfile.BadZipFile) as error:
        raise ValueError('Not a supported custom N9Ezz loader JAR: ' + str(error)) from error


def java_profile_test(candidate, src, execute=False):
    if 'pulse/n9ezz/CompatibilityProfile.class' not in candidate['files']:
        return {'status': 'SKIPPED', 'reason': 'CompatibilityProfile is absent from this candidate'}
    if not execute:
        return {'status': 'SKIPPED', 'reason': 'Static audit; --run-profile-test is required to execute a trusted candidate'}
    if not shutil.which('java') or not shutil.which('javac'):
        return {'status': 'SKIPPED', 'reason': 'Requires JDK 21 (java + javac)'}
    if not src.is_file():
        return {'status': 'FAIL', 'reason': 'Missing ProfileTests.java'}
    try:
        for executable in ('java', 'javac'):
            version = subprocess.run([executable, '-version'], capture_output=True, text=True, timeout=20)
            output = (version.stdout + version.stderr).strip()
            pattern = r'\bjavac 21(?:\.|\s|$)' if executable == 'javac' else r'\bversion "21(?:\.|"|-)'
            if version.returncode or not re.search(pattern, output):
                return {'status': 'SKIPPED', 'reason': 'JDK 21 required; ' + executable + ': ' + output[:300]}
        with tempfile.TemporaryDirectory(prefix='n9ezz-test-') as td:
            temp = Path(td)
            (temp / 'client.jar').write_bytes(candidate['client'])
            compile_result = subprocess.run(
                ['javac', '--release', '21', '-proc:none', '-cp', str(temp / 'client.jar'), '-d', td, str(src)],
                capture_output=True, text=True, timeout=60)
            if compile_result.returncode:
                return {'status': 'FAIL', 'reason': 'Compilation failed', 'stderr': compile_result.stderr[:2000]}
            modes = {}
            for enabled in ('true', 'false'):
                command = ['java', '-ea', f'-Dn9ezz.compatibility={enabled}', '-cp',
                           td + os.pathsep + str(temp / 'client.jar'), 'ProfileTests', enabled]
                result = subprocess.run(command, capture_output=True, text=True, timeout=20)
                modes[enabled] = {'exit_code': result.returncode, 'output': (result.stdout + result.stderr).strip()[:1200]}
            return {'status': 'PASS' if all(r['exit_code'] == 0 for r in modes.values()) else 'FAIL', 'modes': modes}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {'status': 'FAIL', 'reason': str(error)}


def write_reports(folder, report):
    lines = ['N9Ezz AUDIT: ' + report['status'], 'Scope: ' + report['scope']]
    for check in report['checks']:
        lines.append(check['name'] + ': ' + check['status'] + (' — ' + check['reason'] if 'reason' in check else ''))
    if 'candidate' in report:
        lines += [f"Target: Minecraft {report['game']} / Java {report['java']}",
                  f"Build: {report['update_version']} / embedded version: {report['client_version']}",
                  f"Embedded client changes: {len(report['changed_files'])} modified, {len(report['added_files'])} added, {len(report['removed_files'])} removed",
                  'Modified classes:']
        lines += ['  ' + name for name in report['changed_files'] if name.endswith('.class')]
    lines.append('NOTE: No real Minecraft launch, RaidMine session, RTT/loss measurement or anti-cheat result is established by this audit.')
    folder.mkdir(parents=True, exist_ok=True)
    contents = {'audit.json': json.dumps(report, ensure_ascii=False, indent=2) + '\n',
                'audit.txt': '\n'.join(lines) + '\n'}
    for name, content in contents.items():
        # A failed run replaces an earlier PASS report too; no stale success left.
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=folder, delete=False) as output:
            output.write(content)
            temporary = Path(output.name)
        temporary.replace(folder / name)
    print(contents['audit.txt'], end='')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--out', type=Path, default=Path('reports'))
    parser.add_argument('--run-profile-test', action='store_true', help='Execute CompatibilityProfile from a trusted candidate; default is static only')
    args = parser.parse_args(argv)
    report = {'check': 'N9Ezz custom loader offline audit', 'status': 'FAIL',
              'scope': 'Offline integrity and embedded differences; no Minecraft launch or server/network test',
              'checks': [], 'real_minecraft_launch': 'SKIPPED', 'raidmine_session': 'SKIPPED',
              'network_rtt_loss': 'SKIPPED', 'anticheat_bypass': 'NOT_TESTED'}
    try:
        a = open_loader(args.baseline)
        b = open_loader(args.candidate)
        changed = sorted(k for k in set(a['files']) & set(b['files']) if a['files'][k] != b['files'][k])
        added = sorted(set(b['files']) - set(a['files']))
        removed = sorted(set(a['files']) - set(b['files']))
        test_src = Path(__file__).resolve().parent.parent / 'tests' / 'ProfileTests.java'
        tests = java_profile_test(b, test_src, args.run_profile_test)
        report.update({
            'status': 'FAIL' if tests['status'] == 'FAIL' else 'PASS',
            'baseline': {key: a[key] for key in ('name', 'size', 'sha256')},
            'candidate': {key: b[key] for key in ('name', 'size', 'sha256')},
            'game': b['metadata']['minecraft'], 'java': b['metadata']['java'],
            'update_version': b['metadata'].get('updateVersion', 'UNSPECIFIED'),
            'client_version': b['metadata'].get('version', 'UNSPECIFIED'),
            'embedded_client_sha256': b['metadata']['sha256'],
            'changed_files': changed, 'added_files': added, 'removed_files': removed,
            'key_classes': {key: {'baseline': key in a['files'], 'candidate': key in b['files']} for key in KNOWN_CLASSES},
            'compatibility_profile_unit_test': tests,
        })
        report['checks'] += [
            {'name': 'Archive integrity (both inputs)', 'status': 'PASS'},
            {'name': 'Metadata target, embedded SHA-256 and length', 'status': 'PASS'},
            {'name': 'CompatibilityProfile unit test', **tests},
        ]
    # testzip() can raise a decompressor error before it returns a CRC failure.
    # Replace the prior report in that case too: a stale PASS must not survive.
    except (OSError, ValueError, RuntimeError, EOFError, zlib.error, zipfile.BadZipFile) as error:
        report['checks'].append({'name': 'Archive integrity / metadata', 'status': 'FAIL', 'reason': str(error)})
    report['checks'] += [
        {'name': 'Minecraft and RaidMine session', 'status': 'SKIPPED', 'reason': 'Requires a separate game/server integration scenario'},
        {'name': 'RTT and loss behavior', 'status': 'SKIPPED', 'reason': 'No live transport in this static audit'},
    ]
    write_reports(args.out, report)
    return 1 if report['status'] == 'FAIL' else 0


if __name__ == '__main__':
    raise SystemExit(main())
