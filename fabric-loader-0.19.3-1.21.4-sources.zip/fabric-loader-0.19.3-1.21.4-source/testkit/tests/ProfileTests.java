import pulse.n9ezz.CompatibilityProfile;
public class ProfileTests {
 public static void main(String[] args) {
  boolean expected=Boolean.parseBoolean(args[0]);
  assert CompatibilityProfile.enabled()==expected;
  assert CompatibilityProfile.allowDoubleAttack(true)==!expected;
  assert CompatibilityProfile.filterVisible(true,false)==!expected;
  assert CompatibilityProfile.filterVisible(true,true);
  Object a=new Object(), b=new Object();
  assert CompatibilityProfile.filterTarget(a,b)==(expected?null:a);
  assert CompatibilityProfile.filterTarget(a,a)==a;
  assert CompatibilityProfile.filterManualPick(a,b)==(expected?b:a);
  System.out.println("PASS: compatibility="+expected);
 }
}
