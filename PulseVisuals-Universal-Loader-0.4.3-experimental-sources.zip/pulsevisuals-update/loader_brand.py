from pathlib import Path
import hashlib
import shutil

def apply(loader_root: Path, overlay: Path):
    # Paths and visible labels only: retain descriptor names, ABI packages and mod IDs.
    pairs = {'.n9ezz/':'.pulsevisuals/', '.n9ezz-backups':'.pulsevisuals/backups',
             '.n9ezz-install.lock':'.pulsevisuals/install.lock', 'n9ezz-universal':'pulsevisuals-universal',
             'embedded/n9ezz-client-1.5.3.jar':'embedded/pulsevisuals-client-1.5.3.jar',
             'dev/n9ezz/universal-loader/':'dev/pulsevisuals/universal-loader/',
             'dev.n9ezz:universal-loader:':'dev.pulsevisuals:universal-loader:'}
    for area in ('src','scripts'):
        for p in (loader_root/area).rglob('*'):
            if not p.is_file() or p.suffix not in ('.java','.py','.json'): continue
            s=p.read_text()
            for a,b in pairs.items():s=s.replace(a,b)
            # Some cache paths are assembled from a directory component, not a slash path.
            s=s.replace('".n9ezz"', '".pulsevisuals"').replace('/.n9ezz"', '/.pulsevisuals"')
            # No Java identifiers named N9Ezz occur in this loader implementation.
            s=s.replace('N9Ezz','PulseVisuals')
            p.write_text(s)
    for p in overlay.rglob('*.java'):
        target=loader_root/p.relative_to(overlay);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    smoke=loader_root/'scripts/installer_smoke.py'
    s=smoke.read_text()
    h=bytearray(hashlib.md5(b'PulseVisuals:universal:1.21.11').digest());h[6]=(h[6]&15)|48;h[8]=(h[8]&63)|128
    s=s.replace('PROFILE = "PulseVisuals-Universal-1.21.11"','PROFILE = "PulseVisuals-Universal-1.21.11"\nPROFILE_KEY = "'+h.hex()+'"')
    s=s.replace('{PROFILE: {"name": "User profile"}}','{PROFILE_KEY: {"name": "User profile"}}')
    smoke.write_text(s)
