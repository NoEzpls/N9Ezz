import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import javax.tools.ToolProvider;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Runs patched production module/state/menu/power methods with isolated dependency fixtures. */
public final class ModuleTest implements Opcodes {
    private static int checks;
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("ModuleTest baseline.jar updated.jar");
        Path updated = Path.of(args[1]);
        try (ZipFile zip = new ZipFile(updated.toFile())) {
            structural(zip);
            Path temp = Files.createTempDirectory("n9ezz-module-fixtures-");
            try {
                Path classes = fixtures(temp, updated, zip);
                try (URLClassLoader loader = new URLClassLoader(new URL[]{classes.toUri().toURL(), updated.toUri().toURL()}, ClassLoader.getPlatformClassLoader())) {
                    stateAndRegistry(loader, zip);
                    power(loader);
                    menu(loader);
                    commands(loader);
                }
            } finally {
                try (var files = Files.walk(temp)) { for (Path p : files.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); }
            }
        }
        System.out.println("ModuleTest: PASS (" + checks + " checks; real patched methods, isolated dependencies; GUI rendering/live game not tested)");
    }
    private static void check(boolean value, String label) { checks++; if (!value) throw new AssertionError(label); }
    private static ClassNode node(ZipFile zip, String name) throws IOException {
        ClassNode n = new ClassNode();
        try (InputStream in = zip.getInputStream(zip.getEntry(name + ".class"))) { new ClassReader(in.readAllBytes()).accept(n, 0); }
        return n;
    }
    private static MethodNode method(ClassNode n, String name, String descriptor) {
        return n.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(descriptor)).findFirst().orElseThrow();
    }
    private static void structural(ZipFile zip) throws Exception {
        ClassNode state = node(zip, "pulse/module/ClientModule");
        for (String name : List.of("setEnabledState", "setEnabledStateQuiet", "setSubscribed")) {
            MethodNode m = method(state, name, "(Z)V");
            check(Arrays.stream(m.instructions.toArray()).anyMatch(i -> i instanceof MethodInsnNode call
                && call.owner.equals("pulse/n9ezz/InterfaceMode") && call.name.equals("allowActivation")), name + " uses activation policy");
        }
        ClassNode stars = node(zip, "pulse/n9ezz/Stars");
        for (String name : List.of("drawButton", "clickButton")) {
            MethodNode m = stars.methods.stream().filter(x -> x.name.equals(name)).findFirst().orElseThrow();
            check(Arrays.stream(m.instructions.toArray()).anyMatch(i -> i instanceof MethodInsnNode call
                && (call.owner.equals("pulse/n9ezz/PowerModes") || call.owner.equals("pulse/n9ezz/PowerCurve$Level"))), "working level dropdown in " + name);
        }
        ClassNode keyboard = node(zip, "ru/pulse/mixin/KeyboardMixin");
        check(keyboard.methods.stream().flatMap(m -> Arrays.stream(m.instructions.toArray())).anyMatch(i -> i instanceof MethodInsnNode call
            && call.owner.equals("ru/pulse/Pulse") && call.name.equals("getClickGui")), "GUI hotkey independent of removed module registrations");
    }
    private static void stateAndRegistry(ClassLoader l, ZipFile zip) throws Exception {
        Class<?> base = l.loadClass("pulse.module.ClientModule");
        Class<?> n9 = l.loadClass("pulse.n9ezz.N9Ezz");
        Field initialized = n9.getDeclaredField("f0"); initialized.setAccessible(true); initialized.setBoolean(null, true);
        Set<String> combat = Set.of("pulse.n9ezz.u0", "pulse.n9ezz.u1", "pulse.n9ezz.u2", "pulse.n9ezz.u3", "pulse.n9ezz.u4", "pulse.n9ezz.u5");
        List<Object> modules = new ArrayList<>();
        for (Field f : n9.getDeclaredFields()) if (f.getType().getName().matches("pulse\\.n9ezz\\.u[0-9]+")) {
            Object module = f.getType().getConstructor().newInstance(); f.set(null, module); modules.add(module);
        }
        Object[] publicModules = (Object[]) n9.getMethod("modules").invoke(null);
        check(publicModules.length == 6, "N9Ezz.modules only six");
        check(Arrays.stream(publicModules).map(o -> o.getClass().getName()).collect(java.util.stream.Collectors.toSet()).equals(combat), "six exact module identities");
        Set<String> expected = new HashSet<>(combat); expected.addAll(List.of("pulse.modules.visuals.AspectRatio", "pulse.modules.visuals.MotionBlur", "pulse.modules.utilities.Optimization"));
        Class<?> registry = l.loadClass("pulse.module.ModuleRegistry"); registry.getMethod("init").invoke(null);
        List<?> registered = (List<?>) registry.getMethod("all").invoke(null);
        check(registered.size() == 9, "six combat and three restored modules");
        for (Object o : registered) check(expected.contains(o.getClass().getName()), "registry retains wanted identity");
        check(registry.getMethod("findByName", String.class).invoke(null, "BodyGlow") == null, "removed BodyGlow not found by config name");
        for (Field f : registry.getFields()) if (base.isAssignableFrom(f.getType())) modules.add(f.get(null));
        Method enable = base.getMethod("setEnabled", boolean.class), quiet = base.getMethod("setEnabledStateQuiet", boolean.class);
        Method subscribed = base.getMethod("setSubscribed", boolean.class), toggle = base.getMethod("toggle");
        Method enabled = base.getMethod("isEnabled"), active = base.getMethod("isActive"), sub = base.getMethod("isSubscribed");
        Field ef = base.getDeclaredField("enabled"), sf = base.getDeclaredField("subscribed"); ef.setAccessible(true); sf.setAccessible(true);
        for (Object module : modules) {
            boolean allowed = expected.contains(module.getClass().getName());
            enable.invoke(module, true); check(enabled.invoke(module).equals(allowed), "normal enable " + module.getClass().getName());
            check(sub.invoke(module).equals(allowed), "normal event subscription " + module.getClass().getName());
            enable.invoke(module, false);
            quiet.invoke(module, true); check(enabled.invoke(module).equals(allowed), "legacy config/quiet enable " + module.getClass().getName());
            enable.invoke(module, false);
            toggle.invoke(module); check(enabled.invoke(module).equals(allowed), "direct toggle " + module.getClass().getName());
            enable.invoke(module, false);
            subscribed.invoke(module, true); check(sub.invoke(module).equals(allowed), "direct subscription " + module.getClass().getName());
            subscribed.invoke(module, false);
            // A stale enabled field must not revive an excluded feature after migration.
            ef.setBoolean(module, true); sf.setBoolean(module, true);
            check(enabled.invoke(module).equals(allowed) && sub.invoke(module).equals(allowed) && active.invoke(module).equals(allowed), "stale raw state read " + module.getClass().getName());
            ef.setBoolean(module, false); sf.setBoolean(module, false);
        }
        Class<?> im = l.loadClass("pulse.n9ezz.InterfaceMode"); Field hidden = im.getDeclaredField("f0"); hidden.setAccessible(true); hidden.setBoolean(null, true);
        for (Object module : publicModules) { enable.invoke(module, true); check(!(boolean) enabled.invoke(module), "hidden mode still blocks wanted module"); }
        hidden.setBoolean(null, false);
    }
    private static void power(ClassLoader l) throws Exception {
        Class<?> levels = l.loadClass("pulse.n9ezz.PowerCurve$Level"), curve = l.loadClass("pulse.n9ezz.PowerCurve");
        Method strength = curve.getMethod("strength", double.class, levels);
        for (Object level : (Object[]) levels.getMethod("values").invoke(null)) {
            double multiplier = Map.of("LEGIT",1d,"HIGHT",2.5d,"EXTRA",10d).get(((Enum<?>)level).name());
            check(((Double) levels.getMethod("multiplier").invoke(level)) == multiplier, "visible level multiplier restored");
            for (double value : new double[]{0,25,65,100}) check((Double) strength.invoke(null, value, level) == value / 100 * multiplier, "slider strength exact " + value);
            check((Double) strength.invoke(null, Double.NaN, level) == 0, "invalid power stops");
            check((Double) strength.invoke(null, Double.POSITIVE_INFINITY, level) == 0, "infinite power stops");
            check((Double) strength.invoke(null, -10, level) == 0 && (Double) strength.invoke(null, 1000, level) == multiplier, "power bounded");
        }
        for (String legacy : List.of("legit", "hight", "high", "extra")) check(levels.getMethod("parse", String.class).invoke(null, legacy) != null, "legacy level reads " + legacy);
    }
    private static void menu(ClassLoader l) throws Exception {
        // Instantiate the real production tab with harmless grid/widget fixtures.
        Class<?> tab = l.loadClass("pulse.gui.modules.ModulesTab");
        Object receiver = tab.getConstructor().newInstance();
        String[] categories = (String[]) tab.getMethod("c").invoke(receiver);
        check(Arrays.equals(categories, new String[]{"Бой","Визуальные","Оптимизация"}), "three useful categories");
        check(tab.getMethod("g").invoke(receiver).toString().equals("CHEATS"), "initial category is CHEATS");
        Method index = tab.getMethod("a", int.class), current = tab.getMethod("d");
        for (int stale : new int[]{-1,3,99}) { index.invoke(receiver, stale); check(current.invoke(receiver).equals(0), "stale selected category ignored: " + stale); }
        for (int valid : new int[]{1,2,0}) { index.invoke(receiver,valid); check(current.invoke(receiver).equals(valid), "valid category " + valid); }
        Class<?> stars = l.loadClass("pulse.n9ezz.Stars"); stars.getMethod("menuClosed").invoke(null);
        // With no active GUI, both rewritten UI methods take their real early-return path.
        Class<?> renderer = l.loadClass("pulse.render.Renderer2D");
        stars.getMethod("drawButton", tab, Object.class, renderer, float.class,float.class,int.class,int.class)
            .invoke(null, receiver, null, null, 0f,0f,0,0);
        check(!(boolean) stars.getMethod("clickButton",tab,float.class,float.class,int.class,int.class).invoke(null,receiver,0f,0f,0,0), "inactive GUI click ignored; JVM verified rewritten Stars");
        Class<?> im = l.loadClass("pulse.n9ezz.InterfaceMode"); Field hidden=im.getDeclaredField("f0");hidden.setAccessible(true);hidden.setBoolean(null,true);
        check(((String[])tab.getMethod("c").invoke(receiver)).length==3,"hidden labels do not expand to null array entries");hidden.setBoolean(null,false);
    }
    private static void commands(ClassLoader l) throws Exception {
        Class<?> im=l.loadClass("pulse.n9ezz.InterfaceMode"),base=l.loadClass("pulse.module.ClientModule");
        Method command=im.getMethod("handleCommand",String.class),enabled=base.getMethod("isEnabled"),enable=base.getMethod("setEnabled",boolean.class);
        Class<?> registry=l.loadClass("pulse.module.ModuleRegistry");List<?> modules=(List<?>)registry.getMethod("all").invoke(null);
        Object mc=l.loadClass("net.minecraft.class_310").getMethod("method_1551").invoke(null);
        Object player=l.loadClass("net.minecraft.class_746").getConstructor().newInstance();mc.getClass().getField("field_1724").set(mc,player);
        for(Object m:modules)enable.invoke(m,true);
        check((boolean)command.invoke(null," /PV HIDE "),"local hide command consumed");
        check((boolean)im.getMethod("hidden").invoke(null),"hide state set");
        for(Object m:modules)check(!(boolean)enabled.invoke(m),"hide disables " + m.getClass().getSimpleName());
        check((boolean)command.invoke(null,"/pv show"),"local show command consumed");
        check(!(boolean)im.getMethod("hidden").invoke(null),"show restores UI");
        for(Object m:modules)check(!(boolean)enabled.invoke(m),"show never silently restarts " + m.getClass().getSimpleName());
        check(!(boolean)command.invoke(null,"/pvp"),"similar server command passes through");
        check(!(boolean)command.invoke(null,"hello /pv hide"),"ordinary chat passes through");
        check((boolean)command.invoke(null,"/pv unknown"),"unknown local subcommand stays local");
        check(player.getClass().getField("messages").getInt(player)==3,"local feedback delivered");
    }
    private static Path fixtures(Path temp, Path updated, ZipFile zip) throws Exception {
        Map<String,String> src = new LinkedHashMap<>();
        src.put("pulse/client/MinecraftContext", "package pulse.client; public interface MinecraftContext {}");
        src.put("org/apache/logging/log4j/Logger", "package org.apache.logging.log4j; public interface Logger { default void info(String s,Object a,Object b){} }");
        src.put("org/apache/logging/log4j/LogManager", "package org.apache.logging.log4j; public class LogManager { public static Logger getLogger(String s){return new Logger(){};} }");
        src.put("pulse/config/LocalConfigManager", "package pulse.config; public class LocalConfigManager { public static LocalConfigManager get(){return new LocalConfigManager();} public boolean isApplying(){return true;} public void flushSaveNow(String s){} }");
        src.put("pulse/module/ModuleAccessService", "package pulse.module; public class ModuleAccessService { public boolean a(String s){return true;} }");
        src.put("pulse/hud/core/HudServiceRegistry", "package pulse.hud.core; public class HudServiceRegistry { public static final pulse.module.ModuleAccessService MODULE_ACCESS=new pulse.module.ModuleAccessService(); }");
        src.put("pulse/hud/notifications/HudNotificationCenter", "package pulse.hud.notifications; public class HudNotificationCenter {public static void a(String s,boolean b){} }");
        src.put("meteordevelopment/orbit/EventBus", "package meteordevelopment.orbit; public class EventBus { public void subscribe(Object o){} public void unsubscribe(Object o){} }");
        src.put("pulse/events/EventBusService", "package pulse.events; public class EventBusService { public static final meteordevelopment.orbit.EventBus EVENT_BUS=new meteordevelopment.orbit.EventBus(); }");
        for (int i=0;i<30;i++) addModule(src,"pulse/n9ezz/u"+i);
        for (FieldNode field : node(zip,"pulse/module/ModuleRegistry").fields) if (field.desc.startsWith("Lpulse/modules/")) addModule(src, field.desc.substring(1,field.desc.length()-1));
        // The real tab constructor uses only these widget contracts. Its filtering/indexing runs unchanged.
        for (String name:List.of("TabHost","GuiEntrySource","ClickGuiTab","GuiEntry")) src.put("pulse/gui/core/"+name,"package pulse.gui.core; public interface "+name+" {}");
        src.put("pulse/gui/core/TabSelector","package pulse.gui.core; public class TabSelector {public TabSelector(TabHost h){} }");
        src.put("pulse/gui/modules/ModuleGrid","package pulse.gui.modules; public class ModuleGrid {public ModuleGrid(pulse.gui.core.GuiEntrySource s){} public void d(){} }");
        src.put("pulse/gui/core/PanelFadeOverlay","package pulse.gui.core; public class PanelFadeOverlay { public PanelFadeOverlay(){} }");
        src.put("pulse/gui/widgets/SearchBox","package pulse.gui.widgets; public class SearchBox { public SearchBox(float width,float height){} public void a(java.util.function.Consumer<String> listener){} }");
        src.put("pulse/gui/widgets/SettingsIconButton","package pulse.gui.widgets; public class SettingsIconButton { public SettingsIconButton(){} public void a(java.util.function.Consumer<Void> listener){} }");
        src.put("net/minecraft/class_2561","package net.minecraft; public interface class_2561 {public static class_5250 method_43470(String s){return new class_5250();} }");
        src.put("net/minecraft/class_5250","package net.minecraft; public class class_5250 implements class_2561 {}");
        src.put("net/minecraft/class_437","package net.minecraft; public class class_437 {}");
        src.put("net/minecraft/class_1657","package net.minecraft; public class class_1657 { public java.util.UUID method_5667(){return java.util.UUID.randomUUID();} }");
        src.put("net/minecraft/class_742","package net.minecraft; public class class_742 extends class_1657 {}");
        src.put("net/minecraft/class_746","package net.minecraft; public class class_746 extends class_742 { public int messages; public void method_7353(class_2561 text,boolean overlay){messages++;} }");
        src.put("net/minecraft/class_638","package net.minecraft; public class class_638 {public java.util.List<class_742> method_18456(){return java.util.List.of();} }");
        src.put("net/minecraft/class_1132","package net.minecraft; public class class_1132 {}");
        src.put("net/minecraft/class_310","package net.minecraft; public class class_310 { public class_746 field_1724; public class_437 field_1755; public void method_1507(class_437 s){field_1755=s;} private static final class_310 ONE=new class_310(); public static class_310 method_1551(){return ONE;} }");
        src.put("pulse/gui/core/PulseClickGuiScreen","package pulse.gui.core; public class PulseClickGuiScreen extends net.minecraft.class_437 {public int clickBtn;public ClickGuiTab a(){return null;} public void a(ClickGuiTabType t){} public static float d(){return 600;} public static float e(){return 400;} }");
        src.put("ru/pulse/Pulse","package ru.pulse; public class Pulse {public static Pulse getInstance(){return new Pulse();} public net.minecraft.class_437 getClickGui(){return null;} }");
        for(String n:List.of("ConsumableUse","CombatInventory"))src.put("pulse/n9ezz/"+n,"package pulse.n9ezz; public class "+n+" {public static void cancel(){} }");
        src.put("pulse/n9ezz/CombatTargets","package pulse.n9ezz; public class CombatTargets {public static void clear(){} }");
        src.put("org/joml/Matrix3x2fStack","package org.joml; public class Matrix3x2fStack {}");
        Path source=temp.resolve("src"),classes=temp.resolve("classes");Files.createDirectories(classes);
        List<String> args=new ArrayList<>(List.of("--release","21","-proc:none","-classpath",updated.toString(),"-d",classes.toString()));
        for(var e:src.entrySet()){Path p=source.resolve(e.getKey()+".java");Files.createDirectories(p.getParent());Files.writeString(p,e.getValue());args.add(p.toString());}
        int code=ToolProvider.getSystemJavaCompiler().run(null,null,null,args.toArray(String[]::new));check(code==0,"compile isolated module dependencies");
        return classes;
    }
    private static void addModule(Map<String,String> src,String path) {
        int slash=path.lastIndexOf('/');String pkg=path.substring(0,slash).replace('/','.');String name=path.substring(slash+1);
        src.put(path,"package "+pkg+"; @pulse.module.ModuleInfo(a=\""+name+"\",b=\"fixture\",c=pulse.module.ModuleCategory.CHEATS) public class "+name+" extends pulse.module.ClientModule { public "+name+"(){super();} public void cancel(){} public pulse.settings.BooleanSetting open=new pulse.settings.BooleanSetting(\"fixture\",\"fixture\",false); }");
    }
}
