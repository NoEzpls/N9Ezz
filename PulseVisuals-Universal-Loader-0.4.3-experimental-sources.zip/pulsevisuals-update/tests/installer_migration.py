#!/usr/bin/env python3
"""Packaged installer migration, profile preservation and idempotence; no game launch."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile

jar = Path(sys.argv[1]).resolve()
checks = 0

def check(ok, why):
    global checks
    checks += 1
    if not ok:
        raise AssertionError(why)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value)

def invoke(home):
    p = subprocess.run(['java', '-jar', str(jar), '--install', '--game-dir', str(home)], capture_output=True, text=True)
    if p.returncode:
        raise AssertionError(p.stdout + p.stderr)
    return json.loads(p.stdout)

with tempfile.TemporaryDirectory(prefix='pulsevisuals-migration-') as temporary:
    home = Path(temporary)
    write(home/'versions/1.21.11/1.21.11.json', json.dumps({'id':'1.21.11','javaVersion':{'majorVersion':21}}))
    with zipfile.ZipFile(home/'versions/1.21.11/1.21.11.jar', 'w') as z:
        z.writestr('FIXTURE.txt', 'Installer metadata test only; no Minecraft binary')
    legacy = {'name':'N9Ezz Universal', 'n9ezzManaged':True, 'lastVersionId':'N9Ezz-Universal-1.21.11',
              'javaArgs':'-Xmx4G', 'javaDir':'C:/Java21/bin/javaw.exe', 'created':'2025-01-01T00:00:00Z',
              'lastUsed':'2026-10-18T00:00:00Z', 'icon':'Grass', 'custom':{'keep':True}}
    write(home/'launcher_profiles.json',json.dumps({'profiles':{'N9Ezz-Universal-1.21.11':legacy},'settings':{'custom':True}}))
    old = home/'n9ezz-universal'
    paths = {'config/n9ezz/power.properties':'mode=hight','pulse/config/pulse.cfg':'profile',
             'pulse.cfg':'root profile','options.txt':'key-key.attack:key.mouse.left',
             'mods/thirdparty.jar':'must not copy','logs/latest.log':'must not copy log'}
    for rel,text in paths.items(): write(old/rel,text)
    fresh = home/'pulsevisuals-universal'
    write(fresh/'options.txt','user current settings')
    report = invoke(home)
    check(report['settingsMigrated']==3,'three missing configuration files copied')
    check(report['profile']=='PulseVisuals-Universal-1.21.11','new version ID')
    profiles_path = home/'launcher_profiles.json'
    root = json.loads(profiles_path.read_text())
    check(root['profiles']['N9Ezz-Universal-1.21.11']==legacy,'old launcher profile unchanged')
    profile = root['profiles'][report['profileKey']]
    check(len(report['profileKey'])==32 and all(c in '0123456789abcdef' for c in report['profileKey']),'stable hexadecimal launcher key')
    for key in ('javaArgs','javaDir','created','lastUsed','icon','custom'):
        check(profile[key]==legacy[key], 'preserve launcher preference '+key)
    check(profile['lastVersionId']==report['profile'] and profile['pulsevisualsManaged'],'new profile points to new version')
    check(profile['gameDir']==str(fresh),'new profile directory')
    check(root['settings']=={'custom':True},'launcher settings untouched')
    check((fresh/'config/pulsevisuals/power.properties').read_text()=='mode=hight','power config renamed')
    check((fresh/'pulsevisuals/config/pulsevisuals.cfg').read_text()=='profile','nested config renamed')
    check((fresh/'pulsevisuals.cfg').read_text()=='root profile','root config renamed')
    check((fresh/'options.txt').read_text()=='user current settings','existing destination wins')
    check(not (fresh/'mods/thirdparty.jar').exists() and not (fresh/'logs/latest.log').exists(),'external mods and logs not migrated')
    for rel,text in paths.items():check((old/rel).read_text()==text,'legacy data preserved '+rel)
    before = profiles_path.read_bytes()
    stamp = profiles_path.stat().st_mtime_ns
    repeat = invoke(home)
    check(repeat['settingsMigrated']==0,'repeat copies nothing')
    check(profiles_path.read_bytes()==before and profiles_path.stat().st_mtime_ns==stamp,'repeat preserves exact launcher bytes and timestamp')
    cache = Path(report['clientPath'])
    check('.pulsevisuals/builtin' in str(cache) and hashlib.sha256(cache.read_bytes()).hexdigest()==report['clientSha256'],'verified client under new cache path')
print(f'InstallerMigration PASS: {checks} checks; packaged installer, no Minecraft launch')
