import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import pulse.n9ezz.BrandPaths;
import com.google.gson.*;

/** Actual configuration migration, conflict and path handling. */
public final class BrandTest {
    static int checks;
    static void check(boolean v,String why){checks++;if(!v)throw new AssertionError(why);}
    static void write(Path p,String text)throws Exception{Files.createDirectories(p.getParent());Files.writeString(p,text);}
    public static void main(String[] args)throws Exception {
        Path temp=Files.createTempDirectory("pulsevisuals-brand-test-");
        try {
            Path old=temp.resolve("old"),fresh=temp.resolve("new");
            write(old.resolve("one.properties"),"original");write(old.resolve("nested/pulse.cfg"),"profile");
            check(BrandPaths.copyMissing(old,fresh)==2,"all config files copied");
            check(Files.readString(fresh.resolve("nested/pulsevisuals.cfg")).equals("profile"),"config filename migrated");
            check(Files.readString(old.resolve("nested/pulse.cfg")).equals("profile"),"old config preserved");
            write(fresh.resolve("one.properties"),"user edited");
            check(BrandPaths.copyMissing(old,fresh)==0,"repeat is no-op");check(Files.readString(fresh.resolve("one.properties")).equals("user edited"),"newer settings win");
            Path bad=temp.resolve("bad"),out=temp.resolve("out");write(bad.resolve("a.cfg"),"must not partially copy");
            Files.createSymbolicLink(bad.resolve("z.cfg"),old.resolve("one.properties"));
            try{BrandPaths.copyMissing(bad,out);throw new AssertionError("symlink accepted");}catch(java.io.IOException expected){check(!Files.exists(out),"nested symlink fails before copying any file");}
            Path game=temp.resolve("game");write(game.resolve("config/n9ezz/power.properties"),"mode=hight");write(game.resolve("pulse/config/pulse.cfg"),"settings");write(game.resolve("pulse.cfg"),"rootsettings");
            BrandPaths.migrateGame(game);
            check(Files.readString(game.resolve("config/pulsevisuals/power.properties")).equals("mode=hight"),"per-game power path migrated");
            check(Files.readString(game.resolve("pulsevisuals/config/pulsevisuals.cfg")).equals("settings"),"per-game profile path migrated");
            check(Files.readString(game.resolve("pulsevisuals.cfg")).equals("rootsettings"),"root profile migrated");
            check(BrandPaths.copyMissing(temp.resolve("absent"),temp.resolve("absent-new"))==0,"missing legacy path is harmless");
            try(ZipFile z=new ZipFile(args[1])){
                JsonObject mod=JsonParser.parseString(new String(z.getInputStream(z.getEntry("fabric.mod.json")).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
                check(mod.get("name").getAsString().equals("PulseVisuals"),"visible mod renamed");check(mod.get("id").getAsString().equals("pulse"),"binary mod ID preserved");
                check(z.getEntry("META-INF/pulsevisuals/build.json")!=null,"new provenance path");
            }
        }finally{try(var walk=Files.walk(temp)){for(Path p:walk.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
        System.out.println("BrandTest PASS: "+checks+" checks; real filesystem migration and client metadata");
    }
}
