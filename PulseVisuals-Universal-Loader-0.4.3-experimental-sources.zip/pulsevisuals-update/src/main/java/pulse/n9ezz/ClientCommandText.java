package pulse.n9ezz;
import java.util.Locale;
/** Exact local commands; ordinary chat and other server commands pass through. */
public final class ClientCommandText {
    private ClientCommandText() {}
    public static int action(String message) {
        if (message == null) return 0;
        String s = message.strip().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        if (!(s.equals("/pv") || s.startsWith("/pv ") || s.equals(".pv") || s.startsWith(".pv "))) return 0;
        return switch(s.substring(3).strip()) { case "hide" -> 1; case "show" -> 2; case "combat" -> 3; default -> 4; };
    }
}
