package pulse.n9ezz;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
/** Copy configuration only. Old files remain intact and existing destinations win. */
public final class BrandPaths {
    private BrandPaths() {}
    private static final Set<Path> migrated = new HashSet<>();
    public static synchronized void migrateGame(Path game) {
        Path root=game.toAbsolutePath().normalize();
        if(migrated.contains(root))return;
        try {
            copyMissing(root.resolve("config/n9ezz"),root.resolve("config/pulsevisuals"));
            copyMissing(root.resolve("pulse/config"),root.resolve("pulsevisuals/config"));
            copyMissing(root.resolve("pulse.cfg"),root.resolve("pulsevisuals.cfg"));
            String appdata=System.getenv("APPDATA");
            if(appdata!=null&&!appdata.isBlank())copyMissing(Path.of(appdata).resolve("pulse/config"),Path.of(appdata).resolve("pulsevisuals/config"));
            migrated.add(root);
        }catch(IOException e){System.err.println("[PulseVisuals] Настройки сохранены на прежнем месте; перенос не завершён: "+e.getMessage());}
    }
    public static int copyMissing(Path source,Path destination)throws IOException {
        source=source.toAbsolutePath().normalize();destination=destination.toAbsolutePath().normalize();
        if(!Files.exists(source,LinkOption.NOFOLLOW_LINKS))return 0;
        safe(source);safe(destination);
        List<Path> files;
        if(Files.isDirectory(source,LinkOption.NOFOLLOW_LINKS)){try(var walk=Files.walk(source)){files=walk.sorted().toList();}}
        else files=List.of(source);
        // Validate the complete plan before writing: a nested symlink cannot cause a
        // partial migration or read outside the requested configuration tree.
        List<Path[]> plan=new ArrayList<>();
        for(Path file:files){safe(file);Path rel=source.equals(file)?Path.of(""):source.relativize(file);
            Path target=destination.resolve(rel).normalize();
            if(target.getFileName()!=null&&target.getFileName().toString().equals("pulse.cfg"))target=target.resolveSibling("pulsevisuals.cfg");
            if(!target.startsWith(destination.getParent()))throw new IOException("Configuration path escapes destination");
            safe(target);
            if(Files.isDirectory(file,LinkOption.NOFOLLOW_LINKS))continue;
            if(!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS)||Files.size(file)>16*1024*1024)throw new IOException("Unsupported configuration file");
            plan.add(new Path[]{file,target});
        }
        int copied=0;
        for(Path[] pair:plan){Path target=pair[1];if(Files.exists(target,LinkOption.NOFOLLOW_LINKS))continue;
            safe(pair[0]);safe(target);Files.createDirectories(target.getParent());
            try{Files.copy(pair[0],target);copied++;}catch(FileAlreadyExistsException concurrent){/* existing settings win */}
        }
        return copied;
    }
    private static void safe(Path path)throws IOException {for(Path p=path;p!=null;p=p.getParent())if(Files.isSymbolicLink(p))throw new IOException("Symbolic configuration paths are not migrated");}
}
